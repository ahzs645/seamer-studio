import {readFile,writeFile} from 'node:fs/promises';
import {stripTypeScriptTypes} from 'node:module';
import {createHash} from 'node:crypto';
import {Vector3,Triangle,Ray} from '/workspace/seamer-studio/node_modules/three/build/three.module.js';
import {buildBodyContactFeatureNormals} from '/workspace/seamer-studio/packages/cloth-sim/src/webgpu/bodyContactFeatures.ts';
const source=await readFile('/workspace/seamer-studio/packages/cloth-sim/src/webgpu/bodySurfaceBroadphase.ts','utf8');
const {buildBodySurfaceBVH}=await import('data:text/javascript;base64,'+Buffer.from(stripTypeScriptTypes(source.replace(/^import .*\n/gm,''),{mode:'transform'})).toString('base64'));
const dot=(a,b)=>a.reduce((s,v,k)=>s+v*b[k],0),V=(values,id,stride=4)=>new Vector3().fromArray(values,id*stride);
export function finiteBodyQuery(mesh){
 const bvh=buildBodySurfaceBVH(mesh),ints=new Uint32Array(bvh.nodes.buffer),features=buildBodyContactFeatureNormals(mesh),triangles=Array.from({length:mesh.numTriangles},(_,face)=>new Triangle(...Array.from(mesh.triangles.slice(face*4,face*4+3)).map(id=>V(mesh.positions,id))));
 function nearest(point,brute=false){let best=Infinity,face=-1,closest=null,visited=0,tested=0;const consider=id=>{tested++;const q=triangles[id].closestPointToPoint(point,new Vector3()),distance=point.distanceToSquared(q);if(distance<best){best=distance;face=id;closest=q;}};
  if(brute)for(let id=0;id<triangles.length;id++)consider(id);else{let node=0;while(node<bvh.nodeCount){visited++;const offset=node*8,escape=ints[offset+3],bound=[0,1,2].reduce((s,k)=>{const q=Math.max(bvh.nodes[offset+k]-point.getComponent(k),point.getComponent(k)-bvh.nodes[offset+4+k],0);return s+q*q;},0);if(bound>best+Math.max(1e-12,2*Math.sqrt(best)*1e-6)){node=escape;continue;}const leaf=ints[offset+7];if(leaf===0xffffffff){node++;continue;}const count=leaf>>>28,first=leaf&0x0fffffff;for(let at=0;at<count;at++)consider(bvh.triangleIds[first+at]);node=escape;}}
  if(face<0)throw Error('Missing finite feature');const triangle=triangles[face],bary=triangle.getBarycoord(closest,new Vector3()).toArray(),eps=1e-5,slot=bary[1]<=eps&&bary[2]<=eps?3:bary[0]<=eps&&bary[2]<=eps?4:bary[0]<=eps&&bary[1]<=eps?5:bary[2]<=eps?0:bary[0]<=eps?1:bary[1]<=eps?2:6,normal=slot<6?V(features,face*6+slot):triangle.getNormal(new Vector3()),offset=point.clone().sub(closest),inside=offset.dot(normal)<0,escape=closest.clone().sub(point).normalize();return{face,closest:closest.toArray(),distanceMm:Math.sqrt(best)*1000,bary,feature:slot<3?'edge':slot<6?'vertex':'face',featureSlot:slot,pseudoNormal:normal.toArray(),uncertain:normal.length()<.5,inside,signedDistanceMm:(inside?-1:1)*Math.sqrt(best)*1000,escape:escape.toArray(),escapeDotOutward:escape.dot(normal),visited,tested};
 }
 function winding(point){let total=0;for(const t of triangles){const a=t.a.clone().sub(point),b=t.b.clone().sub(point),c=t.c.clone().sub(point);total+=2*Math.atan2(a.dot(b.clone().cross(c)),a.length()*b.length()*c.length()+a.dot(b)*c.length()+b.dot(c)*a.length()+c.dot(a)*b.length());}return total/(4*Math.PI);}
 function pathCuts(start,end){const delta=end.clone().sub(start),len=delta.length(),ray=new Ray(start,delta.divideScalar(len)),hits=[];for(let face=0;face<triangles.length;face++){const t=triangles[face],hit=ray.intersectTriangle(t.a,t.b,t.c,false,new Vector3());if(!hit)continue;const parameter=start.distanceTo(hit)/len;if(parameter>1e-8&&parameter<=1+1e-8)hits.push({face,parameter,point:hit.toArray()});}return hits;}
 return{nearest,winding,pathCuts,bvh};
}
