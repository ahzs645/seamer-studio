export const EXACT_SELF_TRANSITION_CACHE_POLICY:'source-self-exact-request-transition-reuse-v1';
export type ExactActivation={revision:number;sewnUpTo:number;activeSeams:Uint32Array};
export class ExactSelfTransitionRequestCache<T> {
 constructor(input:{owner:object;inspect:(first:Float32Array,last:Float32Array,activation:ExactActivation)=>T;particleCount:number;activation:ExactActivation;capacity?:number});
 inspect(owner:object,first:Float32Array,last:Float32Array,activation:ExactActivation):T;
 readonly statistics:Readonly<{policy:typeof EXACT_SELF_TRANSITION_CACHE_POLICY;logicalTransitions:number;executedTransitions:number;reusedTransitions:number;retainedSnapshotBytes:number;peakRetainedSnapshotBytes:number;capacity:number}>;
 close():void;
}
