import type {CollisionGuardInput,CollisionSeamActivation} from './collisionGuard';
export const MOVING_SEAM_PLANE_POLICY:'source-original-used-seam-moving-plane-bernstein-v1';
export interface MovingOriginalSeamOwner {readonly policy:typeof MOVING_SEAM_PLANE_POLICY}
export function createMovingOriginalSeamOwner(input:CollisionGuardInput):MovingOriginalSeamOwner;
export function certifyMovingOriginalSeamPair(input:{owner:MovingOriginalSeamOwner;clothFace:number;otherClothFace:number;firstPositions:Float32Array;lastPositions:Float32Array;activation:CollisionSeamActivation}):{clear:boolean;policy:typeof MOVING_SEAM_PLANE_POLICY;reason?:string};
