/** Per-request exact computational reuse. This changes no mathematical proof.
 * No Node imports, hashing approximations, sampled paths, or cross-request state. */
export const EXACT_SELF_TRANSITION_CACHE_POLICY='source-self-exact-request-transition-reuse-v1';
const wordView=a=>new Uint32Array(a.buffer,a.byteOffset,a.length);
function sameWords(a,b){if(a.length!==b.length)return false;for(let k=0;k<a.length;k++)if(a[k]!==b[k])return false;return true;}
function captureActivation(a){if(!a||!Number.isSafeInteger(a.revision)||a.revision<0||!Number.isSafeInteger(a.sewnUpTo)||a.sewnUpTo<0||!(a.activeSeams instanceof Uint32Array)||a.activeSeams.some(v=>v!==0&&v!==1))throw Error('Exact request USED activation required');return{revision:a.revision,sewnUpTo:a.sewnUpTo,activeSeams:a.activeSeams.slice()};}
const sameActivation=(a,b)=>a.revision===b.revision&&a.sewnUpTo===b.sewnUpTo&&sameWords(a.activeSeams,b.activeSeams);
/** Inspector must be the synchronous method of the same immutable guard owner.
 * Results are defensive copies and both endpoints are privately snapshotted on
 * every miss BEFORE computation. All XYZ/W bits, including signedzero, bind.
 * Changed activation cannot reuse a result. At most two entries survive inside
 * this ONE request; explicit close releases snapshots and permanently seals it. */
export class ExactSelfTransitionRequestCache{
 #owner;#inspect;#count;#capacity;#entries=[];#closed=false;#busy=false;#activation;#logical=0;#executed=0;#hits=0;#peakBytes=0;
 constructor({owner,inspect,particleCount,activation,capacity=2}){
  if((typeof owner!=='object'&&typeof owner!=='function')||owner===null||typeof inspect!=='function'||!Number.isSafeInteger(particleCount)||particleCount<3||!Number.isSafeInteger(capacity)||capacity<1||capacity>2)throw Error('Immutable request owner/count/bounded cache required');
  this.#owner=owner;this.#inspect=inspect;this.#count=particleCount;this.#capacity=capacity;this.#activation=captureActivation(activation);
 }
 inspect(owner,first,last,activation){
  if(this.#closed||this.#busy||owner!==this.#owner)throw Error('Foreign, closed or reentrant exact request cache');
  if(!(first instanceof Float32Array)||!(last instanceof Float32Array)||first.length!==this.#count*4||last.length!==first.length)throw Error('Exact Float32 endpoint snapshots required');
  const active=captureActivation(activation);
  // This request was sealed to one proof-used mask/prefix/revision. Never infer
  // that another activation has equivalent geometry permissions.
  if(!sameActivation(active,this.#activation))throw Error('USED activation changed during request');
  const a=wordView(first),b=wordView(last);this.#logical++;
  for(let index=0;index<this.#entries.length;index++){
   const entry=this.#entries[index];if(sameWords(a,entry.first)&&sameWords(b,entry.last)){
    this.#entries.splice(index,1);this.#entries.unshift(entry);this.#hits++;return structuredClone(entry.report);
   }
  }
  const firstCopy=first.slice(),lastCopy=last.slice(),firstKey=wordView(firstCopy).slice(),lastKey=wordView(lastCopy).slice();this.#busy=true;
  try{
   const report=this.#inspect(firstCopy,lastCopy,active);
   if(report&&typeof report.then==='function')throw Error('Async inspector cannot own a synchronous proof cache');
   if(!sameWords(firstKey,wordView(firstCopy))||!sameWords(lastKey,wordView(lastCopy))||!sameActivation(active,this.#activation))throw Error('Inspector mutated authenticated proof inputs');
   // Returned arrays and caller snapshots cannot mutate a prior certificate.
   const entry={first:firstKey,last:lastKey,report:structuredClone(report)};
   this.#executed++;this.#entries.unshift(entry);this.#entries.length=Math.min(this.#entries.length,this.#capacity);
   this.#peakBytes=Math.max(this.#peakBytes,this.#entries.reduce((n,e)=>n+e.first.byteLength+e.last.byteLength,0));return structuredClone(entry.report);
  }finally{this.#busy=false;}
 }
 get statistics(){return Object.freeze({policy:EXACT_SELF_TRANSITION_CACHE_POLICY,logicalTransitions:this.#logical,executedTransitions:this.#executed,reusedTransitions:this.#hits,retainedSnapshotBytes:this.#entries.reduce((n,e)=>n+e.first.byteLength+e.last.byteLength,0),peakRetainedSnapshotBytes:this.#peakBytes,capacity:this.#capacity});}
 close(){if(this.#busy)throw Error('Cannot release a running exact request cache');this.#entries=[];this.#closed=true;this.#owner=null;this.#inspect=null;}
}
