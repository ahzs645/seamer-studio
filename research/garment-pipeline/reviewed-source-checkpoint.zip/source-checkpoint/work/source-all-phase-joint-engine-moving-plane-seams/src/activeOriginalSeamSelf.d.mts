import type {CollisionGuardInput,CollisionSeamActivation} from './collisionGuard';
export const SELF_INTERVAL_POLICY:'source-self-linear-outward-interval-v1';
export const COINCIDENT_ACTIVE_SEAM_POLICY:'source-original-active-exact-linear-seam-vertex-identification-v1';
export const ACTIVE_SEAM_POINT_CONE_POLICY:'source-active-original-seam-point-affine-gap-exact-dyadic-v1';
export const ACTIVE_SEAM_EDGE_CONE_POLICY:'source-active-original-seam-edge-affine-gap-exact-dyadic-v1';
export const MOVING_SEAM_PLANE_POLICY:'source-original-used-seam-moving-plane-bernstein-v1';
export function validActiveOriginalSeamScope(value:unknown):boolean;
export interface SelfIntervalResult{clear:boolean;policy:typeof SELF_INTERVAL_POLICY;candidateSelfPairs:number;intervalsChecked:number;positiveSelfThicknessCertified:false;firstUnresolvedPair?:{clothFace:number;otherClothFace:number;interval:[number,number];reason:string};coincidentActiveSeam:{policy:typeof COINCIDENT_ACTIVE_SEAM_POLICY;identifiedOriginalPairs:number;geometryChanged:false;forcesOrMobilityChanged:false;activation:{revision:number;sewnUpTo:number;activeSeams:number[]};wholeLinearCoincidenceRequired:true};activeOriginalPointSeam:{pointConeAttempts:number;pointConeProvedFacePairs:number};activeOriginalEdgeSeam:{edgeConeAttempts:number;edgeConeProvedFacePairs:number};activeOriginalMovingSeamPlane:{policy:typeof MOVING_SEAM_PLANE_POLICY;movingSeamPlaneAttempts:number;movingSeamPlaneProvedFacePairs:number;completePairedTubeBoundM:.003;wholeIntervalCertified:true}}
export class SourceActiveOriginalSeamSelfGuard{constructor(input:CollisionGuardInput,options?:{maxDepth?:number;maxIntervals?:number});inspect(first:Float32Array,last:Float32Array,activation:CollisionSeamActivation):SelfIntervalResult}

export const FAST_AFFINE_SELF_ENDPOINT_POLICY:'source-self-affine-endpoint-and-shared-edge-bernstein-ieee-envelope-v1';

export const SHARED_EDGE_DISTINCT_PLANES_POLICY: string;
