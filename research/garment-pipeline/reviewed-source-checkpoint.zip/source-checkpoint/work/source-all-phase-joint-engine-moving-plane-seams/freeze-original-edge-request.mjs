import fs from'node:fs';import{createHash}from'node:crypto';
const root=new URL('.',import.meta.url).pathname.replace(/\/$/,''),sha=b=>createHash('sha256').update(b).digest('hex'),pins={},dependencies={};
for(const[p,h]of[
 ['/workspace/work/source-all-phase-joint-engine-fast-request/review-pins.json','732bfb274653ead85c5cc5fe5f56364de06d6b9891d9d837c9589e562bd40f48'],
 ['/workspace/work/source-self-shared-edge-original-provenance/review-pins.json','8fbe215e257e0bbd1c45ad997577ce4323bfc7d63419a55f959eb4a12a84d76e'],
 ['/workspace/work/source-self-exact-transition-cache/review-pins.json','83fe49400a3b17c5b44fe611349df81dbea9337e86caef95715f402107eadb5d'],
 ['/workspace/work/source-self-genuine-moving-provenance-replay/review-pins.json','54e2d95bf386ddfcc30651793a3bd6c38fba50433277ff2400a05999f3c8a922']]){
 if(sha(fs.readFileSync(p))!==h)throw Error('Held manifest changed '+p);
 for(const[f,v]of Object.entries(JSON.parse(fs.readFileSync(p)).pins))if(sha(fs.readFileSync(f))!==v)throw Error('Held pin changed '+f);
 dependencies[p]=h;
}
for(const[a,b]of[
 ['src/activeOriginalSeamSelf.mjs','/workspace/work/source-self-shared-edge-original-provenance/activeOriginalSeamSelf.mjs'],
 ['src/exactSelfTransitionCache.mjs','/workspace/work/source-self-exact-transition-cache/src/exactSelfTransitionCache.mjs'],
 ['src/exactSelfTransitionCache.d.mts','/workspace/work/source-self-exact-transition-cache/src/exactSelfTransitionCache.d.mts'],
 ['src/collisionGuard.ts','/workspace/work/source-self-exact-transition-cache/src/collisionGuard.ts']])if(!fs.readFileSync(root+'/'+a).equals(fs.readFileSync(b)))throw Error('Reviewed component changed '+a);
const walk=d=>{for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=d+'/'+e.name;if(e.isDirectory())walk(p);else if(/\.(ts|mjs|mts)$/.test(p))pins[p]=sha(fs.readFileSync(p));}};walk(root+'/src');
for(const n of fs.readdirSync(root))if(/\.(mjs|mts)$/.test(n)||['self-interval-hook.test.ts','tsconfig.json','ORIGINAL-EDGE-REQUEST.md','original-edge-node-controls-final.log','original-edge-worker-controls-final.log','original-edge-context-controls.log','original-edge-tsc.log'].includes(n))pins[root+'/'+n]=sha(fs.readFileSync(root+'/'+n));
const read=n=>fs.readFileSync(root+'/'+n,'utf8');if(!read('original-edge-node-controls-final.log').includes('ℹ fail 0')||!read('original-edge-worker-controls-final.log').includes('104 passed')||read('original-edge-tsc.log')!=='')throw Error('Actual controls incomplete');
const m={scope:'NEW root16 cubic/original seam-edge provenance source+Worker preparation; private895 owner handoff still pending',pins,dependencies,reviewedMathematicsByteExact:true,reviewedTypedCacheCallsiteByteExact:true,NodeCPUControls:140,actualWorkerGuardCPUControls:104,additionalWorkerContextControls:2,strictTypeScriptPassed:true,nativeOFFContextUnchanged:true,defaultProofDeadlineMs:60000,final895NumericalOwnerIntegrated:false,approvedWholePressureArtifactIntegrated:false,GPUInitialized:false,fullJoint40Executed:false,fitAccepted:false,liveSourcesModified:false};fs.writeFileSync(root+'/review-pins.json',JSON.stringify(m,null,2)+'\n');console.log(JSON.stringify({sha256:sha(fs.readFileSync(root+'/review-pins.json')),pins:Object.keys(pins).length}));
