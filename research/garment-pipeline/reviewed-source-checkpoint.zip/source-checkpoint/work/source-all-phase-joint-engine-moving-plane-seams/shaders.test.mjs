import{deltaByteFixture}from'./delta-byte-fixtures.mjs';
import{workerByteFixture}from'./worker-byte-fixtures.mjs';
import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {withSourceDelta}from'./sourceShaderFactories.mjs';
const root=new URL('.',import.meta.url).pathname.replace(/\/$/,'');
fs.mkdirSync(root+'/test-compiled',{recursive:true});
for(const f of ['shaders','finiteContacts','seamGate'])fs.writeFileSync(root+'/test-compiled/'+f+'.ts',fs.readFileSync(root+'/src/webgpu/'+f+'.ts','utf8').replaceAll("from './finiteContacts'","from './finiteContacts.ts'").replaceAll("from './seamGate'","from './seamGate.ts'"));
const factories=await import('./test-compiled/shaders.ts');
const support=await import('./src/supportShader.ts');
const cfg={gravity:[0,-9.81,0],deltaT:.0004,maxVelocity:1,minVelocity:.0001,simulationThickness:.001,globalDamping:.01};
const rows=[['prediction',factories.integrateWGSL(cfg)],['distance',factories.distanceConstraintWGSL(cfg)],['bending',factories.bendingConstraintWGSL(cfg)],['support',support.assemblySupportWGSL()],['apply',factories.applyCorrectionsWGSL()],['velocity',factories.velocityWGSL(cfg)]];
for(const [kind,baseline]of rows){
 test(kind+' default-off factory is byte exact and source storage stays portable',()=>{
  assert.equal(withSourceDelta(kind,baseline,false),baseline);const s=withSourceDelta(kind,baseline,true);assert.ok(s.includes('sourceDelta'));assert.ok([...s.matchAll(/var<storage,/g)].length<=8);
 });
}
test('source velocity consumes algebraic ledger, not rounded coordinate subtraction',()=>{
 const s=withSourceDelta('velocity',factories.velocityWGSL(cfg),true);assert.match(s,/sourceDelta\[index\]\.xyz \/ deltaT/);assert.doesNotMatch(s,/positions\[index\]\.xyz - lastPositions\[index\]\.xyz/);assert.ok(s.indexOf('thickness-positions[index].y')<s.indexOf('positions[index].y = thickness;'));
});
test('correction-count division occurs before ledger/world add; no double accumulation by reset',()=>{
 const s=withSourceDelta('apply',factories.applyCorrectionsWGSL(),true);assert.ok(s.indexOf('let d = correction.xyz / correction.w')<s.indexOf('sourceRecordDelta(index,d)' ));assert.ok(s.indexOf('sourceRecordDelta(index,d)' )<s.indexOf('positions[index] = vec4f(positions[index].xyz + d'));
});
test('factory drift fails closed instead of guessing an unrecorded writer',()=>assert.throws(()=>withSourceDelta('support','@compute fn main(){}',true)));
test('copied engine supplies ledger to source material and all direct writers; rollback covers ledger',()=>{
 const e=fs.readFileSync(root+'/src/webgpu/engine.ts','utf8');assert.match(e,/resetOwner:'engine'/);for(const k of ['prediction','distance','bending','support','apply','velocity'])assert.ok(e.includes("sourcePhaseShader('"+k+"'"));assert.match(e,/copyBufferToBuffer\(this.sourceDelta,0,state/);assert.match(e,/copyBufferToBuffer\(state,at,this.sourceDelta/);assert.match(e,/sourceDelta\?\.destroy/);
});
