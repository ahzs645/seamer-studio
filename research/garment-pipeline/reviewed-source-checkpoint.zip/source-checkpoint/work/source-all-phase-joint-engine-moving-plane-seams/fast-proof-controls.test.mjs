import test from'node:test';import assert from'node:assert/strict';
import{certifyMovingSelfTriangles as fast}from'./src/activeOriginalSeamSelf.mjs';
import{certifyMovingSelfTriangles as original}from'../source-active-seam-edge-cones/selfIntervalClearance.mjs';
const tri=[[0,0,0],[1,0,0],[0,1,0]],shift=(t,d)=>t.map(p=>p.map((x,k)=>x+d[k]));
const run=(proof,a,al,b,bl,ids=[0,1,2],targetIds=[3,4,5])=>proof({first:a,last:al,targetFirst:b,targetLast:bl,ids,targetIds,maxDepth:8});
test('affine endpoint certificate proves translating disjoint support without sampling',()=>{
 const a=tri,al=shift(a,[0,0,2]),b=shift(a,[0,0,1]),bl=shift(b,[0,0,2]);const r=run(fast,a,al,b,bl);assert.equal(r.clear,true);assert.ok(r.fastSelfSeparationPolicy);assert.ok(run(original,a,al,b,bl).intervalsChecked>1);
});
test('shared corner exact trajectory with safely divergent cones uses conservative endpoint signs',()=>{
 const a=tri,b=[[0,0,0],[-1,0,0],[0,-1,0]],d=[.2,.1,.5];const r=run(fast,a,shift(a,d),b,shift(b,d),[0,1,2],[0,3,4]);assert.equal(r.clear,true);assert.ok(r.fastSelfSeparationPolicy);
});
test('near-zero certified gap falls back and real sign reversal still rejects',()=>{
 const a=shift(tri,[30,30,30]),b=shift(a,[0,0,2**-40]);const r=run(fast,a,a,b,b);assert.equal(r.clear,true);assert.equal(r.fastSelfSeparationPolicy,undefined);
 assert.equal(run(fast,tri,tri,shift(tri,[0,0,1]),shift(tri,[0,0,-1])).clear,false);
});
test('subnormal endpoint arithmetic remains in the original fallback',()=>{
 const a=tri.map(p=>p.map(x=>x*2**-1000)),b=shift(a,[0,0,2**-1000]);const r=run(fast,a,a,b,b);assert.equal(r.clear,true);assert.equal(r.fastSelfSeparationPolicy,undefined);
});
test('deterministic dyadic motion families never clear an interior collision',()=>{
 let state=1234567;const rand=()=>{state=(Math.imul(state,1664525)+1013904223)>>>0;return (state%129-64)/32;};
 for(let j=0;j<360;j++){
 const az0=rand(),az1=rand(),bz0=rand(),bz1=rand(),a=shift(tri,[0,0,az0]),al=shift(tri,[0,0,az1]),b=shift(tri,[0,0,bz0]),bl=shift(tri,[0,0,bz1]);
 const gap0=az0-bz0,gap1=az1-bz1,r=run(fast,a,al,b,bl);if(gap0===0||gap1===0||gap0*gap1<0)assert.equal(r.clear,false);else assert.equal(r.clear,true);
 }
});
test('shared moving edge Bernstein bound rejects overlap between valid endpoints',()=>{
 const a=[[0,0,0],[1,0,0],[0,1,1]],al=[[0,0,0],[1,0,0],[0,1,-1]],b=[[0,0,0],[1,0,0],[0,1,-1]],bl=[[0,0,0],[1,0,0],[0,1,1]];
 assert.equal(run(fast,a,a,b,b,[0,1,2],[0,1,3]).clear,true);assert.equal(run(fast,al,al,bl,bl,[0,1,2],[0,1,3]).clear,true);
 assert.equal(run(fast,a,al,b,bl,[0,1,2],[0,1,3]).clear,false);
});
test('shared edge collapse has no guessed strict sign and stays unresolved',()=>{
 const a=tri,al=[[0,0,0],[-1,0,0],[0,1,0]],b=[[0,0,0],[1,0,0],[0,-1,0]],bl=[[0,0,0],[-1,0,0],[0,-1,0]];
 assert.equal(run(fast,a,al,b,bl,[0,1,2],[0,1,3]).clear,false);
});
