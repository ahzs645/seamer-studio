import {defineConfig} from 'vitest/config';export default defineConfig({test:{environment:'node',include:['moving-plane-worker.test.ts'],testTimeout:60000}});
