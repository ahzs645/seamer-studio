import{deltaByteFixture}from'./delta-byte-fixtures.mjs';
import{workerByteFixture}from'./worker-byte-fixtures.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createRequire} from 'node:module';
const ts=createRequire('/workspace/seamer-studio/package.json')('typescript');
const root=new URL('.',import.meta.url).pathname.replace(/\/$/,'');
const compile=file=>ts.transpileModule(fs.readFileSync(`${root}/${file}`,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText.replace(/^import[\s\S]*?from\s+['"][^'"]+['"];\s*/gm,'').replaceAll('export ','');
const immutableSourcePhaseConfig=new Function(compile('src/sourcePhaseConfig.ts')+'\nreturn immutableSourcePhaseConfig;')();
const caller=()=>({gravity:[0,-9.81,0],subSteps:40,seamIterations:8,deltaT:.0004,timeStep:.016,maxVelocity:1,handleSelfCollisions:false,handleExternalCollisions:false,internalHashTableMultiplier:1,externalHashTableMultiplier:1});
test('source executed clone freezes all scheduling and nested gravity without freezing caller; native remains identical',()=>{
 const input=caller(),actual=immutableSourcePhaseConfig(input,true);assert.notEqual(actual,input);assert(Object.isFrozen(actual));assert(Object.isFrozen(actual.gravity));input.subSteps=1;input.seamIterations=64;input.gravity[1]=99;assert.equal(actual.subSteps,40);assert.equal(actual.seamIterations,8);assert.equal(actual.gravity[1],-9.81);assert.throws(()=>actual.seamIterations=64,TypeError);assert.throws(()=>actual.gravity[1]=99,TypeError);assert.equal(immutableSourcePhaseConfig(input,false),input);assert(!Object.isFrozen(input));
});
test('actual engine constructor stores immutable executed source config before GPU allocations; native stores original',()=>{
 const deps={immutableSourcePhaseConfig,sealSourceMaterialSimulation:x=>x,resolveSewingMotionPolicy:()=>null,buildSeamGateLayout:()=>({}),physicalSeamStitchIndices:()=>[]};
 const Engine=new Function(...Object.keys(deps),compile('src/webgpu/engine.ts')+'\nreturn ClothEngine;')(...Object.values(deps));
 let captured;Engine.prototype.measureBodyTriangleRadius=()=>0;Engine.prototype.createBuffers=function(){captured=this.config;throw Error('pre-allocation stop');};
 for(const source of [true,false]){const input=caller(),sim={sourcePhysicalMembrane:source?{}:null,positions:Float32Array.of(0,1,0,1),anchors:new Float32Array(4),particleCount:1,triangleCount:0,maxIncidentTrianglesPerParticle:0,stitchCount:0,seamPairsBySeam:[],seams:new Int32Array(4),seamOrder:new Int32Array(4)};
 assert.throws(()=>new Engine({},sim,{numTriangles:0},input,{strictSurfaceHistory:source}),/pre-allocation stop/);if(source){assert.notEqual(captured,input);input.subSteps=1;input.gravity[1]=88;assert.equal(captured.subSteps,40);assert.equal(captured.gravity[1],-9.81);assert.throws(()=>captured.seamIterations=1,TypeError);}else assert.equal(captured,input);}
});
test('actual wrapper public source config cannot mutate execution while constructor caller remains editable',()=>{
 const input=caller(),deps={immutableSourcePhaseConfig,sealSourceMaterialSimulation:x=>x,applySourceContactPolicy:()=>({config:input,contactPolicy:{preservedExplicitPadding:[]}}),SIM_CONFIG:input};
 const Simulation=new Function(...Object.keys(deps),compile('src/simulator.ts')+'\nreturn ClothSimulation;')(...Object.values(deps));
 let actual,instance;Simulation.prototype.createGuard=function(){instance=this;actual=this.simulationConfig;throw Error('guard construction stop');};
 assert.throws(()=>new Simulation({}, {collisionSafety:true,body:{},simData:{sourcePhysicalMembrane:{},positions:Float32Array.of(0,1,0,1)}}),/guard construction stop/);
 assert(Object.isFrozen(actual));assert(Object.isFrozen(actual.gravity));assert.throws(()=>instance.simulationConfig=caller(),TypeError);assert.throws(()=>Object.defineProperty(instance,'simulationConfig',{value:caller()}),TypeError);assert.throws(()=>actual.subSteps=1,TypeError);assert.throws(()=>actual.gravity[0]=9,TypeError);input.subSteps=1;assert.equal(actual.subSteps,40);
});
