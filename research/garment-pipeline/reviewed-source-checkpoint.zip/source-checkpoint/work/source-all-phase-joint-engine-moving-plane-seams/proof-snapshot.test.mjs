import{bodyFacetFixture,selfIntervalFixture}from'./receipt-fixtures.mjs';
import{deltaByteFixture}from'./delta-byte-fixtures.mjs';
import{workerByteFixture}from'./worker-byte-fixtures.mjs';
import{frame,physicalReceipts,acceptedPressure,bridgeReceipt,h}from'./receipt-fixtures.mjs';
/** Actual async owner methods. Synthetic buffers/receipts, no device proof. */
import test from'node:test';import assert from'node:assert/strict';import fs from'node:fs';import{createRequire}from'node:module';import{SourceJointWholeEngineBackend,actualGuardProofSha256}from'./SourceJointWholeEngineBackend.mjs';
const root=new URL('.',import.meta.url).pathname.replace(/\/$/,''),ts=createRequire('/workspace/seamer-studio/package.json')('typescript');
const code=ts.transpileModule(fs.readFileSync(root+'/src/webgpu/sourceJointEngineBridge.ts','utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText.replace(/^import[\s\S]*?from\s+['"][^'"]+['"];\s*/gm,'').replaceAll('export ','');
const Bridge=new Function(code+'\nreturn SourceJointEngineBridge;')();
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return{promise,resolve};};
function fixture(kind){const used={revision:3,sewnUpTo:5,activeSeams:Uint32Array.of(1)},b=Object.create(kind==='bridge'?Bridge.prototype:SourceJointWholeEngineBackend.prototype);Object.assign(b,{activeOperations:new Set(),creation:{isCurrent:()=>true,simulation:{particleCount:1,sourcePhysicalMembrane:{policySha256:h}}},destroyed:false,closed:false,invalidated:false,awaitingProof:true,physicalSubstep:40,usedActivation:used,generation:2,frameSequence:1,implementationSha256:h,frame:frame(),receipts:physicalReceipts()});return b;}
const proof=()=>({safe:true,finite:true,sourceBodyFacetTrajectory:bodyFacetFixture(),sourceSelfIntervalTrajectory:selfIntervalFixture(),verifiedWorkerRequest:workerByteFixture(),verifiedPhysicalDeltaTrace:deltaByteFixture(),trajectory:{valid:true,expectedSubSteps:40,inspectedSubsteps:40},seamActivation:{revision:3,sewnUpTo:5,activeSeams:Uint32Array.of(1)},detail:{originalWorkerCount:40}});
test('bridge snapshots full proof synchronously before queued acceptance and delayed backend await',async()=>{
 const b=fixture('bridge'),started=deferred(),done=deferred();let observed;
 b.backend={acceptedFrameCommitReceipt:bridgeReceipt(),async acceptFrame(p){observed=p;started.resolve();await done.promise;}};
 const publicProof=proof(),original=structuredClone(publicProof),accepted=b.acceptFrame(publicProof);
 publicProof.safe=false;publicProof.seamActivation.activeSeams[0]=0;publicProof.detail.originalWorkerCount=999;
 await started.promise;assert.deepEqual(observed,original);assert.notEqual(observed,publicProof);publicProof.finite=false;publicProof.trajectory.inspectedSubsteps=0;done.resolve();await accepted;assert.equal(b.awaitingProof,false);assert.deepEqual(observed,original);
});
test('whole backend hashes entry snapshot and pressure history sees unchanged proof during async acceptance',async()=>{
 const b=fixture('backend'),started=deferred(),done=deferred();let hash;
 b.reaction={implementationSha256:h,async acceptFrame(h){hash=h;started.resolve();await done.promise;return acceptedPressure(h);}};
 const publicProof=proof(),original=structuredClone(publicProof),expected=await actualGuardProofSha256(original),accepted=b.acceptFrame(publicProof);
 publicProof.safe=false;publicProof.seamActivation.revision=999;publicProof.seamActivation.activeSeams[0]=0;publicProof.detail.originalWorkerCount=0;
 await started.promise;assert.equal(hash,expected);assert.notEqual(hash,await actualGuardProofSha256(publicProof));publicProof.trajectory.inspectedSubsteps=39;done.resolve();await accepted;assert.equal(b.frame,null);
});
