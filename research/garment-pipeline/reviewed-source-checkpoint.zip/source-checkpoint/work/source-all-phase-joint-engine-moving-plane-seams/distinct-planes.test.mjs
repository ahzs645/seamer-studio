import test from'node:test';import assert from'node:assert/strict';import{certifyMovingSelfTriangles as proof}from'./src/activeOriginalSeamSelf.mjs';import{certifyMovingSelfTriangles as previous}from'../source-self-fast-affine-endpoints/selfIntervalClearance.mjs';
const run=(p,a,al,b,bl,opts={})=>p({first:a,last:al,targetFirst:b,targetLast:bl,ids:[0,1,2],targetIds:[0,1,3],maxDepth:8,...opts});
test('distinct adjacent planes permit unequal-length acute folds that the previous axis cannot prove',()=>{
 const a=[[0,0,0],[1,0,0],[0,1,0]],b=[[0,0,0],[1,0,0],[0,2,1]];assert.equal(run(previous,a,a,b,b).clear,false);const r=run(proof,a,a,b,b);assert.equal(r.clear,true);assert.ok(r.sharedEdgeDistinctPlanesPolicy);
});
test('moving cubic coefficient signs certify whole supports on distinct planes',()=>{
 const a=[[0,0,0],[1,0,0],[0,1,0]],al=[[.125,0,0],[1,.125,.125],[.125,1,.25]],b=[[0,0,0],[1,0,0],[0,2,1]],bl=[[.125,0,0],[1,.125,.125],[.125,2,1.125]];assert.equal(run(proof,a,al,b,bl).clear,true);
});
test('crossing to remote shared-edge overlap between valid endpoints rejects',()=>{
 const a=[[0,0,0],[1,0,0],[0,1,1]],al=[[0,0,0],[1,0,0],[0,1,-1]],b=[[0,0,0],[1,0,0],[0,1,-1]],bl=[[0,0,0],[1,0,0],[0,1,1]];assert.equal(run(proof,a,al,b,bl).clear,false);
});
test('coplanar overlap and edge collapse cannot be declared distinct',()=>{
 const a=[[0,0,0],[1,0,0],[0,1,0]],b=[[0,0,0],[1,0,0],[0,2,0]];assert.equal(run(proof,a,a,b,b).clear,false);
 const al=[[0,0,0],[-1,0,0],[0,1,0]],bl=[[0,0,0],[-1,0,0],[0,-1,0]],opp=[[0,0,0],[1,0,0],[0,-1,0]];assert.equal(run(proof,a,al,opp,bl).clear,false);
});
test('coplanar opposite-side adjacency retains previous safe fallback',()=>{
 const a=[[0,0,0],[1,0,0],[0,1,0]],b=[[0,0,0],[1,0,0],[0,-1,0]],r=run(proof,a,a,b,b);assert.equal(r.clear,true);assert.equal(r.sharedEdgeDistinctPlanesPolicy,undefined);
});
test('shared IDs still require exact endpoints before any distinct-plane early path',()=>{
 const a=[[0,0,0],[1,0,0],[0,1,0]],b=[[0,0,0],[1,0,0],[0,2,1]],wrong=b.map(p=>p.slice());wrong[0][0]=.001;assert.throws(()=>run(proof,a,a,wrong,b),/inconsistent/);
});
