import test from 'node:test';import assert from 'node:assert/strict';
import {SourceActiveOriginalSeamSelfGuard as Guard} from './src/activeOriginalSeamSelf.mjs';
const q=Float32Array.from([[0,0,0],[1,0,0],[0,1,0],[0,0,0],[1,0,0],[0,0,1]].flatMap(p=>[...p,1]));
const group=(seamId,index,pairs,stitchIndices)=>({seamId,index,pairs,stitchIndices,stitchIndexKinds:stitchIndices.map(()=> 'reciprocal-first-stamp')});
const input=groups=>({particleCount:6,clothTriangles:Uint32Array.of(0,1,2,0,3,4,5,0),stitchCount:2,seamPairsBySeam:groups});
const used=n=>({revision:0,sewnUpTo:2,activeSeams:new Uint32Array(n).fill(1)});
test('two unrelated exact point joins do not authorize shared alias edge',()=>{
 const r=new Guard(input([group('a',0,[0,3],[0]),group('b',1,[1,4],[1])])).inspect(q,q,used(2));
 assert.equal(r.clear,false);assert.equal(r.activeOriginalEdgeSeam.edgeConeAttempts,0);
});
test('actual adjacent same-group sewn segment permits exact folded seam edge',()=>{
 const r=new Guard(input([group('a',0,[0,3,1,4],[0,1])])).inspect(q,q,used(1));assert.equal(r.clear,true);
});
test('actual indexed edge remains authorized with unrelated point groups present',()=>{
 const i=input([group('a',0,[0,3],[0]),group('b',1,[1,4],[1])]);i.clothTriangles=Uint32Array.of(0,1,2,0,0,1,5,0);
 assert.equal(new Guard(i).inspect(q,q,used(2)).clear,true);
});
