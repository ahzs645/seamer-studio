import test from'node:test';import assert from'node:assert/strict';import fs from'node:fs';import{createHash}from'node:crypto';
import{bodyFaceFeatureLanesWGSL as rewrite,bodyFaceFeatureDispatchGroups as groups,bodyFaceFeatureAddress as address}from'./bodyFaceFeatureLanes.mjs';
const original=fs.readFileSync('/workspace/work/source-joint-refined-allraw-stage-fenced/full-finite.wgsl','utf8');
test('all original fifteen finite features occur exactly once per authentic source face',()=>{
 const count=6712,seen=new Set();for(let id=0;id<groups(count,65535)*64;id++){const r=address(id,count);if(!r)continue;const key=r.face+':'+r.feature;assert.equal(seen.has(key),false);seen.add(key);}
 assert.equal(seen.size,count*15);for(let feature=0;feature<15;feature++){const r=address(feature,1);assert.equal(r.face,0);assert.equal(r.feature,feature);}
 assert.deepEqual(address(14,1),{face:0,kind:'body-edge-cloth-face-crossing',bodyEdge:2,feature:14});
});
test('actual full shader rewrite changes only three visitor functions and dispatch policy',()=>{
 assert.equal(createHash('sha256').update(original).digest('hex'),'26ea1ed0082964cda75d3bf80dc1aaf9929a4c3f9e29cdbd983ffead17f080d1');
 const changed=rewrite(original);assert.ok(changed.includes('let face=gid.x/15u;let feature=gid.x%15u;'));assert.ok(changed.includes('let edge=feature-12u;'));
 const erase=code=>{for(const name of['jointVisitBodyPair','jointBVHBodyVisit','joint_bvh_body_faces']){const at=code.indexOf('fn '+name+'('),open=code.indexOf('{',at);let d=1,end=open+1;for(;d;end++){if(code[end]==='{')d++;else if(code[end]==='}')d--;}code=code.slice(0,at)+'ERASED:'+name+code.slice(end);}return code.split('\n// BODY_FACE_FEATURE_LANES:')[0];};
 assert.equal(erase(changed),erase(original));
});
test('malformed factory hooks, duplicate application and excess device work reject',()=>{
 assert.throws(()=>rewrite(rewrite(original)),/Original/);assert.throws(()=>rewrite(original.replace('jointVisitBodyPair(face,other);','missing();')));
 assert.throws(()=>groups(6712,100));assert.throws(()=>groups(Math.floor(0xffffffff/15)+1,65535));assert.equal(groups(0,65535),0);assert.equal(groups(6712,65535),1574);
});
