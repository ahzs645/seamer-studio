NEW body-face finite-feature dispatch proposal. CPU/source only, no GPU execution.

The unchanged801 stage diagnostic completed19 stages but body_faces hit its60s
fence bound. Its queue later drained and37/37 buffers/device/lost/instance closed.
CPU initial body-face candidate leaves are zero; compiler expansion is a
hypothesis, not established. This proposal evaluates each source/body pair's
original15 finite features in separate invocation lanes:3 body-corner/cloth-face
proximities,9 edge pairs,3 body-edge/cloth-face crossings. All bodyNearRow,
bodyFeature, closest-point, finite-triangle crossing, history/recovery/uncertainty,
horizon, physical1mm, raw capacity and unknown checks retain their exact source.

For each cloth face, invocation=face*15+feature. Dispatch groups are
ceil(originalClothFaces*15/64), with explicit actual device/u32 limit rejection.
The original BVH visitor still visits every candidate pair separately for every
feature. The near-family retains its original finiteTrianglesCross exclusion.
The crossing-family replaces loop continue with return only for its own lane.
One append's global raw ordinal order may change; every original feature and
functional must remain in the complete inventory. All overflow/unknown failures
remain failures; a partial row prefix never becomes complete evidence.

Three CPU controls verify every100,680 actual initial feature address once,
full WGSL byte identity outside precisely three changed functions, and malformed
factory/device bounds. No numerical whole-body equivalence, compile, optimized
GPU timing, pressure, source frame or fit is claimed. The helper must be applied
to the actual factory output together with the matching actual exporter dispatch
in a NEW frozen diagnostic/private module graph. Original801 and719 stay intact.
Actual broadphase/body witness cases and complete ALLraw device evidence are
required before integration. Browser helper is pure MJS without Node dependencies.
