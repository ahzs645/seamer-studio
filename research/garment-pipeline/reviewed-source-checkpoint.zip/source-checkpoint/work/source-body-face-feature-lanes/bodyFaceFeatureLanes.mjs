export const BODY_FACE_FEATURE_LANES=15;
export const BODY_FACE_FEATURE_POLICY='complete-body-finite-fifteen-feature-lanes-v1';
function changeFunction(code,name,make){
 const marker='fn '+name+'(',at=code.indexOf(marker);if(at<0||code.indexOf(marker,at+1)>=0)throw Error('Ambiguous body finite hook '+name);
 const open=code.indexOf('{',at);let end=open+1,depth=1;for(;end<code.length&&depth;end++){if(code[end]==='{')depth++;else if(code[end]==='}')depth--;}
 if(depth)throw Error('Unbalanced body finite hook');return code.slice(0,at)+make(code.slice(at,end))+code.slice(end);
}
/** Changes dispatch ownership only. Each original corner/edge finite query is
 * still evaluated with identical operands and bodyNearRow/history/pseudonormal.
 * No body query, horizon, clearance, budget or capacity is removed or widened. */
export function bodyFaceFeatureLanesWGSL(code){
 if(typeof code!=='string'||code.includes('BODY_FACE_FEATURE_LANES'))throw Error('Original full finite source required');
 let out=changeFunction(code,'jointVisitBodyPair',original=>{
  const prefix='fn jointVisitBodyPair(face:u32,other:u32){',near='if(!finiteTrianglesCross(a[0],a[1],a[2],b[0],b[1],b[2])){for(var corner=0u;corner<3u;corner++){bodyNearRow(face,other,a,b,old,array<vec3f,2>(getClosestPointOnTriangle(a[0],a[1],a[2],b[corner]),b[corner]),corner);for(var edge=0u;edge<3u;edge++){bodyNearRow(face,other,a,b,old,closestSegmentPair(a[corner],a[(corner+1u)%3u],b[edge],b[(edge+1u)%3u]),3u+corner*3u+edge);}}}',edge='for(var edge=0u;edge<3u;edge++){';
  if(!original.startsWith(prefix)||!original.includes(near)||!original.includes(near+edge)||!original.endsWith('}}'))throw Error('Unexpected original complete body visitor');
  const n=original.indexOf(near),e=n+near.length;
  const crossing=original.slice(e+edge.length,-2);
  // A single selected crossing uses early return in place of loop continue.
  const single=crossing.replaceAll('continue;','return;');
  return original.slice(0,n).replace(prefix,'fn jointVisitBodyPair(face:u32,other:u32,feature:u32){')+`
 if(feature<12u){
  if(finiteTrianglesCross(a[0],a[1],a[2],b[0],b[1],b[2])){return;}
  var closest:array<vec3f,2>;
  if(feature<3u){closest=array<vec3f,2>(getClosestPointOnTriangle(a[0],a[1],a[2],b[feature]),b[feature]);}
  else{let corner=(feature-3u)/3u;let edge=(feature-3u)%3u;closest=closestSegmentPair(a[corner],a[(corner+1u)%3u],b[edge],b[(edge+1u)%3u]);}
  bodyNearRow(face,other,a,b,old,closest,feature);return;
 }
 if(feature>=15u){atomicOr(&state[0],16u);return;}let edge=feature-12u;
 ${single}
}`;
 });
 out=changeFunction(out,'jointBVHBodyVisit',original=>{
  if(!original.startsWith('fn jointBVHBodyVisit(face:u32,lo:vec3f,hi:vec3f)')||original.split('jointVisitBodyPair(face,other);').length!==2)throw Error('Unexpected exact body BVH visitor');
  return original.replace('fn jointBVHBodyVisit(face:u32,lo:vec3f,hi:vec3f)','fn jointBVHBodyVisit(face:u32,lo:vec3f,hi:vec3f,feature:u32)').replace('jointVisitBodyPair(face,other);','jointVisitBodyPair(face,other,feature);');
 });
 out=changeFunction(out,'joint_bvh_body_faces',original=>{
  const marker='let face=gid.x;if(face>=cfg.clothFaces){return;}',call='jointBVHBodyVisit(face,lo-padding,hi+padding);';
  if(original.split(marker).length!==2||original.split(call).length!==2)throw Error('Unexpected actual body-face entry');
  return original.replace(marker,'let face=gid.x/15u;let feature=gid.x%15u;if(face>=cfg.clothFaces){return;}').replace(call,'jointBVHBodyVisit(face,lo-padding,hi+padding,feature);');
 });
 return out+'\n// BODY_FACE_FEATURE_LANES:15; dispatch ceil(originalClothFaces*15/64).\n';
}
export function bodyFaceFeatureDispatchGroups(clothFaces,maximumGroups){
 if(!Number.isSafeInteger(clothFaces)||clothFaces<0||clothFaces>Math.floor(0xffffffff/15)||!Number.isSafeInteger(maximumGroups)||maximumGroups<1)throw Error('Invalid actual body-feature dispatch bounds');
 const groups=Math.ceil(clothFaces*15/64);if(groups>maximumGroups)throw Error('Actual body-feature dispatch exceeds device limit');return groups;
}
export function bodyFaceFeatureAddress(invocation,clothFaces){
 if(!Number.isSafeInteger(invocation)||invocation<0||!Number.isSafeInteger(clothFaces)||clothFaces<0)throw Error('Invalid body-feature invocation');
 const face=Math.floor(invocation/15),feature=invocation%15;if(face>=clothFaces)return null;
 if(feature<3)return{face,kind:'body-corner-cloth-face',corner:feature,feature};
 if(feature<12)return{face,kind:'edge-edge',clothEdge:Math.floor((feature-3)/3),bodyEdge:(feature-3)%3,feature};
 return{face,kind:'body-edge-cloth-face-crossing',bodyEdge:feature-12,feature};
}
