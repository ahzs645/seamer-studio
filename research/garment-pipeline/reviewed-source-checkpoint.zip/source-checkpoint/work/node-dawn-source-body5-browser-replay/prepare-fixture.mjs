import {rebindBodyAnatomicalReferences} from './body-anatomy-rebind.mjs';
import {validateBrowserBodyProof} from './browser-body-proof.mjs';
import {assertBodyReplayContract,EXPECTED_SOURCE_FIT_REVISION} from './body-replay-contract.mjs';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { prepareCloth, SIM_CONFIG, applySourceContactPolicy, SourceStagingController, physicalSeamStitchIndices } from './compiled/production.js';
import {finalizePreparedRefinement,sourceRefinementSnapshot} from '/workspace/seamer-studio/scripts/garmentcode/qa/refined-runtime-provenance.mjs';
import {approvedGatherScopeForFixture} from './approved-gather-fixture.mjs';
export const sha256=data=>createHash('sha256').update(data).digest('hex');
const typedHash=values=>sha256(new Uint8Array(values.buffer,values.byteOffset,values.byteLength));
function exactArray(actual,expected,label){
 if(actual.length!==expected.length)throw new Error(`${label} length mismatch: ${actual.length} != ${expected.length}`);
 for(let i=0;i<actual.length;i++)if(!Object.is(actual[i],expected[i]))throw new Error(`${label} mismatch at${i}: ${actual[i]} != ${expected[i]}`);
 return {length:actual.length,sha256:typedHash(actual),exact:true};
}
export function canonicalJSON(value){
 if(Array.isArray(value))return '['+value.map(canonicalJSON).join(',')+']';
 if(value&&typeof value==='object')return '{'+Object.keys(value).sort().map(key=>JSON.stringify(key)+':'+canonicalJSON(value[key])).join(',')+'}';
 return JSON.stringify(value);
}
export async function prepareFrozenFixture(path,{approveGatherProvenance=false}={}){
 const bytes=readFileSync(path),frozen=JSON.parse(bytes),pattern=structuredClone(frozen.pattern);
 const bodyBuild=JSON.parse(readFileSync(new URL('./build-provenance.json',import.meta.url)));
 const bodyBytes=readFileSync(frozen.bodyReplayContract?.bodyDescriptor??'');
 if(canonicalJSON(frozen.bodyAnatomicalReferences)!==canonicalJSON(rebindBodyAnatomicalReferences(frozen.bodyAnatomicalReferences,JSON.parse(bodyBytes))))throw Error('Stale body4 anatomical world points in body5 descriptor.');
 const actualBrowserBodyProof=validateBrowserBodyProof(frozen,bodyBytes,readFileSync);
 const bodyReplayContract=assertBodyReplayContract(frozen,JSON.parse(bodyBytes),bodyBytes,{expectedRevision:EXPECTED_SOURCE_FIT_REVISION,candidateEpochPinsSha256:bodyBuild.candidateEpochPinsSha256,bodySourceFingerprints:bodyBuild.candidateBodySourceFingerprints});
 if(!frozen.freshPositions||!frozen.bodyPositions||!frozen.bodyIndices)throw new Error('Complete frozen initial source/body fixture required.');
 if(frozen.benchmarkPolicy?.rawEngine||frozen.benchmarkPolicy?.rawDefaultConfig)throw new Error('Only the guarded production source configuration may be reproduced.');
 if(!frozen.benchmarkPolicy?.productionDefault)throw new Error('This bounded handoff supports only unchanged production defaults, no injected resolved config or experimental overrides.');
 const sourceGatherScope=await approvedGatherScopeForFixture(frozen,{approveGatherProvenance});
 let prepared=prepareCloth({pattern,avatarVertices:new Float32Array(frozen.bodyPositions),avatarIndices:new Uint32Array(frozen.bodyIndices),cylinders:new Map()},{fromArrangement:true,sourceGatherScope});
 if(prepared?.simData.sourceGatherRefinement)prepared=await finalizePreparedRefinement(prepared);
 if(!prepared?.collisionSafety)throw new Error('Prepared fixture lacks production source collision safety.');
 const data=prepared.simData;
 const actualRefinement=sourceRefinementSnapshot(prepared);
 for(const key of ['sourceGatherRefinementRevision','sourceGatherRefinement','sourceGatherCollisionGeometry'])
  if(canonicalJSON(actualRefinement[key]??null)!==canonicalJSON(frozen[key]??null))throw new Error('Actual finalized refinement differs from immutable descriptor: '+key);
 const matches={positionsAndInverseMass:exactArray(data.positions,new Float32Array(frozen.freshPositions),'Initial positions/inverse mass'),
  clothTopology:exactArray(data.triangles,new Uint32Array(frozen.clothTriangles),'Cloth triangle topology'),
  sourceArrangedPositions:exactArray(data.sourceArrangedPositions??data.arrangedPositions,new Float32Array(frozen.sourceArrangedPositions),'Raw source positions'),
  arrangedPositions:exactArray(data.arrangedPositions,new Float32Array(frozen.arrangedPositions),'Assembly arranged positions'),
  seamPartners:exactArray(data.seams,new Int32Array(frozen.seams),'Seam partner topology')};
 const expectedBodyPositions=new Float32Array(frozen.bodyPositions.length/3*4),expectedBodyTriangles=new Uint32Array(frozen.bodyIndices.length/3*4);
 for(let vertex=0;vertex<expectedBodyPositions.length/4;vertex++)expectedBodyPositions.set(frozen.bodyPositions.slice(vertex*3,vertex*3+3),vertex*4);
 for(let face=0;face<expectedBodyTriangles.length/4;face++)expectedBodyTriangles.set(frozen.bodyIndices.slice(face*3,face*3+3),face*4);
 matches.packedBodyPositions=exactArray(prepared.body.positions,expectedBodyPositions,'Packed actual frozen body');
 matches.packedBodyTopology=exactArray(prepared.body.triangles,expectedBodyTriangles,'Packed actual frozen body faces');
 matches.supportTargets=exactArray(data.assemblySupport.targets,new Float32Array(frozen.assemblySupport.initialTargets),'Source initial support targets');
 if(canonicalJSON(data.assemblySupport.groups)!==canonicalJSON(frozen.assemblySupport.groups)
  ||data.assemblySupport.activeOnStart!==frozen.assemblySupport.activeOnStart||data.assemblySupport.revision!==frozen.assemblySupport.revision)throw new Error('Source initial support groups/revision mismatch.');
 const normalizePairs=pairs=>pairs.map(entry=>({seamId:entry.seamId,index:entry.index,pairs:Array.from(entry.pairs)}));
 if(JSON.stringify(normalizePairs(data.seamPairsBySeam))!==JSON.stringify(normalizePairs(frozen.seamPairs)))throw new Error('Ordered full seam pairs mismatch.');
 if(data.particleCount!==frozen.particleCount&&frozen.particleCount!==undefined)throw new Error('Particle count mismatch.');
 for(let i=3;i<data.anchors.length;i+=4)if(data.anchors[i]!==0)throw new Error('Hidden XYZ hold in fresh source seed.');
 if(canonicalJSON(data.sourceStaging??null)!==canonicalJSON(frozen.sourceStaging??null))throw new Error('Source structural stage plan differs from immutable initial descriptor.');
 if(canonicalJSON(data.arrangementSourceStaging??null)!==canonicalJSON(frozen.arrangementSourceStaging??null))throw new Error('Source arrangement restart stage template differs.');
 if(data.sourceStaging){
  const stage=new SourceStagingController(data.sourceStaging);
  const snapshot=stage.capture(),serial={...snapshot,activeMask:Array.from(snapshot.activeMask),lastAcceptedMask:Array.from(snapshot.lastAcceptedMask)};
  if(canonicalJSON(serial)!==canonicalJSON(frozen.sourceStagingSnapshot))throw new Error('Initial source stage snapshot differs.');
 }
 const dictionary={stitchCount:data.stitchCount,seamPairsBySeam:data.seamPairsBySeam.map((seam,index)=>({...seam,index,stitchIndices:physicalSeamStitchIndices(data.seams,data.seamOrder,[seam],data.seamStitchRanges)[0],stitchIndexKinds:seam.pairs.filter((_,at)=>at%2===0).map((a,pair)=>a===seam.pairs[pair*2+1]?'identity-logical':'reciprocal-first-stamp')}))};
 if(frozen.collisionSeamDictionary&&canonicalJSON(dictionary)!==canonicalJSON(frozen.collisionSeamDictionary))throw new Error('Authoritative source seam activation dictionary differs.');
 const contactOptions={};
 const contacts=applySourceContactPolicy(SIM_CONFIG,prepared.contactPolicy,contactOptions);
 if(canonicalJSON(contacts.config)!==canonicalJSON(frozen.simulationConfig))throw new Error('Current default resolved production config differs from browser fixture.');
 if(canonicalJSON(contacts.contactPolicy)!==canonicalJSON(frozen.contactPolicy))throw new Error('Current automatic contact policy provenance differs from browser fixture.');
 return {frozen,prepared,contactOptions,report:{kind:'CPU-only exact production preparation',path,inputSha256:sha256(bytes),
  backend:'prepared-for-node-dawn-mesa',bodyReplayContract,actualBrowserBodyProof,matches,orderedFullSeamPairsExact:true,
  particleCount:data.particleCount,clothFaces:data.triangles.length/4,bodyFaces:prepared.body.numTriangles,
  stitches:data.stitchCount,sourceCollisionSafety:true,xyzAnchorWeightsNonzero:0,
  config:contacts.config,contactPolicy:contacts.contactPolicy,sourceStretchPolicy:data.sourceStretchPolicy??null,automaticSourcePolicyExact:true,supportGroupsExact:true,
  bodyInput:'exact frozen actual posed body; no alternate avatar regeneration',benchmarkPolicy:frozen.benchmarkPolicy,gpuProbe:false,actualRefinement}};
}
