/** Reuse immutable native topology coordinates, never old body world-space points. */
export function rebindBodyAnatomicalReferences(references,body){
 if(!references)return null;
 const count=body.bodyPositions.length/3,faceCount=body.bodyIndices.length/3,out={};
 for(const [name,reference]of Object.entries(references)){
  if(!Array.isArray(reference.coordinates)||reference.coordinates.length!==reference.points?.length)throw Error('Incomplete native anatomical coordinate lineage: '+name);
  const points=reference.coordinates.map(c=>{
   const weights=[c.u,c.v,c.w];if(!Number.isSafeInteger(c.faceIndex)||c.faceIndex<0||c.faceIndex>=faceCount||weights.some(w=>!Number.isFinite(w)||w<0||w>1)||Math.abs(weights.reduce((a,b)=>a+b,0)-1)>1e-12)throw Error('Invalid native anatomical barycentric coordinate.');
   const ids=body.bodyIndices.slice(c.faceIndex*3,c.faceIndex*3+3);if(ids.some(id=>!Number.isSafeInteger(id)||id<0||id>=count))throw Error('Anatomical reference topology invalid.');
   const vertex=weights.findIndex(w=>w===1);if(vertex>=0)return body.bodyPositions.slice(ids[vertex]*3,ids[vertex]*3+3);
   return [0,1,2].map(axis=>ids.reduce((sum,id,i)=>sum+weights[i]*body.bodyPositions[id*3+axis],0));
  });out[name]={...structuredClone(reference),points};
 }
 return out;
}
