import {createHash} from 'node:crypto';
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const canonical=value=>Array.isArray(value)?'['+value.map(canonical).join(',')+']':value&&typeof value==='object'?'{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+canonical(value[k])).join(',')+'}':Object.is(value,-0)?'-0':JSON.stringify(value);
export const EXPECTED_SOURCE_FIT_REVISION=5;
export function bodyArrayHashes(body){
 if(!Array.isArray(body.bodyPositions)&&!ArrayBuffer.isView(body.bodyPositions))throw Error('Body XYZ array required.');
 for(const value of body.bodyPositions)if(typeof value!=='number'||!Number.isFinite(value))throw Error('Raw body coordinates must be finite numbers.');
 const positions=new Float32Array(body.bodyPositions),indices=new Uint32Array(body.bodyIndices);
 if(!positions.length||positions.length%3||!indices.length||indices.length%3||!positions.every(Number.isFinite))throw Error('Finite XYZ body and complete triangle array required.');
 for(const id of body.bodyIndices)if(!Number.isSafeInteger(id)||id<0||id>=positions.length/3)throw Error('Invalid body vertex index.');
 return {bodyPositionsSha256:hash(new Uint8Array(positions.buffer)),bodyIndicesSha256:hash(new Uint8Array(indices.buffer)),vertexCount:positions.length/3,triangleCount:indices.length/3};
}
export function selectWorkerAssets(names){
 const guard=names.filter(name=>/^collisionGuard\.worker-[A-Za-z0-9_-]+\.js$/.test(name));
 const source=names.filter(name=>/^sourceFit\.worker-[A-Za-z0-9_-]+\.js$/.test(name));
 if(guard.length!==1||source.length>1)throw Error('Require exactly one collision proof worker and at most one separate source-fit worker.');
 return {collisionGuardWorkerAsset:guard[0],sourceFitWorkerAsset:source[0]??null};
}
export function createBodyReplayContract(body,bodyDescriptorBytes,{expectedRevision,candidateEpochPinsSha256,bodyDescriptor,bodySourceFingerprints=body.sourceFingerprints}={}){
 if(expectedRevision!==EXPECTED_SOURCE_FIT_REVISION||body.sourceFitRevision!==expectedRevision)throw Error('Body revision must match explicit pinned candidate revision5; historical markers are never promoted.');
 if(!/^[a-f0-9]{64}$/.test(candidateEpochPinsSha256??'')||!bodyDescriptor||!body.sourceFitFingerprint||!Object.keys(bodySourceFingerprints??{}).length)throw Error('Actual candidate epoch, source dependencies and fit fingerprint required.');
 return {revision:expectedRevision,bodyDescriptor,bodyDescriptorSha256:hash(bodyDescriptorBytes),candidateEpochPinsSha256,sourceFitFingerprint:structuredClone(body.sourceFitFingerprint),bodySourceFingerprints:structuredClone(bodySourceFingerprints),sourceCalibrationFingerprint:body.sourceCalibrationFingerprint??null,bodyOrigin:body.actualBrowserWorker===true?{kind:"actual desktop browser source-fit worker",actualBrowserWorker:true,geometryBitExact:body.geometryBitExact,geometryComparison:structuredClone(body.geometryComparison)}:{kind:"copied synchronous CPU source-fit"},...bodyArrayHashes(body),gpuExecuted:false,body4Relabeled:false};
}
export function assertBodyReplayContract(frozen,body,bodyDescriptorBytes,{expectedRevision,candidateEpochPinsSha256,bodySourceFingerprints=body.sourceFingerprints}={}){
 const contract=frozen.bodyReplayContract;
 const actual=createBodyReplayContract(body,bodyDescriptorBytes,{expectedRevision,candidateEpochPinsSha256,bodyDescriptor:contract?.bodyDescriptor,bodySourceFingerprints});
 if(canonical(contract)!==canonical(actual))throw Error('Frozen body5 contract differs from actual pinned candidate body/source epoch.');
 if(frozen.sourceFitRevision!==expectedRevision||canonical(frozen.sourceBodyMetadata)!==canonical(body.sourceBodyMetadata)||canonical(frozen.pattern?.body?.garmentCodeBody)!==canonical(body.sourceBodyMetadata))throw Error('Frozen body revision or actual source measurement metadata mismatch.');
 if(canonical(bodyArrayHashes(frozen))!==canonical(bodyArrayHashes(body)))throw Error('Frozen body numerical bytes/topology differ from pinned candidate body.');
 return structuredClone(actual);
}
export function validateExpectedBodyManifest(manifest,bytes,sourceReader){
 if(manifest.expectedSourceFitRevision!==EXPECTED_SOURCE_FIT_REVISION||manifest.fixtures?.length!==7||new Set(manifest.fixtures.map(f=>f.id)).size!==7)throw Error('Explicit revision5 manifest for all seven unique styles required.');
 if(typeof sourceReader!=='function')throw Error('Pinned body source reader required.');
 const epoch=sourceReader(manifest.candidateEpochPinsPath);
 if(hash(epoch)!==manifest.candidateEpochPinsSha256)throw Error('Candidate source epoch changed.');
 for(const entry of manifest.fixtures)if(hash(sourceReader(entry.bodyDescriptor))!==entry.bodyDescriptorSha256)throw Error('Candidate body descriptor changed: '+entry.id);
 return {bodyManifestSha256:hash(bytes),expectedSourceFitRevision:manifest.expectedSourceFitRevision,candidateEpochPinsSha256:manifest.candidateEpochPinsSha256};
}
