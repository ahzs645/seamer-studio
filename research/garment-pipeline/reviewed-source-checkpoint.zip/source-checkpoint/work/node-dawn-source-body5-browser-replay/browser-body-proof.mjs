import{createHash}from'node:crypto';const sha=b=>createHash('sha256').update(b).digest('hex');
const canonical=v=>Array.isArray(v)?'['+v.map(canonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')+'}':JSON.stringify(v);
export function validateBrowserBodyProof(frozen,bodyBytes,read){
 const origin=frozen.descriptorOrigin,manifestBytes=read(origin?.browserBodyManifest);
 if(sha(manifestBytes)!==origin.browserBodyManifestSha256)throw Error('Authoritative browser body manifest SHA mismatch.');
 const manifest=JSON.parse(manifestBytes),body=JSON.parse(bodyBytes);
 if(manifest.actualBrowserWorker!==true||manifest.browserClosed!==true||manifest.gpuInitialized!==false||manifest.expectedSourceFitRevision!==5||body.actualBrowserWorker!==true||body.sourceFitRevision!==5)throw Error('Actual closed revision5 browser-worker proof required.');
 const rows=manifest.reports.filter(r=>r.mode==='desktop'&&r.id),lifecycle=manifest.reports.find(r=>r.mode==='desktop'&&r.lifecycle);
 if(rows.length!==7||new Set(rows.map(r=>r.id)).size!==7||lifecycle?.lifecycle.created!==7||lifecycle.lifecycle.terminated!==7||lifecycle.lifecycle.adapterRequests!==0||lifecycle.errors?.length)throw Error('Incomplete actual desktop body worker lifecycle.');
 const row=rows.find(r=>r.id===body.id);
 if(!row||row.file!==frozen.bodyInputDescriptor||row.sha256!==sha(bodyBytes)||row.actualSourceFitRevision!==5||body.originalDescriptorSha256!==origin.originalClothDescriptorSha256||canonical(body.sourceFingerprints)!==canonical(manifest.sourceFingerprints))throw Error('Exact browser body/cut/source proof binding mismatch.');
 if(canonical(row.geometryComparison)!==canonical(body.geometryComparison)||body.geometryBitExact!==row.geometryBitExact)throw Error('Browser numerical comparison provenance changed.');
 return {actualBrowserWorker:true,mode:'desktop',manifestSha256:sha(manifestBytes),bodyDescriptorSha256:row.sha256,geometryBitExactToCPU:row.geometryBitExact,geometryComparisonToCPU:structuredClone(row.geometryComparison)};
}
