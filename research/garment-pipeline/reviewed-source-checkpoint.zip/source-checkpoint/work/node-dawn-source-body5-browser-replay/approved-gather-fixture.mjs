import {readFileSync} from 'node:fs';
import {approveGeneratedGather,decodeOriginalGatherDocument} from './compiled/production.js';
const pins=JSON.parse(readFileSync('/workspace/work/node-dawn-source-body5-browser-replay/trusted-programs.json'));
/** This is a deliberate review CLI approval, never a trust flag read from the document.
 * The original lossless source, current cuts/body, evidence, style and deployment programs
 * are revalidated before numerical rebuilding. A saved marker alone cannot activate it. */
export async function approvedGatherScopeForFixture(frozen,{approveGatherProvenance=false}={}) {
 const refined=frozen.sourceGatherRefinement!==undefined||frozen.sourceGatherCollisionGeometry!==undefined;
 if(!refined)return undefined;
 if(!approveGatherProvenance)throw Error('A refined review fixture requires explicit --approve-gather-provenance and validated original source evidence.');
 const pattern=frozen.pattern;
 if(pattern?.assembly||pattern?.settings3d?.fixTop||pattern?.pieces?.some(piece=>piece.settings3d.savedSourceGatherIntent==='manual'
  ||piece.settings3d.savedDrapeState==='held'||piece.settings3d.frozen||piece.settings3d.savedPositions?.length))throw Error('Refined review fixtures require a fresh free implicit automatic assembly.');
 const source=pattern?.garmentCodeSource;
 if(!source?.gatherSourceDocument)throw Error('Missing lossless original generated source evidence.');
 const raw=decodeOriginalGatherDocument(structuredClone(source.gatherSourceDocument));
 const approval=await approveGeneratedGather(raw,structuredClone(frozen.pattern),{origin:'explicit-authored-import',...structuredClone(pins)});
 if(!approval.provenance||!approval.scope.enabled||!approval.scope.approvedEvidence?.seams.length)throw Error('Original source gather provenance could not be approved.');
 return structuredClone(approval.scope);
}
