/** Owned runtime entry. Historical compiled-source observations are not reread. */
import fs from 'node:fs';import assert from 'node:assert/strict';
import {verifyRuntimeDependencyHierarchy,runtimeFileSha256} from './runtime-dependencies.mjs';
const file=new URL('./runtime-manifest.json',import.meta.url);
export const REFINED_RUNTIME_PROVENANCE_MODULE=new URL('./runtime/workspace/seamer-studio/scripts/garmentcode/qa/refined-runtime-provenance.mjs',import.meta.url).pathname;
export function assertPreparationRuntimeUnchanged(expected){const bytes=fs.readFileSync(file),manifest=JSON.parse(bytes);if(expected)assert.equal(runtimeFileSha256(bytes),expected,'Preparation runtime manifest changed across await');verifyRuntimeDependencyHierarchy(manifest);return runtimeFileSha256(bytes);}
let modulePromise;
export async function preparePhysicalSourceFixture(id,parameters,options={}){
 const capturedParameters=structuredClone(parameters),capturedOptions=structuredClone(options),identity=assertPreparationRuntimeUnchanged();
 modulePromise??=import('./runtime/workspace/work/source-attached-arm-preparer-sealed-controller/prepare-source.mjs');
 const owner=await modulePromise;assertPreparationRuntimeUnchanged(identity);
 const result=await owner.preparePhysicalSourceFixture(id,capturedParameters,capturedOptions);
 assertPreparationRuntimeUnchanged(identity);return result;
}
