import assert from'node:assert/strict';import{createHash}from'node:crypto';
export const INITIAL_ARRANGEMENT_PROFILE='source-rigid-initial-depenetration-v1';
export const canonicalArrangementPolicy=value=>Array.isArray(value)?value.map(canonicalArrangementPolicy):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().map(k=>[k,canonicalArrangementPolicy(value[k])])):value;
export const arrangementPolicySha256=policy=>createHash('sha256').update(JSON.stringify(canonicalArrangementPolicy(policy))).digest('hex');
export const numericSha256=a=>createHash('sha256').update(Buffer.from(a.buffer,a.byteOffset,a.byteLength)).digest('hex');
export function assertPreparedInitialArrangementBinding(prepared,{initial=true}={}){
 const d=prepared.simData,p=d.sourceInitialArrangementPolicy,h=d.sourceInitialArrangementPolicySha256;
 if(!p&&!h)return null;assert(p&&h&&p.policy===INITIAL_ARRANGEMENT_PROFILE&&/^[a-f0-9]{64}$/.test(h),'Complete source initial arrangement profile required');assert.equal(arrangementPolicySha256(p),h,'Source initial arrangement policy digest changed');
 if(initial)assert.equal(numericSha256(d.positions),p.actualPositionsSha256,'Initial numerical XYZ/W differs from profile');
 for(const[field,key]of[['arrangedPositions','actualArrangedPositionsSha256'],['anchors','actualAnchorsSha256'],['positions2d','sourceRestCoordinatesSha256'],['sourceArrangedPositions','originalSourceArrangedPositionsSha256'],['triangles','clothTrianglesSha256'],['seams','seamsSha256'],['seamOrder','seamOrderSha256']])assert.equal(numericSha256(d[field]),p[key],field+' differs from initial arrangement profile');
 assert.equal(numericSha256(d.assemblySupport.targets),p.assemblySupportTargetsSha256);assert.equal(numericSha256(prepared.body.positions),p.bodyPositionsSha256);assert.equal(numericSha256(prepared.body.triangles),p.bodyTrianglesSha256);assert.equal(numericSha256(d.positions.filter((_,i)=>i%4===3)),p.physicalInverseMassBitsSha256);
 assert.equal(arrangementPolicySha256(d.assemblySupport.groups),p.assemblySupportGroupsSha256);
 assert.equal(arrangementPolicySha256(d.stretchColors.map(g=>({edges:Array.from(g.edges),props:Array.from(g.props)}))),p.actualRestConstraintSha256);
 return Object.freeze({policy:INITIAL_ARRANGEMENT_PROFILE,policySha256:h,actualInitialPositionsSha256:p.actualPositionsSha256});
}
// A saved claim alone grants no warm-cache authority: current fresh preparation is revalidated.
export function assertInitialArrangementCacheCompatible(saved,currentPrepared){
 const identity=assertPreparedInitialArrangementBinding(currentPrepared,{initial:true}),savedHash=saved?.sourceInitialArrangementPolicySha256??null;
 if(!identity){assert.equal(savedHash,null,'Refined initial-arrangement cache cannot be interpreted as legacy');return;}
 assert.equal(savedHash,identity.policySha256,'Saved source initial arrangement profile is absent or stale; reassemble from current original cuts');
 assert.equal(saved?.actualArrangedPositionsSha256,numericSha256(currentPrepared.simData.arrangedPositions),'Saved arrangement seed identity differs');
}
export function initialArrangementRestoreIdentity(prepared,dictionary){const binding=assertPreparedInitialArrangementBinding(prepared,{initial:false});return JSON.stringify({triangles:Array.from(prepared.simData.triangles),dictionary,materialPolicySha256:prepared.simData.sourcePhysicalMembrane?.policySha256??null,...(binding?{sourceInitialArrangementPolicySha256:binding.policySha256}: {})});}
