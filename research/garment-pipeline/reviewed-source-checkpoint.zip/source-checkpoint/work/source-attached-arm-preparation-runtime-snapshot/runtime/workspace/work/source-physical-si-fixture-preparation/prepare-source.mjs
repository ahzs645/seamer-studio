// NEW CPU-only physical-material input. Original browser-body5 fixture remains immutable.
import fs from 'node:fs';import assert from 'node:assert/strict';import{createHash}from'node:crypto';
import{prepareFrozenFixture as prepareOriginal,canonicalJSON}from'/workspace/work/source-attached-arm-preparation-runtime-snapshot/runtime/workspace/work/node-dawn-source-body5-browser-replay/prepare-fixture.mjs';
import{prepareCloth,prepareSourcePhysicalMembrane,validateSourcePhysicalMembrane,SIM_CONFIG,applySourceContactPolicy,finalizeSourceGatherCollisionGeometry}from'/workspace/work/source-attached-arm-preparation-runtime-snapshot/runtime/workspace/work/source-membrane-all-phase-skirt-diagnostic-bindings/compiled/production.js';
import{approvedGatherScopeForFixture}from'/workspace/work/source-attached-arm-preparation-runtime-snapshot/runtime/workspace/work/node-dawn-source-body5-browser-replay/approved-gather-fixture.mjs';
const base='/workspace/work/source-membrane-all-phase-skirt-diagnostic-bindings',sha=b=>createHash('sha256').update(b).digest('hex');
const manifestPath='/workspace/work/node-dawn-source-body5-browser-replay/initial-seven-browser-anatomy-final/manifest.json',manifest=JSON.parse(fs.readFileSync(manifestPath));
export async function preparePhysicalSourceFixture(id,explicitParameters){
 const captured=structuredClone(explicitParameters);assert(captured&&captured.parameterOrigin==='explicit-illustrative-benchmark'&&captured.measuredGarmentParameters===false,'Explicit uncalibrated SI benchmark input required');const {measuredGarmentParameters,...parameters}=captured;
 const fixture=manifest.fixtures.find(f=>f.id===id);assert(fixture,'Actual closed browser-body5 immutable fixture required');
 const originBytes=fs.readFileSync(fixture.descriptor);assert.equal(sha(originBytes),fixture.descriptorSha256);
 const original=await prepareOriginal(fixture.descriptor,{approveGatherProvenance:true}),frozen=original.frozen;
 const sourceGatherScope=await approvedGatherScopeForFixture(frozen,{approveGatherProvenance:true});
 let actual=prepareCloth({pattern:structuredClone(frozen.pattern),avatarVertices:new Float32Array(frozen.bodyPositions),avatarIndices:new Uint32Array(frozen.bodyIndices),cylinders:new Map()},{fromArrangement:true,sourceGatherScope});assert(actual?.collisionSafety);
 if(actual.simData.sourceGatherRefinement)actual={...actual,simData:await finalizeSourceGatherCollisionGeometry(actual.simData)};
 assert.equal(canonicalJSON(actual.simData.sourceGatherRefinement),canonicalJSON(original.prepared.simData.sourceGatherRefinement));
 assert.equal(canonicalJSON(actual.simData.sourceGatherCollisionGeometry),canonicalJSON(original.prepared.simData.sourceGatherCollisionGeometry));
 const bits=a=>Buffer.from(a.buffer,a.byteOffset,a.byteLength),same=(a,b,label)=>assert.deepEqual(bits(a),bits(b),label);
 for(const field of['positions','positions2d','arrangedPositions','sourceArrangedPositions','triangles','seams','seamOrder','anchors'])same(actual.simData[field],original.prepared.simData[field],field+' original geometry/pre-material bits');
 same(actual.body.positions,original.prepared.body.positions,'actual body5 XYZ');same(actual.body.triangles,original.prepared.body.triangles,'actual body5 faces');
 assert.equal(canonicalJSON(actual.simData.sourceStaging??null),canonicalJSON(original.prepared.simData.sourceStaging??null));
 assert.equal(canonicalJSON(actual.simData.assemblySupport),canonicalJSON(original.prepared.simData.assemblySupport));
 const assignments=actual.simData.sourceStretchPolicy.sourcePieceIds.map(pieceId=>{const p=frozen.pattern.pieces.find(p=>p.id===pieceId.replace(/#M$/,''));assert(p);return{pieceId,grainDirection:[p.grainVector.x,p.grainVector.y],parameters:{densityKgPerM2:parameters.densityKgPerM2,sheetTensorNPerM:parameters.sheetTensorNPerM,bendingRigidityNm:parameters.bendingRigidityNm,iterationsPerMaterialStage:parameters.iterationsPerMaterialStage,parameterOrigin:parameters.parameterOrigin,benchmarkId:id==='skirt-170'?'NEW-skirt-source-body5-SI-membrane-only':'NEW-'+id+'-source-body5-SI-membrane-only',parameterProvenance:parameters.parameterProvenance}};});
 const previous=actual.simData,simData=await prepareSourcePhysicalMembrane(previous,assignments),executed=validateSourcePhysicalMembrane(simData);assert(executed);
 for(let i=0;i<simData.positions.length;i++)if(i%4!==3||previous.positions[i]===0)assert(Object.is(previous.positions[i],simData.positions[i]));
 for(const field of['positions2d','triangles','seams','seamOrder','anchors'])same(simData[field],previous[field],field+' post-material identity');
 assert.equal(canonicalJSON(simData.assemblySupport),canonicalJSON(previous.assemblySupport));
 const material=simData.sourcePhysicalMembrane,mass=material.physicalMassesKg.reduce((a,b)=>a+b,0),area=material.triangles.reduce((a,t)=>a+t.areaM2,0);assert(Math.abs(mass-parameters.densityKgPerM2*area)<1e-12);
 const bodyConfig=applySourceContactPolicy(SIM_CONFIG,actual.contactPolicy,{});assert.equal(canonicalJSON(bodyConfig.config),canonicalJSON(frozen.simulationConfig));
 const build=JSON.parse(fs.readFileSync(base+'/build-provenance.json'));assert.equal(sha(fs.readFileSync(base+'/compiled/production.js')),build.productionBundleSha256);
 const descriptor={...frozen,kind:'NEW CPU-origin actual-prepare physical-SI source-body5 initial descriptor',frame:0,clothPositions:Array.from(simData.positions),freshPositions:Array.from(simData.positions),arrangedPositions:Array.from(simData.arrangedPositions),sourceArrangedPositions:Array.from(simData.sourceArrangedPositions),
 sourceFingerprints:build.sourceFingerprints,sourcePhysicalMaterialPolicy:executed,sourcePhysicalMaterialPreparationPolicy:material.policy,sourcePhysicalMaterialPolicySha256:material.policySha256,sourceDeltaPolicy:null,
 bodyOrigin:frozen.bodyOrigin??frozen.bodyReplayContract.bodyOrigin,bodyReplayContract:frozen.bodyReplayContract,sourceFitRevision:5,sourceAssemblyRevision:frozen.sourceAssemblyRevision,
 simulationConfig:bodyConfig.config,contactPolicy:bodyConfig.contactPolicy,sourceStretchPolicy:simData.sourceStretchPolicy,
 benchmarkPolicy:{productionDefault:false,physicalContactConfigurationProductionDefault:true,physicalSubsteps:40,substepContactIterations:4,sewIterations:8,explicitIllustrativeSIMaterial:true,bendingRigidityNm:0,parametersMeasured:false,GPUExecuted:false,backend:'CPU-only copied actual-preparation; pending Node/Mesa public-wrapper diagnostic'},
 materialGeometryLineage:{originalBrowserBody5Manifest:manifestPath,originalManifestSha256:sha(fs.readFileSync(manifestPath)),originalInitialDescriptor:fixture.descriptor,originalInitialDescriptorSha256:sha(originBytes),originalPhysicalWReused:false,allOriginalXYZandFixedW0BitsPreserved:true,authoredCutsRestTopologySeamsSupportAndBodyBitsPreserved:true,materialAssignments:assignments},
 initialPhysicalPositionsFloat32LEBase64:bits(simData.positions).toString('base64'),sourceRestMaterialCoordinatesFloat32LEBase64:bits(simData.positions2d).toString('base64'),physicalMassKg:mass,sourceRestAreaM2:area,
 nodeBuildProvenance:build,sourceAssemblyComplete:false,runtimeSafe:false,accepted:false,fullFitAccepted:false,physicsGPUExecuted:false,sourcePhysicalDeltaTrace:null};
 const report={CPUOnly:true,GPUInitialized:false,sourceEpochSha256:build.sourceEpochSha256,originalDescriptorSha256:sha(originBytes),sourcePhysicalMaterialPolicySha256:material.policySha256,sourcePhysicalMaterialPolicy:executed,allOriginalXYZandFixedW0BitsPreserved:true,body5ActualBrowserLineageValidated:true,bodyXYZAndTopologyBitExact:true,authoredCutsTopologySeamsSupportUnchanged:true,physicalMassKg:mass,restAreaM2:area,particles:simData.particleCount,materialTriangles:material.triangles.length,colors:material.colors.length,
 physicalWChanged:true,oldMaterialWNotRelabeled:true,illustrativeOnly:true,measuredGarmentFabric:false,sourceFullContactDefaultConfigPreserved:true,subSteps:bodyConfig.config.subSteps,realWorkerProofNotExecuted:true,sourceAssemblyComplete:false,accepted:false};
 report.actualSchedule={sourceStretchSewingMode:'sequential',constructorOptions:{},materialStagesPerSubstep:1,subSteps:bodyConfig.config.subSteps,nonemptyMaterialColors:material.colors.filter(c=>c.length>0).length,iterationsPerMaterialStage:material.iterationsPerMaterialStage,lambdaResetDispatches:bodyConfig.config.subSteps};
 report.actualSchedule.materialColorDispatches=report.actualSchedule.nonemptyMaterialColors*material.iterationsPerMaterialStage*bodyConfig.config.subSteps;
 return{prepared:{...actual,simData},descriptor,report,originDescriptor:frozen};
}
