/** REVIEW ONLY. Numerical indices/stamps unchanged; authored graph determines
 * phase membership. No runtime/controller/initial source file is modified. */
import assert from'node:assert/strict';
export const POLICY='source-attached-open-arm-before-tube-v1';
export function buildCapBeforeTubeProposal(f,{freshImplicitSource=true}={}){
 if(!freshImplicitSource||!f.sourceStaging?.provenance?.eligible)return null;
 assert(f.pattern.garmentCodeSource?.format==='garmentcode-json');
 const p=f.pattern,old=f.sourceStaging,roles=new Map(old.provenance.sourceRoles.map(x=>[x.pieceId,x])),edgeOwners=new Map(p.pieces.flatMap(x=>x.mainPaths.map(e=>[e.id,x.id]))),seams=p.seams.map((s,index)=>({index,id:s.id,pieces:[...new Set([...s.fromPaths,...s.toPaths].map(x=>edgeOwners.get(x.id)))]})),byId=new Map(seams.map(s=>[s.id,s]));
 assert.equal(seams.length,f.collisionSeamDictionary.seamPairsBySeam.length);
 for(const s of seams){const g=f.collisionSeamDictionary.seamPairsBySeam[s.index];assert.equal(g.index,s.index);assert.equal(g.seamId,s.id);assert(g.pairs.length&&g.pairs.length===g.stitchIndices.length*2);assert(g.stitchIndices.every(v=>Number.isSafeInteger(v)&&v>=0&&v<f.stitchCount));}
 const mask=Uint32Array.from(f.collisionSeamActivation.activeSeams),units=[];
 for(const u of old.provenance.upperUnits.filter(u=>u.role==='arm-unit')){
  const pieces=new Set(u.pieceIds),cuffs=new Set(u.pieceIds.filter(id=>/cuff_[fb]$/.test(roles.get(id).sourcePanelName))),sleeves=u.pieceIds.filter(id=>!cuffs.has(id));assert.equal(sleeves.length,2,'Only authenticated two-panel sleeve topology supported');
  const caps=seams.filter(s=>s.pieces.some(id=>pieces.has(id))&&s.pieces.some(id=>roles.get(id)?.role==='shell')).map(s=>s.index);assert(caps.length);
  const internal=u.structuralSeamIds.map(id=>byId.get(id).index),longitudinal=internal.filter(i=>seams[i].pieces.length===2&&seams[i].pieces.every(id=>sleeves.includes(id)));assert.equal(longitudinal.length,2);
  const highest=(i)=>{const g=f.collisionSeamDictionary.seamPairsBySeam[i];return Math.max(...g.pairs.map(a=>f.sourceArrangedPositions[a*4+1]));};const [outer,inner]=longitudinal.sort((a,b)=>highest(b)-highest(a));assert(highest(outer)>highest(inner));
  const cuffRings=internal.filter(i=>seams[i].pieces.every(id=>cuffs.has(id))),cuffConnectors=internal.filter(i=>seams[i].pieces.some(id=>cuffs.has(id))&&seams[i].pieces.some(id=>sleeves.includes(id)));
  assert.equal(internal.length,2+cuffRings.length+cuffConnectors.length);
  for(const i of internal)mask[i]=cuffConnectors.includes(i)?1:0;for(const i of caps)mask[i]=1;
  units.push({pieceIds:u.pieceIds.slice(),capIndices:caps,outerIndex:outer,innerIndex:inner,cuffConnectorIndices:cuffConnectors,cuffRingIndices:cuffRings,transitions:[{requireClosed:caps.slice(),enable:[outer]},{requireClosed:[...caps,outer,...cuffConnectors],enable:[inner,...cuffRings]}]});
 }
 if(!units.length)return null;
 const hoods=[];for(const u of old.provenance.upperUnits.filter(u=>u.role==='hood-unit')){const pieces=new Set(u.pieceIds),base=seams.filter(s=>s.pieces.some(id=>pieces.has(id))&&s.pieces.some(id=>roles.get(id)?.role==='shell')).map(s=>s.index),internal=u.structuralSeamIds.map(id=>byId.get(id).index);assert(base.length);for(const i of base)mask[i]=1;for(const i of internal)mask[i]=0;hoods.push({pieceIds:u.pieceIds.slice(),baseIndices:base,transitions:[{requireClosed:base.slice(),enable:internal}]});}
 const stageOf=i=>units.flatMap((u,n)=>u.transitions.flatMap((t,k)=>t.enable.includes(i)?[`arm${n}:${k}`]:[])).concat(hoods.flatMap((u,n)=>u.transitions.flatMap((t,k)=>t.enable.includes(i)?[`hood${n}:${k}`]:[])))[0]??'initial-or-unchanged';
 const actualStampOwners=new Map();for(const g of f.collisionSeamDictionary.seamPairsBySeam)for(const stamp of g.stitchIndices){const cat=stageOf(g.index);assert(!actualStampOwners.has(stamp)||actualStampOwners.get(stamp)===cat,'Repeated physical first stamp spans conflicting phases');actualStampOwners.set(stamp,cat);}
 return{policy:POLICY,initialActiveSeams:Array.from(mask),units,hoods,allOriginalSeamIds:seams.map(s=>s.id),allOriginalStitchIndices:f.collisionSeamDictionary.seamPairsBySeam.map(g=>g.stitchIndices.slice()),gapCriterionM:.003,stableAcceptedFrames:3,sourceCutsRestMassBodyAndDictionaryUnchanged:true,physicalLawChanged:false,assemblyScheduleChanged:true,allActualMandatorySafetyProofsStillRequired:true,originalSupportReleasePrerequisitesUnchanged:true,fullFitAccepted:false};
}
/** Consumes a PROVEN actual-used mask, never a planned candidate. Caller must
 * bind this evidence to the real accepted worker/device proof and own rollback.
 * This helper produces a NEXT mask only; it has no completion authority. */
export function observeProvenUnitTransition(plan,unit,transitionIndex,accepted,stableCount){
 const t=unit.transitions[transitionIndex];if(!t)return{nextMask:accepted.activeSeams.slice(),stableCount:0,transitionIndex};
 assert(accepted.actualMandatoryProofSafe===true,'Actual accepted physical+all41 proof required');assert.equal(accepted.activeSeams.length,plan.initialActiveSeams.length);assert(Number.isSafeInteger(stableCount)&&stableCount>=0);
 const okay=t.requireClosed.every(i=>accepted.activeSeams[i]===1&&accepted.allOriginalPairStampsEnabled[i]===true&&Number.isFinite(accepted.maxGapMetersBySeam[i])&&accepted.maxGapMetersBySeam[i]<=plan.gapCriterionM),count=okay?stableCount+1:0,next=accepted.activeSeams.slice();if(count>=plan.stableAcceptedFrames){for(const i of t.enable)next[i]=1;return{nextMask:next,stableCount:0,transitionIndex:transitionIndex+1};}return{nextMask:next,stableCount:count,transitionIndex};
}
