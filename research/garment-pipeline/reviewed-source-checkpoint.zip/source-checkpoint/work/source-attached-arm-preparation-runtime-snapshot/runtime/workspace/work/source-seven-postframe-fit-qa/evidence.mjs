/** Existing acceptance CLI adapter only. No solver, device, repair, safe defaults or fit authority. */
import fs from'node:fs';import assert from'node:assert/strict';import{createHash}from'node:crypto';
import{sampleEligibility,computeWindowMotion}from'/workspace/work/source-attached-arm-preparation-runtime-snapshot/runtime/workspace/seamer-studio/scripts/garmentcode/qa/motion-window-audit.mjs';
export const SOURCE_MANIFEST='/workspace/work/source-initial-arrangement-preparer-integration/manifest.json';
export const ANATOMY_MANIFEST='/workspace/work/source-host-acceptance-review/anatomy-ready-seven-attempt1/manifest.json';
export const CASES=Object.freeze({
 'tee-short-164':{openingsApplicable:false,shoulderApplicable:true,requiredCoveredRegions:['neck','leftUnderarm','rightUnderarm','waist']},
 'shirt-long-176':{openingsApplicable:true,shoulderApplicable:true,requiredCoveredRegions:['neck','leftUnderarm','rightUnderarm','waist','leftWrist','rightWrist','leftForearm','rightForearm']},
 'hoodie-cuffed-176':{openingsApplicable:true,shoulderApplicable:true,requiredCoveredRegions:['neck','leftUnderarm','rightUnderarm','waist','leftWrist','rightWrist','leftForearm','rightForearm']},
 'skirt-170':{openingsApplicable:false,shoulderApplicable:false,requiredCoveredRegions:['waist','hips','pelvis']},
 'pants-183':{openingsApplicable:false,shoulderApplicable:false,requiredCoveredRegions:['waist','hips','pelvis','crotch','leftThigh','rightThigh','leftCalf','rightCalf']},
 'dress-sleeveless-176':{openingsApplicable:false,shoulderApplicable:true,requiredCoveredRegions:['neck','leftUnderarm','rightUnderarm','waist','hips','pelvis']},
 'dress-default-sleeved-176':{openingsApplicable:false,shoulderApplicable:true,shortSleeveOpeningsApplicable:true,requiredCoveredRegions:['neck','leftUnderarm','rightUnderarm','waist','hips','pelvis']}
});
export const sha=b=>createHash('sha256').update(b).digest('hex');
const canonical=v=>Array.isArray(v)?v.map(canonical):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,canonical(v[k])])):v;
const equal=(a,b)=>JSON.stringify(canonical(a))===JSON.stringify(canonical(b));
const packed=(values,integer=false)=>{assert(Array.isArray(values)&&values.every(Number.isFinite));return Buffer.from((integer?Uint32Array.from(values):Float32Array.from(values)).buffer);};
export function loadBoundInitial(id){
 assert(CASES[id],'Exact seven-source fixture ID required');const mb=fs.readFileSync(SOURCE_MANIFEST),m=JSON.parse(mb),row=m.fixtures.find(x=>x.id===id),db=fs.readFileSync(row.descriptor);assert.equal(sha(db),row.descriptorSha256);const initial=JSON.parse(db),ab=fs.readFileSync(ANATOMY_MANIFEST);assert.equal(sha(ab),'085bb2848c40a404083720bf6dc615f67a89b706a11e89ec330772e4a0ff4ed6');const am=JSON.parse(ab),ar=am.fixtures.find(x=>x.id===id),aBytes=fs.readFileSync(ar.file);assert.equal(sha(aBytes),ar.sha256);const anatomy=JSON.parse(aBytes);
 for(const key of['pattern','clothTriangles','seams','seamOrder','stitchCount','seamPairs','collisionSeamDictionary'])assert(equal(initial[key],anatomy[key]),'Actual anatomical topology mismatch: '+key);
 for(const[key,integer]of[['bodyPositions',false],['bodyIndices',true]])assert(packed(initial[key],integer).equals(packed(anatomy[key],integer)),'Actual body5 anatomy mismatch: '+key);
 assert.equal(initial.sourceFitRevision,5);assert.equal(initial.sourceAssemblyRevision,5);const waistParticles=[...new Set(initial.assemblySupport.groups.filter(g=>g.kind==='waist').flatMap(g=>g.particles))].sort((a,b)=>a-b);
 return{initial,anatomy,row,manifestSha256:sha(mb),anatomyManifestSha256:sha(ab),requirements:{...structuredClone(CASES[id]),waistbandApplicable:waistParticles.length>0},waistParticles};
}
export function bindFrozen(bound,frozen){
 const initial=bound.initial;for(const key of['pattern','inputSha256','sourceFitRevision','sourceFitFingerprint','sourceAssemblyRevision','bodyAnatomicalReferences','sourceBodyMetadata','bodySourceFingerprints','clothTriangles','seams','seamOrder','stitchCount','sourceArrangedPositions','freshPositions','arrangedPositions','sourceStaging','arrangementSourceStaging','sourceGatherRefinement','sourceGatherCollisionGeometry','sourcePhysicalMaterialPreparationPolicy','sourcePhysicalMaterialPolicySha256','sourceInitialArrangementPolicy','sourceInitialArrangementPolicySha256','collisionSeamDictionary','materialGeometryLineage'])assert(equal(initial[key],frozen[key]),'Frozen source mismatch: '+key);
 for(const[key,integer]of[['bodyPositions',false],['bodyIndices',true]])assert(packed(initial[key],integer).equals(packed(frozen[key],integer)),'Frozen body byte mismatch: '+key);
 assert.equal(frozen.clothPositions?.length,initial.clothPositions.length);const a=packed(initial.clothPositions),z=packed(frozen.clothPositions);for(let p=0;p<initial.particleCount;p++)assert.equal(a.readUInt32LE(p*16+12),z.readUInt32LE(p*16+12),'Actual physical W changed');
 for(const key of['pieces','cuffEdges','joints'])assert(equal(bound.anatomy[key],frozen[key]),'Missing/mismatched authentic body5/prepared anatomy: '+key);
 return true;
}
export function actualSeamGaps(f){return f.collisionSeamDictionary.seamPairsBySeam.map(g=>{const rows=[];for(let k=0;k<g.pairs.length;k+=2){const a=g.pairs[k],b=g.pairs[k+1];rows.push({particles:[a,b],stitchIndex:g.stitchIndices[k/2],gapMm:1000*Math.hypot(...[0,1,2].map(x=>f.clothPositions[a*4+x]-f.clothPositions[b*4+x]))});}return{seamId:g.seamId,index:g.index,maxGapMm:Math.max(0,...rows.map(x=>x.gapMm)),rows};}).sort((a,b)=>b.maxGapMm-a.maxGapMm);}
export function supportObservation(f){
 if(typeof f.actualSupportTargetsFloat32LEBase64!=='string')return{observed:false,nonzero:null,reason:'Missing actual support target bytes'};const b=Buffer.from(f.actualSupportTargetsFloat32LEBase64,'base64');assert.equal(b.length,f.clothPositions.length*4);let nonzero=0;for(let i=0;i<b.length/4;i++){const v=b.readFloatLE(i*4);assert(Number.isFinite(v));if(i%4===1){assert(v>=0);if(v>0)nonzero++;}}return{observed:true,nonzero,sha256:sha(b),reportedMatches:f.temporarySupportWeightsNonzero===nonzero};
}
export function anchorObservation(f){
 const a=f.effectiveAnchorState,d=f.drivingUniformState,P=f.clothPositions.length/4;
 const valid=a?.ownerObserved===true&&a.gpuUniformReadback===false&&d?.ownerObserved===true&&d.gpuUniformReadback===false&&Number.isFinite(a.anchorScale)&&a.anchorScale>=0&&Number.isFinite(a.gravityScale)&&a.gravityScale>=0&&Number.isSafeInteger(a.activeXYZAnchorCount)&&a.activeXYZAnchorCount>=0&&Array.isArray(a.effectiveXYZAnchorWeights)&&a.effectiveXYZAnchorWeights.length===P&&a.effectiveXYZAnchorWeights.every(v=>Number.isFinite(v)&&v>=0)&&a.activeXYZAnchorCount===a.effectiveXYZAnchorWeights.filter(v=>v>0).length&&a.activeXYZAnchorCount===f.fixedAnchorWeightsNonzero&&a.grabbed===false&&Number.isSafeInteger(a.sourceGeneration)&&a.sourceGeneration>=0&&['anchorScale','gravityScale','activeXYZAnchorCount','grabbed','sourceGeneration'].every(k=>a[k]===d[k])&&equal(a.effectiveXYZAnchorWeights,Array.from(d.effectiveXYZAnchorWeights??[]));
 return{observed:valid,nonzero:valid?a.activeXYZAnchorCount:null,ownerObserved:valid,gpuUniformReadback:false};
}
export function releaseReadiness(f){
 const seams=actualSeamGaps(f),support=supportObservation(f),anchor=anchorObservation(f);
 const failures=[];if(f.sourceAssemblyComplete!==true)failures.push('sourceAssemblyIncomplete');if(!seams.length||seams[0].maxGapMm>3)failures.push('seamGapAbove3mm');if(!support.observed||!support.reportedMatches||support.nonzero!==0)failures.push('temporarySupportNotObservedReleased');if(!anchor.observed||anchor.nonzero!==0)failures.push('effectiveXYZAnchorsNotObservedReleased');if(!sampleEligibility(f,{sourceAssemblyRequired:true}))failures.push('ordinarySourceReleaseEligibility');if(f.physicalBackendFrameCommitted!==true||f.physicalBackendFrameValidation?.bindingValidated!==true)failures.push('physicalFrameCommitNotValidated');
 return{releaseReady:failures.length===0,failures,seams,support,actualAnchorObserved:anchor.observed,anchor,fullFitAccepted:false};
}
export function createObservedWindows(samples){assert.equal(samples.length,17);assert(samples.every((s,i)=>s.frame===samples[0].frame+i));assert(samples.every(s=>releaseReadiness(s).releaseReady),'Every real sample must be released/eligible');const dt=samples[0].simulatedSecondsPerFrame;assert(Number.isFinite(dt)&&dt>0&&8*dt+1e-9>=.128);assert(samples.every(s=>s.simulatedSecondsPerFrame===dt&&Math.abs(s.simulatedSeconds-s.frame*dt)<1e-9));return[0,8].map(start=>{const rows=samples.slice(start,start+9),metrics=computeWindowMotion(rows);return{fromFrame:rows[0].frame,toFrame:rows[8].frame,fromSeconds:rows[0].simulatedSeconds,toSeconds:rows[8].simulatedSeconds,intervalSeconds:dt*8,sampleFrames:rows.map(s=>s.frame),observedFrameCount:9,...metrics,fullyReleasedForEntireWindow:true,temporarySupportWeightsNonzero:0,fixedAnchorWeightsNonzero:0,bodyContacts:true,surfaceContacts:true,selfContacts:true,selfSurfaceContacts:true,runtimeSafe:true,halted:false,sourceAssemblyComplete:true,fullySewn:true,gravity:rows[0].gravity.slice(),maxSeamGapMm:Math.max(...rows.map(s=>actualSeamGaps(s)[0].maxGapMm))};});}
export function waistEvidence(bound,samples){
 const particles=bound.waistParticles;if(!particles.length)return null;
 const final=samples.at(-1),owner=final?.waistReleaseEvidence,first=owner?.firstFullyReleasedWaistState;
 assert(first,'Actual first fully released sample is required');assert(Number.isSafeInteger(first.frame)&&first.frame>=1&&first.frame<=final.frame);
 const ys=particles.map(p=>bound.initial.assemblySupport.targets[p*4]);
 assert(equal(owner.waistParticleIds,particles)&&equal(first.particleIds,particles),'Actual waist particle identity mismatch');
 assert(equal(owner.waistSourceTargetYs,ys)&&equal(first.sourceTargetYs,ys),'Actual semantic waist targets mismatch');
 const observed=samples.find(s=>s.frame===first.frame);assert(observed,'Actual first release frame must be retained, even before the17sample window');
 const support=supportObservation(observed),anchor=anchorObservation(observed);
 assert(support.observed&&support.reportedMatches&&support.nonzero===0&&anchor.observed&&anchor.nonzero===0,'First release must have actual zero support/anchor weights');
 assert(observed.waistReleaseEvidence?.fullyReleasedOwnerObserved===true,'First release owner state missing');
 assert(equal(first,observed.waistReleaseEvidence.firstFullyReleasedWaistState),'First release baseline mutated');
 const released=particles.map(p=>observed.clothPositions[p*4+1]);assert(equal(first.firstFullyReleasedYs,released),'First release Ys must equal its actual published positions');
 const targetBytes=Buffer.from(observed.actualSupportTargetsFloat32LEBase64,'base64'),actualYs=particles.map(p=>targetBytes.readFloatLE(p*16));
 assert(equal(first.actualTargetYs,actualYs),'First release actual target Ys mismatch');
 assert(Number.isFinite(first.actualSupportElapsedSeconds)&&first.actualSupportElapsedSeconds>=0);
 const current=particles.map(p=>final.clothPositions[p*4+1]);assert(equal(owner.waistActualCurrentYs,current),'Final waist Ys mismatch');
 const level=current.map((y,i)=>1000*(y-ys[i])),drift=current.map((y,i)=>1000*(y-released[i]));
 return{semanticInterfaceConfirmed:true,particles,semanticTargetYs:ys,firstFullyReleasedFrame:first.frame,firstFullyReleasedYs:released,firstFullyReleasedActualTargetYs:actualYs,firstFullyReleasedSourceAssemblyComplete:first.sourceAssemblyComplete,finalLevelFromSemanticTargetMm:level.reduce((a,b)=>a+b,0)/level.length,maxParticleLevelFromSemanticTargetMm:Math.max(...level.map(Math.abs)),releaseLevelDriftMm:drift.reduce((a,b)=>a+b,0)/drift.length,maxParticleReleaseLevelDriftMm:Math.max(...drift.map(Math.abs)),temporarySupportWeightsNonzero:final.temporarySupportWeightsNonzero,fixedAnchorWeightsNonzero:final.fixedAnchorWeightsNonzero};
}
