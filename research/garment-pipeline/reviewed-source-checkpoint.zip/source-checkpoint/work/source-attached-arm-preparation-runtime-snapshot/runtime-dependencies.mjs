/** Runtime snapshots and historical file observations have separate verification rules.
 * The historical manifest bytes are immutable lineage; their prior live paths are not imports. */
import fs from'node:fs';import path from'node:path';import assert from'node:assert/strict';import{createHash}from'node:crypto';
export const runtimeFileSha256=b=>createHash('sha256').update(b).digest('hex');
const sha=x=>typeof x==='string'&&/^[a-f0-9]{64}$/.test(x);
export function verifyRuntimeDependencyHierarchy(manifest,{readFile=fs.readFileSync}={}){
 assert.equal(manifest.kind,'owned-source-preparation-runtime-v1');
 assert(manifest.files&&Object.keys(manifest.files).length>0,'Actual runtime snapshots required');
 assert(manifest.historicalManifests&&Object.keys(manifest.historicalManifests).length>0,'Held historical manifest bytes required');
 for(const[label,pins]of[['runtime',manifest.files],['historical manifest bytes',manifest.historicalManifests]])for(const[p,h]of Object.entries(pins)){
  assert(path.isAbsolute(p)&&p.startsWith('/workspace/work/')&&sha(h),'Owned '+label+' pin required');
  assert.equal(runtimeFileSha256(readFile(p)),h,'Changed '+label+' '+p);
 }
 for(const[p,h]of Object.entries(manifest.historicalOriginalFileObservations??{}))assert(path.isAbsolute(p)&&sha(h),'Invalid historical file observation');
 const d=manifest.descriptorManifest;assert(d&&sha(d.sha256)&&manifest.files[d.path]===d.sha256,'Actual descriptor manifest must be runtime-pinned');
 return structuredClone(manifest);
}
