import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {Worker} from 'node:worker_threads';
import assert from 'node:assert/strict';
import {AvatarController,THREE,measureSourceSurfaceDimensions} from '/workspace/work/source-body6-calibration-owner-reseal-integration/compiled/avatar.js';
const root='/workspace/work/source-native-nape-hand-preserving-candidate-review',out=fileURLToPath(new URL('.',import.meta.url)),inputs={};
const read=path=>{const b=fs.readFileSync(path);inputs[path]=createHash('sha256').update(b).digest('hex');return b;};
const load=path=>JSON.parse(read(path)),pins=load(root+'/review-pins.json');
for(const p of pins.files)assert.equal(createHash('sha256').update(fs.readFileSync(p.path)).digest('hex'),p.sha256,p.path);
globalThis.fetch=async url=>new Response(read('/workspace/seamer-studio/vendor/body-model'+String(url)),{status:200});
const manifest=load('/workspace/work/source-physical-app-source169-owned-worker-export-attempt1/actual-seven-contexts/manifest.json'),model=load('/workspace/seamer-studio/vendor/body-model/models/base_model.json');
const local=fileURLToPath(new URL('.',import.meta.url));const modulePath=local+'compiled/assets/'+fs.readdirSync(local+'compiled/assets').find(n=>n.startsWith('sourceFit.worker-'));read(modulePath);
const closures=[];let created=0,terminated=0;const snapshots=[];
function factory(){
 const w=new Worker(new URL('./worker-shim.mjs',import.meta.url),{workerData:{moduleURL:pathToFileURL(modulePath).href}});created++;
 let resolveExit;const closed=new Promise(resolve=>resolveExit=resolve);closures.push(closed);w.on('exit',code=>{terminated++;resolveExit(code);});
 const facade={onmessage:null,onerror:null,postMessage(value,transfers){snapshots.push({id:value.id,inputVertexCount:value.input.vertices.length/3,sourceHeight:value.input.body.garmentCodeBody.measurementsCm.height,revision:value.revision,policy:value.policy,inputSha256:value.inputSha256});w.postMessage(value,transfers);},terminate(){return w.terminate();}};
 w.on('message',data=>facade.onmessage?.({data}));w.on('error',error=>facade.onerror?.({message:error.message}));return facade;
}
const rows=[];
try{
 for(const fixture of manifest.fixtures){
  const d=load(fixture.sourceExecutionFile),expected=load(root+'/candidate/'+fixture.id+'.json'),material=new THREE.MeshStandardMaterial();let avatar;
  try{
   const started=performance.now();avatar=await AvatarController.create(d.pattern.body,material,{sourceFitMode:'worker',sourceFitWorkerFactory:factory});
   const rest=avatar.skinnedAvatar.restVertices,posed=avatar.vertexPositions,triangles=avatar.indices;
   assert.deepEqual(new Uint32Array(rest.buffer,rest.byteOffset,rest.length),new Uint32Array(Float32Array.from(expected.restPositions).buffer));
   assert.deepEqual(new Uint32Array(posed.buffer,posed.byteOffset,posed.length),new Uint32Array(Float32Array.from(expected.bodyPositions).buffer));
   assert.deepEqual(Array.from(triangles),expected.bodyIndices);
   const identity=avatar.sourceBodyCalibrationIdentity;assert.equal(identity.revision,6);assert.ok(identity.fingerprint.match(/^[0-9a-f]{64}$/));
   const measured=measureSourceSurfaceDimensions(posed,triangles,model),source=d.pattern.body.garmentCodeBody.measurementsCm;
   const residuals=measured.arms.map(arm=>(arm.surfaceLengthM-source.arm_length/100)*1000);
   assert.ok(residuals.every(x=>Math.abs(x)<=.1));assert.ok(Math.abs((measured.shoulderWidthM-source.shoulder_w/100)*1000)<=.1);
   rows.push({id:fixture.id,sourceBodyCalibrationIdentity:identity,restByteExact:true,posedByteExact:true,topologyByteExact:true,actualCompiledWorkerUsed:true,elapsedMs:performance.now()-started,surfaceGeodesicResidualMm:residuals,shoulderWidthResidualMm:(measured.shoulderWidthM-source.shoulder_w/100)*1000});
   console.log(JSON.stringify(rows.at(-1)));
  }finally{avatar?.dispose();material.dispose();}
 }
}finally{await Promise.all(closures);}
assert.equal(created,7);assert.equal(terminated,7);
for(const[p,s]of Object.entries(inputs))assert.equal(createHash('sha256').update(fs.readFileSync(p)).digest('hex'),s,p);
for(const p of pins.files)assert.equal(createHash('sha256').update(fs.readFileSync(p.path)).digest('hex'),p.sha256,p.path);
fs.writeFileSync(out+'worker-equivalence.json',JSON.stringify({CPUOnly:true,GPUInitialized:false,browserLaunched:false,fitAccepted:false,scope:'Actual compiled browser source-fit worker compute executed in separate Node CPU isolates; actual AvatarController transport and final pose used; not measured browser latency',rows,createdWorkers:created,terminatedWorkers:terminated,requestSnapshots:snapshots,inputs},null,2)+'\n');
