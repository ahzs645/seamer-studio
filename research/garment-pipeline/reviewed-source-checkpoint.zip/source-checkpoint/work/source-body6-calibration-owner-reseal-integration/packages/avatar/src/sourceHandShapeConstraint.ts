import * as THREE from 'three';
import type { BaseModel } from '@seamer/body-model';
import { SkinnedAvatar } from './skinnedAvatar';
import type { MeasureSegmentDef } from './bodyMeasurements3d';

type Dyadic = { n: bigint; e: number };
const bits = new DataView(new ArrayBuffer(8));
function exact(v: number): Dyadic {
  if (!Number.isFinite(v)) throw new Error('Finite hand support operands required.');
  bits.setFloat64(0, v, true); const b = bits.getBigUint64(0, true), exponent = Number((b >> 52n) & 2047n);
  return { n: (b >> 63n ? -1n : 1n) * ((b & ((1n << 52n) - 1n)) + (exponent ? 1n << 52n : 0n)), e: exponent ? exponent - 1023 - 52 : -1074 };
}
function add(a: Dyadic, b: Dyadic): Dyadic { const e = Math.min(a.e, b.e); return { n: (a.n << BigInt(a.e - e)) + (b.n << BigInt(b.e - e)), e }; }
function projection(p: number[], axis: number[]): Dyadic { return p.map((v, k) => { const a = exact(v), b = exact(axis[k]); return { n: a.n * b.n, e: a.e + b.e }; }).reduce(add); }
function compare(a: Dyadic, b: Dyadic): number { const d = add(a, { n: -b.n, e: b.e }).n; return d < 0n ? -1 : d > 0n ? 1 : 0; }
const point = (v: Float32Array, id: number) => Array.from(v.subarray(id * 3, id * 3 + 3));

/** Protect complete ORIGINAL hand facets intersecting the exact distal halfspace.
 * All vertices of such facets are protected, including proximal vertices. No
 * rounded clipped-point theorem, arbitrary cube or small-weight threshold. */
export function sourceNativeHandProtection(v: Float32Array, indices: Uint32Array, skinIndices: Uint16Array, skinWeights: Float32Array, model: BaseModel, side: 'Left' | 'Right') {
  const defs = model.measurements as MeasureSegmentDef[], pairs = (model.symmetry as { pairs: number[][] }).pairs;
  const resolve = (name: string, ordinal: number) => {
    const a = defs.find(d => d.name === name)?.coordinates?.[ordinal];
    if (!a || !Number.isInteger(a.faceIndex) || a.faceIndex < 0 || a.faceIndex * 3 + 2 >= indices.length || ![a.u, a.v, a.w].every(x => x === 0 || x === 1) || a.u + a.v + a.w !== 1) throw new Error('Actual indexed hand/wrist definitions required.');
    const id = indices[a.faceIndex * 3 + (a.u === 1 ? 0 : a.v === 1 ? 1 : 2)];
    if (side === 'Right') return id; const pair = pairs.find(p => p.includes(id)); if (!pair) throw new Error('Actual native symmetry required.'); return pair[0] === id ? pair[1] : pair[0];
  };
  const support = [0, 1, 2].map(i => resolve('wristGirth', i)), wrist = resolve('armLength', 2), fold = [0, 1, 2].map(k => support.reduce((s, id) => s + v[id * 3 + k], 0) / support.length);
  const fore = model.bones.find(([name]) => name === 'mixamorig' + side + 'ForeArm')?.[1]; if (!fore) throw new Error('Native forearm proxy required.');
  const centre = [0, 1, 2].map(k => fore.indices.reduce((s, id, i) => s + fore.weights[i] * v[id * 3 + k], 0)), d = fold.map((x, k) => x - centre[k]), len = Math.hypot(...d); if (!(len > 0)) throw new Error('Native hand support axis degenerate.');
  const axis = d.map(x => x / len), anchors = [...support, wrist]; let maximum = projection(point(v, anchors[0]), axis);
  for (const id of anchors) { const q = projection(point(v, id), axis); if (compare(q, maximum) > 0) maximum = q; }
  const handNames = new Set(['mixamorig' + side + 'Hand']); for (let changed = true; changed;) { changed = false; for (const [name, b] of model.bones) if (b.parent && handNames.has(b.parent) && !handNames.has(name)) { handNames.add(name); changed = true; } }
  const boneIds = new Set(model.bones.flatMap(([name], i) => handNames.has(name) ? [i] : [])), hand = new Uint8Array(v.length / 3), signs = new Int8Array(v.length / 3);
  for (let id = 0; id < hand.length; id++) { for (let lane = 0; lane < 4; lane++) if (skinWeights[id * 4 + lane] !== 0 && boneIds.has(skinIndices[id * 4 + lane])) hand[id] = 1; signs[id] = compare(projection(point(v, id), axis), maximum); }
  const vertices = new Set<number>(anchors), faces: number[] = [], transitionFaces: number[] = [];
  for (let at = 0; at < indices.length; at += 3) { const tri = Array.from(indices.subarray(at, at + 3)); if (!tri.some(id => hand[id])) continue; if (tri.some(id => signs[id] > 0)) { faces.push(at / 3); for (const id of tri) vertices.add(id); } else transitionFaces.push(at / 3); }
  if (!faces.length) throw new Error('Complete native distal hand region absent.');
  return { vertices, faces, transitionFaces, wrist, support, axis, handBone: 'mixamorig' + side + 'Hand' };
}

/** Reference is freshly recomputed source5 numerical calibration of the same
 * authenticated model/body input. No saved mesh or garment coordinates enter. */
export function preserveSourceHandShape(fitted: Float32Array, reference: Float32Array, indices: Uint32Array, skinIndices: Uint16Array, skinWeights: Float32Array, model: BaseModel, source: Record<string, number>) {
  const material = new THREE.MeshBasicMaterial(), old = new SkinnedAvatar(model, indices, skinIndices, skinWeights, reference, material), out = fitted.slice();
  const reports: { iteration: number; maximumErrorM: number; rigidFloat32BoundM: number; protectedVertexCounts: number[] }[] = [];
  try {
    old.configureGarmentCodeAPose(source); old.setPose('A'); const referenceQ = old.positions.slice(), oldState = old.calibrationSkinMatrices();
    const protections = (['Left', 'Right'] as const).map(side => sourceNativeHandProtection(referenceQ, indices, skinIndices, skinWeights, model, side));
    let targets: Map<number, THREE.Vector3>[] | undefined;
    const transforms: { rotation: THREE.Matrix4; origin: THREE.Vector3; target: THREE.Vector3 }[] = [];
    for (let iteration = 0; iteration < 18; iteration++) {
      const current = new SkinnedAvatar(model, indices, skinIndices, skinWeights, out, material);
      try {
        current.configureGarmentCodeAPose(source); current.setPose('A'); const q = current.positions, state = current.calibrationSkinMatrices();
        if (!targets) targets = protections.map(p => {
          const i = state.boneNames.indexOf(p.handBone), j = oldState.boneNames.indexOf(p.handBone); if (i < 0 || j < 0) throw new Error('Actual hand pose frames absent.');
          const from = new THREE.Matrix4().fromArray(oldState.worlds[j]), to = new THREE.Matrix4().fromArray(state.worlds[i]); from.setPosition(0, 0, 0); to.setPosition(0, 0, 0); const rotation = to.multiply(from.invert());
          const origin = new THREE.Vector3(...point(referenceQ, p.wrist)), target = new THREE.Vector3(...point(q, p.wrist));
          transforms.push({ rotation, origin, target });
          return new Map([...p.vertices].map(id => [id, new THREE.Vector3(...point(referenceQ, id)).sub(origin).applyMatrix4(rotation).add(target)]));
        });
        for (const id of targets[0].keys()) if (targets[1].has(id)) throw new Error('Native hand protection regions overlap.');
        // Current-axis clipping can admit additional ORIGINAL facets. Retain
        // their full vertices monotonically and apply the same rigid target;
        // no final distal facet may escape the source5 shape constraint.
        for (let side = 0; side < 2; side++) {
          const actual = sourceNativeHandProtection(q, indices, skinIndices, skinWeights, model, side === 0 ? 'Left' : 'Right');
          const map = targets[side], transform = transforms[side];
          for (const id of actual.vertices) if (!map.has(id)) {
            const other = targets[1 - side]; if (other.has(id)) throw new Error('Native hand protection regions overlap.');
            protections[side].vertices.add(id);
            map.set(id, new THREE.Vector3(...point(referenceQ, id)).sub(transform.origin).applyMatrix4(transform.rotation).add(transform.target));
          }
        }
        let maximumError = 0, scale = 1;
        for (const map of targets) for (const [id, target] of map) { const actual = new THREE.Vector3(...point(q, id)); maximumError = Math.max(maximumError, actual.distanceTo(target)); scale = Math.max(scale, Math.abs(target.x), Math.abs(target.y), Math.abs(target.z)); }
        // Explicit numerical bound only: four F32 ulps per world-coordinate
        // lane, with a conservative Euclidean aggregation. No anatomical epsilon.
        const bound = 4 * 2 ** -23 * scale * Math.sqrt(3); reports.push({ iteration, maximumErrorM: maximumError, rigidFloat32BoundM: bound, protectedVertexCounts: protections.map(p => p.vertices.size) });
        if (maximumError <= bound) return { vertices: out, reports, authority: 'fresh-source5-complete-distal-original-facet-rigid-F32-v1' };
        for (const map of targets) for (const [id, target] of map) {
          const transform = new THREE.Matrix4().fromArray(state.blends[id]); if (!Number.isFinite(transform.determinant()) || transform.determinant() === 0) throw new Error('Hand skin blend is not invertible.');
          const rest = target.clone().applyMatrix4(transform.invert()); if (![rest.x, rest.y, rest.z].every(Number.isFinite)) throw new Error('Hand correction is not finite.'); out[id * 3] = rest.x; out[id * 3 + 1] = rest.y; out[id * 3 + 2] = rest.z;
        }
      } finally { current.dispose(); }
    }
    throw new Error('Complete distal hand rigid constraint did not converge within eighteen iterations.');
  } finally { old.dispose(); material.dispose(); }
}
