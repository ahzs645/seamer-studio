type Kind='Float32'|'Uint32'|'Uint16';
const U8=Uint8Array,U32=Uint32Array,F32=Float32Array,U16=Uint16Array;
const proto=Object.getPrototypeOf(U8.prototype),bufferGet=Object.getOwnPropertyDescriptor(proto,'buffer')!.get!,offsetGet=Object.getOwnPropertyDescriptor(proto,'byteOffset')!.get!,bytesGet=Object.getOwnPropertyDescriptor(proto,'byteLength')!.get!,lengthGet=Object.getOwnPropertyDescriptor(proto,'length')!.get!,set=proto.set;
const prototypes={Float32:F32.prototype,Uint32:U32.prototype,Uint16:U16.prototype};
const hooks:PropertyKey[]=['buffer','byteOffset','byteLength','length','slice','subarray','every','set','at','map','filter','reduce','constructor','toJSON',Symbol.iterator,Symbol.toStringTag];
export interface SourceTypedSeal { readonly value:Float32Array|Uint32Array|Uint16Array;readonly kind:Kind;readonly buffer:ArrayBuffer;readonly offset:number;readonly bytes:number;readonly length:number;readonly copy:Uint8Array }
function inspect(value:unknown,kind:Kind){
 if(!value||Object.getPrototypeOf(value)!==prototypes[kind])throw Error('Canonical source typed prototype required.');
 for(const key of hooks)if(Object.getOwnPropertyDescriptor(value,key))throw Error('Source typed hook rejected.');
 const buffer=bufferGet.call(value) as ArrayBuffer,offset=offsetGet.call(value) as number,bytes=bytesGet.call(value) as number,length=lengthGet.call(value) as number;
 if(!(buffer instanceof ArrayBuffer)||offset<0||bytes<0||offset+bytes>buffer.byteLength)throw Error('Source typed view domain invalid.');
 return{buffer,offset,bytes,length};
}
export function sourceTypedCopy<T extends Float32Array|Uint32Array|Uint16Array>(value:T,kind:Kind):T{const h=inspect(value,kind),copy=kind==='Float32'?new F32(h.length):kind==='Uint32'?new U32(h.length):new U16(h.length);set.call(new U8(copy.buffer),new U8(h.buffer,h.offset,h.bytes));Object.preventExtensions(copy);return copy as T;}
export function sealSourceTyped(value:Float32Array|Uint32Array|Uint16Array,kind:Kind):SourceTypedSeal{const h=inspect(value,kind);Object.preventExtensions(value);const copy=new U8(h.bytes);set.call(copy,new U8(h.buffer,h.offset,h.bytes));return{value,kind,...h,copy};}
export function sourceTypedCurrent(value:unknown,seal:SourceTypedSeal):boolean{try{if(value!==seal.value)return false;const h=inspect(value,seal.kind);if(h.buffer!==seal.buffer||h.offset!==seal.offset||h.bytes!==seal.bytes||h.length!==seal.length)return false;const actual=new U8(h.buffer,h.offset,h.bytes);for(let i=0;i<h.bytes;i++)if(actual[i]!==seal.copy[i])return false;return true;}catch{return false;}}
export function sourceTypedSame(a:unknown,b:SourceTypedSeal):boolean{try{const h=inspect(a,b.kind);if(h.bytes!==b.bytes||h.length!==b.length)return false;const actual=new U8(h.buffer,h.offset,h.bytes);for(let i=0;i<h.bytes;i++)if(actual[i]!==b.copy[i])return false;return true;}catch{return false;}}
export function sourceTypedBytes(value:Float32Array|Uint32Array|Uint16Array,kind:Kind):Uint8Array{const h=inspect(value,kind);return new U8(h.buffer,h.offset,h.bytes);}
