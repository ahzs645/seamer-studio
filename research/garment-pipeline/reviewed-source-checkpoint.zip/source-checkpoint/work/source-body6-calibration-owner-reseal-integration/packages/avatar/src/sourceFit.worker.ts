import { computeSourceFit, type SourceFitInput } from './sourceFitWorkerRuntime';
import { sourceFitInputIdentity, recordSourceFitIdentity, SOURCE_BODY_FIT_REVISION, SOURCE_BODY_CALIBRATION_POLICY } from './sourceCalibrationIdentity';
const scope = globalThis as unknown as {
  onmessage: ((event: MessageEvent<{ id: number; input: SourceFitInput; inputSha256:string;revision:number;policy:string }>) => void) | null;
  postMessage(value: unknown, transfers?: Transferable[]): void;
};
scope.onmessage = async event => {
  const { id, input, inputSha256, revision, policy } = event.data;
  try { if(revision!==SOURCE_BODY_FIT_REVISION||policy!==SOURCE_BODY_CALIBRATION_POLICY||inputSha256!==await sourceFitInputIdentity(input))throw Error('Source body Worker input identity mismatch.');const vertices = computeSourceFit(input);const identity=await recordSourceFitIdentity(vertices,inputSha256);scope.postMessage({ id, vertices,identity }, [vertices.buffer]); }
  catch (error) { scope.postMessage({ id, error: error instanceof Error ? error.message : 'Source fitting failed.' }); }
};
