import type { BaseModel } from '@seamer/body-model';
import type { SkinnedAvatar } from './skinnedAvatar';
/** Private state is installed only by the actual skinned owner constructor, never by a caller readiness flag. */
export interface SourceSkinInputs { model:BaseModel;rest:Float32Array;indices:Uint32Array;skinIndices:Uint16Array;skinWeights:Float32Array }
interface Mapping extends SourceSkinInputs { geometry:object;mesh:object;attributes:object;position:object;index:object;posed:Float32Array;skin:object;prototype:object;methods:Map<PropertyKey,PropertyDescriptor>;geometryPrototype:object;geometryMethods:Map<PropertyKey,PropertyDescriptor> }
const states=new WeakMap<object,Mapping>();
const geometryHooks:PropertyKey[]=['getAttribute','getIndex','setAttribute','setIndex'];
const hooks:PropertyKey[]=['positions','indices','calibrationSourceReferences','setPose','applyPose','setRestVertices','configureGarmentCodeAPose','configureAPoseAngle'];
function data(o:unknown,k:PropertyKey):unknown {if(!o||typeof o!=='object')throw Error('Source mapping object required');const d=Object.getOwnPropertyDescriptor(o,k);if(!d||!('value'in d))throw Error('Source mapping own data required');return d.value;}
function sameDescriptor(a:PropertyDescriptor|undefined,b:PropertyDescriptor){return !!a&&a.get===b.get&&a.set===b.set&&a.value===b.value&&a.writable===b.writable&&a.enumerable===b.enumerable&&a.configurable===b.configurable;}
/** Internal constructor hook: this module is not an exported app approval entry. Re-installing an existing owner is forbidden. */
export function initializeSourceSkinnedMappings(owner:SkinnedAvatar,inputs:SourceSkinInputs):void {
 if(states.has(owner))throw Error('Source mapping owner already captured');
 const geometry=data(owner,'geometry') as object,mesh=data(owner,'mesh') as object,attributes=data(geometry,'attributes') as object,position=data(attributes,'position') as object,index=data(geometry,'index') as object,skin=data(owner,'skin') as object,posed=data(position,'array') as Float32Array,prototype=Object.getPrototypeOf(owner),methods=new Map<PropertyKey,PropertyDescriptor>();
 for(const k of hooks){if(Object.getOwnPropertyDescriptor(owner,k))throw Error('Source skinned instance hook rejected');const d=Object.getOwnPropertyDescriptor(prototype,k);if(d)methods.set(k,d);}
 const geometryPrototype=Object.getPrototypeOf(geometry),geometryMethods=new Map<PropertyKey,PropertyDescriptor>();for(const k of geometryHooks){if(Object.getOwnPropertyDescriptor(geometry,k))throw Error('Source geometry method hook rejected');const d=Object.getOwnPropertyDescriptor(geometryPrototype,k);if(d)geometryMethods.set(k,d);}
 states.set(owner,{...inputs,geometry,mesh,attributes,position,index,skin,posed,prototype,methods,geometryPrototype,geometryMethods});
 if(!sourceSkinnedMappingsCurrent(owner,inputs)){states.delete(owner);throw Error('Actual source skin mappings invalid');}
}
export function sourceSkinnedMappingsCurrent(owner:SkinnedAvatar,inputs:SourceSkinInputs):boolean {
 try{const s=states.get(owner);if(!s||Object.getPrototypeOf(owner)!==s.prototype)return false;
 for(const k of hooks){if(Object.getOwnPropertyDescriptor(owner,k))return false;const d=s.methods.get(k);if(d&&!sameDescriptor(Object.getOwnPropertyDescriptor(s.prototype,k),d))return false;}
 if(Object.getPrototypeOf(s.geometry)!==s.geometryPrototype)return false;for(const k of geometryHooks){if(Object.getOwnPropertyDescriptor(s.geometry,k))return false;const d=s.geometryMethods.get(k);if(d&&!sameDescriptor(Object.getOwnPropertyDescriptor(s.geometryPrototype,k),d))return false;}
 return inputs.rest===s.rest&&inputs.model===s.model&&inputs.indices===s.indices&&inputs.skinIndices===s.skinIndices&&inputs.skinWeights===s.skinWeights&&data(owner,'geometry')===s.geometry&&data(owner,'mesh')===s.mesh&&data(s.mesh,'geometry')===s.geometry&&data(s.geometry,'attributes')===s.attributes&&data(s.attributes,'position')===s.position&&data(s.position,'array')===s.posed&&data(s.geometry,'index')===s.index&&data(s.index,'array')===s.indices&&data(owner,'baseModel')===s.model&&data(owner,'restVertices')===inputs.rest&&data(owner,'skin')===s.skin&&data(s.skin,'indices')===s.skinIndices&&data(s.skin,'weights')===s.skinWeights;
 }catch{return false;}
}
export function actualSourceSkinnedPositions(owner:SkinnedAvatar,inputs:SourceSkinInputs):Float32Array {if(!sourceSkinnedMappingsCurrent(owner,inputs))throw Error('Changed source body topology or mappings');return states.get(owner)!.posed;}
