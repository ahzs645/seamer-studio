/** Build-owned identity of the complete calibration/protocol sources. */
export const SOURCE_CALIBRATION_CODE_SHA256 = 'df72180a730a0fbac08272d85bd969405e434119fbe4e90103dd567109b5e849';
