import { sealSourceTyped, sourceTypedCurrent, sourceTypedCopy, type SourceTypedSeal } from './sourceTypedViews';
import type { SourceFitInput } from './sourceFitWorkerRuntime';
import { SOURCE_CALIBRATION_CODE_SHA256 } from './sourceCalibrationCodeIdentity';
export const SOURCE_BODY_FIT_REVISION = 6;
export const SOURCE_BODY_CALIBRATION_POLICY = 'native-posterior-nape+complete-distal-original-hand-facets-rigid-F32-v1';
export interface SourceFitCalibrationIdentity { revision:6; policy:string; codeSha256:string; inputSha256:string; restSha256:string; fingerprint:string }
export interface SourceBodyCalibrationIdentity extends SourceFitCalibrationIdentity { posedSha256:string; pose:string|null; fingerprint:string }
const fitted=new WeakMap<Float32Array,{identity:SourceFitCalibrationIdentity;seal:SourceTypedSeal}>();
const checkpoints=new WeakMap<object,()=>boolean>();
const typedPrototype=Object.getPrototypeOf(Uint8Array.prototype),typedBuffer=Object.getOwnPropertyDescriptor(typedPrototype,'buffer')!.get!,typedOffset=Object.getOwnPropertyDescriptor(typedPrototype,'byteOffset')!.get!,typedLength=Object.getOwnPropertyDescriptor(typedPrototype,'byteLength')!.get!;
const shaPattern=/^[0-9a-f]{64}$/;
/** Exact owned values: no JSON hooks, numeric normalization, user getters or buffers beyond the view. */
function encode(value:unknown,seen=new Set<object>()):string {
 if(value===null)return 'null';if(value===undefined)return 'undefined';
 if(typeof value==='string')return 'string:'+JSON.stringify(value);
 if(typeof value==='boolean')return value?'true':'false';
 if(typeof value==='number'){if(!Number.isFinite(value))throw Error('Finite calibration fields required');const v=new DataView(new ArrayBuffer(8));v.setFloat64(0,value,true);return 'f64:'+Array.from(new Uint8Array(v.buffer),n=>n.toString(16).padStart(2,'0')).join('');}
 if(typeof value!=='object')throw Error('Plain calibration data required');
 if(seen.has(value))throw Error('Cyclic calibration data rejected');seen.add(value);
 try{
  if(ArrayBuffer.isView(value)){const name=Object.getPrototypeOf(value)===Float32Array.prototype?'Float32':Object.getPrototypeOf(value)===Uint32Array.prototype?'Uint32':Object.getPrototypeOf(value)===Uint16Array.prototype?'Uint16':Object.getPrototypeOf(value)===Uint8Array.prototype?'Uint8':null;if(!name)throw Error('Known calibration typed arrays required');return name+':'+Array.from(new Uint8Array(typedBuffer.call(value),typedOffset.call(value),typedLength.call(value)),n=>n.toString(16).padStart(2,'0')).join('');}
  if(Object.getPrototypeOf(value)!==Object.prototype&&Object.getPrototypeOf(value)!==null&&!Array.isArray(value))throw Error('Plain calibration records required');
  const keys=Reflect.ownKeys(value);if(keys.some(k=>typeof k!=='string'))throw Error('Symbol calibration metadata rejected');
  return (Array.isArray(value)?'array:':'object:')+'{'+keys.map(k=>{const d=Object.getOwnPropertyDescriptor(value,k)!;if(!('value'in d))throw Error('Accessor calibration metadata rejected');return JSON.stringify(k)+':'+encode(d.value,seen);}).join(',')+'}';
 }finally{seen.delete(value);}
}
export async function hashSourceCalibrationValue(value:unknown):Promise<string>{const data=new TextEncoder().encode(encode(value));return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',data)),n=>n.toString(16).padStart(2,'0')).join('');}
export async function sourceFitInputIdentity(input:SourceFitInput):Promise<string>{return hashSourceCalibrationValue({revision:SOURCE_BODY_FIT_REVISION,policy:SOURCE_BODY_CALIBRATION_POLICY,codeSha256:SOURCE_CALIBRATION_CODE_SHA256,input});}
export async function recordSourceFitIdentity(vertices:Float32Array,inputSha256:string):Promise<SourceFitCalibrationIdentity>{
 if(!shaPattern.test(inputSha256))throw Error('Authentic calibration input digest required');
 const seal=sealSourceTyped(vertices,'Float32');const restSha256=await hashSourceCalibrationValue(sourceTypedCopy(vertices,'Float32'));const data={revision:6 as const,policy:SOURCE_BODY_CALIBRATION_POLICY,codeSha256:SOURCE_CALIBRATION_CODE_SHA256,inputSha256,restSha256};
 const identity=Object.freeze({...data,fingerprint:await hashSourceCalibrationValue(data)});if(!sourceTypedCurrent(vertices,seal))throw Error('Changed calibration rest during hashing');fitted.set(vertices,{identity,seal});return identity;
}
export function sourceFitIdentity(vertices:Float32Array){const value=fitted.get(vertices);if(!value||!sourceTypedCurrent(vertices,value.seal))throw Error('Executed source calibration rest identity absent or changed');return value.identity;}
export async function bindSourceBodyCalibrationIdentity(vertices:Float32Array,posed:Float32Array,pose:string|null,isCurrent:()=>boolean):Promise<SourceBodyCalibrationIdentity>{
 const fit=sourceFitIdentity(vertices),seal=sealSourceTyped(posed,'Float32'),owned=sourceTypedCopy(posed,'Float32');
 const samePose=()=>sourceTypedCurrent(posed,seal)&&sourceFitIdentityCurrent(vertices);
 const posedSha256=await hashSourceCalibrationValue(owned);if(!isCurrent()||!samePose())throw Error('Stale source body calibration');
 const data={...fit,posedSha256,pose};const identity=Object.freeze({...data,fingerprint:await hashSourceCalibrationValue(data)});if(!isCurrent()||!samePose())throw Error('Stale source body fingerprint');checkpoints.set(identity,()=>isCurrent()&&samePose());return identity;
}
export function currentSourceBodyCalibrationIdentity(value:unknown):value is SourceBodyCalibrationIdentity{return typeof value==='object'&&value!==null&&checkpoints.get(value)?.()===true;}

export function sourceFitIdentityCurrent(vertices:Float32Array):boolean{const state=fitted.get(vertices);return !!state&&sourceTypedCurrent(vertices,state.seal);}
