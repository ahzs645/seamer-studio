import { sourceTypedCopy, sourceTypedBytes } from './sourceTypedViews';
import { snapshotAvatarBody } from './bodySnapshot';
import { computeSourceFit, type SourceFitInput } from './sourceFitWorkerRuntime';
import { sourceFitInputIdentity, recordSourceFitIdentity, SOURCE_BODY_FIT_REVISION, SOURCE_BODY_CALIBRATION_POLICY } from './sourceCalibrationIdentity';
let sourceFitRequest = 0;
export type SourceFitMode = 'worker' | 'synchronous';
export interface SourceFitWorkerLike {
  postMessage(value: unknown, transfers?: Transferable[]): void;
  onmessage: ((event: MessageEvent<unknown>) => void) | null;
  onerror: ((event: ErrorEvent) => void) | null;
  terminate(): void;
}
export type SourceFitWorkerFactory = () => SourceFitWorkerLike;
export const sourceFitWorkerFactory: SourceFitWorkerFactory = () => new Worker(new URL('./sourceFit.worker.ts', import.meta.url), { type: 'module' });
/** Snapshot before any asynchronous work; transfer copies never detach caller geometry. */
export async function fitSourceInWorker(input: SourceFitInput, options: {
  mode?: SourceFitMode; signal?: AbortSignal; factory?: SourceFitWorkerFactory;
} = {}): Promise<Float32Array> {
  const snapshot = structuredClone({ ...input, body: snapshotAvatarBody(input.body) });
  const requestId = ++sourceFitRequest;
  const expectedLength = snapshot.vertices.length;
  if (options.signal?.aborted) return Promise.reject(new Error('Source body fitting was cancelled.'));
  const inputSha256 = await sourceFitInputIdentity(snapshot);
  if (options.signal?.aborted) throw new Error('Source body fitting was cancelled.');
  if (options.mode === 'synchronous') { const vertices = computeSourceFit(snapshot); await recordSourceFitIdentity(vertices,inputSha256); return vertices; }
  return new Promise((resolve, reject) => {
    let worker: SourceFitWorkerLike;
    try { worker = (options.factory ?? sourceFitWorkerFactory)(); }
    catch (error) { reject(new Error(`Source body worker could not start: ${String(error)}`)); return; }
    let done = false;
    const close = (error?: Error, vertices?: Float32Array) => {
      if (done) return; done = true; clearTimeout(timeout);
      options.signal?.removeEventListener('abort', abort);
      worker.onmessage = null; worker.onerror = null; worker.terminate();
      if (error) reject(error); else resolve(vertices!);
    };
    const abort = () => close(new Error('Source body fitting was cancelled.'));
    const timeout = setTimeout(() => close(new Error('Source body fitting exceeded its deadline.')), 60000);
    options.signal?.addEventListener('abort', abort, { once: true });
    worker.onerror = event => close(new Error(`Source body worker failed: ${event.message}`));
    worker.onmessage = async event => {
      const data = event.data as { id?: number; vertices?: unknown; error?: unknown; identity?: { revision?:number; policy?:string; inputSha256?:string; restSha256?:string; codeSha256?:string; fingerprint?:string } } | null;
      if(done)return;
      if (!data || data.id !== requestId) { close(new Error('Source body worker returned an invalid request binding.')); return; }
      if (typeof data.error === 'string') { close(new Error(data.error)); return; }
      let vertices:Float32Array;
      try{vertices=sourceTypedCopy(data.vertices as Float32Array,'Float32');const bytes=sourceTypedBytes(vertices,'Float32');if(bytes.byteLength!==expectedLength*4)throw Error('shape');for(let i=0;i<expectedLength;i++)if(!Number.isFinite(vertices[i]))throw Error('nonfinite');}
      catch{close(new Error('Source body worker returned invalid geometry.'));return;}
      try { const identity=await recordSourceFitIdentity(vertices,inputSha256);
        if(data.identity?.revision!==SOURCE_BODY_FIT_REVISION||data.identity.policy!==SOURCE_BODY_CALIBRATION_POLICY||data.identity.inputSha256!==inputSha256||data.identity.restSha256!==identity.restSha256||data.identity.codeSha256!==identity.codeSha256||data.identity.fingerprint!==identity.fingerprint)throw Error('Source body Worker calibration identity mismatch.');
        if(!done)close(undefined,vertices);
      }catch(error){close(error instanceof Error?error:new Error('Source body Worker identity failed.'));}
    };
    if (options.signal?.aborted) { abort(); return; }
    try { worker.postMessage({ id: requestId, input: snapshot, inputSha256, revision:SOURCE_BODY_FIT_REVISION, policy:SOURCE_BODY_CALIBRATION_POLICY }, [snapshot.vertices.buffer, snapshot.indices.buffer, snapshot.skinIndices.buffer, snapshot.skinWeights.buffer]); }
    catch (error) { close(new Error(`Source body worker request failed: ${String(error)}`)); }
  });
}
