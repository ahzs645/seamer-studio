import type { Pattern } from '@seamer/pattern-model';
import { activeGarmentCodeBody, currentSourceBodyCalibrationIdentity, SOURCE_BODY_FIT_REVISION, type SourceBodyCalibrationIdentity } from '@seamer/avatar';
export { SOURCE_BODY_FIT_REVISION };
import { GARMENT_CODE_ASSEMBLY_REVISION, GARMENT_CODE_SOURCE_STRETCH_POLICY, sourceStretchPolicyApplies, type SimData } from '@seamer/cloth-sim';
export { GARMENT_CODE_ASSEMBLY_REVISION, GARMENT_CODE_SOURCE_STRETCH_POLICY };

// Revision 6 additionally binds executed posterior-nape/distal-hand calibration and actual posed bytes.

/** Only newly captured geometry receives the policy that was actually baked for its piece. */
export function capturedSourceStretchPolicy(pieceId: string, policy: SimData['sourceStretchPolicy'] | null): string | undefined {
  return policy?.sourcePieceIds.some(id => id === pieceId || id === `${pieceId}#M`) ? policy.policy : undefined;
}

/** Source cache reuse needs actual accepted closed/released/free geometry, beyond an all-active
 * mask. The live simulation supplies this eligibility; absent proof never becomes true. */
export function capturedSourceAssemblyComplete(pieceId: string, policy: SimData['sourceStretchPolicy'] | null,
  complete: boolean | null): boolean | undefined {
  return capturedSourceStretchPolicy(pieceId, policy) ? complete === true : undefined;
}

/** Keep the original saved document intact, but do not seed a new body with incompatible cloth.
 * The next simulation/export writes a checkpoint for the current body fit and sewing assembly. */
export function compatibleSourceBodyCheckpoint(pattern: Pattern, identity?: SourceBodyCalibrationIdentity | null): Pattern {
  if (!pattern.garmentCodeSource || !activeGarmentCodeBody(pattern.body)) return pattern;
  let changed = false;
  const pieces = pattern.pieces.map(piece => {
    const saved = piece.settings3d.savedPositions;
    if (!saved.length) return piece;
    const validCache = Array.isArray(saved) && saved.length % 5 === 0 && saved.every(Number.isFinite);
    const originalSourcePiece = sourceStretchPolicyApplies(pattern, piece);
    const currentSourceAssembly = !originalSourcePiece || (
      piece.settings3d.savedAssemblyRevision === GARMENT_CODE_ASSEMBLY_REVISION
      && piece.settings3d.savedSourceStretchPolicy === GARMENT_CODE_SOURCE_STRETCH_POLICY
      && piece.settings3d.savedSourceAssemblyComplete === true);
    if (validCache && piece.settings3d.savedBodyFitRevision === SOURCE_BODY_FIT_REVISION
      && currentSourceBodyCalibrationIdentity(identity)
      && piece.settings3d.savedBodyCalibrationFingerprint === identity.fingerprint
      && piece.settings3d.savedBodyCalibrationPolicy === identity.policy
      && currentSourceAssembly) return piece;
    changed = true;
    return { ...piece, settings3d: { ...piece.settings3d, savedPositions: [], savedMeshSnapshot: undefined,
      savedDrapeState: 'checkpoint' as const, savedBodyFitRevision: SOURCE_BODY_FIT_REVISION,
      savedBodyCalibrationFingerprint: undefined, savedBodyCalibrationPolicy: undefined,
      ...(originalSourcePiece ? { savedAssemblyRevision: GARMENT_CODE_ASSEMBLY_REVISION,
        savedSourceStretchPolicy: GARMENT_CODE_SOURCE_STRETCH_POLICY, savedSourceAssemblyComplete: false } : {}) } };
  });
  return changed ? { ...pattern, pieces } : pattern;
}

/** Saving never promotes a caller hash or inactive/native body into source cache authority. */
export function capturedSourceBodyCalibration(identity: SourceBodyCalibrationIdentity | null | undefined): { savedBodyFitRevision: number; savedBodyCalibrationFingerprint: string; savedBodyCalibrationPolicy: string } {
 if (!currentSourceBodyCalibrationIdentity(identity)) throw new Error('Executed current source body calibration required.');
 return { savedBodyFitRevision: SOURCE_BODY_FIT_REVISION, savedBodyCalibrationFingerprint: identity.fingerprint, savedBodyCalibrationPolicy: identity.policy };
}
