import {parentPort,workerData} from 'node:worker_threads';
globalThis.self=globalThis;
globalThis.location={href:workerData.moduleURL};
globalThis.postMessage=(value,transfers)=>parentPort.postMessage(value,transfers);
await import(workerData.moduleURL);
parentPort.on('message',data=>globalThis.onmessage({data}));
