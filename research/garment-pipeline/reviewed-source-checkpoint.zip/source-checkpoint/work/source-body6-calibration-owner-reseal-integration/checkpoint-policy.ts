// Exact existing assembly/rest policy identities; body6 does not alter assembly semantics.
export { GARMENT_CODE_ASSEMBLY_REVISION } from '/workspace/seamer-studio/packages/cloth-sim/src/assembly';
export { GARMENT_CODE_SOURCE_STRETCH_POLICY, sourceStretchPolicyApplies } from '/workspace/seamer-studio/packages/cloth-sim/src/sourceStretchPolicy';
export type { SimData } from '/workspace/seamer-studio/packages/cloth-sim/src/build';
