export { AvatarController } from './packages/avatar/src/avatarController';
export { fitGarmentCodeAvatar } from './packages/avatar/src/garmentCodeFit';
export { SkinnedAvatar } from './packages/avatar/src/skinnedAvatar';
export * as THREE from 'three';

export { indexedSurfaceDistance, measureSourceSurfaceDimensions, fitSourceSurfaceDimensions } from './packages/avatar/src/sourceSurfaceDimensions';
export { triangleSurfaceGeodesic } from './packages/avatar/src/surfaceGeodesic';
export { surfaceAnchorVertices } from './packages/avatar/src/sourceSurfaceDimensions';

export {fitSourceInWorker} from './packages/avatar/src/sourceFitWorker';
export {computeSourceFit} from './packages/avatar/src/sourceFitWorkerRuntime';

export {snapshotAvatarBody} from './packages/avatar/src/bodySnapshot';

export {sourceNativeNapeAnchor} from './packages/avatar/src/garmentCodeFit';

export {sourceNativeHandProtection,preserveSourceHandShape} from './packages/avatar/src/sourceHandShapeConstraint';

export { SOURCE_BODY_FIT_REVISION, SOURCE_BODY_CALIBRATION_POLICY, currentSourceBodyCalibrationIdentity, hashSourceCalibrationValue } from './packages/avatar/src/sourceCalibrationIdentity';
export type { SourceBodyCalibrationIdentity } from './packages/avatar/src/sourceCalibrationIdentity';
export * from './src/lib/scene/sourceBodyCheckpoint';
