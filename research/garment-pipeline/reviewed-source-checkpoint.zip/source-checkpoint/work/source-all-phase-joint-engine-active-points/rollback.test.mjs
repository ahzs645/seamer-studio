import{bodyFacetFixture,selfIntervalFixture}from'./receipt-fixtures.mjs';
import{deltaByteFixture}from'./delta-byte-fixtures.mjs';
import{workerByteFixture}from'./worker-byte-fixtures.mjs';
import test from'node:test';import assert from'node:assert/strict';import fs from'node:fs';import{createRequire}from'node:module';
const require=createRequire('/workspace/seamer-studio/package.json'),ts=require('typescript');
let js=ts.transpileModule(fs.readFileSync('/workspace/work/source-all-phase-joint-engine-delta-commit/src/simulator.ts','utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText;
js=js.replace(/^import[\s\S]*?from\s+['"][^'"]+['"];\s*/gm,'').replaceAll('export ','');
const {ClothSimulation,CollisionSafetyError}=new Function(js+'\nreturn {ClothSimulation,CollisionSafetyError};')();
test('actual copied wrapper preserves genuine41/phase/delta candidates before destructive rollback and remains halted',async()=>{
 const x=Object.create(ClothSimulation.prototype),pose=Float32Array.of(0,1,0,2),trace=Array.from({length:41},(_,i)=>Float32Array.of(i*.0001,1,0,2)),delta=Array.from({length:41},(_,i)=>Float32Array.of(i*.0000001,0,0,0));
 const phases=[{substep:1,zeroBasedSubstep:0,stage:'support',positions:trace[1].slice()}];const expected=trace[40].slice(),expectedDelta=delta[40].slice();let destroyed=false,proofCalls=0;
 const activation={revision:2,activeSeams:Uint32Array.of(1),sewnUpTo:1};
 Object.assign(x,{stateGeneration:3,disposed:false,requestedActivation:activation,acceptedActivation:activation,acceptedSourceState:null,checkpointSourceComplete:false,checkpointMutation:0,grabActive:false,sourceController:null,latest:pose,simulationConfig:{subSteps:40},acceptedSourceDeltaTrace:[Float32Array.of(.125,0,0,0)]});
 x.guard={inspectTrajectory(candidate,previous,states,count,used){proofCalls++;assert.equal(count,40);assert.equal(states.length,41);assert.deepEqual(candidate,expected);assert.deepEqual(used,activation);return{safe:true,finite:true,sourceBodyFacetTrajectory:bodyFacetFixture(),sourceSelfIntervalTrajectory:selfIntervalFixture(),verifiedWorkerRequest:workerByteFixture(),verifiedPhysicalDeltaTrace:deltaByteFixture(),trajectory:{valid:true,expectedSubSteps:40,inspectedSubsteps:40}};}};
 x.sourceStateFor=()=>null;
 x.engine={setSeamActivation(){},captureAssemblySupport:()=>null,activeXYZAnchorCount:0,captureState:()=>({destroy(){destroyed=true;}}),async step(){throw Error('Source phase delta entire frame invalid: flags=1');},collisionTrajectoryPositions:trace,sourcePhysicalDeltaTrace:delta,collisionPhaseObservations:phases,gpuStageProfile:null,lastStepPerformance:null,
  restoreState(){trace.forEach(p=>p.fill(99));delta.forEach(p=>p.fill(88));phases[0].positions.fill(77);this.collisionTrajectoryPositions=[];this.sourcePhysicalDeltaTrace=[];this.collisionPhaseObservations=[];}};
 await assert.rejects(x.advanceFrame(3),e=>{
  assert(e instanceof CollisionSafetyError,e.name+': '+e.message);assert.deepEqual(e.candidatePositions,expected);assert.deepEqual(e.candidateTrajectory[40],expected);assert.deepEqual(e.candidatePhysicalDeltaTrace[40],expectedDelta);assert.equal(e.candidatePhases[0].positions[0],Math.fround(.0001));assert.match(e.candidateEngineFailure.message,/flags=1/);assert.equal(e.report.safe,true);return true;
 });
 assert.equal(x.sourcePhysicalDeltaTrace[0][0],.125);assert(x.safetyFailure instanceof CollisionSafetyError);assert.deepEqual(x.latest,pose);assert(destroyed);assert.equal(proofCalls,1);assert.equal(x.safetyFailure.candidateSeamActivation.revision,2);
});

test('actual ordinary Worker geometry rejection retains all41 raw delta slots through destructive rollback',async()=>{
 const x=Object.create(ClothSimulation.prototype),pose=Float32Array.of(0,1,0,2),trace=Array.from({length:41},(_,i)=>Float32Array.of(i*.0001,1,0,2)),delta=Array.from({length:41},(_,i)=>Float32Array.of(i*.0000001,-i*.0000002,0,0));
 const phases=[{substep:40,zeroBasedSubstep:39,stage:'final',positions:trace[40].slice()}],activation={revision:2,activeSeams:Uint32Array.of(1),sewnUpTo:1};const expected=trace[40].slice(),raw=delta.map(p=>p.slice());let destroyed=false,workerCalls=0;
 const report={safe:false,finite:true,bodyClosed:true,trajectory:{valid:true,expectedSubSteps:40,inspectedSubsteps:40}};
 Object.assign(x,{stateGeneration:3,disposed:false,requestedActivation:activation,acceptedActivation:activation,acceptedSourceState:null,checkpointSourceComplete:false,checkpointMutation:0,grabActive:false,sourceController:null,latest:pose,simulationConfig:{subSteps:40},acceptedSourceDeltaTrace:[Float32Array.of(.125,0,0,0)]});
 x.guard={};x.guardWorker={async inspectTrajectory(candidate,previous,states,count,used){workerCalls++;assert.deepEqual(candidate,expected);assert.equal(states.length,41);assert.equal(count,40);assert.deepEqual(previous,pose);assert.deepEqual(used,activation);return report;}};x.sourceStateFor=()=>null;
 x.engine={setSeamActivation(){},captureAssemblySupport:()=>null,activeXYZAnchorCount:0,captureState:()=>({destroy(){destroyed=true;}}),async step(){return trace[40];},collisionTrajectoryPositions:trace,sourcePhysicalDeltaTrace:delta,collisionPhaseObservations:phases,gpuStageProfile:null,lastStepPerformance:null,
 restoreState(){trace.forEach(p=>p.fill(99));delta.forEach(p=>p.fill(88));phases[0].positions.fill(77);this.collisionTrajectoryPositions=[];this.sourcePhysicalDeltaTrace=[];this.collisionPhaseObservations=[];}};
 await assert.rejects(x.advanceFrame(),e=>{assert(e instanceof CollisionSafetyError);assert.equal(e.candidateEngineFailure,null);assert.equal(e.candidatePhysicalDeltaTrace.length,41);e.candidatePhysicalDeltaTrace.forEach((p,i)=>assert.deepEqual(p,raw[i]));assert.deepEqual(e.candidateTrajectory[40],expected);assert.deepEqual(e.candidatePositions,expected);assert.equal(e.report,report);return true;});
 assert.equal(workerCalls,1);assert(destroyed);assert.equal(x.safetyFailure.candidatePhysicalDeltaTrace.length,41);assert.deepEqual(x.latest,pose);assert.equal(x.sourcePhysicalDeltaTrace[0][0],.125);
});
test('actual static/reset geometric rejection does not attach previous successful raw delta',()=>{
 const x=Object.create(ClothSimulation.prototype);x.engine={sourcePhysicalDeltaTrace:[Float32Array.of(777,0,0,0)]};x.requestedActivation=null;assert.throws(()=>x.acceptSafetyReport({safe:false},Float32Array.of(0,1,0,2)),e=>{assert(e instanceof CollisionSafetyError);assert.equal(e.candidatePhysicalDeltaTrace,null);assert.equal(e.candidateTrajectory,null);return true;});
});
