import{deltaByteFixture}from'./delta-byte-fixtures.mjs';
import{workerByteFixture}from'./worker-byte-fixtures.mjs';
import test from 'node:test';import assert from 'node:assert/strict';
import {SourceDeltaLedger} from './ledger.mjs';
const pose=()=>new Float32Array([0,1,0,2,0,2,0,0]);
const raw=x=>new Float32Array([x,0,0,0,0,0,0,0]);
test('tiny pre-world-add increments survive packed world equality',()=>{
 const l=new SourceDeltaLedger(2);l.beginFrame(7);l.beginPhysical(0,pose());
 const d=Math.fround(1e-9);assert.equal(Math.fround(1+d),1);
 l.accumulate('material',raw(d));assert.equal(l.consume(.0004)[0],Math.fround(d/.0004));
});
test('joint relinearizations replace contact response at immutable same parent',()=>{
 const l=new SourceDeltaLedger(2);l.beginFrame(4);l.beginPhysical(0,pose());l.accumulate('sewing',raw(.001));l.replaceContact(raw(.003),4,0);l.replaceContact(raw(.002),4,0);
 assert.equal(l.consume(1)[0],Math.fround(Math.fround(.001)+Math.fround(.002)));
});
test('all40 physical boundaries reset once, consumption occurs once and full proof publishes',()=>{
 const l=new SourceDeltaLedger(2);l.beginFrame(8);
 for(let s=0;s<40;s++){l.beginPhysical(s,pose());l.accumulate('prediction',raw(.001));assert.equal(l.consume(1)[0],Math.fround(.001));assert.throws(()=>l.consume(1));}
 assert.throws(()=>l.accept({safe:true,finite:false,generation:8,states:41}));l.accept({safe:true,finite:true,generation:8,states:41});assert.equal(l.state,'idle');
});
test('whole frame rejection restores previous private raw delta and generation',()=>{
 const l=new SourceDeltaLedger(2);l.delta[0]=.04;l.contact[0]=.02;const d=l.delta.slice(),c=l.contact.slice();l.beginFrame(9);l.beginPhysical(0,pose());l.accumulate('support',raw(.002));l.rollback();assert.deepEqual(l.delta,d);assert.deepEqual(l.contact,c);assert.equal(l.generation,0);
});
test('wrong generation/substep/mobility/units cannot contaminate pending raw state',()=>{
 const l=new SourceDeltaLedger(2);l.beginFrame(2);l.beginPhysical(0,pose());
 assert.throws(()=>l.replaceContact(raw(.1),1,0));assert.throws(()=>l.replaceContact(raw(.1),2,1));
 const bad=raw(0);bad[4]=1;assert.throws(()=>l.accumulate('material',bad));assert.throws(()=>l.accumulate('unowned',raw(0)));bad.fill(0);bad[3]=1;assert.throws(()=>l.accumulate('support',bad));assert.deepEqual(l.delta,new Float32Array(8));
});
