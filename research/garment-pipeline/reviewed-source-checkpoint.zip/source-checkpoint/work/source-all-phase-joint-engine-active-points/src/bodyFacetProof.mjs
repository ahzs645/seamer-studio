import {BODY_FACET_POLICY} from './bodyFacetClearance.mjs';
/** Structural proof binding only; the real Worker/context/q41 provides origin. */
export function requireSourceBodyFacetTrajectoryProof(report){
 const p=report.sourceBodyFacetTrajectory;
 if(!p||p.policy!==BODY_FACET_POLICY||p.physicalClearanceM!==.001||p.interpolation!=='piecewise-linear'||
  p.expectedSubsteps!==40||p.inspectedSubsteps!==40||p.clear!==true||p.selfContinuousCertified!==false||
  !Number.isSafeInteger(p.candidateBodyPairs)||p.candidateBodyPairs<0||!Number.isSafeInteger(p.intervalsChecked)||
  p.intervalsChecked<p.candidateBodyPairs||p.firstUnresolvedSubstep!==undefined||p.firstUnresolvedPair!==undefined)
  throw new Error('Missing complete actual source body-facet trajectory clearance proof');
 return structuredClone(p);
}
