import type {CollisionGuardReport} from './collisionGuard';
export function requireSourceBodyFacetTrajectoryProof(report:CollisionGuardReport):NonNullable<CollisionGuardReport['sourceBodyFacetTrajectory']>;
