/** Conservative positive body clearance over the DECLARED linear interval.
 * A fixed projection axis separates the ENTIRE swept triangles, not samples.
 * Subdivision only finds additional separating axes; exhausted budgets reject.
 * This is a geometry screen, not a solver or proof of unrecorded solver paths.
 */
export const BODY_FACET_POLICY = 'source-body-facet-linear-1mm-separating-axis-v1';
const EPS = Number.EPSILON;
const sub = (a,b) => a.map((x,i) => x-b[i]);
const cross = (a,b) => [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const norm = a => Math.hypot(...a);
const dot = (a,b) => a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
const lerp = (a,b,t) => a.map((x,i) => x+(b[i]-x)*t);
function triangle(value) {
 if (!Array.isArray(value) || value.length!==3 || value.some(v => !Array.isArray(v)||v.length!==3||v.some(x=>!Number.isFinite(x)||Math.abs(x)>32)))
  throw Error('Finite triangle coordinates within explicit 32m arithmetic domain required');
 return value.map(v=>v.slice());
}
const edges = t => [sub(t[1],t[0]),sub(t[2],t[1]),sub(t[0],t[2])];
function axes(a,b) {
 const ea=edges(a),eb=edges(b),candidates=[[1,0,0],[0,1,0],[0,0,1],cross(ea[0],ea[1]),cross(eb[0],eb[1])];
 for(const x of ea)for(const y of eb)candidates.push(cross(x,y));
 for(const x of a)for(const y of b)candidates.push(sub(x,y));
 // Extra directions improve completeness near finite vertex/edge features.
 // They carry no distance authority: only full projected swept bounds certify.
 for(const [vertices,other] of [[a,b],[b,a]])for(const point of vertices)for(let j=0;j<3;j++) {
  const origin=other[j],edge=sub(other[(j+1)%3],origin),squared=dot(edge,edge);
  if(squared>0){const t=Math.max(0,Math.min(1,dot(sub(point,origin),edge)/squared));
   candidates.push(sub(point,origin.map((v,i)=>v+edge[i]*t)));}
 }
 return candidates.flatMap(v=>{const n=norm(v);return n>0&&Number.isFinite(n)?[v.map(x=>x/n)]:[];});
}
function separatingBound(first,last,body,left,right,clearance) {
 const lo=first.map((p,i)=>lerp(p,last[i],left)),hi=first.map((p,i)=>lerp(p,last[i],right));
 const middle=first.map((p,i)=>lerp(p,last[i],(left+right)/2));
 const scale=Math.max(clearance,...first.flat().map(Math.abs),...last.flat().map(Math.abs),...body.flat().map(Math.abs));
 // Covers endpoint interpolation, projection subtraction and norm rounding.
 // It subtracts evidence from clearance; it never permits penetration.
 const arithmeticMargin=256*EPS*scale;
 let best=-Infinity;
 for(const axis of axes(middle,body)) {
  const moving=[...lo,...hi].map(p=>dot(p,axis)),fixed=body.map(p=>dot(p,axis));
  const gap=Math.max(Math.min(...moving)-Math.max(...fixed),Math.min(...fixed)-Math.max(...moving));
  const lower=(gap-arithmeticMargin)/(norm(axis)*(1+16*EPS));
  best=Math.max(best,lower);
 }
 return best;
}
export function certifyMovingTriangleBodyClearance(input) {
 const first=triangle(input.first),last=triangle(input.last),body=triangle(input.body);
 const clearance=input.clearanceM??.001,maxDepth=input.maxDepth??20,maxIntervals=input.maxIntervals??4096;
 if(clearance!==.001||!Number.isSafeInteger(maxDepth)||maxDepth<0||maxDepth>24||!Number.isSafeInteger(maxIntervals)||maxIntervals<1||maxIntervals>65536)
  throw Error('Exact 1mm physical clearance and bounded conservative interval policy required');
 const stack=[[0,1,0]],result={policy:BODY_FACET_POLICY,accepted:false,intervalsChecked:0,certifiedIntervals:0,
  minimumCertifiedLowerBoundM:Infinity,unresolvedInterval:null,interpolation:'piecewise-linear',
  physicalClearanceM:clearance,maximumDepth:maxDepth,maximumIntervals:maxIntervals};
 while(stack.length) {
  const [left,right,depth]=stack.pop();
  if(result.intervalsChecked>=maxIntervals){result.unresolvedInterval=[left,right];return result;}
  result.intervalsChecked++;
  const lower=separatingBound(first,last,body,left,right,clearance);
  if(lower>=clearance){result.certifiedIntervals++;result.minimumCertifiedLowerBoundM=Math.min(result.minimumCertifiedLowerBoundM,lower);continue;}
  // A nonseparated midpoint is not classified as penetration; it rejects as
  // unresolved unless further interval separation supplies a positive proof.
  if(depth===maxDepth){result.unresolvedInterval=[left,right];return result;}
  const middle=(left+right)/2;
  stack.push([middle,right,depth+1],[left,middle,depth+1]);
 }
 result.accepted=true;return result;
}

const bounds = points => [0,1,2].map(i=>Math.min(...points.map(p=>p[i]))).concat([0,1,2].map(i=>Math.max(...points.map(p=>p[i]))));
function overlap(a,b,pad){return [0,1,2].every(i=>a[i]<=b[i+3]+pad&&b[i]<=a[i+3]+pad);}
function tree(faces) {
 if(!faces.length)return null;
 const box=[0,1,2].map(i=>Math.min(...faces.map(f=>f.bounds[i]))).concat([0,1,2].map(i=>Math.max(...faces.map(f=>f.bounds[i+3]))));
 if(faces.length<=8)return{bounds:box,faces};
 let axis=0;for(let i=1;i<3;i++)if(box[i+3]-box[i]>box[axis+3]-box[axis])axis=i;
 const sorted=faces.slice().sort((a,b)=>a.bounds[axis]+a.bounds[axis+3]-b.bounds[axis]-b.bounds[axis+3]),mid=sorted.length>>1;
 return{bounds:box,left:tree(sorted.slice(0,mid)),right:tree(sorted.slice(mid))};
}
function query(node,box,pad,visit){
 if(!node||!overlap(node.bounds,box,pad))return;
 if(node.faces){for(const f of node.faces)if(overlap(f.bounds,box,pad))visit(f);}
 else{query(node.left,box,pad,visit);query(node.right,box,pad,visit);}
}
function indices(values,stride,count){
 if(!Number.isSafeInteger(stride)||stride<3||values.length%stride)throw Error('Invalid facet stride');
 const result=[];for(let i=0;i<values.length;i+=stride){const ids=[values[i],values[i+1],values[i+2]];
  if(new Set(ids).size!==3||ids.some(v=>!Number.isSafeInteger(v)||v<0||v>=count))throw Error('Invalid facet IDs');result.push(ids);}
 return result;
}
const read = (values,id,stride) => [values[id*stride],values[id*stride+1],values[id*stride+2]];
export class SourceBodyFacetClearanceGuard {
 #cloth;#bodyTree;#count;#maximumDepth;#maximumIntervals;
 constructor(input,options={}) {
  const stride=input.bodyPositionStride??3;
  if(!Number.isSafeInteger(stride)||stride<3||input.bodyPositions.length%stride||!Number.isSafeInteger(input.particleCount)||input.particleCount<1)
   throw Error('Invalid immutable source-body facet context');
  const faces=indices(input.bodyIndices,input.bodyTriangleStride??3,input.bodyPositions.length/stride).map((ids,id)=>{
   const points=triangle(ids.map(v=>read(input.bodyPositions,v,stride)));return{id,points,bounds:bounds(points)};
  });
  if(!faces.length)throw Error('Body facets required');
  this.#cloth=indices(input.clothTriangles,input.clothTriangleStride??4,input.particleCount);
  if(!this.#cloth.length)throw Error('Cloth facets required');
  this.#bodyTree=tree(faces);this.#count=input.particleCount;
  this.#maximumDepth=options.maxDepth??20;this.#maximumIntervals=options.maxIntervals??4096;
  if(!Number.isSafeInteger(this.#maximumDepth)||this.#maximumDepth<0||this.#maximumDepth>24||
   !Number.isSafeInteger(this.#maximumIntervals)||this.#maximumIntervals<1||this.#maximumIntervals>65536)throw Error('Invalid interval budgets');
 }
 inspect(first,last) {
  if(!(first instanceof Float32Array)||!(last instanceof Float32Array)||first.length!==this.#count*4||last.length!==first.length||
   first.some(x=>!Number.isFinite(x))||last.some(x=>!Number.isFinite(x)))throw Error('Actual finite Float32 vec4 source boundaries required');
  const firstBits=new Uint32Array(first.buffer,first.byteOffset,first.length),lastBits=new Uint32Array(last.buffer,last.byteOffset,last.length);
  for(let p=0;p<this.#count;p++)if(firstBits[p*4+3]!==lastBits[p*4+3]||first[p*4+3]<0)
   throw Error('Exact unchanged physical inverse-mass bits required');
  const result={policy:BODY_FACET_POLICY,accepted:true,clothFacesChecked:0,candidateBodyPairs:0,intervalsChecked:0,
   unresolvedPair:null,physicalClearanceM:.001,interpolation:'piecewise-linear',selfFacetClearanceCertified:false};
  for(let face=0;face<this.#cloth.length;face++) {
   const a=this.#cloth[face].map(id=>read(first,id,4)),b=this.#cloth[face].map(id=>read(last,id,4));
   triangle(a);triangle(b);const box=bounds([...a,...b]);result.clothFacesChecked++;
   query(this.#bodyTree,box,.001+256*EPS*32,body=>{
    if(!result.accepted)return;
    result.candidateBodyPairs++;
    const proof=certifyMovingTriangleBodyClearance({first:a,last:b,body:body.points,maxDepth:this.#maximumDepth,maxIntervals:this.#maximumIntervals});
    result.intervalsChecked+=proof.intervalsChecked;
    if(!proof.accepted){result.accepted=false;result.unresolvedPair={clothFace:face,bodyFace:body.id,interval:proof.unresolvedInterval};}
   });
   if(!result.accepted)break;
  }
  return result;
 }
}
