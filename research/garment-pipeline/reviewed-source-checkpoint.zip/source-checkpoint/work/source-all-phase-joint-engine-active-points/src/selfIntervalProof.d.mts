import type {CollisionGuardReport} from './collisionGuard';
export function requireSourceSelfIntervalTrajectoryProof(report:CollisionGuardReport):NonNullable<CollisionGuardReport['sourceSelfIntervalTrajectory']>;
