export const SELF_INTERVAL_POLICY:'source-self-linear-outward-interval-v1';
