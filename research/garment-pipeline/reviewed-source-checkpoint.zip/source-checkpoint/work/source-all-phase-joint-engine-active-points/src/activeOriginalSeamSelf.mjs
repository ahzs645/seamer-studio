// Conservative zero-thickness self separation for declared linear motion.
// Every arithmetic bound uses outward rounding; sampled axes only propose proofs.
export const SELF_INTERVAL_POLICY='source-self-linear-outward-interval-v1';
const bits=new DataView(new ArrayBuffer(8));
function next(x,up){
 if(Number.isNaN(x)||x===(up?Infinity:-Infinity))return x;
 if(x===0)return up?Number.MIN_VALUE:-Number.MIN_VALUE;
 bits.setFloat64(0,x,false);let u=bits.getBigUint64(0,false);
 u+=(x>0)===up?1n:-1n;bits.setBigUint64(0,u,false);return bits.getFloat64(0,false);
}
const I=x=>[x,x], add=(a,b)=>[next(a[0]+b[0],false),next(a[1]+b[1],true)],
 neg=a=>[-a[1],-a[0]], sub=(a,b)=>add(a,neg(b));
function mul(a,b){const p=[a[0]*b[0],a[0]*b[1],a[1]*b[0],a[1]*b[1]];return[next(Math.min(...p),false),next(Math.max(...p),true)];}
const vsub=(a,b)=>a.map((x,k)=>sub(x,b[k])),
 dot=(a,b)=>a.reduce((s,x,k)=>add(s,mul(x,b[k])),I(0)),
 cross=(a,b)=>[sub(mul(a[1],b[2]),mul(a[2],b[1])),sub(mul(a[2],b[0]),mul(a[0],b[2])),sub(mul(a[0],b[1]),mul(a[1],b[0]))];
const exactVec=v=>v.map(I), pointAt=(a,b,t)=>a.map((x,k)=>add(I(x),mul(sub(I(b[k]),I(x)),t)));
const rawSub=(a,b)=>a.map((v,k)=>v-b[k]), rawCross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],
 mid=(a,b)=>a.map((v,k)=>(v+b[k])/2);
function candidates(first,last,targetFirst,targetLast){
 const a=first.map((v,k)=>mid(v,last[k])),b=targetFirst.map((v,k)=>mid(v,targetLast[k]));
 const ae=a.map((v,k)=>rawSub(a[(k+1)%3],v)),be=b.map((v,k)=>rawSub(b[(k+1)%3],v));
 const an=rawCross(ae[0],ae[1]),bn=rawCross(be[0],be[1]),axes=[[1,0,0],[0,1,0],[0,0,1],an,bn];
 for(const e of [...ae,...be])axes.push(rawCross(an,e),rawCross(bn,e));
 for(const u of ae)for(const v of be)axes.push(rawCross(u,v));
 for(const u of a)for(const v of b)axes.push(rawSub(u,v));
 return axes.filter(v=>v.every(Number.isFinite)&&v.some(x=>x!==0)).map(exactVec);
}
function boundSeparated(a,b,axes){
 for(const axis of axes){const ap=a.map(v=>dot(v,axis)),bp=b.map(v=>dot(v,axis));
  if(Math.max(...ap.map(v=>v[1]))<Math.min(...bp.map(v=>v[0]))||Math.max(...bp.map(v=>v[1]))<Math.min(...ap.map(v=>v[0])))return true;
 }return false;
}
function sharedCornerSeparated(a,b,ai,bi,axes){
 // The shared trajectory is exactly the same indexed point. Its projection cancels.
 const ar=a.filter((_,k)=>k!==ai).map(v=>vsub(v,a[ai])),br=b.filter((_,k)=>k!==bi).map(v=>vsub(v,b[bi]));
 for(const axis of axes){const ap=ar.map(v=>dot(v,axis)),bp=br.map(v=>dot(v,axis));
  if(ap.every(v=>v[0]>0)&&bp.every(v=>v[1]<0)||ap.every(v=>v[1]<0)&&bp.every(v=>v[0]>0))return true;
 }return false;
}
function sharedEdgeSeparated(first,last,targetFirst,targetLast,ids,targetIds,shared,t){
 // Algebraic axis(t) is perpendicular to the EXACT shared edge at every t.
 // Its polynomial sign is enclosed by outward interval arithmetic on t.
 // Unlike an approximate fixed plane, it needs no equality tolerance.
 const ia=ids.indexOf(shared[0]),ib=ids.indexOf(shared[1]),ja=targetIds.indexOf(shared[0]);
 const ua=ids.findIndex(id=>!shared.includes(id)),ub=targetIds.findIndex(id=>!shared.includes(id));
 const p=pointAt(first[ia],last[ia],t),e=vsub(pointAt(first[ib],last[ib],t),p),
  a=vsub(pointAt(first[ua],last[ua],t),p),b=vsub(pointAt(targetFirst[ub],targetLast[ub],t),pointAt(targetFirst[ja],targetLast[ja],t));
 const axis=cross(e,cross(e,vsub(a,b))),da=dot(axis,a),db=dot(axis,b);
 return da[0]>0&&db[1]<0||da[1]<0&&db[0]>0;
}
function validateTriangle(p){return Array.isArray(p)&&p.length===3&&p.every(v=>Array.isArray(v)&&v.length===3&&v.every(x=>Number.isFinite(x)&&Math.abs(x)<=32));}
export function certifyMovingSelfTriangles({first,last,targetFirst,targetLast,ids,targetIds,maxDepth=20,maxIntervals=4096}){
 if(![first,last,targetFirst,targetLast].every(validateTriangle)||!Array.isArray(ids)||!Array.isArray(targetIds)||ids.length!==3||targetIds.length!==3||
  [...ids,...targetIds].some(x=>!Number.isSafeInteger(x)||x<0)||new Set(ids).size!==3||new Set(targetIds).size!==3||
  !Number.isSafeInteger(maxDepth)||maxDepth<0||maxDepth>24||!Number.isSafeInteger(maxIntervals)||maxIntervals<1||maxIntervals>65536)throw Error('Invalid self interval input');
 const shared=ids.filter(id=>targetIds.includes(id));
 for(const id of shared){const a=ids.indexOf(id),b=targetIds.indexOf(id);if(first[a].some((v,k)=>!Object.is(v,targetFirst[b][k]))||last[a].some((v,k)=>!Object.is(v,targetLast[b][k])))throw Error('Shared index has inconsistent trajectory');}
 const axes=candidates(first,last,targetFirst,targetLast);
 if(shared.length===1){
  const ai=ids.indexOf(shared[0]),bi=targetIds.indexOf(shared[0]),p=mid(first[ai],last[ai]);
  const units=(f,l,omit)=>f.filter((_,k)=>k!==omit).map((_,j)=>{const k=[0,1,2].filter(k=>k!==omit)[j],v=rawSub(mid(f[k],l[k]),p),n=Math.hypot(...v);return n>0?v.map(x=>x/n):[0,0,0];});
  const a=units(first,last,ai),b=units(targetFirst,targetLast,bi),sum=v=>[0,1,2].map(k=>v.reduce((s,p)=>s+p[k],0));
  const n=rawSub(sum(a),sum(b));if(n.every(Number.isFinite)&&n.some(v=>v!==0))axes.push(exactVec(n));
  // A deterministic numerical proposal for narrow separating cones. Its output
  // is accepted ONLY by the outward all-time projection proof above.
  const directions=[...a,...b.map(v=>v.map(x=>-x))];let proposal=n.slice();
  for(let iteration=0;iteration<64;iteration++){
   let changed=false;for(const v of directions){const d=v.reduce((s,x,k)=>s+x*proposal[k],0),norm=v.reduce((s,x)=>s+x*x,0);
    if(d<1&&norm>0){proposal=proposal.map((x,k)=>x+(1-d)/norm*v[k]);changed=true;}}
   if(!changed)break;
  }
  if(proposal.every(Number.isFinite)&&proposal.some(v=>v!==0))axes.push(exactVec(proposal));
 }
 let intervalsChecked=0,certifiedIntervals=0;
 const pending=[{t:[0,1],depth:0}];
 while(pending.length){const {t,depth}=pending.pop();
  if(intervalsChecked>=maxIntervals)return{clear:false,intervalsChecked,certifiedIntervals,unresolvedInterval:t,reason:'interval-budget'};
  intervalsChecked++;
  const a=first.map((v,k)=>pointAt(v,last[k],t)),b=targetFirst.map((v,k)=>pointAt(v,targetLast[k],t));
  const proved=shared.length===0?boundSeparated(a,b,axes):shared.length===1?sharedCornerSeparated(a,b,ids.indexOf(shared[0]),targetIds.indexOf(shared[0]),axes):
   shared.length===2?sharedEdgeSeparated(first,last,targetFirst,targetLast,ids,targetIds,shared,t):false;
  if(proved){certifiedIntervals++;continue;}
  if(depth>=maxDepth||shared.length===3)return{clear:false,intervalsChecked,certifiedIntervals,unresolvedInterval:t,reason:shared.length===3?'duplicate-face':'unresolved-separation'};
  const m=(t[0]+t[1])/2;pending.push({t:[m,t[1]],depth:depth+1},{t:[t[0],m],depth:depth+1});
 }
 return{clear:true,intervalsChecked,certifiedIntervals};
}
const bounds=(first,last)=>({lo:[0,1,2].map(k=>Math.min(...first.map(v=>v[k]),...last.map(v=>v[k]))),hi:[0,1,2].map(k=>Math.max(...first.map(v=>v[k]),...last.map(v=>v[k])))});
const overlap=(a,b)=>a.lo.every((v,k)=>v<=b.hi[k]&&a.hi[k]>=b.lo[k]);
function tree(rows){
 const box={lo:[0,1,2].map(k=>Math.min(...rows.map(v=>v.box.lo[k]))),hi:[0,1,2].map(k=>Math.max(...rows.map(v=>v.box.hi[k])))};
 if(rows.length<=8)return{box,rows};
 const spans=box.hi.map((v,k)=>v-box.lo[k]),axis=spans.indexOf(Math.max(...spans));rows.sort((a,b)=>(a.box.lo[axis]+a.box.hi[axis])-(b.box.lo[axis]+b.box.hi[axis])||a.face-b.face);
 const m=Math.floor(rows.length/2);return{box,left:tree(rows.slice(0,m)),right:tree(rows.slice(m))};
}
export class SourceSelfIntervalGuard{
 #count;#faces;#options;
 constructor({particleCount,clothTriangles,clothTriangleStride=4},{maxDepth=20,maxIntervals=4096}={}){
  if(!Number.isSafeInteger(particleCount)||particleCount<3||![3,4].includes(clothTriangleStride)||!clothTriangles||clothTriangles.length%clothTriangleStride)throw Error('Invalid self topology');
  if(!Number.isSafeInteger(maxDepth)||maxDepth<0||maxDepth>24||!Number.isSafeInteger(maxIntervals)||maxIntervals<1||maxIntervals>65536)throw Error('Invalid self interval budgets');
  this.#count=particleCount;this.#faces=[];this.#options={maxDepth,maxIntervals};
  const topology=Array.from(clothTriangles);
  for(let at=0;at<topology.length;at+=clothTriangleStride){const ids=topology.slice(at,at+3);
   if(ids.some(v=>!Number.isSafeInteger(v)||v<0||v>=particleCount)||new Set(ids).size!==3)throw Error('Invalid self triangle IDs');this.#faces.push(ids);
  }
 }
 inspect(first,last){
  if(!(first instanceof Float32Array)||!(last instanceof Float32Array)||first.length!==this.#count*4||last.length!==first.length)throw Error('Invalid self trajectory snapshots');
  const abits=new Uint32Array(first.buffer,first.byteOffset,first.length),bbits=new Uint32Array(last.buffer,last.byteOffset,last.length);
  for(let k=0;k<first.length;k++){if(!Number.isFinite(first[k])||!Number.isFinite(last[k])||(k%4!==3&&(Math.abs(first[k])>32||Math.abs(last[k])>32)))throw Error('Nonfinite or out-of-domain self trajectory');
   if(k%4===3&&(first[k]<0||last[k]<0||abits[k]!==bbits[k]))throw Error('Self trajectory changed mobility bits');
  }
  const rows=this.#faces.map((ids,face)=>{const a=ids.map(i=>Array.from(first.subarray(i*4,i*4+3))),b=ids.map(i=>Array.from(last.subarray(i*4,i*4+3)));return{face,ids,first:a,last:b,box:bounds(a,b)};});
  if(!rows.length)return{clear:true,policy:SELF_INTERVAL_POLICY,candidateSelfPairs:0,intervalsChecked:0,positiveSelfThicknessCertified:false};
  const root=tree(rows.slice());let candidateSelfPairs=0,intervalsChecked=0;
  for(const row of rows){const pending=[root];while(pending.length){const node=pending.pop();if(!overlap(row.box,node.box))continue;
   if(!node.rows){pending.push(node.right,node.left);continue;}
   for(const other of node.rows){if(other.face<=row.face||!overlap(row.box,other.box))continue;candidateSelfPairs++;
    const r=certifyMovingSelfTriangles({first:row.first,last:row.last,targetFirst:other.first,targetLast:other.last,ids:row.ids,targetIds:other.ids,...this.#options});intervalsChecked+=r.intervalsChecked;
    if(!r.clear)return{clear:false,policy:SELF_INTERVAL_POLICY,candidateSelfPairs,intervalsChecked,positiveSelfThicknessCertified:false,firstUnresolvedPair:{clothFace:row.face,otherClothFace:other.face,interval:r.unresolvedInterval,reason:r.reason}};
   }
  }}return{clear:true,policy:SELF_INTERVAL_POLICY,candidateSelfPairs,intervalsChecked,positiveSelfThicknessCertified:false};
 }
}

export const ACTIVE_SEAM_POINT_CONE_POLICY='source-active-original-seam-point-affine-gap-exact-dyadic-v1';
function exactDyadic(x){
 bits.setFloat64(0,x,false);const u=bits.getBigUint64(0,false),e=Number((u>>52n)&2047n),f=u&((1n<<52n)-1n),n=e===0?f:f+(1n<<52n);
 return{n:u>>63n?-n:n,e:e===0?-1074:e-1075};
}
// The plane's finite floating axis defines an EXACT dyadic real direction.
// Products/sums here are exact integers; no zero or sign epsilon is used.
function exactProjectedGapSign(axis,a,b){
 const terms=[];for(let k=0;k<3;k++){const u=exactDyadic(axis[k]);for(const [point,sign]of[[a,1n],[b,-1n]]){const v=exactDyadic(point[k]);if(u.n!==0n&&v.n!==0n)terms.push({n:sign*u.n*v.n,e:u.e+v.e});}}
 if(!terms.length)return 0;const e=Math.min(...terms.map(v=>v.e)),n=terms.reduce((s,v)=>s+(v.n<<BigInt(v.e-e)),0n);return n>0n?1:n<0n?-1:0;
}
/** This certifies that any contact is confined to the two specified vertices.
 * Actual original-stitch/USED authorization MUST be supplied by the source
 * wrapper/Worker. It does not itself authenticate that these are sewn vertices. */
export function certifyActiveSeamPointTriangles({first,last,targetFirst,targetLast,seamVertex,targetSeamVertex,maxDepth=20,maxIntervals=4096}){
 if(![first,last,targetFirst,targetLast].every(validateTriangle)||![seamVertex,targetSeamVertex].every(k=>Number.isInteger(k)&&k>=0&&k<3)||
  !Number.isSafeInteger(maxDepth)||maxDepth<0||maxDepth>24||!Number.isSafeInteger(maxIntervals)||maxIntervals<1||maxIntervals>65536)throw Error('Invalid active seam point proof input');
 const axes=candidates(first,last,targetFirst,targetLast).map(v=>v.map(x=>x[0]));
 const units=(f,l,p)=>f.map((v,k)=>k===p?null:rawSub(mid(v,l[k]),mid(f[p],l[p]))).filter(Boolean).map(v=>{const n=Math.hypot(...v);return n?v.map(x=>x/n):[0,0,0];});
 const ar=units(first,last,seamVertex),br=units(targetFirst,targetLast,targetSeamVertex),sum=vs=>[0,1,2].map(k=>vs.reduce((s,v)=>s+v[k],0));let proposal=rawSub(sum(ar),sum(br));
 for(let iteration=0;iteration<64;iteration++){let changed=false;for(const v of[...ar,...br.map(v=>v.map(x=>-x))]){const d=v.reduce((s,x,k)=>s+x*proposal[k],0),norm=v.reduce((s,x)=>s+x*x,0);if(d<1&&norm>0){proposal=proposal.map((x,k)=>x+(1-d)/norm*v[k]);changed=true;}}if(!changed)break;}
 if(proposal.every(Number.isFinite)&&proposal.some(v=>v!==0))axes.push(proposal);
 const allowed=[];
 for(const axis of axes){
  const firstSign=exactProjectedGapSign(axis,first[seamVertex],targetFirst[targetSeamVertex]),lastSign=exactProjectedGapSign(axis,last[seamVertex],targetLast[targetSeamVertex]);
  if(firstSign>=0&&lastSign>=0)allowed.push({axis:exactVec(axis),positiveA:true});
  if(firstSign<=0&&lastSign<=0)allowed.push({axis:exactVec(axis),positiveA:false});
 }
 let intervalsChecked=0,certifiedIntervals=0;const pending=[{t:[0,1],depth:0}];
 while(pending.length){const {t,depth}=pending.pop();if(intervalsChecked>=maxIntervals)return{clear:false,intervalsChecked,certifiedIntervals,unresolvedInterval:t,reason:'interval-budget'};intervalsChecked++;
  const a=first.map((v,k)=>pointAt(v,last[k],t)),b=targetFirst.map((v,k)=>pointAt(v,targetLast[k],t));
  const av=a.filter((_,k)=>k!==seamVertex).map(v=>vsub(v,a[seamVertex])),bv=b.filter((_,k)=>k!==targetSeamVertex).map(v=>vsub(v,b[targetSeamVertex]));
  const proved=allowed.some(({axis,positiveA})=>{const ap=av.map(v=>dot(v,axis)),bp=bv.map(v=>dot(v,axis));return positiveA?ap.every(v=>v[0]>0)&&bp.every(v=>v[1]<0):ap.every(v=>v[1]<0)&&bp.every(v=>v[0]>0);});
  if(proved){certifiedIntervals++;continue;}if(depth>=maxDepth)return{clear:false,intervalsChecked,certifiedIntervals,unresolvedInterval:t,reason:'unresolved-point-cones'};
  const m=(t[0]+t[1])/2;pending.push({t:[m,t[1]],depth:depth+1},{t:[t[0],m],depth:depth+1});
 }
 return{clear:true,policy:ACTIVE_SEAM_POINT_CONE_POLICY,intervalsChecked,certifiedIntervals,intersectionRestrictedToSpecifiedVertices:true,originalUsedStitchOriginAuthenticated:false,positiveSelfThicknessCertified:false};
}

export const ACTIVE_SEAM_EDGE_CONE_POLICY='source-active-original-seam-edge-affine-gap-exact-dyadic-v1';
/** Any intersection is confined to the two specified edges. A source wrapper
 * must authenticate BOTH original active endpoint stitches and actual face edges.
 * This standalone geometry proof supplies no USED or sewing authorization. */
export function certifyActiveSeamEdgeTriangles({first,last,targetFirst,targetLast,seamEdge,targetSeamEdge,maxDepth=20,maxIntervals=4096}){
 const edge=e=>Array.isArray(e)&&e.length===2&&new Set(e).size===2&&e.every(k=>Number.isInteger(k)&&k>=0&&k<3);
 if(![first,last,targetFirst,targetLast].every(validateTriangle)||!edge(seamEdge)||!edge(targetSeamEdge)||
 !Number.isSafeInteger(maxDepth)||maxDepth<0||maxDepth>24||!Number.isSafeInteger(maxIntervals)||maxIntervals<1||maxIntervals>65536)throw Error('Invalid active seam edge proof input');
 const ai=[0,1,2].find(k=>!seamEdge.includes(k)),bi=[0,1,2].find(k=>!targetSeamEdge.includes(k));
 const axes=candidates(first,last,targetFirst,targetLast).map(v=>v.map(x=>x[0]));
 // Numerical proposals are never evidence: only exact gap and outward signs
 // below can certify. Third-vertex to own edge-midpoint improves folded cases.
 const own=(f,l,e,k)=>{const p=mid(f[k],l[k]),q=mid(mid(f[e[0]],l[e[0]]),mid(f[e[1]],l[e[1]]));return rawSub(p,q);};
 const proposal=rawSub(own(first,last,seamEdge,ai),own(targetFirst,targetLast,targetSeamEdge,bi));
 if(proposal.every(Number.isFinite)&&proposal.some(v=>v!==0))axes.push(proposal);
 const allowed=[];
 for(const axis of axes){
 const signs=[];for(const [a,b]of[[first,targetFirst],[last,targetLast]])for(const i of seamEdge)for(const j of targetSeamEdge)signs.push(exactProjectedGapSign(axis,a[i],b[j]));
 if(signs.every(s=>s>=0))allowed.push({axis:exactVec(axis),positiveA:true});
 if(signs.every(s=>s<=0))allowed.push({axis:exactVec(axis),positiveA:false});
 }
 let intervalsChecked=0,certifiedIntervals=0;const pending=[{t:[0,1],depth:0}];
 while(pending.length){const {t,depth}=pending.pop();if(intervalsChecked>=maxIntervals)return{clear:false,intervalsChecked,certifiedIntervals,unresolvedInterval:t,reason:'interval-budget'};intervalsChecked++;
 const a=first.map((v,k)=>pointAt(v,last[k],t)),b=targetFirst.map((v,k)=>pointAt(v,targetLast[k],t));
 const ar=seamEdge.map(k=>vsub(a[ai],a[k])),br=targetSeamEdge.map(k=>vsub(b[bi],b[k]));
 const proved=allowed.some(({axis,positiveA})=>{const ap=ar.map(v=>dot(v,axis)),bp=br.map(v=>dot(v,axis));return positiveA?ap.every(v=>v[0]>0)&&bp.every(v=>v[1]<0):ap.every(v=>v[1]<0)&&bp.every(v=>v[0]>0);});
 if(proved){certifiedIntervals++;continue;}if(depth>=maxDepth)return{clear:false,intervalsChecked,certifiedIntervals,unresolvedInterval:t,reason:'unresolved-edge-cones'};
 const m=(t[0]+t[1])/2;pending.push({t:[m,t[1]],depth:depth+1},{t:[t[0],m],depth:depth+1});
 }
 return{clear:true,policy:ACTIVE_SEAM_EDGE_CONE_POLICY,intervalsChecked,certifiedIntervals,intersectionRestrictedToSpecifiedEdges:true,originalUsedStitchOriginAuthenticated:false,positiveSelfThicknessCertified:false};
}

/** Whole-pair traversal with BUILTIN direct original USED stitch authority.
 * No caller callback can authorize a failed pair. Unequal point trajectories
 * remain distinct; only the reviewed cone proof can restrict their contact. */
export class SourceActiveOriginalSeamSelfGuard{
 #count;#faces;#groups;#stitchCount;#options;
 constructor({particleCount,clothTriangles,clothTriangleStride=4,seamPairsBySeam,stitchCount},{maxDepth=20,maxIntervals=4096}={}){
  new SourceSelfIntervalGuard({particleCount,clothTriangles,clothTriangleStride},{maxDepth,maxIntervals});
  if(!Number.isSafeInteger(stitchCount)||stitchCount<0||!Array.isArray(seamPairsBySeam))throw Error('Authoritative original seam dictionary required');
  this.#count=particleCount;this.#stitchCount=stitchCount;this.#options={maxDepth,maxIntervals};this.#faces=[];
  const triangles=Array.from(clothTriangles);for(let at=0;at<triangles.length;at+=clothTriangleStride)this.#faces.push(triangles.slice(at,at+3));
  const names=new Set();this.#groups=seamPairsBySeam.map((g,index)=>{
   if(typeof g.seamId!=='string'||!g.seamId||names.has(g.seamId)||g.index!==index||!g.pairs||g.pairs.length%2||!g.stitchIndices||!g.stitchIndexKinds||g.stitchIndices.length!==g.pairs.length/2||g.stitchIndexKinds.length!==g.stitchIndices.length)throw Error('Invalid authoritative original seam group');
   const pairs=Array.from(g.pairs),stitches=Array.from(g.stitchIndices),kinds=Array.from(g.stitchIndexKinds);
   if(pairs.some(v=>!Number.isSafeInteger(v)||v<0||v>=particleCount)||stitches.some(v=>!Number.isSafeInteger(v)||v<0||v>=stitchCount)||kinds.some((v,k)=>v!==(pairs[k*2]===pairs[k*2+1]?'identity-logical':'reciprocal-first-stamp')))throw Error('Invalid original seam stitch provenance');
   names.add(g.seamId);return{pairs,stitches,kinds};
  });
 }
 inspect(first,last,activation){
  if(!activation||!Number.isSafeInteger(activation.revision)||activation.revision<0||!(activation.activeSeams instanceof Uint32Array)||activation.activeSeams.length!==this.#groups.length||activation.activeSeams.some(v=>v!==0&&v!==1)||!Number.isSafeInteger(activation.sewnUpTo)||activation.sewnUpTo<0||activation.sewnUpTo>this.#stitchCount)throw Error('Actual USED seam activation required');
  if(!(first instanceof Float32Array)||!(last instanceof Float32Array)||first.length!==this.#count*4||last.length!==first.length)throw Error('Invalid self trajectory snapshots');
  // Snapshot mutable arguments before building either authority or geometry.
  first=first.slice();last=last.slice();const active=activation.activeSeams.slice(),used={revision:activation.revision,sewnUpTo:activation.sewnUpTo,activeSeams:Array.from(active)},fa=new Uint32Array(first.buffer),la=new Uint32Array(last.buffer);
  for(let k=0;k<first.length;k++){if(!Number.isFinite(first[k])||!Number.isFinite(last[k])||(k%4!==3&&(Math.abs(first[k])>32||Math.abs(last[k])>32)))throw Error('Nonfinite or out-of-domain self trajectory');if(k%4===3&&(first[k]<0||last[k]<0||fa[k]!==la[k]))throw Error('Self trajectory changed mobility bits');}
  const parent=Array.from({length:this.#count},(_,k)=>k),find=i=>{let root=i;while(parent[root]!==root)root=parent[root];while(parent[i]!==i){const n=parent[i];parent[i]=root;i=n;}return root;};
  const segments=[];const direct=new Map(),add=(a,b)=>{if(!direct.has(a))direct.set(a,new Set());direct.get(a).add(b);};let identifiedOriginalPairs=0;
  for(let group=0;group<this.#groups.length;group++){if(active[group]!==1)continue;const g=this.#groups[group];for(let k=0;k<g.stitches.length;k++){
   if(g.stitches[k]>=used.sewnUpTo||g.kinds[k]!=='reciprocal-first-stamp')continue;const a=g.pairs[k*2],b=g.pairs[k*2+1];add(a,b);add(b,a);
   if([0,1,2].every(c=>fa[a*4+c]===fa[b*4+c]&&la[a*4+c]===la[b*4+c])){const ar=find(a),br=find(b);if(ar!==br)parent[Math.max(ar,br)]=Math.min(ar,br);identifiedOriginalPairs++;}
  }
   // Only adjacent pairs in the SAME original declared seam group form a segment.
   for(let k=0;k+1<g.stitches.length;k++)if(g.kinds[k]==='reciprocal-first-stamp'&&g.kinds[k+1]==='reciprocal-first-stamp'&&g.stitches[k]<used.sewnUpTo&&g.stitches[k+1]<used.sewnUpTo)segments.push({left:[g.pairs[k*2],g.pairs[(k+1)*2]],right:[g.pairs[k*2+1],g.pairs[(k+1)*2+1]]});
  }
  const rows=this.#faces.map((originalIds,face)=>{const ids=originalIds.map(find);if(new Set(ids).size!==3)throw Error('Exact stitch identification degenerates a face');const a=originalIds.map(i=>Array.from(first.subarray(i*4,i*4+3))),b=originalIds.map(i=>Array.from(last.subarray(i*4,i*4+3)));return{face,ids,originalIds,first:a,last:b,box:bounds(a,b)};});
  let candidateSelfPairs=0,intervalsChecked=0,pointConeAttempts=0,pointConeProvedFacePairs=0,edgeConeAttempts=0,edgeConeProvedFacePairs=0;
  const result=(clear,firstUnresolvedPair)=>({clear,policy:SELF_INTERVAL_POLICY,candidateSelfPairs,intervalsChecked,positiveSelfThicknessCertified:false,...(firstUnresolvedPair?{firstUnresolvedPair}:{}),coincidentActiveSeam:{policy:'source-original-active-exact-linear-seam-vertex-identification-v1',identifiedOriginalPairs,geometryChanged:false,forcesOrMobilityChanged:false,activation:used,wholeLinearCoincidenceRequired:true},activeOriginalPointSeam:{policy:ACTIVE_SEAM_POINT_CONE_POLICY,pointConeAttempts,pointConeProvedFacePairs,originalUsedStitchOriginAuthenticated:true,geometryIdentification:false,wholeEdgeContactCertified:false,refinedChildContactCertified:false,positiveSelfThicknessCertified:false,activation:used},activeOriginalEdgeSeam:{policy:ACTIVE_SEAM_EDGE_CONE_POLICY,edgeConeAttempts,edgeConeProvedFacePairs,originalAdjacentUsedStitchOriginAuthenticated:true,refinedChildContactCertified:false,positiveSelfThicknessCertified:false,activation:used}});
  if(!rows.length)return result(true);const root=tree(rows.slice());
  for(const row of rows){const pending=[root];while(pending.length){const node=pending.pop();if(!overlap(row.box,node.box))continue;if(!node.rows){pending.push(node.right,node.left);continue;}for(const other of node.rows){
   if(other.face<=row.face||!overlap(row.box,other.box))continue;candidateSelfPairs++;
   const ordinary=certifyMovingSelfTriangles({first:row.first,last:row.last,targetFirst:other.first,targetLast:other.last,ids:row.ids,targetIds:other.ids,...this.#options});let pairIntervals=ordinary.intervalsChecked;intervalsChecked+=ordinary.intervalsChecked;if(ordinary.clear)continue;
   let proved=false;
   for(let ai=0;ai<3&&!proved;ai++)for(let bi=0;bi<3&&!proved;bi++){
    if(!direct.get(row.originalIds[ai])?.has(other.originalIds[bi])||pairIntervals>=this.#options.maxIntervals)continue;
    pointConeAttempts++;const point=certifyActiveSeamPointTriangles({first:row.first,last:row.last,targetFirst:other.first,targetLast:other.last,seamVertex:ai,targetSeamVertex:bi,maxDepth:this.#options.maxDepth,maxIntervals:this.#options.maxIntervals-pairIntervals});pairIntervals+=point.intervalsChecked;intervalsChecked+=point.intervalsChecked;
    if(point.clear){proved=true;pointConeProvedFacePairs++;}
   }
   if(!proved)for(const segment of segments){
    for(const [left,right]of[[segment.left,segment.right],[segment.right,segment.left]]){
     const ae=left.map(i=>row.originalIds.indexOf(i)),be=right.map(i=>other.originalIds.indexOf(i));
     if(ae.some(i=>i<0)||be.some(i=>i<0)||new Set(ae).size!==2||new Set(be).size!==2||pairIntervals>=this.#options.maxIntervals)continue;
     edgeConeAttempts++;const edge=certifyActiveSeamEdgeTriangles({first:row.first,last:row.last,targetFirst:other.first,targetLast:other.last,seamEdge:ae,targetSeamEdge:be,maxDepth:this.#options.maxDepth,maxIntervals:this.#options.maxIntervals-pairIntervals});pairIntervals+=edge.intervalsChecked;intervalsChecked+=edge.intervalsChecked;
     if(edge.clear){proved=true;edgeConeProvedFacePairs++;break;}
    }if(proved)break;
   }
   // A resolved pair is not a complete mesh receipt: traversal always continues.
   if(!proved)return result(false,{clothFace:row.face,otherClothFace:other.face,interval:ordinary.unresolvedInterval,reason:ordinary.reason});
  }}}return result(true);
 }
}

export const COINCIDENT_ACTIVE_SEAM_POLICY='source-original-active-exact-linear-seam-vertex-identification-v1';
/** Checks the recorded proof scope, not a substitute for trajectory inspection. */
export function validActiveOriginalSeamScope(p){
 return !!p&&p.activeOriginalPointSeamPolicy===ACTIVE_SEAM_POINT_CONE_POLICY&&p.activeOriginalEdgeSeamPolicy===ACTIVE_SEAM_EDGE_CONE_POLICY&&p.originalUsedStitchOriginAuthenticated===true&&p.originalAdjacentUsedStitchOriginAuthenticated===true&&p.pointConeGeometryIdentification===false&&p.refinedChildContactCertified===false&&['pointConeAttempts','pointConeProvedFacePairs','edgeConeAttempts','edgeConeProvedFacePairs'].every(k=>Number.isSafeInteger(p[k])&&p[k]>=0)&&p.pointConeProvedFacePairs<=p.pointConeAttempts&&p.edgeConeProvedFacePairs<=p.edgeConeAttempts&&p.pointConeProvedFacePairs+p.edgeConeProvedFacePairs<=p.candidateSelfPairs;
}
