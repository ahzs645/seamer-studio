// Conservative zero-thickness self separation for declared linear motion.
// Every arithmetic bound uses outward rounding; sampled axes only propose proofs.
export const SELF_INTERVAL_POLICY='source-self-linear-outward-interval-v1';
const bits=new DataView(new ArrayBuffer(8));
function next(x,up){
 if(Number.isNaN(x)||x===(up?Infinity:-Infinity))return x;
 if(x===0)return up?Number.MIN_VALUE:-Number.MIN_VALUE;
 bits.setFloat64(0,x,false);let u=bits.getBigUint64(0,false);
 u+=(x>0)===up?1n:-1n;bits.setBigUint64(0,u,false);return bits.getFloat64(0,false);
}
const I=x=>[x,x], add=(a,b)=>[next(a[0]+b[0],false),next(a[1]+b[1],true)],
 neg=a=>[-a[1],-a[0]], sub=(a,b)=>add(a,neg(b));
function mul(a,b){const p=[a[0]*b[0],a[0]*b[1],a[1]*b[0],a[1]*b[1]];return[next(Math.min(...p),false),next(Math.max(...p),true)];}
const vsub=(a,b)=>a.map((x,k)=>sub(x,b[k])),
 dot=(a,b)=>a.reduce((s,x,k)=>add(s,mul(x,b[k])),I(0)),
 cross=(a,b)=>[sub(mul(a[1],b[2]),mul(a[2],b[1])),sub(mul(a[2],b[0]),mul(a[0],b[2])),sub(mul(a[0],b[1]),mul(a[1],b[0]))];
const exactVec=v=>v.map(I), pointAt=(a,b,t)=>a.map((x,k)=>add(I(x),mul(sub(I(b[k]),I(x)),t)));
const rawSub=(a,b)=>a.map((v,k)=>v-b[k]), rawCross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],
 mid=(a,b)=>a.map((v,k)=>(v+b[k])/2);
function candidates(first,last,targetFirst,targetLast){
 const a=first.map((v,k)=>mid(v,last[k])),b=targetFirst.map((v,k)=>mid(v,targetLast[k]));
 const ae=a.map((v,k)=>rawSub(a[(k+1)%3],v)),be=b.map((v,k)=>rawSub(b[(k+1)%3],v));
 const an=rawCross(ae[0],ae[1]),bn=rawCross(be[0],be[1]),axes=[[1,0,0],[0,1,0],[0,0,1],an,bn];
 for(const e of [...ae,...be])axes.push(rawCross(an,e),rawCross(bn,e));
 for(const u of ae)for(const v of be)axes.push(rawCross(u,v));
 for(const u of a)for(const v of b)axes.push(rawSub(u,v));
 return axes.filter(v=>v.every(Number.isFinite)&&v.some(x=>x!==0)).map(exactVec);
}
function boundSeparated(a,b,axes){
 for(const axis of axes){const ap=a.map(v=>dot(v,axis)),bp=b.map(v=>dot(v,axis));
  if(Math.max(...ap.map(v=>v[1]))<Math.min(...bp.map(v=>v[0]))||Math.max(...bp.map(v=>v[1]))<Math.min(...ap.map(v=>v[0])))return true;
 }return false;
}
function sharedCornerSeparated(a,b,ai,bi,axes){
 // The shared trajectory is exactly the same indexed point. Its projection cancels.
 const ar=a.filter((_,k)=>k!==ai).map(v=>vsub(v,a[ai])),br=b.filter((_,k)=>k!==bi).map(v=>vsub(v,b[bi]));
 for(const axis of axes){const ap=ar.map(v=>dot(v,axis)),bp=br.map(v=>dot(v,axis));
  if(ap.every(v=>v[0]>0)&&bp.every(v=>v[1]<0)||ap.every(v=>v[1]<0)&&bp.every(v=>v[0]>0))return true;
 }return false;
}
function sharedEdgeSeparated(first,last,targetFirst,targetLast,ids,targetIds,shared,t){
 // Algebraic axis(t) is perpendicular to the EXACT shared edge at every t.
 // Its polynomial sign is enclosed by outward interval arithmetic on t.
 // Unlike an approximate fixed plane, it needs no equality tolerance.
 const ia=ids.indexOf(shared[0]),ib=ids.indexOf(shared[1]),ja=targetIds.indexOf(shared[0]);
 const ua=ids.findIndex(id=>!shared.includes(id)),ub=targetIds.findIndex(id=>!shared.includes(id));
 const p=pointAt(first[ia],last[ia],t),e=vsub(pointAt(first[ib],last[ib],t),p),
  a=vsub(pointAt(first[ua],last[ua],t),p),b=vsub(pointAt(targetFirst[ub],targetLast[ub],t),pointAt(targetFirst[ja],targetLast[ja],t));
 const axis=cross(e,cross(e,vsub(a,b))),da=dot(axis,a),db=dot(axis,b);
 return da[0]>0&&db[1]<0||da[1]<0&&db[0]>0;
}
function validateTriangle(p){return Array.isArray(p)&&p.length===3&&p.every(v=>Array.isArray(v)&&v.length===3&&v.every(x=>Number.isFinite(x)&&Math.abs(x)<=32));}
export function certifyMovingSelfTriangles({first,last,targetFirst,targetLast,ids,targetIds,maxDepth=20,maxIntervals=4096}){
 if(![first,last,targetFirst,targetLast].every(validateTriangle)||!Array.isArray(ids)||!Array.isArray(targetIds)||ids.length!==3||targetIds.length!==3||
  [...ids,...targetIds].some(x=>!Number.isSafeInteger(x)||x<0)||new Set(ids).size!==3||new Set(targetIds).size!==3||
  !Number.isSafeInteger(maxDepth)||maxDepth<0||maxDepth>24||!Number.isSafeInteger(maxIntervals)||maxIntervals<1||maxIntervals>65536)throw Error('Invalid self interval input');
 const shared=ids.filter(id=>targetIds.includes(id));
 for(const id of shared){const a=ids.indexOf(id),b=targetIds.indexOf(id);if(first[a].some((v,k)=>!Object.is(v,targetFirst[b][k]))||last[a].some((v,k)=>!Object.is(v,targetLast[b][k])))throw Error('Shared index has inconsistent trajectory');}
 const axes=candidates(first,last,targetFirst,targetLast);
 if(shared.length===1){
  const ai=ids.indexOf(shared[0]),bi=targetIds.indexOf(shared[0]),p=mid(first[ai],last[ai]);
  const units=(f,l,omit)=>f.filter((_,k)=>k!==omit).map((_,j)=>{const k=[0,1,2].filter(k=>k!==omit)[j],v=rawSub(mid(f[k],l[k]),p),n=Math.hypot(...v);return n>0?v.map(x=>x/n):[0,0,0];});
  const a=units(first,last,ai),b=units(targetFirst,targetLast,bi),sum=v=>[0,1,2].map(k=>v.reduce((s,p)=>s+p[k],0));
  const n=rawSub(sum(a),sum(b));if(n.every(Number.isFinite)&&n.some(v=>v!==0))axes.push(exactVec(n));
  // A deterministic numerical proposal for narrow separating cones. Its output
  // is accepted ONLY by the outward all-time projection proof above.
  const directions=[...a,...b.map(v=>v.map(x=>-x))];let proposal=n.slice();
  for(let iteration=0;iteration<64;iteration++){
   let changed=false;for(const v of directions){const d=v.reduce((s,x,k)=>s+x*proposal[k],0),norm=v.reduce((s,x)=>s+x*x,0);
    if(d<1&&norm>0){proposal=proposal.map((x,k)=>x+(1-d)/norm*v[k]);changed=true;}}
   if(!changed)break;
  }
  if(proposal.every(Number.isFinite)&&proposal.some(v=>v!==0))axes.push(exactVec(proposal));
 }
 let intervalsChecked=0,certifiedIntervals=0;
 const pending=[{t:[0,1],depth:0}];
 while(pending.length){const {t,depth}=pending.pop();
  if(intervalsChecked>=maxIntervals)return{clear:false,intervalsChecked,certifiedIntervals,unresolvedInterval:t,reason:'interval-budget'};
  intervalsChecked++;
  const a=first.map((v,k)=>pointAt(v,last[k],t)),b=targetFirst.map((v,k)=>pointAt(v,targetLast[k],t));
  const proved=shared.length===0?boundSeparated(a,b,axes):shared.length===1?sharedCornerSeparated(a,b,ids.indexOf(shared[0]),targetIds.indexOf(shared[0]),axes):
   shared.length===2?sharedEdgeSeparated(first,last,targetFirst,targetLast,ids,targetIds,shared,t):false;
  if(proved){certifiedIntervals++;continue;}
  if(depth>=maxDepth||shared.length===3)return{clear:false,intervalsChecked,certifiedIntervals,unresolvedInterval:t,reason:shared.length===3?'duplicate-face':'unresolved-separation'};
  const m=(t[0]+t[1])/2;pending.push({t:[m,t[1]],depth:depth+1},{t:[t[0],m],depth:depth+1});
 }
 return{clear:true,intervalsChecked,certifiedIntervals};
}
const bounds=(first,last)=>({lo:[0,1,2].map(k=>Math.min(...first.map(v=>v[k]),...last.map(v=>v[k]))),hi:[0,1,2].map(k=>Math.max(...first.map(v=>v[k]),...last.map(v=>v[k])))});
const overlap=(a,b)=>a.lo.every((v,k)=>v<=b.hi[k]&&a.hi[k]>=b.lo[k]);
function tree(rows){
 const box={lo:[0,1,2].map(k=>Math.min(...rows.map(v=>v.box.lo[k]))),hi:[0,1,2].map(k=>Math.max(...rows.map(v=>v.box.hi[k])))};
 if(rows.length<=8)return{box,rows};
 const spans=box.hi.map((v,k)=>v-box.lo[k]),axis=spans.indexOf(Math.max(...spans));rows.sort((a,b)=>(a.box.lo[axis]+a.box.hi[axis])-(b.box.lo[axis]+b.box.hi[axis])||a.face-b.face);
 const m=Math.floor(rows.length/2);return{box,left:tree(rows.slice(0,m)),right:tree(rows.slice(m))};
}
export class SourceSelfIntervalGuard{
 #count;#faces;#options;
 constructor({particleCount,clothTriangles,clothTriangleStride=4},{maxDepth=20,maxIntervals=4096}={}){
  if(!Number.isSafeInteger(particleCount)||particleCount<3||![3,4].includes(clothTriangleStride)||!clothTriangles||clothTriangles.length%clothTriangleStride)throw Error('Invalid self topology');
  if(!Number.isSafeInteger(maxDepth)||maxDepth<0||maxDepth>24||!Number.isSafeInteger(maxIntervals)||maxIntervals<1||maxIntervals>65536)throw Error('Invalid self interval budgets');
  this.#count=particleCount;this.#faces=[];this.#options={maxDepth,maxIntervals};
  const topology=Array.from(clothTriangles);
  for(let at=0;at<topology.length;at+=clothTriangleStride){const ids=topology.slice(at,at+3);
   if(ids.some(v=>!Number.isSafeInteger(v)||v<0||v>=particleCount)||new Set(ids).size!==3)throw Error('Invalid self triangle IDs');this.#faces.push(ids);
  }
 }
 inspect(first,last){
  if(!(first instanceof Float32Array)||!(last instanceof Float32Array)||first.length!==this.#count*4||last.length!==first.length)throw Error('Invalid self trajectory snapshots');
  const abits=new Uint32Array(first.buffer,first.byteOffset,first.length),bbits=new Uint32Array(last.buffer,last.byteOffset,last.length);
  for(let k=0;k<first.length;k++){if(!Number.isFinite(first[k])||!Number.isFinite(last[k])||(k%4!==3&&(Math.abs(first[k])>32||Math.abs(last[k])>32)))throw Error('Nonfinite or out-of-domain self trajectory');
   if(k%4===3&&(first[k]<0||last[k]<0||abits[k]!==bbits[k]))throw Error('Self trajectory changed mobility bits');
  }
  const rows=this.#faces.map((ids,face)=>{const a=ids.map(i=>Array.from(first.subarray(i*4,i*4+3))),b=ids.map(i=>Array.from(last.subarray(i*4,i*4+3)));return{face,ids,first:a,last:b,box:bounds(a,b)};});
  if(!rows.length)return{clear:true,policy:SELF_INTERVAL_POLICY,candidateSelfPairs:0,intervalsChecked:0,positiveSelfThicknessCertified:false};
  const root=tree(rows.slice());let candidateSelfPairs=0,intervalsChecked=0;
  for(const row of rows){const pending=[root];while(pending.length){const node=pending.pop();if(!overlap(row.box,node.box))continue;
   if(!node.rows){pending.push(node.right,node.left);continue;}
   for(const other of node.rows){if(other.face<=row.face||!overlap(row.box,other.box))continue;candidateSelfPairs++;
    const r=certifyMovingSelfTriangles({first:row.first,last:row.last,targetFirst:other.first,targetLast:other.last,ids:row.ids,targetIds:other.ids,...this.#options});intervalsChecked+=r.intervalsChecked;
    if(!r.clear)return{clear:false,policy:SELF_INTERVAL_POLICY,candidateSelfPairs,intervalsChecked,positiveSelfThicknessCertified:false,firstUnresolvedPair:{clothFace:row.face,otherClothFace:other.face,interval:r.unresolvedInterval,reason:r.reason}};
   }
  }}return{clear:true,policy:SELF_INTERVAL_POLICY,candidateSelfPairs,intervalsChecked,positiveSelfThicknessCertified:false};
 }
}
