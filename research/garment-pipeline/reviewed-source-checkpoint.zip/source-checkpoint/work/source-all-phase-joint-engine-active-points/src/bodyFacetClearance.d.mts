import type { CollisionGuardInput } from './collisionGuard';
export const BODY_FACET_POLICY: 'source-body-facet-linear-1mm-separating-axis-v1';
export interface BodyFacetIntervalReport {
 policy: typeof BODY_FACET_POLICY; accepted: boolean; clothFacesChecked: number;
 candidateBodyPairs: number; intervalsChecked: number;
 unresolvedPair: {clothFace:number;bodyFace:number;interval:[number,number]} | null;
 physicalClearanceM: .001; interpolation: 'piecewise-linear'; selfFacetClearanceCertified: false;
}
export class SourceBodyFacetClearanceGuard {
 constructor(input: CollisionGuardInput, options?: {maxDepth?:number;maxIntervals?:number});
 inspect(first:Float32Array,last:Float32Array):BodyFacetIntervalReport;
}
