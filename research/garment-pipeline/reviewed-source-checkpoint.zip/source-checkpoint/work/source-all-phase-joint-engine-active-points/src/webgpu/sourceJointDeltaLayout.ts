/** NEW joint direct-correction ledger ABI4 contract only; frozen CSR3 unchanged.
 * Vec4 segments share ONE storage binding. δ lanes are METERS, W=0. Candidate
 * stores actual XYZ/inverse-mass bits. Native returns0 bytes and no allocations.
 */
export const JOINT_DIRECT_DELTA_LAYOUT_ABI=4;
/** All offsets are vec4 particle offsets unless suffixed Bytes. Each range may
 * be bound separately with size particleCount*16, or the full buffer may be bound
 * with a particleOffset uniform. Padding is never part of the physical ledger. */
export function jointDirectDeltaLayout(particleCount:number,scope:'fresh-source'|'native',storageOffsetAlignment=256){
 const disabled={enabled:false,abi:4,particleCount:0,byteLength:0,segmentBytes:0,strideBytes:0,storageOffsetAlignment:0,ideal:0,candidate:0,tentative:0,accepted:0,physical:0,idealBytes:0,candidateBytes:0,tentativeBytes:0,acceptedBytes:0,physicalBytes:0};
 if(scope==='native')return Object.freeze(disabled);
 if(scope!=='fresh-source'||!Number.isSafeInteger(particleCount)||particleCount<1||!Number.isSafeInteger(storageOffsetAlignment)||storageOffsetAlignment<16||storageOffsetAlignment%16!==0||(storageOffsetAlignment&(storageOffsetAlignment-1))!==0)throw Error('Explicit source joint ledger capacity/alignment');
 const segmentBytes=particleCount*16,strideBytes=Math.ceil(segmentBytes/storageOffsetAlignment)*storageOffsetAlignment,byteLength=strideBytes*5;
 if(!Number.isSafeInteger(byteLength)||byteLength>0xffffffff)throw Error('Explicit source joint ledger byte capacity');
 const stride=strideBytes/16;
 return Object.freeze({enabled:true,abi:4,particleCount,byteLength,segmentBytes,strideBytes,storageOffsetAlignment,ideal:0,candidate:stride,tentative:stride*2,accepted:stride*3,physical:stride*4,idealBytes:0,candidateBytes:strideBytes,tentativeBytes:strideBytes*2,acceptedBytes:strideBytes*3,physicalBytes:strideBytes*4});
}
export interface JointPhysicalParentKey {frameGeneration:number;physicalSubstep:number;parentToken:number;sourceToken:number;bodyGeneration:number;gateRevision:number;}
export function jointPhysicalParentKeyWords(input:JointPhysicalParentKey):Uint32Array{
 const values=[input.frameGeneration,input.physicalSubstep,input.parentToken,input.sourceToken,input.bodyGeneration,input.gateRevision];
 if(values.some(n=>!Number.isSafeInteger(n)||n<0||n>0xffffffff)||!input.frameGeneration||!input.parentToken||input.physicalSubstep<1||input.physicalSubstep>40)throw Error('Unbound joint physical parent');
 return Uint32Array.of(JOINT_DIRECT_DELTA_LAYOUT_ABI,...values,0);
}
/** GPU adapter must preserve these exact offsets/dispatch boundaries. */
export const jointDirectDeltaContract=Object.freeze({
 originalParent:'actual post-support/pre-ANY-finishing contact physical substep input',
 materialHistory:'actual previous corrected physical substep; immutable through relinearization',
 relinearization:'ideal and tentative contactδ are REPLACED relative same original parent, never summed across virtual rounds',
 tentativeUse:'only fully certified final finite virtual contactδ feeds physical velocity BEFORE next prediction',
 velocity:'vPrediction + (direct material+bend+sewing+support correction sum + final tentative contact correction)/physicalDt',
 publication:'accepted ledger/sourceλ/contactλ/history/publicXYZ publish ONLY after strict ALL40/41 frame proof',
 rollback:'restore entire frame entry geometry, velocity, ideal/tentative/accepted ledger, both multiplier histories, owner cache and support state',
 rangeBindings:'all segment starts aligned to supplied minStorageBufferOffsetAlignment; bind exactly N*16 bytes or full buffer+vec4 offset uniform',
 physicalLedger:'separate appended physical segment owned by ALL40 engine; material/bend/sew/support ADD direct corrections, contact REPLACES same-parent tentative segment, never sum relinearizations',
 friction:'must reconcile persistent normalλ/kg·m to pressureλ/dt²; friction integration NOT implemented by this layout',
 sourceScope:'native/off allocate0; no physical material/cuts/mass/padding/clearance change',
});
/** Scratch CPU lifecycle reference for meaningful replacement/rollback controls.
 * It is NOT a GPU backend, constitutive solver or acceptance authority.
 */
export class JointDirectDeltaReference {
 readonly layout;readonly words:Float32Array;private parentKey:string|null=null;private frameEntry:Float32Array|null=null;private capturedGeneration=0;private tentativeCertified=false;
 constructor(readonly particleCount:number,scope:'fresh-source'|'native',storageOffsetAlignment=256){this.layout=jointDirectDeltaLayout(particleCount,scope,storageOffsetAlignment);this.words=new Float32Array(this.layout.byteLength/4);}
 beginFrame(generation:number){if(!this.layout.enabled)return;if(this.frameEntry||!Number.isSafeInteger(generation)||generation<1)throw Error('Joint ledger frame already active/unbound');this.frameEntry=this.words.slice();this.capturedGeneration=generation;}
 beginParent(key:JointPhysicalParentKey,parent:Float32Array){if(!this.layout.enabled)return;if(!this.frameEntry||key.frameGeneration!==this.capturedGeneration||parent.length!==this.particleCount*4)throw Error('Joint ledger stale parent');this.parentKey=Array.from(jointPhysicalParentKeyWords(key)).join('/');this.tentativeCertified=false;this.words.set(parent,this.layout.candidate*4);this.words.fill(0,this.layout.ideal*4,(this.layout.ideal+this.particleCount)*4);this.words.fill(0,this.layout.tentative*4,(this.layout.tentative+this.particleCount)*4);}
 replaceTentative(key:JointPhysicalParentKey,ideal:Float32Array,candidate:Float32Array,certified:boolean){if(!this.layout.enabled)return;if(this.parentKey!==Array.from(jointPhysicalParentKeyWords(key)).join('/')||ideal.length!==this.particleCount*4||candidate.length!==ideal.length||ideal.some((v,i)=>!Number.isFinite(v)||(i%4===3&&v!==0))||candidate.some(v=>!Number.isFinite(v)))throw Error('Joint ledger stale/nonfinite correction');this.words.set(ideal,this.layout.ideal*4);this.words.set(candidate,this.layout.candidate*4);this.words.set(ideal,this.layout.tentative*4);this.tentativeCertified=certified;}
 consumeForNextPrediction(key:JointPhysicalParentKey){if(!this.layout.enabled)return new Float32Array(0);if(!this.tentativeCertified||this.parentKey!==Array.from(jointPhysicalParentKeyWords(key)).join('/'))throw Error('Joint ledger uncertified/stale velocity input');return this.words.slice(this.layout.tentative*4,(this.layout.tentative+this.particleCount)*4);}
 publishFrame(all41Proof:boolean){if(!this.layout.enabled)return;if(!this.frameEntry||!all41Proof||!this.tentativeCertified)throw Error('Joint ledger missing full frame proof');this.words.set(this.words.slice(this.layout.tentative*4,(this.layout.tentative+this.particleCount)*4),this.layout.accepted*4);this.frameEntry=null;this.parentKey=null;this.tentativeCertified=false;}
 rollbackFrame(){if(!this.layout.enabled)return;if(!this.frameEntry)throw Error('Missing ledger frame snapshot');this.words.set(this.frameEntry);this.frameEntry=null;this.parentKey=null;this.tentativeCertified=false;}
}
