import { packMembraneRecords, validateSourcePhysicalMembrane, type CandidateSim, type ExecutedMaterialPolicy } from '../sourcePhysicalMembrane.ts';
import { sourceMembraneWGSL } from './sourceMembraneShaders.ts';

export interface SharedSourceCorrection {
  /** Engine-owned packed storage. This module never clears, snapshots or destroys it. */
  buffer: GPUBuffer;
  particleOffset: number;
  resetOwner: 'engine';
}

/** Isolated candidate only. The enclosing source wrapper owns whole-frame publication/rollback. */
export class SourceMembranePass {
  private readonly owned: GPUBuffer[] = [];
  private readonly lambdas: GPUBuffer;
  private readonly state: GPUBuffer;
  private readonly readback: GPUBuffer;
  private readonly correctionAccumulator: GPUBuffer;
  private readonly particleCount: number;
  private readonly correctionParticleOffset: number;
  private readonly ownsCorrectionAccumulator: boolean;
  private readonly pipelines: Record<string, GPUComputePipeline>;
  private readonly frameGroup: GPUBindGroup;
  private readonly resetGroup: GPUBindGroup;
  private readonly colorGroups: readonly { count: number; group: GPUBindGroup }[];
  private readonly triangleCount: number;
  private readonly iterationsPerStage: number;
  private disposed = false;
  private mapped = false;
  private readInFlight = false;
  private frameScopeOpen = false;
  private latestFlags = 0;
  private readonly initialization: Promise<Error | null>;
  readonly policySha256: string;
  private readonly executedPolicy: ExecutedMaterialPolicy;
  private readonly expectedInverseMass: Float32Array;

  private readonly device: GPUDevice;
  constructor(device: GPUDevice, positions: GPUBuffer, sim: CandidateSim, dtSeconds: number, sharedCorrection?: SharedSourceCorrection) {
    this.device = device;
    const executed = validateSourcePhysicalMembrane(sim);
    if (!executed) throw Error('Explicit source material unavailable');
    this.executedPolicy = executed;
    this.particleCount = sim.particleCount;
    this.ownsCorrectionAccumulator = !sharedCorrection;
    this.correctionParticleOffset = sharedCorrection?.particleOffset ?? 0;
    if (sharedCorrection && (sharedCorrection.buffer === positions || sharedCorrection.resetOwner !== 'engine'
      || !Number.isInteger(sharedCorrection.particleOffset) || sharedCorrection.particleOffset < 0
      || sharedCorrection.particleOffset > 0xffffffff - this.particleCount
      || (sharedCorrection.particleOffset + this.particleCount) * 16 > sharedCorrection.buffer.size
      || sharedCorrection.buffer.size > device.limits.maxStorageBufferBindingSize
      || !(sharedCorrection.buffer.usage & GPUBufferUsage.STORAGE))) throw Error('Exact bounded engine-owned correction storage required');
    this.expectedInverseMass = sim.positions.filter((_, i) => i % 4 === 3);
    const material = sim.sourcePhysicalMembrane!;
    if (!(Number.isFinite(dtSeconds) && dtSeconds > 0) || !Number.isFinite(Math.fround(dtSeconds)) || Math.fround(dtSeconds) <= 0) throw Error('Representable positive physical timestep required');
    if (device.limits.maxStorageBuffersPerShaderStage < 6 || !material.triangles.length || !material.policySha256) throw Error('Source membrane resource or policy unavailable');
    this.policySha256 = material.policySha256;
    this.triangleCount = material.triangles.length;
    this.iterationsPerStage = material.iterationsPerMaterialStage;
    if (!Number.isInteger(this.iterationsPerStage) || this.iterationsPerStage < 1 || this.iterationsPerStage > 512) throw Error('Explicit bounded material iterations required');
    const bytes = new Uint8Array(material.records.buffer, material.records.byteOffset, material.records.byteLength);
    const hex = Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
    const expected = packMembraneRecords(material.triangles), expectedBytes = new Uint8Array(expected.buffer);
    if (bytes.length !== expectedBytes.length || bytes.some((v, i) => v !== expectedBytes[i])
      || material.policy.materialRecordBitsFloat32 !== hex
      || JSON.stringify(material.policy.colors) !== JSON.stringify(material.colors.map(c => Array.from(c)))) throw Error('Material records/color order changed after immutable policy hashing');
    const used = new Set<number>();
    for (const ids of material.colors) {
      const vertices = new Set<number>();
      for (const id of ids) {
        if (id >= this.triangleCount || used.has(id)) throw Error('Exact triangle color partition required');
        used.add(id);
        for (const v of material.triangles[id].ids) { if (vertices.has(v)) throw Error('Color contains shared read/write material vertices'); vertices.add(v); }
      }
    }
    if (used.size !== this.triangleCount) throw Error('Color omitted a material triangle');
    let validationScopeOpen = false;
    try {
      device.pushErrorScope('validation'); validationScopeOpen = true;
      const storage = GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC;
      const records = this.buffer(material.records, storage);
      this.lambdas = this.buffer(this.triangleCount * 16, storage);
      this.state = this.buffer(new Uint32Array(4), storage);
      this.readback = this.buffer(16, GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST);
      this.correctionAccumulator = sharedCorrection?.buffer ?? this.buffer(this.particleCount * 16, storage);
      const module = device.createShaderModule({ code: sourceMembraneWGSL });
      this.pipelines = Object.fromEntries(['beginFrame', 'beginPrediction', 'solveColor'].map(entryPoint => [entryPoint, device.createComputePipeline({ layout: 'auto', compute: { module, entryPoint } })]));
      const group = (entry: string, entries: { binding: number; resource: { buffer: GPUBuffer } }[]) => device.createBindGroup({ layout: this.pipelines[entry].getBindGroupLayout(0), entries });
      this.frameGroup = group('beginFrame', [{ binding: 3, resource: { buffer: this.state } }]);
      this.resetGroup = group('beginPrediction', [{ binding: 2, resource: { buffer: this.lambdas } }, { binding: 3, resource: { buffer: this.state } }, { binding: 5, resource: { buffer: this.buffer(new Uint32Array([this.triangleCount, 0, this.correctionParticleOffset, this.ownsCorrectionAccumulator ? this.particleCount : 0]), GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST) } }, { binding: 6, resource: { buffer: this.correctionAccumulator } }]);
      this.colorGroups = material.colors.map(ids => {
        const color = this.buffer(ids, storage), params = new ArrayBuffer(16), view = new DataView(params);
        view.setUint32(0, ids.length, true); view.setFloat32(4, dtSeconds, true); view.setUint32(8, this.correctionParticleOffset, true); view.setUint32(12, this.particleCount, true);
        const uniform = this.buffer(new Uint8Array(params), GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST);
        return { count: ids.length, group: group('solveColor', [positions, records, this.lambdas, this.state, color, uniform, this.correctionAccumulator].map((buffer, binding) => ({ binding, resource: { buffer } }))) };
      });
      const validation = device.popErrorScope(); validationScopeOpen = false;
      this.initialization = Promise.all([module.getCompilationInfo(), validation]).then(([info, error]) => {
        const messages = info.messages.filter(m => m.type === 'error').map(m => `${m.lineNum}:${m.linePos} ${m.message}`);
        return error ? new Error(error.message) : messages.length ? new Error(messages.join('\n')) : null;
      }).catch(error => error instanceof Error ? error : new Error(String(error)));
    } catch (error) {
      if (validationScopeOpen) void device.popErrorScope().catch(() => {});
      this.owned.forEach(buffer => buffer.destroy()); this.disposed = true; throw error;
    }
  }

  private buffer(data: number | ArrayBufferView, usage: GPUBufferUsageFlags): GPUBuffer {
    const size = typeof data === 'number' ? data : data.byteLength;
    if (size > this.device.limits.maxBufferSize || usage & GPUBufferUsage.STORAGE && size > this.device.limits.maxStorageBufferBindingSize) throw Error('Material buffer exceeds exact device limit');
    const buffer = this.device.createBuffer({ size: Math.max(4, size), usage }); this.owned.push(buffer);
    if (typeof data !== 'number') this.device.queue.writeBuffer(buffer, 0, data.buffer as ArrayBuffer, data.byteOffset, data.byteLength);
    return buffer;
  }

  beginFrame(pass: GPUComputePassEncoder): void {
    if (this.disposed || this.readInFlight || this.frameScopeOpen) throw Error('Material pass lifecycle unavailable');
    this.device.pushErrorScope('validation'); this.frameScopeOpen = true;
    this.latestFlags = 0;
    pass.setPipeline(this.pipelines.beginFrame); pass.setBindGroup(0, this.frameGroup); pass.dispatchWorkgroups(1);
  }

  async assertReady(): Promise<void> { const error = await this.initialization; if (error) throw error; }

  /** Pop synchronously after submit, before any asynchronous render/device work can share scope. */
  finishFrameSubmission(): Promise<void> {
    if (!this.frameScopeOpen) throw Error('Missing material frame validation scope');
    this.frameScopeOpen = false;
    return this.device.popErrorScope().then(error => {
      if (error) { this.latestFlags = 8; throw new SourceMaterialFrameError(8, this.policySha256); }
    });
  }
  abortUnsubmittedFrame(): void {
    if (this.frameScopeOpen) { this.frameScopeOpen = false; void this.device.popErrorScope().catch(() => {}); }
  }

  /** Exactly once after every production integrate prediction, never between material colors. */
  beginPrediction(pass: GPUComputePassEncoder): void {
    pass.setPipeline(this.pipelines.beginPrediction); pass.setBindGroup(0, this.resetGroup); pass.dispatchWorkgroups(Math.ceil(Math.max(this.triangleCount, this.ownsCorrectionAccumulator ? this.particleCount : 0) / 64));
  }

  solveMaterialStage(pass: GPUComputePassEncoder): void {
    for (let i = 0; i < this.iterationsPerStage; i++) this.solveIteration(pass);
  }

  solveIteration(pass: GPUComputePassEncoder): void {
    pass.setPipeline(this.pipelines.solveColor);
    for (const color of this.colorGroups) {
      pass.setBindGroup(0, color.group); pass.dispatchWorkgroups(Math.ceil(color.count / 64));
    }
  }

  encodeStatusReadback(encoder: GPUCommandEncoder): void { encoder.copyBufferToBuffer(this.state, 0, this.readback, 0, 16); }

  async assertFrameValid(isCurrent: () => boolean): Promise<void> {
    if (this.readInFlight || this.disposed) throw Error('Material readback unavailable');
    this.readInFlight = true;
    try {
      await this.readback.mapAsync(GPUMapMode.READ); this.mapped = true;
      const flags = new Uint32Array(this.readback.getMappedRange().slice(0))[0];
      if (isCurrent()) { this.latestFlags = flags; if (flags) throw new SourceMaterialFrameError(flags, this.policySha256); }
    } finally {
      if (this.mapped) { this.readback.unmap(); this.mapped = false; }
      this.readInFlight = false;
    }
  }

  get flags(): number { return this.latestFlags; }
  get diagnosticPolicy(): ExecutedMaterialPolicy { return { ...this.executedPolicy }; }
  validateResetPositions(positions: Float32Array): void {
    if (positions.length !== this.expectedInverseMass.length * 4 || this.expectedInverseMass.some((w, i) => !Object.is(w, positions[i * 4 + 3]))) throw Error('Reset mobility differs from privately executed physical policy');
  }
  /** Internal engine resource in metres; tentative until whole-frame proof/publication. */
  get correctionBuffer(): GPUBuffer { return this.correctionAccumulator; }
  get correctionOffsetParticles(): number { return this.correctionParticleOffset; }
  get ownsCorrectionBuffer(): boolean { return this.ownsCorrectionAccumulator; }
  get snapshotBytes(): number { return this.lambdas.size + this.state.size + (this.ownsCorrectionAccumulator ? this.correctionAccumulator.size : 0); }
  encodeSnapshot(encoder: GPUCommandEncoder, destination: GPUBuffer, offset: number): void {
    encoder.copyBufferToBuffer(this.lambdas, 0, destination, offset, this.lambdas.size);
    encoder.copyBufferToBuffer(this.state, 0, destination, offset + this.lambdas.size, this.state.size);
    if (this.ownsCorrectionAccumulator) encoder.copyBufferToBuffer(this.correctionAccumulator, 0, destination, offset + this.lambdas.size + this.state.size, this.correctionAccumulator.size);
  }
  encodeRestore(encoder: GPUCommandEncoder, snapshot: GPUBuffer, offset: number): void {
    encoder.copyBufferToBuffer(snapshot, offset, this.lambdas, 0, this.lambdas.size);
    encoder.copyBufferToBuffer(snapshot, offset + this.lambdas.size, this.state, 0, this.state.size);
    if (this.ownsCorrectionAccumulator) encoder.copyBufferToBuffer(snapshot, offset + this.lambdas.size + this.state.size, this.correctionAccumulator, 0, this.correctionAccumulator.size);
  }
  resetHistory(): void {
    this.latestFlags = 0;
    this.device.queue.writeBuffer(this.lambdas, 0, new Float32Array(this.triangleCount * 4));
    this.device.queue.writeBuffer(this.state, 0, new Uint32Array(4));
    if (this.ownsCorrectionAccumulator) this.device.queue.writeBuffer(this.correctionAccumulator, 0, new Float32Array(this.particleCount * 4));
  }
  /** Owner defers this until the complete parent engine frame/readbacks finish. */
  dispose(): void {
    if (this.readInFlight || this.mapped) throw Error('Owner must drain material readback before disposal');
    if (this.disposed) return;
    this.abortUnsubmittedFrame();
    this.disposed = true; this.owned.forEach(buffer => buffer.destroy());
  }
}

export class SourceMaterialFrameError extends Error {
  readonly flags: number;
  readonly policySha256: string;
  constructor(flags: number, policySha256: string) {
    super(`Source membrane entire frame invalid: flags=${flags}, policy=${policySha256}`);
    this.name = 'SourceMaterialFrameError';
    this.flags = flags; this.policySha256 = policySha256;
  }
}
