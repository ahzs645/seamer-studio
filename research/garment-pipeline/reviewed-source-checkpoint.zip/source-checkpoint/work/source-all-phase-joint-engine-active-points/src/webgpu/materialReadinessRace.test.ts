import { describe, it, expect, vi } from 'vitest';
import { ClothEngine } from './engine';

describe('source material compilation generation boundary', () => {
  const fixture = (source: boolean) => {
    let release!: () => void;
    const gate = new Promise<void>(resolve => { release = resolve; });
    const encode = vi.fn(() => { throw new Error('encoding reached'); });
    const writes = vi.fn(), destroyed = vi.fn();
    const material = { assertReady: () => gate, abortUnsubmittedFrame: vi.fn(), validateResetPositions: vi.fn(), resetHistory: vi.fn() };
    const engine = Object.create(ClothEngine.prototype) as ClothEngine;
    Object.assign(engine, { device: { createCommandEncoder: encode, queue: { writeBuffer: writes } }, sourceMembrane: source ? material : undefined,
      inFlight: false, disposalRequested: false, stateGeneration: 0, particleCount: 1, positions: {}, velocities: {}, lastPositions: {}, destroyResources: destroyed });
    return { engine, release, encode, writes, destroyed, material };
  };
  it('native encoding retains synchronous prefix; no introduced await(undefined) microtask', async () => {
    const f = fixture(false), pending = f.engine.step();
    expect(f.encode).toHaveBeenCalledTimes(1);
    await expect(pending).rejects.toThrow('encoding reached');
  });
  it('actual reset while compile is pending preserves its new seed and never encodes old frame', async () => {
    const f = fixture(true), pending = f.engine.step();
    expect(f.encode).not.toHaveBeenCalled();
    f.engine.resetPositions(Float32Array.of(1, 2, 3, 7));
    expect(f.writes).toHaveBeenCalledTimes(3);
    f.release();
    expect((await pending).length).toBe(0);
    expect(f.encode).not.toHaveBeenCalled();
    expect(f.writes).toHaveBeenCalledTimes(3);
    expect(f.material.resetHistory).toHaveBeenCalledTimes(1);
  });
  it('actual dispose while compile is pending never dispatches and drains owner resources once', async () => {
    const f = fixture(true), pending = f.engine.step();
    f.engine.dispose();
    expect(f.destroyed).not.toHaveBeenCalled();
    f.release();
    expect((await pending).length).toBe(0);
    expect(f.encode).not.toHaveBeenCalled();
    expect(f.destroyed).toHaveBeenCalledTimes(1);
  });
});
