/** UNFROZEN copied whole-engine adapter. This is executable boundary/commit code,
 * not a concrete finite producer or a claim of backend/device readiness. A reviewed
 * autonomous GPU producer + CSR response + physical pressure/friction backend must
 * be supplied explicitly. No factory => no allocations, dispatches or awaits. */
import type {SimConfig} from '../config';
import type {SimData} from '../build';
import type {CollisionGuardReport,CollisionSeamActivation} from '../collisionGuard';
import type {BodyMesh} from './engine';
import type {SeamGateLayout} from './seamGate';
import type {jointDirectDeltaLayout} from './sourceJointDeltaLayout';
type DeltaLayout=ReturnType<typeof jointDirectDeltaLayout>;
export interface SourceJointParentKey {
 generation:number;frameSequence:number;physicalSubstep:number;parentToken:number;gateRevision:number;
}
export interface SourceJointCreation {
 device:GPUDevice;simulation:SimData;body:BodyMesh;config:SimConfig;
 /** Both are immutable owned GPU copies, never the live world buffer or W0 history. */
 originalParent:GPUBuffer;materialHistory:GPUBuffer;usedGate:GPUBuffer;gateLayout:SeamGateLayout;finiteStatus:GPUBuffer;
 /** Actual owner/controller copy; backend independently observes/reseals GPU parent/history/gate. */
 captureRefinedRuntimeState?:(key:Readonly<SourceJointParentKey>)=>Readonly<{controllerOwned:true;key:SourceJointParentKey;anchors:Float32Array;supportTargets:Float32Array;supportGroups:readonly unknown[];usedActivation:CollisionSeamActivation}>;
 isCurrent:()=>boolean;
}
export interface SourceJointCertificate {
 key:SourceJointParentKey;
 originalParentSha256:string;historySha256:string;candidateSha256:string;sourceSha256:string;bodySha256:string;usedGateSha256:string;
 actualGpuFiniteProducer:true;allCurrentRawOccurrencesChecked:true;
 rawOccurrences:number;unsupported:number;clearanceDeficits:number;minimumClearanceLowerBoundM:number;
 maximumOriginalParentNetM:number;physicalMassAndFixedBitsUnchanged:true;
 normalReactionAuthoritative:true;normalMultiplierUnit:'kg-m';
 frictionReconciled:true;frictionHistoryGeneration:number;
 /** A numerical response margin must never impersonate normal reaction. */
 numericalMarginIsPhysicalPressure:false;
 refinedSeamProof:'actual-child-material-u-v3'|'ordinary-source-topology';
 published:false;
}
export interface SourceJointVirtualResult {
 candidate:GPUBuffer;idealContactDelta:GPUBuffer;certificate:SourceJointCertificate;
}
export interface SourceJointBackend {
 readonly implementationSha256:string;
 readonly snapshotBytes:number;
 /** Full pending/accepted pressure, tangential anchor/history, graph/cache/λ snapshots. */
 encodeSnapshot(encoder:GPUCommandEncoder,target:GPUBuffer,offset:number):void;
 encodeRestore(encoder:GPUCommandEncoder,source:GPUBuffer,offset:number):void;
 beginFrame(input:Readonly<{generation:number;frameSequence:number;sourceDeltaPolicySha256:string;usedActivation:CollisionSeamActivation}>):Promise<void>;
 /** Uses immutable GPU parent/history; candidate and ideal must remain distinct.
  * No backend write to live engine positions or physical ledger is permitted. */
 finishPhysicalSubstep(input:Readonly<{key:SourceJointParentKey;physicalDt:number;usedActivation:CollisionSeamActivation}>):Promise<SourceJointVirtualResult>;
 /** Actual fresh ALLraw certificate AFTER velocity/floor world writes. Read-only:
  * no hidden correction or second ideal impulse is permitted here. */
 sealPhysicalSubstep(input:Readonly<{key:SourceJointParentKey;positions:GPUBuffer;usedActivation:CollisionSeamActivation}>):Promise<SourceJointCertificate>;
 finishFrame():Promise<void>;
 readonly acceptedFrameCommitReceipt:Readonly<Record<string,unknown>>|null;
 acceptFrame(proof:CollisionGuardReport):Promise<void>;
 /** Cancellation must drain owned queues/maps. Engine restoration is authoritative. */
 invalidate():void;
 resetHistory():void;
 destroy():Promise<void>;
}
export type SourceJointBackendFactory=(input:SourceJointCreation)=>SourceJointBackend;
const cloneActivation=(a:CollisionSeamActivation):CollisionSeamActivation=>({...a,activeSeams:a.activeSeams.slice()});
const u32=(v:number)=>Number.isSafeInteger(v)&&v>=0&&v<=0xffffffff;
const sha=(v:string)=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
const lowerBound=(c:SourceJointCertificate)=>c.rawOccurrences===0&&c.minimumClearanceLowerBoundM===Infinity||Number.isFinite(c.minimumClearanceLowerBoundM)&&c.minimumClearanceLowerBoundM>=.001;
export function validateSourceJointCertificate(c:SourceJointCertificate,key:SourceJointParentKey,refined:boolean):void {
 if(!c||JSON.stringify(c.key)!==JSON.stringify(key)||!Object.values(key).every(u32)||!key.frameSequence||key.physicalSubstep<1||key.physicalSubstep>40||!key.parentToken)throw Error('Stale/unbound joint physical parent');
 if(![c.originalParentSha256,c.historySha256,c.candidateSha256,c.sourceSha256,c.bodySha256,c.usedGateSha256].every(sha)||c.actualGpuFiniteProducer!==true||c.allCurrentRawOccurrencesChecked!==true||!u32(c.rawOccurrences)||c.unsupported!==0||c.clearanceDeficits!==0||!lowerBound(c)||!Number.isFinite(c.maximumOriginalParentNetM)||c.maximumOriginalParentNetM<0||c.maximumOriginalParentNetM>.005||c.physicalMassAndFixedBitsUnchanged!==true||c.published!==false)throw Error('Incomplete/unsupported/unbounded joint finite certificate');
 if(c.normalReactionAuthoritative!==true||c.normalMultiplierUnit!=='kg-m'||c.frictionReconciled!==true||c.numericalMarginIsPhysicalPressure!==false||c.frictionHistoryGeneration!==key.generation)throw Error('Missing authoritative pressure/friction reconciliation');
 if(c.refinedSeamProof!==(refined?'actual-child-material-u-v3':'ordinary-source-topology'))throw Error('Joint finite proof omitted actual refined source child path');
}
export function sourceJointCommitWGSL():string{return `
struct Params { particleCount:u32, pad0:u32, pad1:u32, pad2:u32 };
@group(0) @binding(0) var<storage,read_write> positions:array<vec4f>;
@group(0) @binding(1) var<storage,read> parent:array<vec4f>;
@group(0) @binding(2) var<storage,read> candidate:array<vec4f>;
@group(0) @binding(3) var<storage,read> ideal:array<vec4f>;
@group(0) @binding(4) var<storage,read_write> physical:array<vec4f>;
@group(0) @binding(5) var<storage,read_write> status:array<atomic<u32>>;
@group(0) @binding(6) var<storage,read_write> frameFiniteStatus:array<atomic<u32>>;
@group(0) @binding(7) var<uniform> params:Params;
fn reject(bits:u32){atomicOr(&status[0],bits);atomicOr(&frameFiniteStatus[0],0x10000u|bits);}
fn finite4(v:vec4f)->bool{return all((bitcast<vec4u>(v)&vec4u(0x7f800000u))!=vec4u(0x7f800000u));}
@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) gid:vec3u){
 let i=gid.x;if(i>=params.particleCount){return;}
 let p=parent[i];let c=candidate[i];let d=ideal[i];let base=physical[i];
 if(!finite4(p)||!finite4(c)||!finite4(d)||!finite4(base)||d.w!=0.0||base.w!=0.0||bitcast<u32>(c.w)!=bitcast<u32>(p.w)){reject(1u);return;}
 if(any(bitcast<vec4u>(positions[i])!=bitcast<vec4u>(p))){reject(2u);return;}
 if(p.w==0.0){if(any(bitcast<vec4u>(c)!=bitcast<vec4u>(p))||any(d.xyz!=vec3f(0))){reject(4u);return;}}
 else {var expected=p.xyz;for(var axis=0u;axis<3u;axis++){if(d[axis]!=0.0){expected[axis]=expected[axis]+d[axis];}}if(any(bitcast<vec3u>(c.xyz)!=bitcast<vec3u>(expected))||dot(c.xyz-p.xyz,c.xyz-p.xyz)>0.000025){reject(8u);return;}}
 let next=vec4f(base.xyz+d.xyz,0);if(!finite4(next)){reject(16u);return;}
 physical[i]=next;positions[i]=c;atomicAdd(&status[1],1u);
}`;}
const copyWGSL=`@group(0) @binding(0) var<storage,read> input:array<vec4f>;
@group(0) @binding(1) var<storage,read_write> output:array<vec4f>;
@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) gid:vec3u){if(gid.x<arrayLength(&input)){output[gid.x]=input[gid.x];}}`;
export class SourceJointEngineBridge {
 private readonly owned:GPUBuffer[]=[];readonly originalParent:GPUBuffer;readonly materialHistory:GPUBuffer;
 private readonly backend:SourceJointBackend;private readonly copyPipe:GPUComputePipeline;private readonly commitPipe:GPUComputePipeline;
 private readonly historyBG:GPUBindGroup;private readonly parentBG:GPUBindGroup;private readonly status:GPUBuffer;private readonly readback:GPUBuffer;private readonly params:GPUBuffer;
 private readonly activeOperations=new Set<Promise<unknown>>();private closePromise:Promise<void>|null=null;
 private frameSequence=0;private generation=0;private parentToken=0;private physicalSubstep=0;private awaitingProof=false;private destroyed=false;private usedActivation:CollisionSeamActivation|null=null;private lastCertificate:SourceJointCertificate|null=null;private acceptedFrameReceipt:Readonly<Record<string,unknown>>|null=null;
 constructor(private readonly creation:Omit<SourceJointCreation,'originalParent'|'materialHistory'>,private readonly positions:GPUBuffer,private readonly packedDelta:GPUBuffer,private readonly layout:DeltaLayout,factory:SourceJointBackendFactory){
  const n=creation.simulation.particleCount,bytes=n*16,d=creation.device;
  if(!creation.simulation.sourcePhysicalMembrane||!layout.enabled||creation.config.subSteps!==40||d.limits.maxStorageBuffersPerShaderStage<8||bytes>d.limits.maxBufferSize||bytes>d.limits.maxStorageBufferBindingSize)throw Error('Unsupported explicit source joint engine scope');
  let pendingBackend:SourceJointBackend|undefined;
  try{
   const alloc=(label:string,size:number,usage:number)=>{const b=d.createBuffer({label:'copied-joint-engine:'+label,size,usage});this.owned.push(b);return b;};
   const usage=GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST;
   this.originalParent=alloc('immutable-post-support-parent',bytes,usage);this.materialHistory=alloc('immutable-corrected-before-prediction-history',bytes,usage);
   this.status=alloc('once-only-contact-commit-status',16,usage);this.readback=alloc('commit-status-readback',16,GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ);this.params=alloc('commit-count',16,GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST);
   d.queue.writeBuffer(this.params,0,Uint32Array.of(n,0,0,0));
   this.copyPipe=d.createComputePipeline({layout:'auto',compute:{module:d.createShaderModule({code:copyWGSL}),entryPoint:'main'}});
   this.commitPipe=d.createComputePipeline({layout:'auto',compute:{module:d.createShaderModule({code:sourceJointCommitWGSL()}),entryPoint:'main'}});
   const bg=(target:GPUBuffer)=>d.createBindGroup({layout:this.copyPipe.getBindGroupLayout(0),entries:[{binding:0,resource:{buffer:positions}},{binding:1,resource:{buffer:target}}]});this.historyBG=bg(this.materialHistory);this.parentBG=bg(this.originalParent);
   this.backend=pendingBackend=factory({...creation,originalParent:this.originalParent,materialHistory:this.materialHistory});
   if(!sha(this.backend.implementationSha256)||!u32(this.backend.snapshotBytes)||this.backend.snapshotBytes%4)throw Error('Unbound concrete source backend snapshot/code');
  }catch(error){if(pendingBackend)void pendingBackend.destroy().catch(()=>{});this.owned.forEach(b=>b.destroy());throw error;}
 }
 get acceptedFrameCommitReceipt(){return this.acceptedFrameReceipt?structuredClone(this.acceptedFrameReceipt):null;}
 get snapshotBytes(){return this.creation.simulation.particleCount*32+16+this.backend.snapshotBytes;}
 get policy(){return{scope:'COPIED source joint whole-engine proposal',backendImplementationSha256:this.backend.implementationSha256,legacyFinishingSkipped:true,normalPressureAndFrictionRequired:true,physicalDeltaAddition:'once/final certified parent',nativeOffAllocationCount:0,deviceValidated:false,fullFitAccepted:false};}
 encodeSnapshot(e:GPUCommandEncoder,target:GPUBuffer,offset:number){const bytes=this.creation.simulation.particleCount*16;e.copyBufferToBuffer(this.originalParent,0,target,offset,bytes);e.copyBufferToBuffer(this.materialHistory,0,target,offset+bytes,bytes);e.copyBufferToBuffer(this.status,0,target,offset+2*bytes,16);this.backend.encodeSnapshot(e,target,offset+2*bytes+16);}
 encodeRestore(e:GPUCommandEncoder,target:GPUBuffer,offset:number){const bytes=this.creation.simulation.particleCount*16;e.copyBufferToBuffer(target,offset,this.originalParent,0,bytes);e.copyBufferToBuffer(target,offset+bytes,this.materialHistory,0,bytes);e.copyBufferToBuffer(target,offset+2*bytes,this.status,0,16);this.backend.encodeRestore(e,target,offset+2*bytes+16);this.awaitingProof=false;this.physicalSubstep=0;this.usedActivation=null;this.lastCertificate=null;this.acceptedFrameReceipt=null;this.backend.invalidate();}
 beginFrame(generation:number,activation:CollisionSeamActivation,policySha256:string){return this.trackOperation(()=>this.beginFrameInner(generation,activation,policySha256));}
 private async beginFrameInner(generation:number,activation:CollisionSeamActivation,policySha256:string){
  if(this.destroyed||this.awaitingProof||!u32(generation)||!sha(policySha256)||!u32(activation.revision)||!u32(activation.sewnUpTo))throw Error('Unbound/concurrent source joint frame');
  this.acceptedFrameReceipt=null;this.generation=generation;this.frameSequence++;this.physicalSubstep=0;this.usedActivation=cloneActivation(activation);this.awaitingProof=true;
  await this.backend.beginFrame({generation,frameSequence:this.frameSequence,sourceDeltaPolicySha256:policySha256,usedActivation:cloneActivation(activation)});this.requireCurrent();
 }
 private requireCurrent(){if(this.destroyed||!this.awaitingProof||!this.creation.isCurrent())throw Error('Source joint immutable frame lease changed');}
 captureMaterialHistory(pass:GPUComputePassEncoder){this.requireCurrent();pass.setPipeline(this.copyPipe);pass.setBindGroup(0,this.historyBG);pass.dispatchWorkgroups(Math.ceil(this.creation.simulation.particleCount/64));}
 captureOriginalParent(pass:GPUComputePassEncoder){this.requireCurrent();pass.setPipeline(this.copyPipe);pass.setBindGroup(0,this.parentBG);pass.dispatchWorkgroups(Math.ceil(this.creation.simulation.particleCount/64));}
 private key(physicalSubstep:number){return Object.freeze({generation:this.generation,frameSequence:this.frameSequence,physicalSubstep,parentToken:this.parentToken,gateRevision:this.usedActivation!.revision});}
 finishPhysicalSubstep(physicalSubstep:number){return this.trackOperation(()=>this.finishPhysicalSubstepInner(physicalSubstep));}
 private async finishPhysicalSubstepInner(physicalSubstep:number){
  this.requireCurrent();if(physicalSubstep!==this.physicalSubstep+1||physicalSubstep>40)throw Error('Skipped/duplicated joint physical step');this.parentToken++;
  const key=this.key(physicalSubstep),usedActivation=cloneActivation(this.usedActivation!);const result=await this.backend.finishPhysicalSubstep({key,physicalDt:this.creation.config.deltaT,usedActivation});this.requireCurrent();
  validateSourceJointCertificate(result.certificate,key,!!this.creation.simulation.sourceGatherCollisionGeometry);
  const bytes=this.creation.simulation.particleCount*16;
  if(result.candidate===result.idealContactDelta||[this.positions,this.originalParent,this.materialHistory,this.packedDelta].some(b=>b===result.candidate||b===result.idealContactDelta)||result.candidate.size<bytes||result.idealContactDelta.size<bytes)throw Error('Aliased/incomplete joint candidate and ideal delta');
  const d=this.creation.device,e=d.createCommandEncoder();e.clearBuffer(this.status);const pass=e.beginComputePass();pass.setPipeline(this.commitPipe);pass.setBindGroup(0,d.createBindGroup({layout:this.commitPipe.getBindGroupLayout(0),entries:[{binding:0,resource:{buffer:this.positions}},{binding:1,resource:{buffer:this.originalParent}},{binding:2,resource:{buffer:result.candidate,offset:0,size:bytes}},{binding:3,resource:{buffer:result.idealContactDelta,offset:0,size:bytes}},{binding:4,resource:{buffer:this.packedDelta,offset:this.layout.physicalBytes,size:bytes}},{binding:5,resource:{buffer:this.status}},{binding:6,resource:{buffer:this.creation.finiteStatus}},{binding:7,resource:{buffer:this.params}}]}));pass.dispatchWorkgroups(Math.ceil(this.creation.simulation.particleCount/64));pass.end();e.copyBufferToBuffer(this.status,0,this.readback,0,16);d.queue.submit([e.finish()]);
  let mapped=false;try{await this.readback.mapAsync(GPUMapMode.READ);mapped=true;const words=new Uint32Array(this.readback.getMappedRange().slice(0));this.requireCurrent();if(words[0]||words[1]!==this.creation.simulation.particleCount)throw Error('Source joint contact commit invalid: flags='+words[0]+' particles='+words[1]);}finally{if(mapped)this.readback.unmap();}
  this.physicalSubstep=physicalSubstep;this.lastCertificate=structuredClone(result.certificate);
 }
 sealPhysicalSubstep(){return this.trackOperation(()=>this.sealPhysicalSubstepInner());}
 private async sealPhysicalSubstepInner(){this.requireCurrent();const key=this.key(this.physicalSubstep);const c=await this.backend.sealPhysicalSubstep({key,positions:this.positions,usedActivation:cloneActivation(this.usedActivation!)});this.requireCurrent();validateSourceJointCertificate(c,key,!!this.creation.simulation.sourceGatherCollisionGeometry);if(c.originalParentSha256!==this.lastCertificate?.originalParentSha256||c.historySha256!==this.lastCertificate?.historySha256||c.sourceSha256!==this.lastCertificate?.sourceSha256||c.bodySha256!==this.lastCertificate?.bodySha256||c.usedGateSha256!==this.lastCertificate?.usedGateSha256)throw Error('Joint final physical certificate changed immutable provenance');this.lastCertificate=structuredClone(c);}
 finishFrame(){return this.trackOperation(()=>this.finishFrameInner());}
 private async finishFrameInner(){this.requireCurrent();if(this.physicalSubstep!==40)throw Error('Incomplete source joint40 frame');await this.backend.finishFrame();this.requireCurrent();}
 acceptFrame(proof:CollisionGuardReport){let captured:CollisionGuardReport;try{captured=structuredClone(proof);}catch(error){return Promise.reject(error);}return this.trackOperation(()=>this.acceptFrameInner(captured));}
 private async acceptFrameInner(proof:CollisionGuardReport){this.requireCurrent();if(!proof.safe||!proof.finite||proof.trajectory?.valid!==true||proof.trajectory.expectedSubSteps!==40||proof.trajectory.inspectedSubsteps!==40||this.physicalSubstep!==40)throw Error('Missing actual all41 joint frame proof');const bytes=proof.verifiedWorkerRequest;if(!bytes||bytes.encoding!=='source-guard-actual-byte-receipt-v1'||bytes.expectedSubSteps!==40||bytes.sampleSha256s.length!==41||!bytes.sampleSha256s.every(sha)||!sha(bytes.workerContextSha256)||!sha(bytes.activationSha256)||!u32(bytes.requestId)||!bytes.requestId||bytes.startPositionsSha256!==bytes.sampleSha256s[0]||bytes.finalPositionsSha256!==bytes.sampleSha256s[40])throw Error('Missing actual joint Worker41 byte binding');const gate=proof.seamActivation,used=this.usedActivation!;if(!gate||gate.revision!==used.revision||gate.sewnUpTo!==used.sewnUpTo||gate.activeSeams.length!==used.activeSeams.length||gate.activeSeams.some((v,i)=>v!==used.activeSeams[i]))throw Error('Joint proof used a foreign sewing activation');await this.backend.acceptFrame(proof);this.requireCurrent();const receipt=this.backend.acceptedFrameCommitReceipt;
  const accepted=receipt?.usedActivation as CollisionSeamActivation|undefined;
  if(receipt?.kind!=='actual-source-joint-frame-commit-v1'||receipt.accepted!==true||receipt.fullFitAccepted!==false||receipt.generation!==this.generation||receipt.frameSequence!==this.frameSequence||receipt.physicalSubsteps!==40||receipt.geometrySamples!==41||!sha(receipt.all41GuardProofSha256 as string)||!sha(receipt.frameCommitSha256 as string)||!sha(receipt.pressureHistorySha256 as string)||!accepted||accepted.revision!==used.revision||accepted.sewnUpTo!==used.sewnUpTo||accepted.activeSeams.length!==used.activeSeams.length||accepted.activeSeams.some((v,i)=>v!==used.activeSeams[i]))throw Error('Backend did not retain the actual accepted frame commit receipt');
  this.acceptedFrameReceipt=structuredClone(receipt);this.awaitingProof=false;}
 invalidate(){this.acceptedFrameReceipt=null;this.backend.invalidate();}
 resetHistory(){this.acceptedFrameReceipt=null;this.backend.invalidate();this.backend.resetHistory();this.awaitingProof=false;this.physicalSubstep=0;this.lastCertificate=null;}
 private trackOperation<T>(run:()=>Promise<T>):Promise<T>{
  if(this.destroyed)return Promise.reject(Error('Destroyed source joint bridge'));
  const operation=Promise.resolve().then(run);this.activeOperations.add(operation);
  void operation.then(()=>this.activeOperations.delete(operation),()=>this.activeOperations.delete(operation));return operation;
 }
 destroy():Promise<void>{
  if(this.closePromise)return this.closePromise;this.destroyed=true;this.acceptedFrameReceipt=null;this.backend.invalidate();
  this.closePromise=(async()=>{
   await Promise.allSettled(Array.from(this.activeOperations));
   try{await this.backend.destroy();}finally{await this.creation.device.queue.onSubmittedWorkDone().catch(()=>{});this.owned.forEach(b=>b.destroy());}
  })();return this.closePromise;
 }
}
