import{SourceSelfIntervalGuard}from'./selfIntervalClearance.mjs';
export const COINCIDENT_ACTIVE_SEAM_POLICY='source-original-active-exact-linear-seam-vertex-identification-v1';
/** Exact coincident original stitch trajectories acquire a shared topological
 * point ONLY for geometric self separation. No force/mass/topology is rewritten.
 * Actual Worker/source context must bind this immutable dictionary and the USED
 * activation; this component alone does not authenticate upstream GPU origin. */
export class SourceCoincidentActiveSeamSelfGuard{
 #count;#triangles;#stride;#groups;#stitchCount;#options;
 constructor(input,options={}){
  const {particleCount,clothTriangles,clothTriangleStride=4,seamPairsBySeam,stitchCount}=input;
  new SourceSelfIntervalGuard({particleCount,clothTriangles,clothTriangleStride},options);
  if(!Number.isSafeInteger(stitchCount)||stitchCount<0||!Array.isArray(seamPairsBySeam))throw Error('Authoritative original seam dictionary required');
  this.#count=particleCount;this.#triangles=Array.from(clothTriangles);this.#stride=clothTriangleStride;this.#stitchCount=stitchCount;this.#options={...options};
  const names=new Set();this.#groups=seamPairsBySeam.map((g,index)=>{
   if(typeof g.seamId!=='string'||!g.seamId||names.has(g.seamId)||g.index!==index||!g.pairs||g.pairs.length%2||!g.stitchIndices||!g.stitchIndexKinds||g.stitchIndices.length!==g.pairs.length/2||g.stitchIndexKinds.length!==g.stitchIndices.length)throw Error('Invalid authoritative original seam group');
   const pairs=Array.from(g.pairs),stitches=Array.from(g.stitchIndices),kinds=Array.from(g.stitchIndexKinds);
   if(pairs.some(v=>!Number.isSafeInteger(v)||v<0||v>=particleCount)||stitches.some(v=>!Number.isSafeInteger(v)||v<0||v>=stitchCount)||
    kinds.some((v,k)=>v!==(pairs[k*2]===pairs[k*2+1]?'identity-logical':'reciprocal-first-stamp')))throw Error('Invalid original seam stitch provenance');
   names.add(g.seamId);return{seamId:g.seamId,pairs,stitches};
  });
 }
 inspect(first,last,activation){
  if(!activation||!Number.isSafeInteger(activation.revision)||activation.revision<0||!(activation.activeSeams instanceof Uint32Array)||activation.activeSeams.length!==this.#groups.length||
   activation.activeSeams.some(v=>v!==0&&v!==1)||!Number.isSafeInteger(activation.sewnUpTo)||activation.sewnUpTo<0||activation.sewnUpTo>this.#stitchCount)throw Error('Actual USED seam activation required');
  if(!(first instanceof Float32Array)||!(last instanceof Float32Array)||first.length!==this.#count*4||last.length!==first.length)throw Error('Invalid seam trajectory snapshots');
  const active=activation.activeSeams.slice(),parent=Array.from({length:this.#count},(_,k)=>k),fa=new Uint32Array(first.buffer,first.byteOffset,first.length),la=new Uint32Array(last.buffer,last.byteOffset,last.length);
  const find=i=>{let root=i;while(parent[root]!==root)root=parent[root];while(parent[i]!==i){const n=parent[i];parent[i]=root;i=n;}return root;};
  let identifiedOriginalPairs=0;
  for(let group=0;group<this.#groups.length;group++){if(active[group]!==1)continue;const g=this.#groups[group];
   for(let k=0;k<g.stitches.length;k++){
    if(g.stitches[k]>=activation.sewnUpTo)continue;const a=g.pairs[k*2],b=g.pairs[k*2+1];if(a===b)continue;
    if(![0,1,2].every(c=>fa[a*4+c]===fa[b*4+c]&&la[a*4+c]===la[b*4+c]))continue;
    const ar=find(a),br=find(b);if(ar!==br)parent[Math.max(ar,br)]=Math.min(ar,br);identifiedOriginalPairs++;
   }
  }
  const triangles=this.#triangles.map((id,k)=>k%this.#stride<3?find(id):id);
  const guard=new SourceSelfIntervalGuard({particleCount:this.#count,clothTriangles:triangles,clothTriangleStride:this.#stride},this.#options),report=guard.inspect(first,last);
  return{...report,coincidentActiveSeam:{policy:COINCIDENT_ACTIVE_SEAM_POLICY,identifiedOriginalPairs,geometryChanged:false,forcesOrMobilityChanged:false,
   activation:{revision:activation.revision,sewnUpTo:activation.sewnUpTo,activeSeams:Array.from(active)},wholeLinearCoincidenceRequired:true}};
 }
}
