import type {CollisionGuardInput,CollisionSeamActivation} from './collisionGuard';
export const SELF_INTERVAL_POLICY:'source-self-linear-outward-interval-v1';
export const COINCIDENT_ACTIVE_SEAM_POLICY:'source-original-active-exact-linear-seam-vertex-identification-v1';
export const ACTIVE_SEAM_POINT_CONE_POLICY:'source-active-original-seam-point-affine-gap-exact-dyadic-v1';
export const ACTIVE_SEAM_EDGE_CONE_POLICY:'source-active-original-seam-edge-affine-gap-exact-dyadic-v1';
export function validActiveOriginalSeamScope(value:unknown):boolean;
export interface SelfIntervalResult{clear:boolean;policy:typeof SELF_INTERVAL_POLICY;candidateSelfPairs:number;intervalsChecked:number;positiveSelfThicknessCertified:false;firstUnresolvedPair?:{clothFace:number;otherClothFace:number;interval:[number,number];reason:string};coincidentActiveSeam:{policy:typeof COINCIDENT_ACTIVE_SEAM_POLICY;identifiedOriginalPairs:number;geometryChanged:false;forcesOrMobilityChanged:false;activation:{revision:number;sewnUpTo:number;activeSeams:number[]};wholeLinearCoincidenceRequired:true};activeOriginalPointSeam:{pointConeAttempts:number;pointConeProvedFacePairs:number};activeOriginalEdgeSeam:{edgeConeAttempts:number;edgeConeProvedFacePairs:number}}
export class SourceActiveOriginalSeamSelfGuard{constructor(input:CollisionGuardInput,options?:{maxDepth?:number;maxIntervals?:number});inspect(first:Float32Array,last:Float32Array,activation:CollisionSeamActivation):SelfIntervalResult}
