import {SELF_INTERVAL_POLICY} from './selfIntervalClearance.mjs';
import {COINCIDENT_ACTIVE_SEAM_POLICY,validActiveOriginalSeamScope} from './activeOriginalSeamSelf.mjs';
/** Bound report schema, not an independent origin or positive thickness proof. */
export function requireSourceSelfIntervalTrajectoryProof(report){
 const p=report?.sourceSelfIntervalTrajectory,a=report?.seamActivation,b=p?.usedActivation;
 if(!validActiveOriginalSeamScope(p)||!p||p.policy!==SELF_INTERVAL_POLICY||p.coincidentActiveSeamPolicy!==COINCIDENT_ACTIVE_SEAM_POLICY||p.interpolation!=='piecewise-linear'||p.expectedSubsteps!==40||p.inspectedSubsteps!==40||p.clear!==true||p.zeroThicknessSelfContinuousCertified!==true||p.positiveSelfThicknessCertified!==false||p.wholeLinearCoincidenceRequired!==true||!['candidateSelfPairs','intervalsChecked','identifiedOriginalPairs'].every(k=>Number.isSafeInteger(p[k])&&p[k]>=0)||p.intervalsChecked<p.candidateSelfPairs||p.firstUnresolvedSubstep!==undefined||p.firstUnresolvedPair!==undefined||!a||!b||a.revision!==b.revision||a.sewnUpTo!==b.sewnUpTo||!(Array.isArray(a.activeSeams)||a.activeSeams instanceof Uint32Array)||!Array.isArray(b.activeSeams)||a.activeSeams.length!==b.activeSeams.length||a.activeSeams.some((v,i)=>v!==b.activeSeams[i]))throw Error('Missing complete actual source zero-thickness self-interval proof');
 return structuredClone(p);
}
