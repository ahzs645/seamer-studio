import type { SimConfig } from './config';

/** Bind executed source scheduling to its policy snapshot. Native/off returns the original object. */
export function immutableSourcePhaseConfig(config: SimConfig, enabled: boolean): SimConfig {
  if (!enabled) return config;
  const copy = structuredClone(config);
  const freeze = (value: object): void => {
    for (const child of Object.values(value)) {
      if (child !== null && typeof child === 'object') freeze(child);
    }
    Object.freeze(value);
  };
  freeze(copy);
  return copy;
}
