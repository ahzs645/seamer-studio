// Copied research adapter. Baseline source strings are never mutated in place.
// A source-only opt-in records the actual algebraic correction BEFORE world-coordinate add.
const bind=(binding)=>`\n@group(0) @binding(${binding}) var<storage, read_write> sourceDelta: array<vec4f>;\n`;
function replaceOnce(text,needle,replacement){
  if(text.split(needle).length!==2)throw Error('Source shader drift or duplicate delta writer: '+needle);
  return text.replace(needle,replacement);
}
function binding(text,b){return replaceOnce(text,'@compute',bind(b)+`
@group(0) @binding(${b+1}) var<storage, read_write> sourceDeltaStatus: array<atomic<u32>>;
fn sourceRecordDelta(index:u32, increment:vec3f) {
  let next=sourceDelta[index].xyz+increment;
  if(any((bitcast<vec3u>(increment)&vec3u(0x7f800000u))==vec3u(0x7f800000u)) || any((bitcast<vec3u>(next)&vec3u(0x7f800000u))==vec3u(0x7f800000u))) { atomicOr(&sourceDeltaStatus[0],1u); return; }
  sourceDelta[index]=vec4f(next,0.0);
}
`+'@compute');}
export function withSourceDelta(kind,baseline,enabled=false){
  if(!enabled)return baseline;
  let s=baseline;
  if(kind==='prediction'){
    s=binding(s,8);
    s=replaceOnce(s,'  pos += vel * deltaT;','  let predictionDelta = vel * deltaT;\n  sourceDelta[index] = vec4f(0.0);\n  sourceRecordDelta(index,predictionDelta);\n  pos += predictionDelta;');
    s=replaceOnce(s,'  positions[index] = vec4f(pos, invMass);','  if (invMass > 0.0) { positions[index] = vec4f(pos, invMass); }');
    s=replaceOnce(s,'        pos += grabbedDelta * grabInfluence;','        let grabDelta = grabbedDelta * grabInfluence;\n        sourceRecordDelta(index,grabDelta);\n        pos += grabDelta;');
    s=replaceOnce(s,'    pos = mix(pos, anchors[index].xyz, anchorStrength * aw);','    let anchorDelta = (anchors[index].xyz - pos) * (anchorStrength * aw);\n    sourceRecordDelta(index,anchorDelta);\n    pos += anchorDelta;');
  }else if(kind==='distance'){
    s=binding(s,3);
    s=replaceOnce(s,'  p1 += grad * lambda * w1;\n  p2 += grad * -lambda * w2;','  let d1 = grad * lambda * w1; let d2 = grad * -lambda * w2;\n  sourceRecordDelta(p1Index,d1);\n  sourceRecordDelta(p2Index,d2);\n  p1 += d1; p2 += d2;');
    s=replaceOnce(s,'  positions[p1Index] = vec4f(p1, w1);\n  positions[p2Index] = vec4f(p2, w2);','  if (w1 > 0.0) { positions[p1Index] = vec4f(p1, w1); }\n  if (w2 > 0.0) { positions[p2Index] = vec4f(p2, w2); }');
  }else if(kind==='bending'){
    s=binding(s,3);
    s=replaceOnce(s,'    p1 = hingeMid + rotateAroundAxis(p1 - hingeMid, edgeDir, -angleStep * w1Scale);\n    p2 = hingeMid + rotateAroundAxis(p2 - hingeMid, edgeDir, angleStep * w2Scale);',
      '    let r1 = p1 - hingeMid; let r2 = p2 - hingeMid;\n    let a1 = -angleStep * w1Scale; let a2 = angleStep * w2Scale;\n    let d1 = r1 * (cos(a1)-1.0) + cross(edgeDir,r1)*sin(a1) + edgeDir*dot(edgeDir,r1)*(1.0-cos(a1));\n    let d2 = r2 * (cos(a2)-1.0) + cross(edgeDir,r2)*sin(a2) + edgeDir*dot(edgeDir,r2)*(1.0-cos(a2));\n    sourceRecordDelta(p1Index,d1); sourceRecordDelta(p2Index,d2);\n    p1 += d1; p2 += d2;');
    s=replaceOnce(s,'    p1 += grad * lambda * w1;\n    p2 += grad * -lambda * w2;','    let d1 = grad * lambda * w1; let d2 = grad * -lambda * w2;\n    sourceRecordDelta(p1Index,d1); sourceRecordDelta(p2Index,d2);\n    p1 += d1; p2 += d2;');
    s=s.replaceAll('    positions[p1Index] = vec4f(p1, w1);','    if (w1 > 0.0) { positions[p1Index] = vec4f(p1, w1); }').replaceAll('    positions[p2Index] = vec4f(p2, w2);','    if (w2 > 0.0) { positions[p2Index] = vec4f(p2, w2); }');
  }else if(kind==='support'){
    s=binding(s,3);
    s=replaceOnce(s,'  positions[i].y += correction;','  sourceRecordDelta(i,vec3f(0.0,correction,0.0));\n  positions[i].y += correction;');
  }else if(kind==='apply'){
    s=binding(s,2);
    s=replaceOnce(s,'  positions[index] = vec4f(positions[index].xyz + d, positions[index].w);','  sourceRecordDelta(index,d);\n  positions[index] = vec4f(positions[index].xyz + d, positions[index].w);');
  }else if(kind==='velocity'){
    s=binding(s,3);
    s=replaceOnce(s,'  if (positions[index].y <= thickness) {','  if (positions[index].w <= 0.0) { velocities[index]=vec4f(0.0); return; }\n  if (positions[index].y <= thickness) {');
    s=replaceOnce(s,'    positions[index].y = thickness;','    sourceRecordDelta(index,vec3f(0.0,thickness-positions[index].y,0.0));\n    positions[index].y = thickness;');
    s=replaceOnce(s,'  var vel = globalDamping * (positions[index].xyz - lastPositions[index].xyz) / deltaT;','  var vel = globalDamping * sourceDelta[index].xyz / deltaT;');
  }else if(kind==='body-point-solve'){
    s=replaceOnce(s,'@compute',bind(6)+'@compute');
    s=replaceOnce(s,'  let delta=positions[index].xyz-previous[index].xyz;','  let delta=sourceDelta[index].xyz;');
  }else throw Error('Unowned position phase '+kind);
  const storage=[...s.matchAll(/var<storage,/g)].length;
  if(storage>8)throw Error('Portable source storage limit exceeded');
  return s;
}
