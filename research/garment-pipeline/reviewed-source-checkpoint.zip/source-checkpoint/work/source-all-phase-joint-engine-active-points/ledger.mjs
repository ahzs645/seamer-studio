// CPU lifecycle oracle for one tentative source frame, not a cloth solver.
export const PHASES=['prediction','material','bending','particle-self','sewing','support','contact','floor'];
export class SourceDeltaLedger {
  constructor(particleCount){
    if(!Number.isSafeInteger(particleCount)||particleCount<1)throw Error('Particle count');
    this.n=particleCount;this.delta=new Float32Array(particleCount*4);this.contact=new Float32Array(particleCount*4);this.state='idle';this.generation=0;
  }
  beginFrame(generation){
    if(this.state!=='idle'||!Number.isSafeInteger(generation)||generation<0)throw Error('Frame lifetime');
    this.snapshot={delta:this.delta.slice(),contact:this.contact.slice(),generation:this.generation};this.generation=generation;this.substep=-1;this.state='frame';
  }
  beginPhysical(substep,positions){
    if(this.state!=='frame'||substep!==this.substep+1||substep>=40||positions.length!==this.n*4)throw Error('Physical history lifetime');
    this.substep=substep;this.mass=positions.filter((_,i)=>i%4===3);this.delta.fill(0);this.contact.fill(0);this.state='physical';this.consumed=false;
  }
  accumulate(phase,raw){
    if(this.state!=='physical'||!PHASES.includes(phase)||phase==='contact'||raw.length!==this.n*4)throw Error('Raw phase ownership');
    for(let i=0;i<raw.length;i++){
      if(!Number.isFinite(raw[i])||(i%4===3&&raw[i]!==0)||(this.mass[i>>2]<=0&&raw[i]!==0))throw Error('Raw finite mobility');
    }
    const next=this.delta.slice();for(let i=0;i<raw.length;i++)next[i]=Math.fround(next[i]+raw[i]);
    if(next.some(x=>!Number.isFinite(x)))throw Error('Delta overflow');this.delta=next;
  }
  replaceContact(raw,generation,substep){
    if(this.state!=='physical'||generation!==this.generation||substep!==this.substep||raw.length!==this.n*4)throw Error('Contact parent lifetime');
    if(raw.some((x,i)=>!Number.isFinite(x)||(i%4===3&&x!==0)||(this.mass[i>>2]<=0&&x!==0)))throw Error('Contact finite mobility');
    this.contact=raw.slice();
  }
  consume(dt){
    if(this.state!=='physical'||this.consumed||!Number.isFinite(dt)||dt<=0)throw Error('Once-only delta consumption');
    const result=new Float32Array(this.n*4);for(let i=0;i<result.length;i++)if(i%4!==3)result[i]=Math.fround(Math.fround(this.delta[i]+this.contact[i])/dt);
    if(result.some(x=>!Number.isFinite(x)))throw Error('Velocity overflow');this.consumed=true;this.state='frame';return result;
  }
  accept(proof){if(this.state!=='frame'||this.substep!==39||!proof?.safe||!proof?.finite||proof.generation!==this.generation||proof.states!==41)throw Error('Whole-frame publication');this.state='idle';this.snapshot=null;}
  rollback(){if(!this.snapshot)throw Error('Rollback lifetime');this.delta=this.snapshot.delta;this.contact=this.snapshot.contact;this.generation=this.snapshot.generation;this.snapshot=null;this.state='idle';}
}
