/** CPU executed-byte boundary controls; no device or garment acceptance. */
import test from 'node:test';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
import {requireActualPhysicalOperatorReadback,validatePhysicalReactionReceipt} from './SourceJointWholeEngineBackend.mjs';
import {actualAllContactOperatorEvidence} from '../source-pressure-friction-whole-provider/actualAllContactOperatorEvidence.mjs';
const sha=x=>createHash('sha256').update(x).digest('hex'),H='a'.repeat(64),key={generation:1,frameSequence:1,physicalSubstep:1,parentToken:2,gateRevision:0};
function fixture(){
 const rows=new Uint32Array(24);rows[18]=1;const rowBytes=new Uint8Array(rows.buffer),terms=new Uint8Array(384),proof=Uint32Array.of(0,2,8,12,2,7,5,0);
 const status=Uint32Array.of(0,2,7,12,1,2,7,1,0,0,1,2,0,0,0,0),reaction=Float32Array.of(1,0,0,0,2,0,0,0),ideal=new Float32Array(4);
 const binding={key,sourceToken:7,bodyGeneration:5,rawOccurrences:8,originalRawOccurrences:8,originalRawRow128Sha256:H,originalRawProofSha256:H,...Object.fromEntries(['originalParentSha256','historySha256','sourceSha256','bodySha256','usedGateSha256','fullRawRow128Sha256','physicalMassPolicySha256','declaredFrictionProfileSha256','executedTolerancePolicySha256','executedAnchorPartitionPolicySha256'].map(k=>[k,H]))};
 const input={key,rawOccurrences:8,binding:structuredClone(binding)};
 binding.packedPhysicalJacobianSha256=sha(Buffer.concat([rowBytes,terms]));binding.physicalRhsSha256=sha(rowBytes);
 const evidence=actualAllContactOperatorEvidence({actualGpuPhysicalPackProducer:true,actualPhysicalRows:rowBytes,actualPhysicalTerms:terms,proof},{actualGpuReactionReadback:true,physicalOperatorAccepted:true,normalMultiplierUnit:'kg-m',numericalMarginIsPhysicalPressure:false,statusCapacity:status,reaction,idealCombinedContactDelta:ideal,executed:{components:1}},binding,1);
 return{input,operator:{...evidence,binding,actualGpuOperatorReadbackVerified:true,packedPhysicalJacobianSha256:binding.packedPhysicalJacobianSha256,physicalRhsSha256:binding.physicalRhsSha256,actualPhysicalRows:rowBytes,actualPhysicalTerms:terms,actualPackProof:proof,actualStatus:status,actualReaction:reaction,actualIdealPhysicalContactDelta:ideal}};
}
test('actual operator J/RHS authored after pack bind by complete readback, not input labels',async()=>{
 const {input,operator}=fixture();assert.equal(input.binding.packedPhysicalJacobianSha256,undefined);await requireActualPhysicalOperatorReadback(operator,input,1);
 assert.equal(operator.selfContactPhysicalRowCount,1);assert.equal(operator.actualReaction[4],2);
});
test('changed actual row/term/lambda/proof/status/delta cannot keep same operator digest',async()=>{
 for(const name of ['actualPhysicalRows','actualPhysicalTerms','actualReaction','actualPackProof','actualStatus','actualIdealPhysicalContactDelta']){const{input,operator}=fixture();new Uint8Array(operator[name].buffer)[0]^=1;await assert.rejects(requireActualPhysicalOperatorReadback(operator,input,1),/operator|ALL-contact/);}
 for(const name of ['packedPhysicalJacobianSha256','physicalRhsSha256','actualAllContactOperatorReceiptSha256']){const{input,operator}=fixture();operator[name]=H;await assert.rejects(requireActualPhysicalOperatorReadback(operator,input,1),/digest/);}
});
test('foreign physical key/source/raw inventory cannot authenticate a private executed operator',async()=>{
 for(const name of ['sourceSha256','originalParentSha256','fullRawRow128Sha256','physicalMassPolicySha256','originalRawProofSha256']){const{input,operator}=fixture();operator.binding[name]='b'.repeat(64);await assert.rejects(requireActualPhysicalOperatorReadback(operator,input,1),/binding|inventory/);}
 const{input,operator}=fixture();operator.binding.key={...key,parentToken:99};await assert.rejects(requireActualPhysicalOperatorReadback(operator,input,1),/lease/);
});
test('authority booleans or pre-pack guessed hashes alone do not satisfy receipt boundary',()=>{
 const{input}=fixture();assert.throws(()=>validatePhysicalReactionReceipt({binding:input.binding},input,{}, {},H),/scope|readback/);
});
test('authenticated genuine empty operator retains its exact binding hash domain',async()=>{
 const proof=Uint32Array.of(0,0,7,0,0,0,0,0),proofSHA=sha(new Uint8Array(proof.buffer)),{input}=fixture();input.rawOccurrences=0;input.binding={...input.binding,originalRawOccurrences:0,originalRawRow128Sha256:sha(new Uint8Array()),fullRawRow128Sha256:sha(new Uint8Array()),originalRawProofSha256:proofSHA};
 const emptyHashBinding=structuredClone(input.binding),operator={actualGpuOperatorReadbackVerified:true,actualAuthenticatedEmptyOperator:true,binding:structuredClone(input.binding),emptyHashBinding,actualOriginalRawProof:proof,allContactPhysicalRowCount:0,bodyContactPhysicalRowCount:0,selfContactPhysicalRowCount:0,packedPhysicalJacobianSha256:sha(new Uint8Array()),physicalRhsSha256:sha(new Uint8Array()),actualAllContactOperatorReceiptSha256:sha('actual-empty-physical-operator-v1\n'+JSON.stringify(emptyHashBinding)+proofSHA)};
 await requireActualPhysicalOperatorReadback(operator,input,1);
 for(const change of [{emptyHashBinding:{...emptyHashBinding,sourceSha256:'b'.repeat(64)}},{actualOriginalRawProof:Uint32Array.of(0,0,7,1,0,0,0,0)},{allContactPhysicalRowCount:1}])await assert.rejects(requireActualPhysicalOperatorReadback({...operator,...change},input,1));
});
test('operator observations and input bindings are captured before first async digest',async()=>{
 const{input,operator}=fixture(),pending=requireActualPhysicalOperatorReadback(operator,input,1);operator.actualPhysicalRows[0]=255;operator.binding.sourceSha256='b'.repeat(64);input.binding.sourceSha256='c'.repeat(64);const result=await pending;assert.equal(result.actualPhysicalRows[0],0);assert.equal(result.binding.sourceSha256,H);
});
