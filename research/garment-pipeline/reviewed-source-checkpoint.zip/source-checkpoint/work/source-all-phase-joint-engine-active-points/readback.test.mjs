import{deltaByteFixture}from'./delta-byte-fixtures.mjs';
import{workerByteFixture}from'./worker-byte-fixtures.mjs';
import test from'node:test';import assert from'node:assert/strict';import fs from'node:fs';import{createRequire}from'node:module';
const require=createRequire('/workspace/seamer-studio/package.json'),ts=require('typescript');
const path='/workspace/work/source-all-phase-joint-engine-delta-commit/src/webgpu/engine.ts';
let js=ts.transpileModule(fs.readFileSync(path,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText;
js=js.replace(/^import[\s\S]*?from\s+['"][^'"]+['"];\s*/gm,'').replaceAll('export class ','class ');
const ClothEngine=new Function(js+'\nreturn ClothEngine;')();
Object.assign(globalThis,{GPUMapMode:{READ:1},GPUBufferUsage:{COPY_SRC:4,COPY_DST:8}});
function engine({stale=false,reject=false,invalid=false}={}){
 const x=Object.create(ClothEngine.prototype),words=new Float32Array(41*8);if(invalid)words[9]=NaN;let unmapped=0,primaryUnmapped=0;
 x.particleCount=2;x.config={subSteps:40};x.stateGeneration=stale?2:1;x.disposalRequested=false;x.latestSourceDeltaTrace=[];
 x.sourceDeltaTraceReadback={async mapAsync(){if(reject)throw Error('map rejected');},getMappedRange(){return words.buffer;},unmap(){unmapped++;}};
 x.readback={unmap(){primaryUnmapped++;}};return{x,words,counts:()=>({unmapped,primaryUnmapped})};
}
test('actual copied engine preserves41 private raw delta slots as independent copies',async()=>{
 const f=engine();f.words[8]=.000001;await f.x.finishSourceDeltaTrace(1);assert.equal(f.x.sourcePhysicalDeltaTrace.length,41);const before=f.x.sourcePhysicalDeltaTrace[1][0];f.words[8]=99;assert.equal(f.x.sourcePhysicalDeltaTrace[1][0],before);assert.deepEqual(f.counts(),{unmapped:1,primaryUnmapped:0});
});
test('stale generation never publishes ledger readback and still unmaps',async()=>{
 const f=engine({stale:true});await f.x.finishSourceDeltaTrace(1);assert.deepEqual(f.x.sourcePhysicalDeltaTrace,[]);assert.deepEqual(f.counts(),{unmapped:1,primaryUnmapped:0});
});
test('failed raw map drains primary map and cannot certify delta trace',async()=>{
 const f=engine({reject:true});await assert.rejects(f.x.finishSourceDeltaTrace(1),/map rejected/);assert.deepEqual(f.x.sourcePhysicalDeltaTrace,[]);assert.deepEqual(f.counts(),{unmapped:0,primaryUnmapped:1});
});
test('actual nonfinite delta trace rejects while preserving exact diagnostic sample',async()=>{
 const f=engine({invalid:true});await assert.rejects(f.x.finishSourceDeltaTrace(1),/nonfinite/);assert(Number.isNaN(f.x.sourcePhysicalDeltaTrace[1][1]));assert.deepEqual(f.counts(),{unmapped:1,primaryUnmapped:1});
});
test('actual engine snapshot restores packed ideal/contact/physical deltas and persistent flags',()=>{
 const x=Object.create(ClothEngine.prototype),make=size=>({size,bytes:new Uint8Array(size),destroy(){}}),copies=[];
 const encoder={copyBufferToBuffer(a,ao,b,bo,n){copies.push([ao,bo,n]);b.bytes.set(a.bytes.subarray(ao,ao+n),bo);},finish(){return{};}};
 x.device={createBuffer:({size})=>make(size),createCommandEncoder:()=>encoder,queue:{submit(){}}};
 x.particleCount=2;x.positions=make(32);x.lastPositions=make(32);x.velocities=make(32);x.sourceDelta=make(1280);x.sourceDeltaStatus=make(16);x.sourceMembrane=null;
 x.gateSnapshots=new WeakMap();x.supportSnapshots=new WeakMap();x.assemblyController=null;x.sewnUpToValue=0;x.sourceStructuralStaging=false;x.currentSeamActivation=null;x.setSewnUpTo=()=>{};
 const buffers=[x.positions,x.lastPositions,x.velocities,x.sourceDelta,x.sourceDeltaStatus];buffers.forEach((b,i)=>b.bytes.fill(i+17));const originals=buffers.map(b=>b.bytes.slice());
 const snapshot=x.captureState();buffers.forEach(b=>b.bytes.fill(0));x.latestSourceDeltaTrace=[Float32Array.of(99)];x.restoreState(snapshot);
 buffers.forEach((b,i)=>assert.deepEqual(b.bytes,originals[i]));assert.deepEqual(x.sourcePhysicalDeltaTrace,[]);assert.equal(snapshot.size,96+1280+16);assert.equal(copies.length,10);
});
test('actual executed delta policy binds shader and captured config; getter edits never mutate hash',async()=>{
 const x=Object.create(ClothEngine.prototype);x.sourceDelta={};x.sourceDeltaLayout={abi:4,physicalBytes:256};x.sourceDeltaShaderPackets={prediction:'authentic shader bytes'};x.sourceDeltaConfig={deltaT:.0004,gravity:[0,-9.81,0]};x.sourceMembrane={policySha256:'material-v3'};
 assert.equal(await x.bindSourceDeltaPolicy(),null);const first=x.sourceDeltaPolicy;assert.match(first.policySha256,/^[0-9a-f]{64}$/);first.configuration.deltaT=7;first.shaderSha256.prediction='tampered';assert.equal(x.sourceDeltaPolicy.configuration.deltaT,.0004);assert.notEqual(x.sourceDeltaPolicy.shaderSha256.prediction,'tampered');assert.equal(x.sourceDeltaPolicy.policySha256,first.policySha256);assert.equal(x.sourceDeltaPolicy.jointFinisherImplemented,false);
});

test('actual reset clears prior-generation private raw delta diagnostics',()=>{
 const f=engine();f.x.latestSourceDeltaTrace=[Float32Array.of(777,0,0,0)];Object.assign(f.x,{sourceMembrane:null,device:{queue:{writeBuffer(){}}},sourceDelta:{size:1280},sourceDeltaStatus:{},positions:{},velocities:{},lastPositions:{}});f.x.resetPositions(Float32Array.of(0,1,0,2,0,2,0,2));assert.equal(f.x.sourcePhysicalDeltaTrace.length,0);assert.equal(f.x.collisionTrajectoryPositions.length,0);
});
test('actual source frame entry discards old candidate41/delta/profile before an early readiness failure',async()=>{
 const f=engine();Object.assign(f.x,{inFlight:false,sourceDelta:{},sourceMembrane:null,latestSourceDeltaTrace:[Float32Array.of(777)],latestCollisionTrajectory:[Float32Array.of(888)],latestCollisionSubsteps:[Float32Array.of(999)],latestGPUProfile:{old:true},latestCollisionPhases:[{old:true}]});f.x.stepInner=async()=>{assert.equal(f.x.sourcePhysicalDeltaTrace.length,0);assert.equal(f.x.collisionTrajectoryPositions.length,0);assert.equal(f.x.collisionPhaseObservations.length,0);assert.equal(f.x.gpuStageProfile,null);throw Error('early material readiness failure');};await assert.rejects(f.x.step(),/early material/);assert.equal(f.x.inFlight,false);assert.equal(f.x.sourcePhysicalDeltaTrace.length,0);
});
test('actual body replacement and disposal invalidate prior candidate delta diagnostics',()=>{
 for(const operation of ['body','dispose']){const f=engine();Object.assign(f.x,{sourceDelta:{},latestSourceDeltaTrace:[Float32Array.of(777)],inFlight:true,bodyPositions:{destroy(){throw Error('body allocation stop');}}});if(operation==='body')assert.throws(()=>f.x.updateBodyMesh({}),/body allocation stop/);else f.x.dispose();assert.equal(f.x.sourcePhysicalDeltaTrace.length,0);}
});
