/** Synthetic CPU structural fixture only; not actual worker/device evidence. */
import{createHash}from'node:crypto';const b=new ArrayBuffer(5*8),v=new DataView(b);[1,3,5,1,1].forEach((x,i)=>v.setFloat64(i*8,x,true));const activationSha=createHash('sha256').update(Buffer.from(b)).digest('hex');
export const workerByteFixture=()=>({encoding:'source-guard-actual-byte-receipt-v1',workerContextSha256:'a'.repeat(64),activationSha256:activationSha,requestId:1,expectedSubSteps:40,sampleSha256s:Array(41).fill('a'.repeat(64)),startPositionsSha256:'a'.repeat(64),finalPositionsSha256:'a'.repeat(64)});
