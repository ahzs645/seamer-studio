import{bodyFacetFixture,selfIntervalFixture}from'./receipt-fixtures.mjs';
import{deltaByteFixture}from'./delta-byte-fixtures.mjs';
import{workerByteFixture}from'./worker-byte-fixtures.mjs';
import{bridgeReceipt}from'./receipt-fixtures.mjs';
/** CPU lifecycle/shader-reflection controls only. Fake buffers never prove GPU physics. */
import test from'node:test';import assert from'node:assert/strict';import fs from'node:fs';import{createRequire}from'node:module';
const root='/workspace/work/source-all-phase-joint-engine-delta-commit';const ts=createRequire('/workspace/seamer-studio/package.json')('typescript');
const compile=p=>ts.transpileModule(fs.readFileSync(root+'/'+p,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText.replace(/^import[\s\S]*?from\s+['"][^'"]+['"];\s*/gm,'').replaceAll('export ','');
const {SourceJointEngineBridge,validateSourceJointCertificate,sourceJointCommitWGSL}=new Function(compile('src/webgpu/sourceJointEngineBridge.ts')+'\nreturn {SourceJointEngineBridge,validateSourceJointCertificate,sourceJointCommitWGSL};')();
const Engine=new Function(compile('src/webgpu/engine.ts')+'\nreturn ClothEngine;')();
const key={generation:2,frameSequence:1,physicalSubstep:1,parentToken:1,gateRevision:3},h='a'.repeat(64);
const certificate=()=>({key:{...key},originalParentSha256:h,historySha256:h,candidateSha256:h,sourceSha256:h,bodySha256:h,usedGateSha256:h,actualGpuFiniteProducer:true,allCurrentRawOccurrencesChecked:true,rawOccurrences:17,unsupported:0,clearanceDeficits:0,minimumClearanceLowerBoundM:.0011,maximumOriginalParentNetM:.001,physicalMassAndFixedBitsUnchanged:true,normalReactionAuthoritative:true,normalMultiplierUnit:'kg-m',frictionReconciled:true,frictionHistoryGeneration:2,numericalMarginIsPhysicalPressure:false,refinedSeamProof:'ordinary-source-topology',published:false});
test('bound certificate requires actual pressure/friction, allraw/refined proof and immutable physical parent',()=>{
 validateSourceJointCertificate(certificate(),key,false);
 for(const [field,value]of [['normalReactionAuthoritative',false],['frictionReconciled',false],['numericalMarginIsPhysicalPressure',true],['unsupported',1],['clearanceDeficits',1],['maximumOriginalParentNetM',.00501],['frictionHistoryGeneration',3],['allCurrentRawOccurrencesChecked',false]])assert.throws(()=>validateSourceJointCertificate({...certificate(),[field]:value},key,false),Error,field);
 assert.throws(()=>validateSourceJointCertificate(certificate(),{...key,parentToken:2},false),/Stale/);assert.throws(()=>validateSourceJointCertificate(certificate(),key,true),/refined/);validateSourceJointCertificate({...certificate(),refinedSeamProof:'actual-child-material-u-v3'},key,true);
 validateSourceJointCertificate({...certificate(),rawOccurrences:0,minimumClearanceLowerBoundM:Infinity},key,false);
 assert.throws(()=>validateSourceJointCertificate({...certificate(),minimumClearanceLowerBoundM:Infinity},key,false),/Incomplete/);
 assert.throws(()=>validateSourceJointCertificate({...certificate(),rawOccurrences:0,minimumClearanceLowerBoundM:NaN},key,false),/Incomplete/);
});
test('actual commit kernel has7storage and retains signed-zero axes; ledger added once, fixed and physicalW protected',()=>{
 const code=sourceJointCommitWGSL();assert.equal([...code.matchAll(/var<storage,/g)].length,7);assert.match(code,/if\(d\[axis\]!=0.0\)/);assert.match(code,/bitcast<u32>\(c.w\)!=bitcast<u32>\(p.w\)/);assert.match(code,/if\(p.w==0.0\)/);assert.match(code,/physical\[i\]=next;positions\[i\]=c/);assert.equal([...code.matchAll(/base.xyz\+d.xyz/g)].length,1);assert.equal(Object.is(Math.fround(-0+0),-0),false);let seed=-0;if(0!==0)seed=Math.fround(seed+0);assert(Object.is(seed,-0));
});
test('actual stepInner flushes all40 real boundary captures, replaces ALL legacy finishing and seals after velocity/floor',async()=>{
 const e=Object.create(Engine.prototype),events=[],pipeline=label=>({label});
 const pass=()=>({setPipeline(p){events.push('pipe:'+p?.label);},setBindGroup(){},dispatchWorkgroups(){},end(){events.push('end');}}),encoder=()=>({beginComputePass:pass,copyBufferToBuffer(){},finish(){return{};}});
 Object.assign(globalThis,{GPUMapMode:{READ:1}});
 Object.assign(e,{config:{subSteps:40,deltaT:.0004,seamIterations:8,useBending:true,localDamping:0,nearDamping:0,substepContactIterations:4,finalContactIterations:4},device:{createCommandEncoder:encoder,queue:{submit(){events.push('submit');}}},particleCount:2,triangleCount:1,stateGeneration:2,disposalRequested:false,sourceDeltaExecutedPolicy:{policySha256:h},currentSeamActivation:{revision:3,activeSeams:Uint32Array.of(1),sewnUpTo:1},selfCollision:false,externalCollision:true,externalDirty:false,stretchGroups:[],bendGroups:[],readback:{async mapAsync(){events.push('map-positions');}},readbackControllerMs:0});
 e.wg=n=>Math.ceil(n/64);e.finishTrajectoryReadback=async()=>{};e.finishPhaseReadback=async()=>{};e.finishReadback=()=>Float32Array.of(0,1,0,2,0,2,0,2);
 for(const name of ['integrate','distance','bend','seam','apply','reset','support','velocity','solveExternal','solveExternalSurface','solveSelfSurface'])e[name+'Pipe']=pipeline(name);
 e.supportBG={};e.sourceJointBridge={async beginFrame(){events.push('begin-frame');},captureMaterialHistory(){events.push('old-corrected-history');},captureOriginalParent(){events.push('post-support-parent');},async finishPhysicalSubstep(s){assert.equal(events.at(-1),'submit');events.push('joint:'+s);},async sealPhysicalSubstep(){assert.equal(events.at(-1),'submit');events.push('fresh-final-floor-certificate');},async finishFrame(){events.push('pending-frame');}};
 await e.stepInner(2);assert.equal(events.filter(v=>v==='old-corrected-history').length,40);assert.equal(events.filter(v=>v==='post-support-parent').length,40);assert.equal(events.filter(v=>v==='fresh-final-floor-certificate').length,40);assert.equal(events.filter(v=>v==='submit').length,81);assert(!events.some(v=>['pipe:solveExternal','pipe:solveExternalSurface','pipe:solveSelfSurface'].includes(v)));
 for(let s=0;s<40;s++){const at=events.indexOf('joint:'+(s+1)),old=events.lastIndexOf('old-corrected-history',at),support=events.lastIndexOf('pipe:support',at),parent=events.lastIndexOf('post-support-parent',at),prediction=events.indexOf('pipe:integrate',old),velocity=events.indexOf('pipe:velocity',at),fresh=events.indexOf('fresh-final-floor-certificate',at);assert(old<prediction&&prediction<support&&support<parent&&parent<at&&at<velocity&&velocity<fresh);}
 assert(events.indexOf('pending-frame')<events.indexOf('map-positions'));
});
test('actual source snapshot byte topology reserves backend/private parent/history state; no backend leaves original shape',()=>{
 const code=fs.readFileSync(root+'/src/webgpu/engine.ts','utf8');assert.match(code,/sourceJointBridge\?\.snapshotBytes\?\?0/);assert.match(code,/sourceJointBridge\.encodeSnapshot/);assert.match(code,/sourceJointBridge\.encodeRestore/);assert.match(code,/if\(options.sourceJointBackendFactory\)/);assert.match(code,/sourceJointBridge\?\.resetHistory/);
});
test('bridge actual acceptFrame rejects insufficient40/41 proof before backend publication',async()=>{
 const b=Object.create(SourceJointEngineBridge.prototype);b.activeOperations=new Set();b.usedActivation={revision:3,sewnUpTo:5,activeSeams:Uint32Array.of(1)};b.creation={isCurrent:()=>true};b.awaitingProof=true;b.destroyed=false;b.physicalSubstep=40;b.generation=2;b.frameSequence=1;let calls=0;b.backend={acceptedFrameCommitReceipt:bridgeReceipt(),async acceptFrame(){calls++;}};
 await assert.rejects(b.acceptFrame({safe:true,finite:true,sourceBodyFacetTrajectory:bodyFacetFixture(),sourceSelfIntervalTrajectory:selfIntervalFixture(),verifiedWorkerRequest:workerByteFixture(),verifiedPhysicalDeltaTrace:deltaByteFixture(),trajectory:{valid:true,expectedSubSteps:40,inspectedSubsteps:39}}),/all41/);assert.equal(calls,0);await b.acceptFrame({safe:true,finite:true,sourceBodyFacetTrajectory:bodyFacetFixture(),sourceSelfIntervalTrajectory:selfIntervalFixture(),verifiedWorkerRequest:workerByteFixture(),verifiedPhysicalDeltaTrace:deltaByteFixture(),trajectory:{valid:true,expectedSubSteps:40,inspectedSubsteps:40},seamActivation:{revision:3,sewnUpTo:5,activeSeams:[1]}});assert.equal(calls,1);assert.equal(b.awaitingProof,false);
});
test('actual executed policy reports supplied scheduler while keeping unvalidated joint readiness explicit',async()=>{
 for(const supplied of [false,true]){const e=Object.create(Engine.prototype);e.sourceDelta={};e.sourceDeltaLayout={abi:4,physicalBytes:256};e.sourceDeltaConfig={subSteps:40};e.sourceDeltaShaderPackets={};e.sourceJointBridge=supplied?{policy:{deviceValidated:false}}:undefined;
 assert.equal(await e.bindSourceDeltaPolicy(),null);const p=e.sourceDeltaPolicy;assert.equal(p.legacyFinishingContactsRemain,!supplied);assert.equal(p.jointFinisherImplemented,supplied);if(supplied){assert.equal(p.jointBackendInjected,true);assert.equal(p.jointFinisherDeviceValidated,false);}else assert(!('jointBackendInjected'in p));assert.match(p.policySha256,/^[a-f0-9]{64}$/);}
});
