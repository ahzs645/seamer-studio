import {defineConfig} from 'vitest/config';
export default defineConfig({test:{environment:'node',include:['body-facet-hook.test.ts','src/collisionGuard.test.ts','src/collisionGuardWorker.test.ts']}});
