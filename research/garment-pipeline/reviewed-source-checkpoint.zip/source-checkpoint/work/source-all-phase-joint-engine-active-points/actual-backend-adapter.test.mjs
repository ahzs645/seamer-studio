import{bodyFacetFixture,selfIntervalFixture}from'./receipt-fixtures.mjs';
import{deltaByteFixture}from'./delta-byte-fixtures.mjs';
import{workerByteFixture}from'./worker-byte-fixtures.mjs';
import{frame,physicalReceipts,acceptedPressure}from'./receipt-fixtures.mjs';
/** CPU contract/lifecycle tests only; no device request, no garment solve. */
import test from 'node:test';import assert from 'node:assert/strict';
import {SourceJointWholeEngineBackend,bindActualInventoryCertificate,validatePhysicalReactionReceipt as actualValidatePhysicalReactionReceipt,requireActualPhysicalOperatorReadback,actualGuardProofSha256,requireActualRefinedProducerProof} from './SourceJointWholeEngineBackend.mjs';
import{SOURCE_ANCHOR_PARTITION_POLICY_SHA256}from'../source-pressure-friction-whole-provider/anchorPartitionPolicy.mjs';
const h='a'.repeat(64),j='b'.repeat(64),key={generation:2,frameSequence:1,physicalSubstep:1,parentToken:4,gateRevision:3};
const binding=()=>({...Object.fromEntries(['originalParentSha256','historySha256','usedGateSha256','sourceSha256','bodySha256','fullRawRow128Sha256','originalRawProofSha256','packedPhysicalJacobianSha256','physicalMassPolicySha256','declaredFrictionProfileSha256','physicalRhsSha256','executedTolerancePolicySha256','executedAnchorPartitionPolicySha256'].map(k=>[k,k==='executedAnchorPartitionPolicySha256'?SOURCE_ANCHOR_PARTITION_POLICY_SHA256:h])),key:{...key}});
const validation={receiptSha256:h,driverSha256:h,physicalPackShaderSha256:h,reactionShaderSha256:h,validatedAnchorPartitionPolicySha256:SOURCE_ANCHOR_PARTITION_POLICY_SHA256,authenticBodyBVHAnchorProbeReceiptSha256:h,anchorProbeShaderSha256:h,validatedAnchorPartitionPolicy:{sourceMaterialPartitionError:2e-6,bodyBarycentricPartitionError:2e-6},validatedTolerancePolicySha256:h,validatedTolerances:{algebraicNormalDeficitM:1e-8,algebraicComplementarityResidualM:1e-8,frictionResidualM:1e-8},actualDeviceControlsPassed:true,scopedCases:['CPU fixture only'],resourcesClosed:true};
const fresh=()=>({...binding(),candidateSha256:h,maximumOriginalParentNetM:.001});
const receipt=()=>({reactionRecordScope:'body-pressure-friction-only-v1',actualAllContactOperatorReceiptSha256:h,allContactPhysicalRowCount:1,bodyContactPhysicalRowCount:1,selfContactPhysicalRowCount:0,binding:{...binding(),originalRawOccurrences:1,originalRawRow128Sha256:h},mechanicalCandidateSha256:h,finalCandidateSha256:h,normalPhysicalRhs:'exact-physical-1mm',normalMultiplierUnit:'kg-m',numericalMarginIsPhysicalPressure:false,normalReactionAuthoritative:true,algebraicNormalDeficitM:0,algebraicComplementarityResidualM:0,frictionResidualM:0,storedForceFinite:true,fixedMassAndSignedZeroBitsPreserved:true,reactions:[],numericalClearanceDeltaSha256:h,idealCombinedContactDeltaSha256:h,actualFreshAllRawCertificateSha256:h,originalParentNetM:.001,actualFreshAllRawCertificateEncoding:'canonical-sorted-json-v2-empty-contact-bounds',all41GuardProofSha256:null,deviceReactionReceiptSha256:h,executedPhysicalPackShaderSha256:h,executedReactionShaderSha256:h});
// Synthetic CPU schema fixtures; actual private GPU-byte validation is tested separately.
const operatorFixture=()=>({actualGpuOperatorReadbackVerified:true,binding:binding(),packedPhysicalJacobianSha256:h,physicalRhsSha256:h,actualAllContactOperatorReceiptSha256:h,allContactPhysicalRowCount:1,bodyContactPhysicalRowCount:1,selfContactPhysicalRowCount:0});
function validatePhysicalReactionReceipt(r,input,fresh,v,hash){return actualValidatePhysicalReactionReceipt({...r,binding:{...r.binding,originalRawOccurrences:input.rawOccurrences}},input,fresh,v,hash,{...operatorFixture(),allContactPhysicalRowCount:r.allContactPhysicalRowCount,bodyContactPhysicalRowCount:r.bodyContactPhysicalRowCount,selfContactPhysicalRowCount:r.selfContactPhysicalRowCount});}
test('actual inventory ABI retains empty infinity and rejects unsupported/incomplete rows',()=>{
 const c={complete:true,physicalClearanceCertified:true,unsupportedFlags:0,strictClearanceDeficits:0,allRawOccurrences:0,minimumLowerBoundM:Infinity};
 const b=bindActualInventoryCertificate(c,key);assert.equal(b.rawOccurrences,0);assert.equal(b.minimumClearanceLowerBoundM,Infinity);assert.notEqual(b.key,key);
 for(const [k,v]of [['complete',false],['physicalClearanceCertified',false],['unsupportedFlags',1],['strictClearanceDeficits',1],['allRawOccurrences',-.1]])assert.throws(()=>bindActualInventoryCertificate({...c,[k]:v},key));
});
test('physical receipts bind complete raw/J/mass/RHS and device shader epochs, never numerical pressure',()=>{
 validatePhysicalReactionReceipt(receipt(),{key,binding:binding(),rawOccurrences:1},fresh(),validation,h);
 for(const k of Object.keys(binding()).filter(k=>k!=='key')){const r=receipt();r.binding[k]=j;assert.throws(()=>validatePhysicalReactionReceipt(r,{key,binding:binding(),rawOccurrences:1},fresh(),validation,h),/binding/);}
 for(const [k,v]of [['normalPhysicalRhs','augmented-64u'],['numericalMarginIsPhysicalPressure',true],['normalMultiplierUnit','kg-m2'],['fixedMassAndSignedZeroBitsPreserved',false],['all41GuardProofSha256',h],['finalCandidateSha256',j],['deviceReactionReceiptSha256',j],['frictionResidualM',NaN],['originalParentNetM',.006],['actualFreshAllRawCertificateSha256',j]])assert.throws(()=>validatePhysicalReactionReceipt({...receipt(),[k]:v},{key,binding:binding(),rawOccurrences:1},fresh(),validation,h),Error,k);
});
test('missing pressure/device readiness rejects before concrete GPU constructor or geometry preparation',async()=>{
 let prepared=0;const create=()=>({isCurrent:()=>true,simulation:{},device:null});
 const options={implementationSha256:h,prepareActualGeometry:async()=>{prepared++;}};
 const b=new SourceJointWholeEngineBackend(create(),options);
 await assert.rejects(b.beginFrame({generation:2,frameSequence:1,sourceDeltaPolicySha256:h,usedActivation:{revision:3,sewnUpTo:5,activeSeams:Uint32Array.of(1)}}),/provider unavailable/);assert.equal(prepared,0);await b.destroy();
 const noop=()=>{},p={implementationSha256:h,snapshotBytes:0,deviceValidation:null,encodeSnapshot:noop,encodeRestore:noop,beforeFrame:noop,reconcileActualReaction:noop,readActualAllContactOperatorReceipt:noop,acceptFrame:noop,invalidate:noop,resetHistory:noop,destroy:noop};
 const c=new SourceJointWholeEngineBackend(create(),{...options,physicalReactionProvider:p});await assert.rejects(c.beginFrame({generation:2,frameSequence:1,usedActivation:{revision:3,sewnUpTo:5,activeSeams:Uint32Array.of(1)}}),/device/);assert.equal(prepared,0);await c.destroy();
});
test('whole-frame acceptance hashes actual proof and does not publish deficient40 proof',async()=>{
 const b=Object.create(SourceJointWholeEngineBackend.prototype);b.activeOperations=new Set();b.creation={isCurrent:()=>true,simulation:{particleCount:1,sourcePhysicalMembrane:{policySha256:h}}};b.frame=frame();b.receipts=physicalReceipts();b.implementationSha256=h;b.closed=false;b.invalidated=false;let accepted=null;b.reaction={implementationSha256:h,async acceptFrame(hash){accepted=hash;return acceptedPressure(hash);}};
 await assert.rejects(b.acceptFrame({safe:true,finite:true,sourceBodyFacetTrajectory:bodyFacetFixture(),sourceSelfIntervalTrajectory:selfIntervalFixture(),verifiedWorkerRequest:workerByteFixture(),verifiedPhysicalDeltaTrace:deltaByteFixture(),trajectory:{valid:true,expectedSubSteps:40,inspectedSubsteps:39}}),/41/);assert.equal(accepted,null);
 const proof={safe:true,finite:true,sourceBodyFacetTrajectory:bodyFacetFixture(),sourceSelfIntervalTrajectory:selfIntervalFixture(),verifiedWorkerRequest:workerByteFixture(),verifiedPhysicalDeltaTrace:deltaByteFixture(),trajectory:{valid:true,expectedSubSteps:40,inspectedSubsteps:40},seamActivation:{revision:3,activeSeams:Uint32Array.of(1),sewnUpTo:5}};
 await b.acceptFrame(proof);assert.equal(accepted,await actualGuardProofSha256(proof));assert.equal(b.frame,null);
 assert.notEqual(accepted,await actualGuardProofSha256({...proof,seamActivation:{...proof.seamActivation,activeSeams:Uint32Array.of(0)}}));
});
test('final floor freshness cannot relabel a changed candidate as same authoritative pressure state',async()=>{
 const b=Object.create(SourceJointWholeEngineBackend.prototype);b.activeOperations=new Set();b.creation={isCurrent:()=>true,simulation:{}};b.frame={};b.closed=false;b.invalidated=false;b.step={args:{key},combined:{receipt:{finalCandidateSha256:h},release(){}}};b.virtual={async inspectPhysicalCandidate(){return{virtualCertified:true,certificate:{candidateSha256:j,refinedSeamProof:'ordinary-source-topology'}};}};
 await assert.rejects(b.sealPhysicalSubstep({key,positions:{}}),/Floor|floor/);
});
test('actual producer child proof cannot be inferred or upgraded from a prepared scope boolean',()=>{
 assert.throws(()=>requireActualRefinedProducerProof({sourceGatherCollisionGeometry:{}},{refinedSeamProof:'ordinary-source-topology',actualRefinedChildContextVerified:true}),/producer/);
 assert.equal(requireActualRefinedProducerProof({sourceGatherCollisionGeometry:{}},{refinedSeamProof:'actual-child-material-u-v3'}),'actual-child-material-u-v3');
 assert.throws(()=>requireActualRefinedProducerProof({},{refinedSeamProof:'actual-child-material-u-v3'}));
});
const packetHarness=(mutate=false)=>{
 const owned=[],copies=[];globalThis.GPUBufferUsage={STORAGE:1,COPY_SRC:2,COPY_DST:4};
 const buffer=(size)=>({size,bytes:new Uint8Array(size),destroy(){this.destroyed=true;}});
 const device={limits:{maxBufferSize:1024,maxStorageBufferBindingSize:1024},createBuffer(o){const b=buffer(o.size);owned.push(b);return b;},createCommandEncoder(){return{copyBufferToBuffer(a,offset,b,target,size){copies.push({a,b,size});b.bytes.set(a.bytes.slice(offset,offset+size),target);},finish(){return{};}};},queue:{submit(){},async onSubmittedWorkDone(){}}};
 const parent=buffer(16),history=buffer(16),raw=buffer(128),proof=buffer(32),current=buffer(16);raw.bytes[3]=43;proof.bytes[0]=99;
 const b=Object.create(SourceJointWholeEngineBackend.prototype);b.activeOperations=new Set();b.creation={isCurrent:()=>!b.invalidated,device,simulation:{particleCount:1},originalParent:parent,materialHistory:history};b.frame={};b.closed=false;b.invalidated=false;b.pendingPhysicalInput={key};b.pendingPhysicalPacket=null;b.geometry={};b.virtual={async read(x,size){return x.bytes.slice(0,size).buffer;}};
 b.options={async preparePhysicalReactionInput({actualInventoryLease:l}){if(mutate)b.invalidated=true;return{key,originalParent:parent,history,actualRow128:l.raw,actualRawProof:l.proofBuffer,rawOccurrences:1,produceOwnedBodyAnchors(){throw Error('CPU fixture cannot launch anchor');},binding:{...binding(),originalRawProofSha256:(await import('node:crypto')).createHash('sha256').update(l.proofBuffer.bytes).digest('hex'),fullRawRow128Sha256:await actualGuardProofSha256({notByteHash:true})}};}};
 const lease={exclusiveReadLease:true,key,inventory:{complete:true,physicalClearanceCertified:true,allRawOccurrences:1},raw,proofBuffer:proof,current,rawByteLength:128,proof:Uint32Array.of(99),binding:{}};
 return{b,device,lease,owned,copies,parent,history};
};
test('actual adapter owned-copy method uses GPU proof copy, rejects forged raw binding and drains all copies',async()=>{
 const{b,lease,owned,copies}=packetHarness();
 await assert.rejects(b.captureFinalActualInventory(lease),/actual complete GPU Row128/);assert.equal(owned.length,4);assert(owned.every(x=>x.destroyed));assert.equal(copies.length,3);assert(copies.some(x=>x.a===lease.proofBuffer&&x.b!==lease.proofBuffer));assert.equal(b.pendingPhysicalPacket,null);
});
test('generation cancellation during authentic packet preparation never retains copied rows',async()=>{
 const{b,lease,owned}=packetHarness(true);await assert.rejects(b.captureFinalActualInventory(lease),/generation changed/);assert.equal(owned.length,4);assert(owned.every(x=>x.destroyed));assert.equal(b.pendingPhysicalPacket,null);
});
test('valid byte-bound packet is distinct from producer buffers and records actual first proof bytes',async()=>{
 const{b,lease,owned}=packetHarness();const crypto=await import('node:crypto');
 b.options.preparePhysicalReactionInput=async({actualInventoryLease:l})=>({key,originalParent:b.creation.originalParent,history:b.creation.materialHistory,actualRow128:l.raw,actualRawProof:l.proofBuffer,rawOccurrences:1,produceOwnedBodyAnchors(){throw Error('CPU fixture cannot launch anchor');},binding:{...binding(),originalRawProofSha256:(await import('node:crypto')).createHash('sha256').update(l.proofBuffer.bytes).digest('hex'),fullRawRow128Sha256:crypto.createHash('sha256').update(l.raw.bytes).digest('hex')}});
 await b.captureFinalActualInventory(lease);const p=b.pendingPhysicalPacket;assert.equal(p.owned.length,4);assert.notEqual(p.reactionInput.actualRow128,lease.raw);assert.notEqual(p.reactionInput.actualRawProof,lease.proofBuffer);assert.equal(p.reactionInput.actualRawProof.bytes[0],99);assert.equal(p.reactionInput.actualRow128.bytes[3],43);assert(!owned.some(x=>x.destroyed));p.owned.forEach(x=>x.destroy());
});
test('declared device residual bounds and physical reaction row/anchor schema gate authority',()=>{
 const input={key,binding:binding(),rawOccurrences:1},r=receipt();
 for(const name of ['algebraicNormalDeficitM','algebraicComplementarityResidualM','frictionResidualM'])assert.throws(()=>validatePhysicalReactionReceipt({...r,[name]:1e-7},input,fresh(),validation,h),/tolerance/);
 assert.throws(()=>validatePhysicalReactionReceipt(r,input,fresh(),{...validation,validatedTolerancePolicySha256:j},h),/tolerance policy/);
 const row=bodyRow();
 validatePhysicalReactionReceipt({...r,reactions:[row]},input,fresh(),validation,h);
 for(const bad of [{...row,physicalNormalLambdaKgM:-1},{...row,normalForceN:[0,NaN,0]},{...row,tangentialLambdaKgM:[0,Infinity,0]},{...row,originalRawAliases:[1]},{...row,mode:'separated'},{...row,currentBodyMaterialAnchor:{bodyFace:1}}])assert.throws(()=>validatePhysicalReactionReceipt({...r,reactions:[bad]},input,fresh(),validation,h),/physical|anchor/);
 assert.throws(()=>validatePhysicalReactionReceipt({...r,allContactPhysicalRowCount:2,bodyContactPhysicalRowCount:2,reactions:[row,row]},{...input,rawOccurrences:2},fresh(),validation,h),/reaction row/);
});
test('pending frame validation cannot be retagged by mutable provider tolerance/device metadata',()=>{
 const b=Object.create(SourceJointWholeEngineBackend.prototype);Object.assign(b,{closed:false,invalidated:false,frame:{},creation:{isCurrent:()=>true,simulation:{particleCount:1,sourcePhysicalMembrane:{policySha256:h}}},reaction:{deviceValidation:validation}});
 // Actual shared hash, distinct from Float32 geometry byte hashes.
 b.validationFingerprint='b'.repeat(64);assert.throws(()=>b.requireCurrent(),/validation changed/);
});

const bodyRow=()=>({materialFunctionalSha256:h,originalRawAliases:[0],physicalNormalLambdaKgM:1e-6,normalForceN:[0,6.25,0],tangentialLambdaKgM:[0,0,0],mode:'stick',currentBodyMaterialAnchor:{sourceMaterialIds:[1,2,3],sourceMaterialWeights:[Math.fround(.2),Math.fround(.3),Math.fround(.5)],bodyFace:5,bodyBarycentric:[Math.fround(.2),Math.fround(.3),Math.fround(.5)],materialOffset:[0,0,0],authenticFiniteProbeSha256:h,producerPhysicalSubstep:key.physicalSubstep,bodySha256:h,sourceSha256:h,historySha256:h,usedGateSha256:h}});
test('authentic represented-F32 body and material anchor partitions bind declared dimensionless policy',()=>{
 const input={key,binding:binding(),rawOccurrences:1},row=bodyRow(),r={...receipt(),reactions:[row]};
 validatePhysicalReactionReceipt(r,input,fresh(),validation,h);
 for(const field of ['sourceMaterialWeights','bodyBarycentric'])for(const weights of [[0,0,0],[.5,.5,.5],[1,0,Math.fround(3e-6)]])assert.throws(()=>validatePhysicalReactionReceipt({...r,reactions:[{...row,currentBodyMaterialAnchor:{...row.currentBodyMaterialAnchor,[field]:weights}}]},input,fresh(),validation,h),/partition/);
 for(const invalid of [null,{sourceMaterialPartitionError:Infinity,bodyBarycentricPartitionError:2e-6},{sourceMaterialPartitionError:-1,bodyBarycentricPartitionError:2e-6},{sourceMaterialPartitionError:.1,bodyBarycentricPartitionError:2e-6}])assert.throws(()=>validatePhysicalReactionReceipt(r,input,fresh(),{...validation,validatedAnchorPartitionPolicy:invalid},h),/partition/);
 assert.throws(()=>validatePhysicalReactionReceipt(r,input,fresh(),{...validation,validatedAnchorPartitionPolicySha256:j},h),/partition policy/);
 assert.throws(()=>validatePhysicalReactionReceipt(r,input,fresh(),{...validation,validatedAnchorPartitionPolicySha256:undefined},h),/partition policy/);
 // A validated stricter arithmetic bound must be honored, not replaced by 2e-6.
 assert.throws(()=>validatePhysicalReactionReceipt(r,input,fresh(),{...validation,validatedAnchorPartitionPolicy:{sourceMaterialPartitionError:0,bodyBarycentricPartitionError:0}},h),/partition/);
});
test('missing anchor-policy device validation blocks preparation before GPU allocation',async()=>{
 let prepared=0;const noop=()=>{},bad={...validation};delete bad.validatedAnchorPartitionPolicySha256;
 const provider={implementationSha256:h,snapshotBytes:0,deviceValidation:bad,encodeSnapshot:noop,encodeRestore:noop,beforeFrame:noop,reconcileActualReaction:noop,readActualAllContactOperatorReceipt:noop,acceptFrame:noop,invalidate:noop,resetHistory:noop,destroy:noop};
 const b=new SourceJointWholeEngineBackend({isCurrent:()=>true,simulation:{},device:null},{implementationSha256:h,prepareActualGeometry:async()=>{prepared++;},physicalReactionProvider:provider});
 await assert.rejects(b.beginFrame({generation:2,frameSequence:1,usedActivation:{revision:3,sewnUpTo:5,activeSeams:Uint32Array.of(1)}}),/device/);assert.equal(prepared,0);await b.destroy();
});

test('whole-provider missing actual body-BVH anchor authority fails before geometry/GPU preparation',async()=>{
 for(const field of ['authenticBodyBVHAnchorProbeReceiptSha256','anchorProbeShaderSha256']){let prepared=0;const noop=()=>{},bad={...validation};delete bad[field];const provider={implementationSha256:h,snapshotBytes:0,deviceValidation:bad,encodeSnapshot:noop,encodeRestore:noop,beforeFrame:noop,reconcileActualReaction:noop,readActualAllContactOperatorReceipt:noop,acceptFrame:noop,invalidate:noop,resetHistory:noop,destroy:noop};const b=new SourceJointWholeEngineBackend({isCurrent:()=>true,simulation:{},device:null},{implementationSha256:h,prepareActualGeometry:async()=>{prepared++;},physicalReactionProvider:provider});await assert.rejects(b.beginFrame({generation:2,frameSequence:1,usedActivation:{revision:3,sewnUpTo:5,activeSeams:Uint32Array.of(1)}}),/device/);assert.equal(prepared,0);await b.destroy();}
});

test('body-only pressure records retain all-contact operator counts and reject self relabeling',()=>{
 const input={key,binding:binding(),rawOccurrences:2};const r={...receipt(),allContactPhysicalRowCount:2,bodyContactPhysicalRowCount:1,selfContactPhysicalRowCount:1,reactions:[bodyRow()]};
 validatePhysicalReactionReceipt(r,input,fresh(),validation,h);
 for(const patch of [{reactionRecordScope:'all-contact-pressure'},{actualAllContactOperatorReceiptSha256:null},{allContactPhysicalRowCount:3},{bodyContactPhysicalRowCount:0},{selfContactPhysicalRowCount:0},{allContactPhysicalRowCount:2.5}])assert.throws(()=>validatePhysicalReactionReceipt({...r,...patch},input,fresh(),validation,h),/scope/);
 for(const anchor of [null,undefined])assert.throws(()=>validatePhysicalReactionReceipt({...r,reactions:[{...bodyRow(),currentBodyMaterialAnchor:anchor}]},input,fresh(),validation,h),/body-material anchor/);
});

test('body pressure aliases cannot repeat within or across physical functionals',()=>{
 const input={key,binding:binding(),rawOccurrences:3},r={...receipt(),allContactPhysicalRowCount:3,bodyContactPhysicalRowCount:3};
 for(const rows of [[{...bodyRow(),originalRawAliases:[0,0]}],[bodyRow(),{...bodyRow(),materialFunctionalSha256:j}]])assert.throws(()=>validatePhysicalReactionReceipt({...r,reactions:rows},input,fresh(),validation,h),/physical raw alias/);
});

test('owned raw preserves authentic capacity while hashes and copy range use exact declared rows',async()=>{
 const {b,lease,owned,copies}=packetHarness();lease.raw.size=512;const crypto=await import('node:crypto');
 b.options.preparePhysicalReactionInput=async({actualInventoryLease:l})=>({key,originalParent:b.creation.originalParent,history:b.creation.materialHistory,actualRow128:l.raw,actualRawProof:l.proofBuffer,rawOccurrences:1,produceOwnedBodyAnchors(){throw Error('CPU fixture cannot launch anchor');},binding:{...binding(),originalRawProofSha256:(await import('node:crypto')).createHash('sha256').update(l.proofBuffer.bytes).digest('hex'),fullRawRow128Sha256:crypto.createHash('sha256').update(l.raw.bytes.slice(0,128)).digest('hex')}});
 await b.captureFinalActualInventory(lease);assert.equal(b.pendingPhysicalPacket.reactionInput.actualRow128.size,512);assert.equal(copies.find(x=>x.a===lease.raw).size,128);assert.deepEqual(b.pendingPhysicalPacket.observedRawProof,lease.proof);assert.equal(b.pendingPhysicalPacket.expected.rawOccurrences,1);owned.forEach(x=>x.destroy());
});

test('actual physical output lease is retained through final seal and released before rollback',async()=>{
 const b=Object.create(SourceJointWholeEngineBackend.prototype);const order=[];b.step={combined:{release(){order.push('release');}}};b.reaction={encodeRestore(){order.push('restore');},invalidate(){}};b.virtual={invalidate(){}};b.encodeRestore({}, {}, 0);assert.deepEqual(order,['release','restore']);assert.equal(b.step,null);
 const c=Object.create(SourceJointWholeEngineBackend.prototype);Object.assign(c,{activeOperations:new Set(),creation:{isCurrent:()=>true,simulation:{}},frame:{},closed:false,invalidated:false,step:{args:{key},combined:{receipt:{finalCandidateSha256:h},release(){order.push('failed-seal-release');}}},virtual:{async inspectPhysicalCandidate(){throw Error('fresh finite failure');}}});
 await assert.rejects(c.sealPhysicalSubstep({key,positions:{}}),/finite failure/);assert.equal(c.step,null);assert.equal(order.at(-1),'failed-seal-release');
});

test('seeded numerical callback binds the same original parent/history/gate and physical key',async()=>{
 const b=Object.create(SourceJointWholeEngineBackend.prototype);Object.assign(b,{creation:{isCurrent:()=>true},frame:{},closed:false,invalidated:false});let got;b.virtual={async projectNumericalClearance(q){got=q;return{cpuFixture:true};}};const args={parent:{},history:{},gate:{},key,isCurrent:()=>true},q={originalParent:args.parent,history:args.history,gate:args.gate,key,mechanicalCandidate:{},mechanicalIdeal:{},originalParentSha256:h};
 await b.projectActualNumericalClearance(q,args);assert.equal(got.originalParent,args.parent);assert.equal(got.gate,args.gate);assert.notEqual(got.key,key);
 for(const patch of [{originalParent:{}},{history:{}},{gate:{}},{key:{...key,parentToken:99}}])assert.throws(()=>b.projectActualNumericalClearance({...q,...patch},args),/seed owner/);
});
