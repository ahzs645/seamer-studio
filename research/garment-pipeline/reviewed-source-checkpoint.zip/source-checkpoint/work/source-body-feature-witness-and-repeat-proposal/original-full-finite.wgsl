
struct Row {a:vec4u,b:vec4u,wa:vec4f,wb:vec4f,n:vec4f,q:vec4f,feature:vec4u,proof:vec4u};
struct Config{particles:u32,clothFaces:u32,bodyFaces:u32,capacity:u32,bodyGeneration:u32,sourceToken:u32,gateRevision:u32,substep:u32,cacheSlots:u32,parentStart:u32,finalEnumeration:u32,reserved:u32,snapshotEpoch:u32,historyToken:u32,gateToken:u32,refitFirst:u32,refitCount:u32,refitDepth:u32,p0:u32,p1:u32,expected:array<vec4u,20>};
@group(0) @binding(0) var<storage,read> current:array<vec4f>;
@group(0) @binding(1) var<storage,read> previous:array<vec4f>;
@group(0) @binding(2) var<storage,read> geometry:array<u32>;
@group(0) @binding(3) var<storage,read_write> rows:array<Row>;
@group(0) @binding(4) var<storage,read_write> state:array<atomic<u32>>;
@group(0) @binding(5) var<storage,read_write> cache:array<atomic<u32>>;
@group(0) @binding(8) var<uniform> cfg:Config;
struct Gate {
    sewnUpTo:i32, masked:u32, p1:u32, p2:u32,
    stitchBits:array<vec4u,2>, seamBits:array<vec4u,1>
  };
  fn activeSourceStitch(stitch:i32)->bool {
    if(gate.masked==0u || stitch<0) { return true; }
    let index=u32(stitch); if(index>=175u) { return false; }
    return (gate.stitchBits[index/128u][(index/32u)%4u] & (1u<<(index%32u)))!=0u;
  }
  fn activeSourceSeam(seam:u32)->bool {
    if(gate.masked==0u) { return true; }
    if(seam>=6u) { return false; }
    return (gate.seamBits[seam/128u][(seam/32u)%4u] & (1u<<(seam%32u)))!=0u;
  }
  fn activeSourceSegment(stitch:u32)->bool {
    if(gate.masked==0u) { return true; }
    if(stitch==0xffffffffu) { return false; }
    return i32(stitch)<gate.sewnUpTo && activeSourceStitch(i32(stitch));
  }
@group(0) @binding(9) var<uniform> gate:Gate;
const allowWarmStart=false;const NONE=0xffffffffu;

fn getClosestPointOnSegment(start: vec3f, end: vec3f, point: vec3f) -> vec3f {
  let edge = end - start;
  let lengthSq = dot(edge, edge);
  if (lengthSq <= 1e-20) { return start; }
  return start + edge * clamp(dot(point - start, edge) / lengthSq, 0.0, 1.0);
}

fn getClosestPointOnTriangle(p0: vec3f, p1: vec3f, p2: vec3f, point: vec3f) -> vec3f {
  let ab = p1 - p0; let ac = p2 - p0;
  let normal = cross(ab, ac);
  if (dot(normal, normal) <= 1e-7 * max(dot(ab, ab) * dot(ac, ac), 1e-20)) {
    let a = getClosestPointOnSegment(p0, p1, point);
    let b = getClosestPointOnSegment(p0, p2, point);
    let c = getClosestPointOnSegment(p1, p2, point);
    let da = dot(point - a, point - a);
    let db = dot(point - b, point - b);
    let dc = dot(point - c, point - c);
    if (da <= db && da <= dc) { return a; }
    if (db <= dc) { return b; }
    return c;
  }
  let ap = point - p0;
  let d1 = dot(ab, ap); let d2 = dot(ac, ap);
  if (d1 <= 0.0 && d2 <= 0.0) { return p0; }
  let bp = point - p1;
  let d3 = dot(ab, bp); let d4 = dot(ac, bp);
  if (d3 >= 0.0 && d4 <= d3) { return p1; }
  let vc = d1 * d4 - d3 * d2;
  if (vc <= 0.0 && d1 >= 0.0 && d3 <= 0.0) {
    return p0 + ab * (d1 / (d1 - d3));
  }
  let cp = point - p2;
  let d5 = dot(ab, cp); let d6 = dot(ac, cp);
  if (d6 >= 0.0 && d5 <= d6) { return p2; }
  let vb = d5 * d2 - d1 * d6;
  if (vb <= 0.0 && d2 >= 0.0 && d6 <= 0.0) {
    return p0 + ac * (d2 / (d2 - d6));
  }
  let va = d3 * d6 - d5 * d4;
  if (va <= 0.0 && d4 - d3 >= 0.0 && d5 - d6 >= 0.0) {
    return p1 + (p2 - p1) * ((d4 - d3) / (d4 - d3 + d5 - d6));
  }
  let inverse = 1.0 / (va + vb + vc);
  return p0 + ab * (vb * inverse) + ac * (vc * inverse);
}

fn segmentTriangleHit(start: vec3f, end: vec3f, a: vec3f, b: vec3f, c: vec3f) -> vec4f {
  let direction = end - start;
  let ab = b - a; let ac = c - a;
  let p = cross(direction, ac);
  let determinant = dot(ab, p);
  if (abs(determinant) < 1e-12) { return vec4f(0.0, 0.0, 0.0, -1.0); }
  let inverse = 1.0 / determinant;
  let origin = start - a;
  let u = dot(origin, p) * inverse;
  let q = cross(origin, ab);
  let v = dot(direction, q) * inverse;
  let time = dot(ac, q) * inverse;
  if (u < -1e-5 || v < -1e-5 || u + v > 1.00001 || time < -1e-5 || time > 1.00001) {
    return vec4f(0.0, 0.0, 0.0, -1.0);
  }
  return vec4f(start + direction * clamp(time, 0.0, 1.0), clamp(time, 0.0, 1.0));
}
fn pointSegmentDistance(point: vec3f, a: vec3f, b: vec3f) -> f32 {
  let edge = b - a;
  let time = clamp(dot(point - a, edge) / max(dot(edge, edge), 1e-12), 0.0, 1.0);
  return distance(point, a + time * edge);
}
fn finiteTrianglesCross(a: vec3f, b: vec3f, c: vec3f, p: vec3f, q: vec3f, r: vec3f) -> bool {
  return segmentTriangleHit(a,b,p,q,r).w >= 0.0 || segmentTriangleHit(b,c,p,q,r).w >= 0.0
    || segmentTriangleHit(c,a,p,q,r).w >= 0.0 || segmentTriangleHit(p,q,a,b,c).w >= 0.0
    || segmentTriangleHit(q,r,a,b,c).w >= 0.0 || segmentTriangleHit(r,p,a,b,c).w >= 0.0;
}

// Uses only invocation-local data. Existing eight storage buffers plus uniform gate suffice.
// Existing finite hit collection, topology, active gate, and EVERY-endpoint local seam proof stay.
struct Witness {
  a: vec3f,
  b: vec3f,
  normal: vec3f,
  oldGap: f32,
  uncertainty: f32,
  valid: u32,
  owner: u32,
};
struct Response {
  a: array<vec3f, 3>,
  b: array<vec3f, 3>,
};
fn finiteBarycentric(tri: array<vec3f,3>, p: vec3f) -> vec3f {
  let ab=tri[1]-tri[0];let ac=tri[2]-tri[0];let ap=p-tri[0];
  let aa=dot(ab,ab);let bb=dot(ab,ac);let cc=dot(ac,ac);
  let det=aa*cc-bb*bb;
  if(det<=1e-20) { return vec3f(0.0); }
  let y=(cc*dot(ap,ab)-bb*dot(ap,ac))/det;
  let z=(aa*dot(ap,ac)-bb*dot(ap,ab))/det;
  let weights=max(vec3f(1.0-y-z,y,z),vec3f(0.0));
  return weights/max(dot(weights,vec3f(1.0)),1e-20);
}
fn baryPoint(tri: array<vec3f,3>, weights: vec3f) -> vec3f {
  return tri[0]*weights.x+tri[1]*weights.y+tri[2]*weights.z;
}
// Arithmetic side uncertainty only: no body/cloth safety or physical clearance tolerance.
fn gramCondition(tri:array<vec3f,3>)->f32 {
  let ab=tri[1]-tri[0];let ac=tri[2]-tri[0];
  let aa=dot(ab,ab);let bb=dot(ab,ac);let cc=dot(ac,ac);
  let gamma16=16.0*0.000000059604644775390625/(1.0-16.0*0.000000059604644775390625);
  let lower=aa*cc-bb*bb-gamma16*(aa*cc+bb*bb);
  if(lower<=0.0) { return 1e30; }
  return (aa+cc)*(aa+cc)/lower;
}
fn materialHistoryUncertainty(a:array<vec3f,3>,b:array<vec3f,3>,oldA:array<vec3f,3>,oldB:array<vec3f,3>,hit:vec3f,weightsA:vec3f,weightsB:vec3f)->f32 {
  var scale=max(abs(hit.x),max(abs(hit.y),abs(hit.z)));
  for(var k=0u;k<3u;k++) {
    let value=max(max(abs(a[k]),abs(b[k])),max(abs(oldA[k]),abs(oldB[k])));
    scale=max(scale,max(value.x,max(value.y,value.z)));
  }
  let spanA=length(oldA[1]-oldA[0])+length(oldA[2]-oldA[0]);
  let spanB=length(oldB[1]-oldB[0])+length(oldB[2]-oldB[0]);
  let ab=oldB[1]-oldB[0];let ac=oldB[2]-oldB[0];let area=length(cross(ab,ac));
  if(area<=1e-20) { return 1e30; }
  let normalCondition=length(ab)*length(ac)/area;
  let relative=length(baryPoint(oldA,weightsA)-baryPoint(oldB,weightsB));
  let u=0.000000059604644775390625;
  return max(1e-7,16.0*u*scale+32.0*u*((1.0+gramCondition(a))*spanA+(1.0+gramCondition(b))*spanB)+16.0*u*normalCondition*relative);
}
fn canonicalFaces(aId:u32,bId:u32,aLayer:u32,bLayer:u32) -> vec2u {
  if(aLayer>bLayer || (aLayer==bLayer && aId<bId)) { return vec2u(aId,bId); }
  return vec2u(bId,aId);
}
fn finiteCrossingWitness(a:array<vec3f,3>,b:array<vec3f,3>,
  oldA:array<vec3f,3>,oldB:array<vec3f,3>,hit:vec3f,lowerLayerKinematic:bool,targetOutsideFlipped:bool,continuedSides:u32) -> Witness {
  var result=Witness(vec3f(0.0),vec3f(0.0),vec3f(0.0),0.0,0.0,0u,1u);
  result.a=finiteBarycentric(a,hit);result.b=finiteBarycentric(b,hit);
  if(dot(result.a,vec3f(1.0))<0.5 || dot(result.b,vec3f(1.0))<0.5) { return result; }
  // The finite FACE containing an interior intersection point supplies the edge/face
  // normal. A target edge through the source interior must not use the target's unrelated
  // plane normal. Native warm starts and authored unequal layers keep their target policy.
  if(!allowWarmStart && !lowerLayerKinematic) {
    let sourceInterior=min(result.a.x,min(result.a.y,result.a.z))>1e-5;
    let targetInterior=min(result.b.x,min(result.b.y,result.b.z))>1e-5;
    if(sourceInterior==targetInterior) { result.owner=2u;return result; }
    result.owner=select(1u,0u,sourceInterior);
  }
  var owner=b;var oldOwner=oldB;
  if(result.owner==0u) { owner=a;oldOwner=oldA; }
  let oldRaw=cross(oldOwner[1]-oldOwner[0],oldOwner[2]-oldOwner[0]);
  let raw=cross(owner[1]-owner[0],owner[2]-owner[0]);
  if(length(raw)<=1e-12 || (!lowerLayerKinematic && length(oldRaw)<=1e-12)) { return result; }
  var normal=normalize(raw);var oldNormal=normal;
  if(length(oldRaw)>1e-12) { oldNormal=normalize(oldRaw); }
  if(dot(normal,oldNormal)<0.0) { normal=-normal; }
  // At an actual finite crossing both CURRENT material points identify the same witness.
  // Transport relative motion without subtracting rounded metre-scale reconstructions.
  let movementA=array<vec3f,3>(oldA[0]-a[0],oldA[1]-a[1],oldA[2]-a[2]);
  let movementB=array<vec3f,3>(oldB[0]-b[0],oldB[1]-b[1],oldB[2]-b[2]);
  result.oldGap=dot(baryPoint(movementA,result.a)-baryPoint(movementB,result.b),oldNormal);
  if(result.owner==0u) {
    result.uncertainty=materialHistoryUncertainty(b,a,oldB,oldA,hit,result.b,result.a);
  } else {
    result.uncertainty=materialHistoryUncertainty(a,b,oldA,oldB,hit,result.a,result.b);
  }
  if(lowerLayerKinematic) {
    result.normal=normal*select(1.0,-1.0,targetOutsideFlipped);
  } else {
    let side=(continuedSides>>(28u+2u*result.owner))&3u;
    if(side==3u) { return result; }
    if(side==0u && abs(result.oldGap)<=result.uncertainty) { return result; }
    let positive=select(result.oldGap>0.0,side==1u,side!=0u);
    result.normal=normal*select(-1.0,1.0,positive);
  }
  result.valid=1u;
  return result;
}
// Equal-layer proof checks all endpoints separately for each actual owning face. Source-owner
// and target-owner signs may differ; neither may reinterpret the other's side bits. Conflicting
// or uncertain history stays unresolved. Both invocations share canonical roles and hit order.
fn finiteClosestWitness(a:array<vec3f,3>,b:array<vec3f,3>,
  oldB:array<vec3f,3>,closestA:vec3f,closestB:vec3f,thickness:f32,lowerLayerKinematic:bool,targetOutsideFlipped:bool) -> Witness {
  let delta=closestA-closestB;let distance=length(delta);
  var result=Witness(vec3f(0.0),vec3f(0.0),vec3f(0.0),0.0,0.0,0u,1u);
  if(distance>=thickness || distance<=1e-9) { return result; }
  result.a=finiteBarycentric(a,closestA);result.b=finiteBarycentric(b,closestB);
  result.normal=delta/distance;
  if(lowerLayerKinematic) {
    let raw=cross(b[1]-b[0],b[2]-b[0]);if(length(raw)<=1e-12) { return result; }
    var normal=normalize(raw);
    let oldRaw=cross(oldB[1]-oldB[0],oldB[2]-oldB[0]);
    if(length(oldRaw)>1e-12 && dot(normal,oldRaw)<0.0) { normal=-normal; }
    result.normal=normal*select(1.0,-1.0,targetOutsideFlipped);
  }
  result.valid=1u;return result;
}
// closestA/B must come from the actual minimum among six vertex/finite-face plus nine
// finite edge/edge closest pairs, as in the CPU reference. Negative infinite plane is insufficient.

fn closestSegmentPair(a:vec3f,b:vec3f,p:vec3f,q:vec3f)->array<vec3f,2> {
  let d1=b-a;let d2=q-p;let relative=a-p;
  let aa=dot(d1,d1);let ee=dot(d2,d2);let ff=dot(d2,relative);
  var s=0.0;var t=0.0;
  if(aa<=1e-20 && ee<=1e-20) { return array<vec3f,2>(a,p); }
  if(aa<=1e-20) { t=clamp(ff/ee,0.0,1.0); }
  else {
    let cc=dot(d1,relative);
    if(ee<=1e-20) { s=clamp(-cc/aa,0.0,1.0); }
    else {
      let bb=dot(d1,d2);let det=aa*ee-bb*bb;
      if(det>1e-12*aa*ee) { s=clamp((bb*ff-cc*ee)/det,0.0,1.0); }
      t=(bb*s+ff)/ee;
      if(t<0.0) { t=0.0;s=clamp(-cc/aa,0.0,1.0); }
      else if(t>1.0) { t=1.0;s=clamp((bb-cc)/aa,0.0,1.0); }
    }
  }
  return array<vec3f,2>(a+d1*s,p+d2*t);
}
fn closestFinitePair(a:array<vec3f,3>,b:array<vec3f,3>)->array<vec3f,2> {
  var result=array<vec3f,2>(a[0],getClosestPointOnTriangle(b[0],b[1],b[2],a[0]));
  var best=dot(result[0]-result[1],result[0]-result[1]);
  for(var k=0u;k<3u;k++) {
    let closestBPoint=getClosestPointOnTriangle(b[0],b[1],b[2],a[k]);
    let d=a[k]-closestBPoint;let squared=dot(d,d);
    if(squared<best) { best=squared;result=array<vec3f,2>(a[k],closestBPoint); }
    let source=getClosestPointOnTriangle(a[0],a[1],a[2],b[k]);
    let reverse=source-b[k];let reversedSquared=dot(reverse,reverse);
    if(reversedSquared<best) { best=reversedSquared;result=array<vec3f,2>(source,b[k]); }
    for(var j=0u;j<3u;j++) {
      let pair=closestSegmentPair(a[k],a[(k+1u)%3u],b[j],b[(j+1u)%3u]);
      let delta=pair[0]-pair[1];let separation=dot(delta,delta);
      if(separation<best) { best=separation;result=pair; }
    }
  }
  return result;
}

fn tri(face:u32)->vec4u{let o=geometry[6]+face*4u;return vec4u(geometry[o],geometry[o+1u],geometry[o+2u],geometry[o+3u]);}
fn bodyTri(face:u32)->vec4u{let o=geometry[7]+face*4u;return vec4u(geometry[o],geometry[o+1u],geometry[o+2u],geometry[o+3u]);}
fn skinPoint(id:u32)->vec3f{let o=geometry[8]+id*4u;return bitcast<vec3f>(vec3u(geometry[o],geometry[o+1u],geometry[o+2u]));}
fn clothPoints(ids:vec4u,old:bool)->array<vec3f,3>{if(old){return array<vec3f,3>(previous[ids.x].xyz,previous[ids.y].xyz,previous[ids.z].xyz);}return array<vec3f,3>(current[ids.x].xyz,current[ids.y].xyz,current[ids.z].xyz);}
fn bodyPoints(id:u32)->array<vec3f,3>{let t=bodyTri(id);return array<vec3f,3>(skinPoint(t.x),skinPoint(t.y),skinPoint(t.z));}
fn bodyFeature(face:u32,weights:vec3f)->vec3f{let p=bodyPoints(face);var n=cross(p[1]-p[0],p[2]-p[0]);if(length(n)<=1e-20){return vec3f(0.0);}n=normalize(n);let near=weights<=vec3f(0.00001);var slot=NONE;if(near.y&&near.z){slot=3u;}else if(near.x&&near.z){slot=4u;}else if(near.x&&near.y){slot=5u;}else if(near.z){slot=0u;}else if(near.x){slot=1u;}else if(near.y){slot=2u;}if(slot!=NONE){let o=geometry[9]+face*24u+slot*4u;n=bitcast<vec3f>(vec3u(geometry[o],geometry[o+1u],geometry[o+2u]));}return n;}
struct Nearest{q:vec3f,distance:f32,n:vec3f,face:u32};
fn nearestBody(point:vec3f)->Nearest{return jointNearestBody(point);}
fn uncertainty(point:vec3f,old:vec3f,q:vec3f)->f32{return 32.0*0.000000059604644775390625*max(1.0,max(max(max(abs(point.x),abs(point.y)),abs(point.z)),max(max(max(abs(old.x),abs(old.y)),abs(old.z)),max(max(abs(q.x),abs(q.y)),abs(q.z)))));}
fn append(r:Row){
 let index=jointBVHReserveRawRow();if(index==NONE){return;}
 rows[index]=r;if(!validRow(r)){atomicOr(&state[0],2u);return;}
 atomicAdd(&state[5],1u);let a=jointInventoryPoint(r,false);let b=jointInventoryPoint(r,true);
 let coordinate=max(1.0,max(max(abs(a.x),max(abs(a.y),abs(a.z))),max(abs(b.x),max(abs(b.y),abs(b.z)))));
 let lower=dot(a-b,r.n.xyz)-32.0*0.000000059604644775390625*coordinate;
 if(!finite(lower)){atomicOr(&state[0],2u);return;}
 atomicMin(&state[4],bitcast<u32>(max(0.0,lower)));
 if(lower<r.n.w){atomicAdd(&state[3],1u);}
 }
fn makeRow(a:vec3u,b:vec3u,wa:vec3f,wb:vec3f,n:vec3f,q:vec3f,kind:u32,face:u32,other:u32,feature:u32,gap:f32,bound:f32)->Row{return Row(vec4u(a,kind),vec4u(b,select(63u,127u,kind==2u||kind==6u)),vec4f(wa,gap),vec4f(wb,bound),vec4f(n,0.001),vec4f(q,select(0.0,1.0,kind>=3u)),vec4u(face,other,cfg.gateRevision,feature),vec4u(cfg.bodyGeneration,cfg.substep,cfg.sourceToken,select(63u,127u,kind==2u||kind==6u)));}
fn jointOrdinarySegmentProof(face:u32,other:u32,point:vec3f,seam:u32)->bool{let t=geometry[10];let l=geometry[12];for(var at=geometry[t+face];at<geometry[t+face+1u];at+=5u){if(geometry[t+at]!=other||geometry[t+at+4u]!=seam){continue;}let threshold=geometry[t+at+1u];if(threshold!=NONE&&gate.sewnUpTo<=i32(threshold)){continue;}if(!activeSourceSeam(seam)||!activeSourceSegment(geometry[t+at+3u])){continue;}let link=geometry[t+at+2u];if((link&0x80000000u)!=0u){continue;}let a=current[geometry[l+link]].xyz;let b=current[geometry[l+link+1u]].xyz;let c=current[geometry[l+link+2u]].xyz;let d=current[geometry[l+link+3u]].xyz;let mid=(a+b)*0.5;let edge=(c+d)*0.5-mid;let tvalue=clamp(dot(point-mid,edge)/max(dot(edge,edge),1e-20),0.0,1.0);let A=mix(a,c,tvalue);let B=mix(b,d,tvalue);if(distance(point,A)<=0.005&&distance(point,B)<=0.005&&distance(A,B)<=0.003){return true;}}return false;}

fn jointChildCoordinate(id:u32)->vec4f{return bitcast<vec4f>(vec4u(geometry[1124592u+id*4u],geometry[1124592u+id*4u+1u],geometry[1124592u+id*4u+2u],geometry[1124592u+id*4u+3u]));}
fn jointChildFaceTouches(face:u32,child:u32)->bool{if(face>=cfg.clothFaces||child>=cfg.clothFaces){return false;}let a=tri(face).xyz;let b=tri(child).xyz;return any(a==vec3u(b.x))||any(a==vec3u(b.y))||any(a==vec3u(b.z));}
fn jointChildMaterialPath(ids:vec3u)->bool{
 let A=jointChildCoordinate(ids.x);let B=jointChildCoordinate(ids.z);if(A.w!=B.w){return false;}if(ids.y==NONE){return true;}
 let M=jointChildCoordinate(ids.y);if(M.w!=A.w){return false;}let scale=max(vec2f(1e-6),max(abs(A.xy),max(abs(B.xy),abs(M.xy))));let bound=8.0*0.000000059604644775390625*scale;
 return all(abs(M.xy-(A.xy+B.xy)*0.5)<=bound);
}
fn jointChildInterval(face:u32,other:u32,point:vec3f,relative:u32)->bool{
 let l=geometry[12];let count=geometry[13];if(relative>count||count-relative<10u){atomicOr(&state[0],16u);return false;}
 let a=vec3u(geometry[l+relative],geometry[l+relative+1u],geometry[l+relative+2u]);let b=vec3u(geometry[l+relative+3u],geometry[l+relative+4u],geometry[l+relative+5u]);
 if(a.x>=cfg.particles||a.z>=cfg.particles||b.x>=cfg.particles||b.z>=cfg.particles||((a.y!=NONE)&&(a.y>=cfg.particles))||((b.y!=NONE)&&(b.y>=cfg.particles))||((a.y==NONE)==(b.y==NONE))){atomicOr(&state[0],16u);return false;}
 if(!jointChildMaterialPath(a)||!jointChildMaterialPath(b)){atomicOr(&state[0],16u);return false;}
 // A free numerical midpoint is never an activated sewing/contact identity.
 if(a.y!=NONE){if(dot(point-current[a.y].xyz,point-current[a.y].xyz)<=1e-12){return false;}}
 if(b.y!=NONE){if(dot(point-current[b.y].xyz,point-current[b.y].xyz)<=1e-12){return false;}}
 for(var cell=0u;cell<2u;cell++){
  let childA=geometry[l+relative+6u+cell];let childB=geometry[l+relative+8u+cell];
  if(!((jointChildFaceTouches(face,childA)&&jointChildFaceTouches(other,childB))||(jointChildFaceTouches(face,childB)&&jointChildFaceTouches(other,childA)))){continue;}
  let u0=f32(cell)*0.5;let u1=f32(cell+1u)*0.5;
  var a0=mix(current[a.x].xyz,current[a.z].xyz,u0);var a1=mix(current[a.x].xyz,current[a.z].xyz,u1);var b0=mix(current[b.x].xyz,current[b.z].xyz,u0);var b1=mix(current[b.x].xyz,current[b.z].xyz,u1);
  if(a.y!=NONE){a0=current[a.x].xyz;a1=current[a.y].xyz;if(cell==1u){a0=current[a.y].xyz;a1=current[a.z].xyz;}}
  if(b.y!=NONE){b0=current[b.x].xyz;b1=current[b.y].xyz;if(cell==1u){b0=current[b.y].xyz;b1=current[b.z].xyz;}}
  let mid=(a0+b0)*0.5;let edge=(a1+b1)*0.5-mid;let squared=dot(edge,edge);var t=0.0;if(squared>0.0){t=clamp(dot(point-mid,edge)/squared,0.0,1.0);}
  let A=mix(a0,a1,t);let B=mix(b0,b1,t);if(distance(point,A)<=0.005&&distance(point,B)<=0.005&&distance(A,B)<=0.003){return true;}
 }return false;
}
fn segmentProof(face:u32,other:u32,point:vec3f,seam:u32)->bool{
 if(1124592u+cfg.particles*4u!=arrayLength(&geometry)){atomicOr(&state[0],16u);return false;}
 let t=geometry[10];for(var at=geometry[t+face];at<geometry[t+face+1u];at+=5u){
  if(geometry[t+at]!=other||geometry[t+at+4u]!=seam){continue;}let threshold=geometry[t+at+1u];if(threshold!=NONE&&gate.sewnUpTo<=i32(threshold)){continue;}
  if(!activeSourceSeam(seam)||!activeSourceSegment(geometry[t+at+3u])){continue;}let link=geometry[t+at+2u];if((link&0x80000000u)==0u){continue;}
  if(jointChildInterval(face,other,point,link&0x7fffffffu)){return true;}
 }
 return jointOrdinarySegmentProof(face,other,point,seam);
}
fn expectedSeam(face:u32,other:u32,hits:array<vec3f,12>,count:u32)->bool{let t=geometry[10];for(var at=geometry[t+face];at<geometry[t+face+1u];at+=5u){if(geometry[t+at]!=other){continue;}let seam=geometry[t+at+4u];var valid=true;for(var i=0u;i<count;i++){if(!segmentProof(face,other,hits[i],seam)){valid=false;break;}}if(valid){return true;}}return false;}
fn nearRow(face:u32,other:u32,a:array<vec3f,3>,b:array<vec3f,3>,oldA:array<vec3f,3>,oldB:array<vec3f,3>,closest:array<vec3f,2>,feature:u32){let separation=distance(closest[0],closest[1]);if(separation>=jointFiniteHorizon()){return;}var hit:array<vec3f,12>;hit[0]=(closest[0]+closest[1])*0.5;if(expectedSeam(face,other,hit,1u)){return;}if(separation<=1e-9){atomicOr(&state[0],4u);return;}let wa=finiteBarycentric(a,closest[0]);let wb=finiteBarycentric(b,closest[1]);let n=(closest[0]-closest[1])/separation;let gap=separation;let bound=materialHistoryUncertainty(a,b,a,b,hit[0],wa,wb);if(gap<=bound){atomicOr(&state[0],4u);return;}append(makeRow(tri(face).xyz,tri(other).xyz,wa,wb,n,vec3f(0.0),2u,face,other,feature,gap,bound));}
fn bodyNearRow(face:u32,other:u32,a:array<vec3f,3>,b:array<vec3f,3>,old:array<vec3f,3>,closest:array<vec3f,2>,feature:u32){let distance=length(closest[0]-closest[1]);if(distance>=jointFiniteHorizon()){return;}let weights=finiteBarycentric(a,closest[0]);let skinWeights=finiteBarycentric(b,closest[1]);let bound=materialHistoryUncertainty(a,b,a,b,(closest[0]+closest[1])*0.5,weights,skinWeights);if(distance<=bound){atomicOr(&state[0],4u);return;}let globallyNearest=nearestBody(closest[0]);if(length(globallyNearest.n)<0.5){atomicOr(&state[0],4u);return;}let inside=dot(closest[0]-globallyNearest.q,globallyNearest.n)<0.0;var n=(closest[0]-closest[1])/distance;var q=closest[1];var gap=distance;var kind=6u;var targetFeature=other;var uncertaintyBound=bound;
 // Strictly outside finite proximity is a clearance PROTECTION, not an invented old side.
 // If this source material point is inside the whole body, use its exact whole-skin nearest
 // feature and require supported previous material escape history as an actual recovery row.
 if(inside){if(globallyNearest.distance<=bound){atomicOr(&state[0],4u);return;}q=globallyNearest.q;n=normalize(q-closest[0]);targetFeature=globallyNearest.face;kind=4u;let oldPoint=baryPoint(old,weights);gap=dot(oldPoint-q,n);uncertaintyBound=max(bound,uncertainty(closest[0],oldPoint,q));if(gap<=uncertaintyBound){let closed=jointClosedBodyMaterialRecovery(tri(face).xyz,weights);if(closed.valid==0u){atomicOr(&state[0],4u);return;}gap=closed.oldMargin;uncertaintyBound=max(uncertaintyBound,closed.uncertainty);n=closed.normal;q=closed.closest;targetFeature=closed.nearestFace;if(gap<=uncertaintyBound){atomicOr(&state[0],4u);return;}}}
 append(makeRow(tri(face).xyz,vec3u(NONE),weights,vec3f(0.0),n,q,kind,face,targetFeature,0x20000000u+other*16u+feature,gap,uncertaintyBound));}
fn cachePair(a:u32,b:u32)->u32{let hash=(a*1664525u+b*1013904223u)%cfg.cacheSlots;for(var attempt=0u;attempt<cfg.cacheSlots;attempt++){let slot=(hash+attempt)%cfg.cacheSlots;let o=slot*8u;let first=atomicLoad(&cache[o]);if(first==a+1u&&atomicLoad(&cache[o+1u])==b+1u){return o;}if(first==0u){let claim=atomicCompareExchangeWeak(&cache[o],0u,a+1u);if(claim.exchanged){atomicStore(&cache[o+1u],b+1u);return o;}}}atomicOr(&state[0],1u);return NONE;}
@compute @workgroup_size(64) fn reset(@builtin(global_invocation_id) gid:vec3u){if(gid.x==0u){atomicStore(&state[1],0u);atomicStore(&state[2],0u);atomicStore(&state[3],0u);atomicStore(&state[4],0x7f800000u);atomicStore(&state[5],0u);if(geometry[0]!=0x4a464731u||geometry[1]!=1u||geometry[2]!=cfg.particles||geometry[3]!=cfg.clothFaces||geometry[5]!=cfg.bodyFaces||geometry[14]!=cfg.sourceToken||geometry[15]!=cfg.bodyGeneration||gate.masked!=1u||gate.sewnUpTo<0||gate.sewnUpTo>175i){atomicOr(&state[0],16u);}}if(cfg.parentStart!=0u&&gid.x<cfg.cacheSlots*8u){atomicStore(&cache[gid.x],0u);}}
fn jointVisitSelfPair(face:u32,other:u32){let ids=tri(face);let a=clothPoints(ids,false);let oldA=clothPoints(ids,true);let targetFeature=tri(other);var incident=false;for(var i=0u;i<3u;i++){for(var j=0u;j<3u;j++){if(ids[i]==targetFeature[j]){incident=true;}}}if(incident){return;}let b=clothPoints(targetFeature,false);let oldB=clothPoints(targetFeature,true);if(any(min(a[0],min(a[1],a[2]))-vec3f(jointFiniteHorizon())>max(b[0],max(b[1],b[2]))) || any(min(b[0],min(b[1],b[2]))-vec3f(jointFiniteHorizon())>max(a[0],max(a[1],a[2])))){return;}
 var hits:array<vec3f,12>;var count=0u;for(var i=0u;i<3u;i++){let h=segmentTriangleHit(a[i],a[(i+1u)%3u],b[0],b[1],b[2]);if(h.w>=0.0){hits[count]=h.xyz;count++;}let reverse=segmentTriangleHit(b[i],b[(i+1u)%3u],a[0],a[1],a[2]);if(reverse.w>=0.0){hits[count]=reverse.xyz;count++;}}
 if(count>0u&&expectedSeam(face,other,hits,count)){return;}let near=closestFinitePair(a,b);let separation=distance(near[0],near[1]);if(count==0u&&separation>=jointFiniteHorizon()){return;}if((ids.w&0x7fffffffu)!=(targetFeature.w&0x7fffffffu)){atomicOr(&state[0],8u);return;}let cacheAt=cachePair(face,other);if(cacheAt==NONE){return;}
 if(count==0u){atomicStore(&cache[cacheAt+2u],0u);atomicStore(&cache[cacheAt+4u],0u);atomicStore(&cache[cacheAt+5u],0u);
 // All six finite vertex/face and nine edge/edge near protections are queried; selecting only
 // one minimum can let the next corner collide when kinematic body constraints move the patch.
 for(var i=0u;i<3u;i++){nearRow(face,other,a,b,oldA,oldB,array<vec3f,2>(a[i],getClosestPointOnTriangle(b[0],b[1],b[2],a[i])),12u+i);nearRow(face,other,a,b,oldA,oldB,array<vec3f,2>(getClosestPointOnTriangle(a[0],a[1],a[2],b[i]),b[i]),15u+i);for(var j=0u;j<3u;j++){nearRow(face,other,a,b,oldA,oldB,closestSegmentPair(a[i],a[(i+1u)%3u],b[j],b[(j+1u)%3u]),18u+i*3u+j);}}return;}

 var witnesses:array<Witness,12>;let retainedSides=atomicLoad(&cache[cacheAt+2u]);var sides=retainedSides;var proposed=0u;var valid=true;
 // Initial witnesses are ALL proved before any newly inferred owner side is retained. A
 // source-owner sign cannot hide an opposite second endpoint or seed the other owning face.
 for(var i=0u;i<count;i++){let w=finiteCrossingWitness(a,b,oldA,oldB,hits[i],false,false,retainedSides);witnesses[i]=w;if(w.valid==0u){valid=false;break;}let shift=28u+2u*w.owner;let retained=(retainedSides>>shift)&3u;if(retained==0u){let sign=select(2u,1u,w.oldGap>0.0);proposed|=sign<<shift;let first=((proposed>>shift)&3u)==sign;if(!first){valid=false;break;}let old=bitcast<f32>(atomicLoad(&cache[cacheAt+4u+w.owner]));let bound=bitcast<f32>(atomicLoad(&cache[cacheAt+6u+w.owner]));atomicStore(&cache[cacheAt+4u+w.owner],bitcast<u32>(select(min(old,abs(w.oldGap)),abs(w.oldGap),old==0.0)));atomicStore(&cache[cacheAt+6u+w.owner],bitcast<u32>(max(bound,w.uncertainty)));}else if(retained==3u){valid=false;break;}}
 if(valid){sides|=proposed;}else{sides|=proposed;if(((proposed>>28u)&3u)==3u||((proposed>>30u)&3u)==3u){sides|=proposed;}}

 atomicStore(&cache[cacheAt+2u],sides);if(!valid){atomicOr(&state[0],4u);return;}for(var i=0u;i<count;i++){let w=witnesses[i];let gap=bitcast<f32>(atomicLoad(&cache[cacheAt+4u+w.owner]));let bound=bitcast<f32>(atomicLoad(&cache[cacheAt+6u+w.owner]));append(makeRow(ids.xyz,targetFeature.xyz,w.a,w.b,w.normal,vec3f(0.0),1u,face,other,i,gap,bound));} }
@compute @workgroup_size(64) fn self_rows(@builtin(global_invocation_id) gid:vec3u){let face=gid.x;if(face>=cfg.clothFaces){return;}for(var other=face+1u;other<cfg.clothFaces;other++){jointVisitSelfPair(face,other);}}
@compute @workgroup_size(64) fn body_points(@builtin(global_invocation_id) gid:vec3u){let id=gid.x;if(id>=cfg.particles){return;}let point=current[id].xyz;let near=nearestBody(point);if(near.face==NONE||length(near.n)<0.5){atomicOr(&state[0],4u);return;}let signed=dot(point-near.q,near.n);if(signed>=0.0&&near.distance>=jointFiniteHorizon()){return;}let bound=uncertainty(point,point,near.q);if(near.distance<=bound){atomicOr(&state[0],4u);return;}let interior=signed<0.0;var n=normalize(select(point-near.q,near.q-point,interior));var q=near.q;var targetFeature=near.face;var gap=near.distance;var proofBound=bound;var kind=6u;
 if(interior){let old=previous[id].xyz;gap=dot(old-near.q,n);proofBound=uncertainty(point,old,near.q);kind=3u;if(gap<=proofBound){let closed=jointClosedBodyMaterialRecovery(vec3u(id),vec3f(1.0,0.0,0.0));if(closed.valid==0u){atomicOr(&state[0],4u);return;}gap=closed.oldMargin;proofBound=max(proofBound,closed.uncertainty);n=closed.normal;q=closed.closest;targetFeature=closed.nearestFace;if(gap<=proofBound){atomicOr(&state[0],4u);return;}}}
 append(makeRow(vec3u(id,NONE,NONE),vec3u(NONE),vec3f(1.0,0.0,0.0),vec3f(0.0),n,q,kind,id,targetFeature,0u,gap,proofBound));}

fn jointVisitBodyPair(face:u32,other:u32){let ids=tri(face);let a=clothPoints(ids,false);let old=clothPoints(ids,true);let b=bodyPoints(other);if(any(min(a[0],min(a[1],a[2]))-vec3f(jointFiniteHorizon())>max(b[0],max(b[1],b[2])))||any(min(b[0],min(b[1],b[2]))-vec3f(jointFiniteHorizon())>max(a[0],max(a[1],a[2])))){return;}if(!finiteTrianglesCross(a[0],a[1],a[2],b[0],b[1],b[2])){for(var corner=0u;corner<3u;corner++){bodyNearRow(face,other,a,b,old,array<vec3f,2>(getClosestPointOnTriangle(a[0],a[1],a[2],b[corner]),b[corner]),corner);for(var edge=0u;edge<3u;edge++){bodyNearRow(face,other,a,b,old,closestSegmentPair(a[corner],a[(corner+1u)%3u],b[edge],b[(edge+1u)%3u]),3u+corner*3u+edge);}}}for(var edge=0u;edge<3u;edge++){let hit=segmentTriangleHit(b[edge],b[(edge+1u)%3u],a[0],a[1],a[2]);if(hit.w<0.0){continue;}let weights=finiteBarycentric(a,hit.xyz);if(dot(weights,vec3f(1.0))<0.5){atomicOr(&state[0],4u);continue;}var skinWeights=vec3f(0.0);skinWeights[edge]=1.0-hit.w;skinWeights[(edge+1u)%3u]=hit.w;let n=bodyFeature(other,skinWeights);if(length(n)<0.5){atomicOr(&state[0],4u);continue;}let oldPoint=baryPoint(old,weights);let gap=dot(oldPoint-hit.xyz,n);let bound=materialHistoryUncertainty(a,b,old,b,hit.xyz,weights,skinWeights);if(gap<=bound||distance(baryPoint(a,weights),hit.xyz)>bound){atomicOr(&state[0],4u);continue;}append(makeRow(ids.xyz,vec3u(NONE),weights,vec3f(0.0),n,hit.xyz,4u,face,other,0x10000000u+other*3u+edge,gap,bound));}}

fn jointBVHBodyChords(face:u32){let ids=tri(face);let a=clothPoints(ids,false);let old=clothPoints(ids,true);

 for(var edge=0u;edge<3u;edge++){var times:array<f32,34>;times[0]=0.0;times[1]=1.0;var count=2u;{
 if(jointBVHReady(true)){let jointLow=(min(a[edge],a[(edge+1u)%3u])-vec3f(jointFiniteHorizon()));let jointHigh=(max(a[edge],a[(edge+1u)%3u])+vec3f(jointFiniteHorizon()));
 if(!jointBVHFinite(jointLow)||!jointBVHFinite(jointHigh)||any(jointLow>jointHigh)){jointBVHFail();}else{
 var jointNode=bodyBVH[6];while(jointNode!=JOINT_BVH_NONE&&jointNode<bodyBVH[7]){
 if(!jointBVHNode(true,jointNode)){break;}let jointOffset=bodyBVH[8]+jointNode*8u;let jointEscape=bodyBVH[jointOffset+3u];
 if(!jointBVHOverlap(true,jointNode,jointLow,jointHigh)){jointNode=jointEscape;continue;}
 let bodyFace=jointBVHFace(true,jointNode);if(bodyFace!=JOINT_BVH_NONE){let b=bodyPoints(bodyFace);let hit=segmentTriangleHit(a[edge],a[(edge+1u)%3u],b[0],b[1],b[2]);if(hit.w>=0.0&&hit.w>0.0&&hit.w<1.0){if(count>=34u){atomicOr(&state[0],1u);}else{times[count]=hit.w;count++;}}
 jointNode=jointEscape;}else{jointNode++;}
 }}}
}for(var i=1u;i<count;i++){let selected=times[i];var j=i;while(j>0u&&times[j-1u]>selected){times[j]=times[j-1u];j--;}times[j]=selected;}
 for(var interval=0u;interval+1u<count;interval++){if(times[interval+1u]<=times[interval]){continue;}let t=(times[interval]+times[interval+1u])*0.5;let point=mix(a[edge],a[(edge+1u)%3u],t);let near=nearestBody(point);if(length(near.n)<0.5){atomicOr(&state[0],4u);continue;}if(dot(point-near.q,near.n)>=0.0){continue;}if(near.distance<=1e-9){atomicOr(&state[0],4u);continue;}let n=normalize(near.q-point);var weights=vec3f(0.0);weights[edge]=1.0-t;weights[(edge+1u)%3u]=t;let previousPoint=baryPoint(old,weights);let gap=dot(previousPoint-near.q,n);let bound=uncertainty(point,previousPoint,near.q);var confidence=gap;var confidenceBound=bound;var rowNormal=n;var rowPoint=near.q;var rowFeature=near.face;
 if(gap<=bound){let closed=jointClosedBodyMaterialRecovery(ids.xyz,weights);if(closed.valid==0u){atomicOr(&state[0],4u);continue;}confidence=closed.oldMargin;confidenceBound=max(bound,closed.uncertainty);rowNormal=closed.normal;rowPoint=closed.closest;rowFeature=closed.nearestFace;if(confidence<=confidenceBound){atomicOr(&state[0],4u);continue;}}
 append(makeRow(ids.xyz,vec3u(NONE),weights,vec3f(0.0),rowNormal,rowPoint,4u,face,rowFeature,edge*34u+interval,confidence,confidenceBound));}
 }}
@compute @workgroup_size(1) fn complete(){if(jointBVHReady(false)&&jointBVHReady(true)){atomicStore(&state[2],7u);}}


@group(0) @binding(6) var<storage, read_write> clothBVH:array<u32>;
@group(0) @binding(7) var<storage, read> bodyBVH:array<u32>;
const JOINT_BVH_MAGIC:u32=0x4a425631u;
const JOINT_BVH_NONE:u32=0xffffffffu;
const JOINT_BVH_HORIZON:f32=0.011;
fn jointBVHFail(){atomicOr(&state[0],16u);}
// Integration append() uses this instead of atomicAdd, so even u32 raw-count exhaustion
// cannot wrap back to a small apparently complete certificate. Capacity overflow remains
// explicit and count retains all representable emitted rows; saturated count is a failure.
fn jointBVHReserveRawRow()->u32{
 while(true){let count=atomicLoad(&state[1]);if(count==JOINT_BVH_NONE){atomicOr(&state[0],1u);return JOINT_BVH_NONE;}
 let claimed=atomicCompareExchangeWeak(&state[1],count,count+1u);if(claimed.exchanged){if(count>=cfg.capacity){atomicOr(&state[0],1u);return JOINT_BVH_NONE;}return count;}}
 return JOINT_BVH_NONE;
}
fn jointBVHWord(body:bool,at:u32)->u32{if(body){return bodyBVH[at];}return clothBVH[at];}
fn jointBVHLength(body:bool)->u32{if(body){return arrayLength(&bodyBVH);}return arrayLength(&clothBVH);}
fn jointBVHHeader(body:bool,dynamic:bool)->bool{
 let length=jointBVHLength(body);if(length<80u){jointBVHFail();return false;}
 let n=jointBVHWord(body,5u);let faces=jointBVHWord(body,3u);let ordered=jointBVHWord(body,9u);
 if(jointBVHWord(body,0u)!=JOINT_BVH_MAGIC||jointBVHWord(body,1u)!=1u||jointBVHWord(body,2u)!=select(0u,1u,body)||jointBVHWord(body,29u)!=1u||faces!=select(cfg.clothFaces,cfg.bodyFaces,body)||jointBVHWord(body,7u)!=n||jointBVHWord(body,8u)!=80u||jointBVHWord(body,12u)!=length||n>(length-80u)/8u||ordered!=80u+n*8u||ordered>length||faces>length-ordered||jointBVHWord(body,20u)!=faces||jointBVHWord(body,21u)!=ordered+faces||jointBVHWord(body,23u)!=ordered+faces*2u||jointBVHWord(body,10u)!=jointBVHWord(body,23u)||jointBVHWord(body,11u)!=jointBVHWord(body,22u)*3u||jointBVHWord(body,24u)!=jointBVHWord(body,23u)+jointBVHWord(body,22u)*3u||jointBVHWord(body,25u)!=n-faces||jointBVHWord(body,26u)!=jointBVHWord(body,24u)+jointBVHWord(body,25u)||jointBVHWord(body,26u)>length||n>length-jointBVHWord(body,26u)||jointBVHWord(body,26u)+n!=length||n!=select(0u,faces*2u-1u,faces>0u)||jointBVHWord(body,6u)!=select(JOINT_BVH_NONE,0u,n>0u)) {jointBVHFail();return false;}
 for(var at=14u;at<16u;at++){if(jointBVHWord(body,at)!=jointBVHExpectedWord(at)){jointBVHFail();return false;}}
 for(var at=32u;at<56u;at++){if(jointBVHWord(body,at)!=jointBVHExpectedWord(at)){jointBVHFail();return false;}}
 if(!body&&jointBVHWord(body,4u)!=cfg.particles){jointBVHFail();return false;}
 if(dynamic&&!body){for(var at=16u;at<20u;at++){if(clothBVH[at]!=jointBVHExpectedWord(at)){jointBVHFail();return false;}}for(var at=56u;at<80u;at++){if(clothBVH[at]!=jointBVHExpectedWord(at)){jointBVHFail();return false;}}}
 return true;
}
fn jointBVHReady(body:bool)->bool{if(!jointBVHHeader(body,true)||jointBVHWord(body,31u)!=1u){jointBVHFail();return false;}return true;}
fn jointBVHLo(body:bool,node:u32)->vec3f{let at=jointBVHWord(body,8u)+node*8u;return bitcast<vec3f>(vec3u(jointBVHWord(body,at),jointBVHWord(body,at+1u),jointBVHWord(body,at+2u)));}
fn jointBVHHi(body:bool,node:u32)->vec3f{let at=jointBVHWord(body,8u)+node*8u+4u;return bitcast<vec3f>(vec3u(jointBVHWord(body,at),jointBVHWord(body,at+1u),jointBVHWord(body,at+2u)));}
fn jointBVHFinite(p:vec3f)->bool{return all(abs(p)<=vec3f(3.402823466e38));}
fn jointBVHNode(body:bool,node:u32)->bool{
 let n=jointBVHWord(body,5u);if(node>=n){jointBVHFail();return false;}let at=jointBVHWord(body,8u)+node*8u;
 let escape=jointBVHWord(body,at+3u);let leaf=jointBVHWord(body,at+7u);let lo=jointBVHLo(body,node);let hi=jointBVHHi(body,node);
 if(escape<=node||escape>n||!jointBVHFinite(lo)||!jointBVHFinite(hi)||any(lo>hi)||jointBVHWord(body,jointBVHWord(body,26u)+node)!=jointBVHWord(body,16u)){jointBVHFail();return false;}
 if(leaf!=JOINT_BVH_NONE&&(escape!=node+1u||leaf>=jointBVHWord(body,3u))){jointBVHFail();return false;}
 return true;
}
fn jointBVHPadding(lo:vec3f,hi:vec3f)->f32{return JOINT_BVH_HORIZON+32.0*0.000000059604644775390625*max(1.0,max(max(max(abs(lo.x),abs(lo.y)),abs(lo.z)),max(max(abs(hi.x),abs(hi.y)),abs(hi.z))));}
// The finite visitors and ALL broadphase/chord queries must call this SAME radius.
// A root-magnitude visitor with a local-magnitude query can miss a narrow real protection shell.
fn jointBVHDiscoveryHorizon()->f32{
 if(!jointBVHReady(false)||!jointBVHReady(true)){return JOINT_BVH_HORIZON;}
 var radius=JOINT_BVH_HORIZON;
 if(clothBVH[5]>0u){radius=max(radius,jointBVHPadding(jointBVHLo(false,0u),jointBVHHi(false,0u)));}
 if(bodyBVH[5]>0u){radius=max(radius,jointBVHPadding(jointBVHLo(true,0u),jointBVHHi(true,0u)));}
 return radius;
}
fn jointBVHOverlap(body:bool,node:u32,lo:vec3f,hi:vec3f)->bool{return all(jointBVHLo(body,node)<=hi)&&all(jointBVHHi(body,node)>=lo);}
fn jointBVHFace(body:bool,node:u32)->u32{let at=jointBVHWord(body,8u)+node*8u;let leaf=jointBVHWord(body,at+7u);if(leaf==JOINT_BVH_NONE){return JOINT_BVH_NONE;}let face=jointBVHWord(body,jointBVHWord(body,9u)+leaf);if(face>=jointBVHWord(body,3u)){jointBVHFail();return JOINT_BVH_NONE;}return face;}
// Complete monotonic stackless traversal. Escape or +1 always advances; malformed metadata
// rejects instead of imposing a max candidate count or an iteration budget that skips witnesses.
fn jointBVHSelfVisit(face:u32,lo:vec3f,hi:vec3f){
 if(!jointBVHReady(false)){return;}var at=clothBVH[6];let end=clothBVH[7];
 while(at!=JOINT_BVH_NONE&&at<end){if(!jointBVHNode(false,at)){return;}let o=clothBVH[8]+at*8u;let escape=clothBVH[o+3u];if(!jointBVHOverlap(false,at,lo,hi)){at=escape;continue;}let other=jointBVHFace(false,at);if(other!=JOINT_BVH_NONE){if(other>face){jointVisitSelfPair(face,other);}at=escape;}else{at++;}}
}
fn jointBVHBodyVisit(face:u32,lo:vec3f,hi:vec3f){
 if(!jointBVHReady(true)){return;}var at=bodyBVH[6];let end=bodyBVH[7];
 while(at!=JOINT_BVH_NONE&&at<end){if(!jointBVHNode(true,at)){return;}let o=bodyBVH[8]+at*8u;let escape=bodyBVH[o+3u];if(!jointBVHOverlap(true,at,lo,hi)){at=escape;continue;}let other=jointBVHFace(true,at);if(other!=JOINT_BVH_NONE){jointVisitBodyPair(face,other);at=escape;}else{at++;}}
}
@compute @workgroup_size(64) fn joint_bvh_self_rows(@builtin(global_invocation_id) gid:vec3u){
 let face=gid.x;if(face>=cfg.clothFaces){return;}if(!jointBVHReady(false)||!jointBVHReady(true)){return;}let a=clothPoints(tri(face),false);let lo=min(a[0],min(a[1],a[2]));let hi=max(a[0],max(a[1],a[2]));if(!jointBVHFinite(lo)||!jointBVHFinite(hi)){jointBVHFail();return;}let padding=vec3f(jointBVHDiscoveryHorizon());jointBVHSelfVisit(face,lo-padding,hi+padding);
}
@compute @workgroup_size(64) fn joint_bvh_body_faces(@builtin(global_invocation_id) gid:vec3u){
 let face=gid.x;if(face>=cfg.clothFaces){return;}if(!jointBVHReady(false)||!jointBVHReady(true)){return;}let a=clothPoints(tri(face),false);let lo=min(a[0],min(a[1],a[2]));let hi=max(a[0],max(a[1],a[2]));if(!jointBVHFinite(lo)||!jointBVHFinite(hi)){jointBVHFail();return;}let padding=vec3f(jointBVHDiscoveryHorizon());jointBVHBodyVisit(face,lo-padding,hi+padding);
}
// Exact nearest finite BODY feature, not nearest candidate rank for raw row enumeration.
// Branch bound adds arithmetic slack to retain near-ties. Unknown normals remain caller failure.
fn jointNearestBody(point:vec3f)->Nearest{
 var result=Nearest(vec3f(0.0),1e30,vec3f(0.0),JOINT_BVH_NONE);
 if(!jointBVHReady(true)||!jointBVHFinite(point)){jointBVHFail();return result;}
 var at=bodyBVH[6];while(at!=JOINT_BVH_NONE&&at<bodyBVH[7]){if(!jointBVHNode(true,at)){return Nearest(vec3f(0.0),1e30,vec3f(0.0),JOINT_BVH_NONE);}let o=bodyBVH[8]+at*8u;let escape=bodyBVH[o+3u];let lo=jointBVHLo(true,at);let hi=jointBVHHi(true,at);let delta=max(max(lo-point,point-hi),vec3f(0.0));let slack=jointBVHPadding(min(point,lo),max(point,hi))-JOINT_BVH_HORIZON;
 if(length(delta)>result.distance+slack){at=escape;continue;}let face=jointBVHFace(true,at);if(face==JOINT_BVH_NONE){at++;continue;}let p=bodyPoints(face);let q=getClosestPointOnTriangle(p[0],p[1],p[2],point);let d=distance(point,q);if(d<result.distance||(d==result.distance&&face<result.face)){result=Nearest(q,d,bodyFeature(face,finiteBarycentric(p,q)),face);}at=escape;}
 return result;
}
@compute @workgroup_size(1) fn joint_bvh_begin(){
 if(!jointBVHHeader(false,false)||clothBVH[31]!=1u||jointBVHExpectedWord(16u)<=clothBVH[16]){jointBVHFail();return;}
 clothBVH[31]=0u;for(var at=16u;at<20u;at++){clothBVH[at]=jointBVHExpectedWord(at);}for(var at=56u;at<80u;at++){clothBVH[at]=jointBVHExpectedWord(at);}atomicStore(&state[6],0u);atomicStore(&state[7],0u);
}
@compute @workgroup_size(64) fn joint_bvh_leaves(@builtin(global_invocation_id) gid:vec3u){
 if(!jointBVHHeader(false,true)||clothBVH[31]!=0u||cfg.refitFirst!=0u||cfg.refitCount!=clothBVH[20]){jointBVHFail();return;}let index=gid.x;if(index>=cfg.refitCount){return;}let node=clothBVH[clothBVH[21]+index];if(node>=clothBVH[5]){jointBVHFail();return;}let o=clothBVH[8]+node*8u;let leaf=clothBVH[o+7u];if(leaf==JOINT_BVH_NONE||leaf>=cfg.clothFaces||clothBVH[o+3u]!=node+1u){jointBVHFail();return;}let face=clothBVH[clothBVH[9]+leaf];if(face>=cfg.clothFaces){jointBVHFail();return;}let ids=tri(face);if(any(ids.xyz>=vec3u(cfg.particles))){jointBVHFail();return;}let a=clothPoints(ids,false);let lo=min(a[0],min(a[1],a[2]));let hi=max(a[0],max(a[1],a[2]));if(!jointBVHFinite(lo)||!jointBVHFinite(hi)){jointBVHFail();return;}
 for(var axis=0u;axis<3u;axis++){clothBVH[o+axis]=bitcast<u32>(lo[axis]);clothBVH[o+4u+axis]=bitcast<u32>(hi[axis]);}clothBVH[clothBVH[26]+node]=clothBVH[16];atomicAdd(&state[6],1u);
}
@compute @workgroup_size(64) fn joint_bvh_parents(@builtin(global_invocation_id) gid:vec3u){
 if(!jointBVHHeader(false,true)||clothBVH[31]!=0u){jointBVHFail();return;}var groupFound=false;for(var group=0u;group<clothBVH[22];group++){let g=clothBVH[23]+group*3u;if(clothBVH[g]==cfg.refitDepth&&clothBVH[g+1u]==cfg.refitFirst&&clothBVH[g+2u]==cfg.refitCount){groupFound=true;break;}}if(!groupFound){jointBVHFail();return;}let index=gid.x;if(index>=cfg.refitCount){return;}if(cfg.refitFirst>=clothBVH[25]||cfg.refitCount>clothBVH[25]-cfg.refitFirst){jointBVHFail();return;}let node=clothBVH[clothBVH[24]+cfg.refitFirst+index];if(node>=clothBVH[5]){jointBVHFail();return;}let o=clothBVH[8]+node*8u;let left=node+1u;if(left>=clothBVH[5]||clothBVH[o+7u]!=JOINT_BVH_NONE){jointBVHFail();return;}let right=clothBVH[clothBVH[8]+left*8u+3u];if(right<=left||right>=clothBVH[o+3u]||right>=clothBVH[5]||clothBVH[clothBVH[8]+right*8u+3u]!=clothBVH[o+3u]||clothBVH[clothBVH[26]+left]!=clothBVH[16]||clothBVH[clothBVH[26]+right]!=clothBVH[16]){jointBVHFail();return;}
 let lo=min(jointBVHLo(false,left),jointBVHLo(false,right));let hi=max(jointBVHHi(false,left),jointBVHHi(false,right));if(!jointBVHFinite(lo)||!jointBVHFinite(hi)){jointBVHFail();return;}for(var axis=0u;axis<3u;axis++){clothBVH[o+axis]=bitcast<u32>(lo[axis]);clothBVH[o+4u+axis]=bitcast<u32>(hi[axis]);}clothBVH[clothBVH[26]+node]=clothBVH[16];atomicAdd(&state[7],1u);
}
@compute @workgroup_size(1) fn joint_bvh_complete(){
 if(!jointBVHHeader(false,true)||clothBVH[31]!=0u||atomicLoad(&state[0])!=0u||atomicLoad(&state[6])!=clothBVH[20]||atomicLoad(&state[7])!=clothBVH[25]||(clothBVH[5]>0u&&clothBVH[clothBVH[26]]!=clothBVH[16])){jointBVHFail();return;}clothBVH[31]=1u;
}

fn jointBVHExpectedWord(slot:u32)->u32{return cfg.expected[slot/4u][slot%4u];}
fn jointFiniteHorizon()->f32{
 return jointBVHDiscoveryHorizon();
}
@compute @workgroup_size(64) fn joint_bvh_chords(@builtin(global_invocation_id) gid:vec3u){let face=gid.x;if(face>=cfg.clothFaces){return;}if(jointBVHReady(false)&&jointBVHReady(true)){jointBVHBodyChords(face);}}

fn jointRecoveryClosedBodyValidated()->bool{return cfg.sourceToken==1u&&cfg.bodyGeneration==1u&&bodyBVH[40u]==186815175u&&jointBVHExpectedWord(40u)==bodyBVH[40u]&&bodyBVH[41u]==1274184244u&&jointBVHExpectedWord(41u)==bodyBVH[41u]&&bodyBVH[42u]==2521851613u&&jointBVHExpectedWord(42u)==bodyBVH[42u]&&bodyBVH[43u]==2061184418u&&jointBVHExpectedWord(43u)==bodyBVH[43u]&&bodyBVH[44u]==142964815u&&jointBVHExpectedWord(44u)==bodyBVH[44u]&&bodyBVH[45u]==2729448484u&&jointBVHExpectedWord(45u)==bodyBVH[45u]&&bodyBVH[46u]==3239149195u&&jointBVHExpectedWord(46u)==bodyBVH[46u]&&bodyBVH[47u]==2787019520u&&jointBVHExpectedWord(47u)==bodyBVH[47u];}

struct JointClosedRayVote {votes:vec4u,counts:vec4u};
fn jointRecoveryParity(point:vec3f,margin:f32)->JointClosedRayVote{
 let root=bodyBVH[6];let low=jointBVHLo(true,root);let high=jointBVHHi(true,root);let center=(low+high)*0.5;
 let span=distance(point,center)+2.0*length(high-low)+1.0;
 let directions=array<vec3f,3>(normalize(vec3f(1.0,0.373,0.719)),normalize(vec3f(-0.317,1.0,0.613)),normalize(vec3f(0.537,-0.419,1.0)));
 var out:JointClosedRayVote;out.votes=vec4u(2u,2u,2u,0u);var valid=true;for(var ray=0u;ray<3u;ray++){let direction=directions[ray];let end=point+direction*span;var count=0u;var invalid=false;
 {
 if(jointBVHReady(true)){let jointLow=(min(point,end)-vec3f(margin));let jointHigh=(max(point,end)+vec3f(margin));
 if(!jointBVHFinite(jointLow)||!jointBVHFinite(jointHigh)||any(jointLow>jointHigh)){jointBVHFail();}else{
 var jointNode=bodyBVH[6];while(jointNode!=JOINT_BVH_NONE&&jointNode<bodyBVH[7]){
 if(!jointBVHNode(true,jointNode)){break;}let jointOffset=bodyBVH[8]+jointNode*8u;let jointEscape=bodyBVH[jointOffset+3u];
 if(!jointBVHOverlap(true,jointNode,jointLow,jointHigh)){jointNode=jointEscape;continue;}
 let bodyFace=jointBVHFace(true,jointNode);if(bodyFace!=JOINT_BVH_NONE){
 let t=bodyPoints(bodyFace);let hit=segmentTriangleHit(point,end,t[0],t[1],t[2]);
 if(hit.w>=0.0){let e0=t[1]-t[0];let e1=t[2]-t[0];let area=length(cross(e0,e1));
  if(area<=0.0){invalid=true;}else{let condition=length(e0)*length(e1)/area;let bary=finiteBarycentric(t,hit.xyz);let pbound=64.0*5.960464477539063e-8*(1.0+condition);
   if(!jointBVHFinite(bary)||any(bary<=vec3f(pbound))||abs(dot(normalize(cross(e0,e1)),direction))<=pbound||hit.w*span<=margin){invalid=true;}
   count+=1u;
  }
 }
 
 jointNode=jointEscape;}else{jointNode++;}
 }}}
}
 out.counts[ray]=count;if(invalid){valid=false;}else{out.votes[ray]=count%2u;}
 }out.votes.w=select(0u,1u,valid&&out.votes.x==out.votes.y&&out.votes.x==out.votes.z);return out;
}
struct JointClosedRecovery {
 valid:u32, reason:u32, nearestFace:u32, oldFace:u32,
 entryFace:u32, entryCount:u32, exitCount:u32, reserved:u32,
 closest:vec3f, oldMargin:f32,
 normal:vec3f, currentMargin:f32,
 entryPoint:vec3f, firstTime:f32,
 entryNormal:vec3f, uncertainty:f32,
 oldRayVotes:vec4u, currentRayVotes:vec4u, oldRayCounts:vec4u, currentRayCounts:vec4u,
};
fn jointRecoveryBound(point:vec3f,near:Nearest)->f32{
 let body=bodyPoints(near.face);let e0=body[1]-body[0];let e1=body[2]-body[0];let area=length(cross(e0,e1));
 if(area<=0.0){return 1e30;}let condition=length(e0)*length(e1)/area;
 let scale=max(1.0,max(max(abs(point.x),abs(point.y)),max(abs(point.z),max(max(abs(near.q.x),abs(near.q.y)),abs(near.q.z)))));
 return (32.0*5.960464477539063e-8/(1.0-32.0*5.960464477539063e-8))*scale*(1.0+condition);
}
fn jointClosedBodyMaterialRecovery(ids:vec3u,weights:vec3f)->JointClosedRecovery{
 var out:JointClosedRecovery;out.valid=0u;out.reason=4u;out.nearestFace=JOINT_BVH_NONE;out.oldFace=JOINT_BVH_NONE;out.entryFace=JOINT_BVH_NONE;out.oldRayVotes=vec4u(2u,2u,2u,0u);out.currentRayVotes=vec4u(2u,2u,2u,0u);
 if(!jointRecoveryClosedBodyValidated()||!jointBVHReady(true)||any(ids>=vec3u(cfg.particles))||any(weights<vec3f(0.0))||any(weights>vec3f(1.0))||abs(dot(weights,vec3f(1.0))-1.0)>8.0*5.960464477539063e-8){return out;}
 for(var k=0u;k<3u;k++){if(bitcast<u32>(current[ids[k]].w)!=bitcast<u32>(previous[ids[k]].w)){return out;}}
 let currentPoint=baryPoint(clothPoints(vec4u(ids,0u),false),weights);let oldPoint=baryPoint(clothPoints(vec4u(ids,0u),true),weights);
 if(!jointBVHFinite(currentPoint)||!jointBVHFinite(oldPoint)){return out;}
 let now=jointNearestBody(currentPoint);let before=jointNearestBody(oldPoint);
 if(now.face==JOINT_BVH_NONE||before.face==JOINT_BVH_NONE||!jointBVHFinite(now.n)||!jointBVHFinite(before.n)||length(now.n)<0.5||length(before.n)<0.5){return out;}
 let oldBound=jointRecoveryBound(oldPoint,before);let currentBound=jointRecoveryBound(currentPoint,now);let margin=max(oldBound,currentBound);
 let oldSigned=dot(oldPoint-before.q,before.n);let nowSigned=dot(currentPoint-now.q,now.n);
 out.nearestFace=now.face;out.oldFace=before.face;out.oldMargin=oldSigned;out.currentMargin=nowSigned;out.uncertainty=margin;
 // Globally nearest finite signs on independently closed/oriented body; never use
 // OLD projection against the CURRENT nearest triangle's extended plane.
 if(oldSigned<=oldBound||nowSigned>=-currentBound||before.distance<=oldBound||now.distance<=currentBound){return out;}
 let oldRays=jointRecoveryParity(oldPoint,oldBound);let nowRays=jointRecoveryParity(currentPoint,currentBound);out.oldRayVotes=oldRays.votes;out.oldRayCounts=oldRays.counts;out.currentRayVotes=nowRays.votes;out.currentRayCounts=nowRays.counts;
 if(oldRays.votes.w!=1u||nowRays.votes.w!=1u||any(oldRays.votes.xyz!=vec3u(0u))||any(nowRays.votes.xyz!=vec3u(1u))){return out;}
 let delta=currentPoint-oldPoint;let travel=length(delta);if(travel<=margin){return out;}let direction=delta/travel;
 var firstTime=2.0;var secondTime=2.0;var firstOrientation=0.0;var entryFace=JOINT_BVH_NONE;var entryPoint=vec3f(0.0);var entryNormal=vec3f(0.0);var hits=0u;var entries=0u;var exits=0u;var uncertain=false;
 {
 if(jointBVHReady(true)){let jointLow=(min(oldPoint,currentPoint)-vec3f(margin));let jointHigh=(max(oldPoint,currentPoint)+vec3f(margin));
 if(!jointBVHFinite(jointLow)||!jointBVHFinite(jointHigh)||any(jointLow>jointHigh)){jointBVHFail();}else{
 var jointNode=bodyBVH[6];while(jointNode!=JOINT_BVH_NONE&&jointNode<bodyBVH[7]){
 if(!jointBVHNode(true,jointNode)){break;}let jointOffset=bodyBVH[8]+jointNode*8u;let jointEscape=bodyBVH[jointOffset+3u];
 if(!jointBVHOverlap(true,jointNode,jointLow,jointHigh)){jointNode=jointEscape;continue;}
 let bodyFace=jointBVHFace(true,jointNode);if(bodyFace!=JOINT_BVH_NONE){
 let body=bodyPoints(bodyFace);let hit=segmentTriangleHit(oldPoint,currentPoint,body[0],body[1],body[2]);
 if(hit.w>=0.0){
  let bary=finiteBarycentric(body,hit.xyz);let edgeA=body[1]-body[0];let edgeB=body[2]-body[0];let area=length(cross(edgeA,edgeB));
  if(area<=0.0||!jointBVHFinite(bary)){uncertain=true;}else{
   let condition=length(edgeA)*length(edgeB)/area;let parameterBound=64.0*5.960464477539063e-8*(1.0+condition);
   let n=normalize(cross(edgeA,edgeB));let orientation=dot(n,direction);
   // Boundary/tangent/tied hits are conservatively unknown; never distance-dedup.
   if(any(bary<=vec3f(parameterBound))||any(bary>=vec3f(1.0-parameterBound))||abs(orientation)<=parameterBound||hit.w*travel<=margin||((1.0-hit.w)*travel)<=margin){uncertain=true;}
   if(hit.w<firstTime){secondTime=firstTime;firstTime=hit.w;entryFace=bodyFace;entryPoint=hit.xyz;entryNormal=n;firstOrientation=orientation;}else{secondTime=min(secondTime,hit.w);}
   hits+=1u;if(orientation<0.0){entries+=1u;}else{exits+=1u;}
  }
 }
 
 jointNode=jointEscape;}else{jointNode++;}
 }}}
}
 out.entryFace=entryFace;out.entryCount=entries;out.exitCount=exits;out.entryPoint=entryPoint;out.entryNormal=entryNormal;out.firstTime=firstTime;
 if(uncertain||hits==0u||(hits%2u)!=1u||entries!=exits+1u||firstTime>=1.0||firstOrientation>=0.0||(secondTime-firstTime)*travel<=margin){return out;}
 let escape=normalize(now.q-currentPoint);if(dot(escape,now.n)<=0.5){return out;}
 out.closest=now.q;out.normal=escape;out.valid=1u;out.reason=0u;return out;
}

fn jointRecoveryStore(index:u32,sourceFace:u32,feature:u32,ids:vec3u,weights:vec3f,p:JointClosedRecovery){
 if(index*2u+1u>=cfg.capacity){atomicOr(&state[0],1u);return;}
 var r:Row;r.a=vec4u(p.valid,p.reason,p.nearestFace,p.oldFace);r.b=vec4u(p.entryFace,p.entryCount,p.exitCount,0u);r.wa=vec4f(p.closest,p.oldMargin);r.wb=vec4f(p.normal,p.currentMargin);r.n=vec4f(p.entryPoint,p.firstTime);r.q=vec4f(p.entryNormal,p.uncertainty);r.feature=p.oldRayVotes;r.proof=p.currentRayVotes;rows[index*2u]=r;
 var s:Row;s.a=p.oldRayCounts;s.b=p.currentRayCounts;s.wa=vec4f(weights,f32(feature));s.wb=vec4f(baryPoint(clothPoints(vec4u(ids,0u),false),weights),0.0);s.n=vec4f(baryPoint(clothPoints(vec4u(ids,0u),true),weights),0.0);s.feature=vec4u(ids,sourceFace);s.proof=vec4u(cfg.sourceToken,cfg.bodyGeneration,cfg.gateRevision,cfg.substep);rows[index*2u+1u]=s;
}
@compute @workgroup_size(1) fn joint_closed_body_probe(){
 let face=cfg.p0;if(face>=cfg.clothFaces||!jointRecoveryClosedBodyValidated()||!jointBVHReady(true)){atomicOr(&state[0],16u);return;}
 let ids=tri(face);let a=clothPoints(ids,false);
 for(var edge=0u;edge<3u;edge++){
  var times:array<f32,34>;times[0]=0.0;times[1]=1.0;var count=2u;{
 if(jointBVHReady(true)){let jointLow=(min(a[edge],a[(edge+1u)%3u])-vec3f(jointFiniteHorizon()));let jointHigh=(max(a[edge],a[(edge+1u)%3u])+vec3f(jointFiniteHorizon()));
 if(!jointBVHFinite(jointLow)||!jointBVHFinite(jointHigh)||any(jointLow>jointHigh)){jointBVHFail();}else{
 var jointNode=bodyBVH[6];while(jointNode!=JOINT_BVH_NONE&&jointNode<bodyBVH[7]){
 if(!jointBVHNode(true,jointNode)){break;}let jointOffset=bodyBVH[8]+jointNode*8u;let jointEscape=bodyBVH[jointOffset+3u];
 if(!jointBVHOverlap(true,jointNode,jointLow,jointHigh)){jointNode=jointEscape;continue;}
 let bodyFace=jointBVHFace(true,jointNode);if(bodyFace!=JOINT_BVH_NONE){let b=bodyPoints(bodyFace);let hit=segmentTriangleHit(a[edge],a[(edge+1u)%3u],b[0],b[1],b[2]);if(hit.w>0.0&&hit.w<1.0){if(count>=34u){atomicOr(&state[0],1u);}else{times[count]=hit.w;count++;}}
 jointNode=jointEscape;}else{jointNode++;}
 }}}
}
  for(var i=1u;i<count;i++){let t=times[i];var j=i;while(j>0u&&times[j-1u]>t){times[j]=times[j-1u];j--;}times[j]=t;}
  for(var interval=0u;interval+1u<count;interval++){
   if(times[interval+1u]<=times[interval]){continue;}let time=(times[interval]+times[interval+1u])*0.5;let point=mix(a[edge],a[(edge+1u)%3u],time);let near=jointNearestBody(point);if(near.face==JOINT_BVH_NONE){atomicOr(&state[0],4u);continue;}if(dot(point-near.q,near.n)>=0.0){continue;}
   var weights=vec3f(0.0);weights[edge]=1.0-time;weights[(edge+1u)%3u]=time;
   let proof=jointClosedBodyMaterialRecovery(ids.xyz,weights);let index=atomicAdd(&state[1],1u);jointRecoveryStore(index,face,edge*34u+interval,ids.xyz,weights,proof);
   if(proof.valid==0u){atomicOr(&state[0],4u);}
  }
 }atomicStore(&state[2],7u);
}

fn finite(x:f32)->bool{return x==x && abs(x)<1e30;}
fn validRow(r:Row)->bool {
 let isProtection=r.a.w==2u||r.a.w==6u;let required=select(63u,127u,isProtection);
 if(r.a.w<1u||r.a.w>6u||r.a.w==5u||r.b.w!=required||r.proof.w!=required||r.feature.z!=cfg.gateRevision||r.proof.x!=cfg.bodyGeneration||r.proof.y!=cfg.substep||r.proof.z!=cfg.sourceToken){return false;}
 if(!finite(r.wa.w)||!finite(r.wb.w)||r.wb.w<0.0||r.wa.w<=r.wb.w||r.n.w!=0.001||abs(dot(r.n.xyz,r.n.xyz)-1.0)>4e-5){return false;}
 var sumA=0.0;var sumB=0.0;for(var k=0u;k<3u;k++){
  if(!finite(r.wa[k])||!finite(r.wb[k])||r.wa[k]<0.0||r.wb[k]<0.0){return false;}
  if(r.a[k]!=NONE){if(r.a[k]>=cfg.particles){return false;}sumA+=r.wa[k];}else if(r.wa[k]!=0.0){return false;}
  if(r.b[k]!=NONE){if(r.b[k]>=cfg.particles||r.a.w>=3u){return false;}sumB+=r.wb[k];}else if(r.wb[k]!=0.0){return false;}
  if(!finite(r.n[k])||!finite(r.q[k])){return false;}
 }
 if(abs(sumA-1.0)>2e-6|| (r.a.w<3u && (abs(sumB-1.0)>2e-6||r.feature.x>=r.feature.y))){return false;}
 for(var i=0u;i<3u;i++){for(var j=i+1u;j<3u;j++){if((r.a[i]!=NONE&&r.a[i]==r.a[j])||(r.b[i]!=NONE&&r.b[i]==r.b[j])){return false;}}for(var j=0u;j<3u;j++){if(r.a[i]!=NONE&&r.a[i]==r.b[j]){return false;}}}
 return r.a.x!=NONE && r.q.w==select(0.0,1.0,r.a.w>=3u);
}

 fn jointInventoryPoint(r:Row,isRigidTarget:bool)->vec3f{
 if(isRigidTarget&&r.q.w==1.0){return r.q.xyz;}var q=vec3f(0.0);
 for(var k=0u;k<3u;k++){let id=select(r.a[k],r.b[k],isRigidTarget);if(id!=NONE){q+=current[id].xyz*select(r.wa[k],r.wb[k],isRigidTarget);}}return q;
 }