import{bodyFaceFeatureLanesWGSL,BODY_FACE_FEATURE_POLICY}from'../../source-body-face-feature-lanes/bodyFaceFeatureLanes.mjs';
import{toHistoricalInventoryIdentifier}from'./inventoryIdentifier.mjs';
/** NEW CPU preparation authority. No adapter/device access. Producer integration
 * must observe runtime parent/history/gate/holds in its own exclusive GPU lease. */
import {createHash} from 'node:crypto';
import fs from 'node:fs';
import {validateSourcePhysicalMembrane} from '/workspace/work/source-membrane-all-phase-skirt-diagnostic-bindings/compiled/production.js';
import {bindPreparedRefinedMobility} from '/workspace/work/source-joint-refined-classifier-diagnostic/mobilityBinding.mjs';
import {packJointRefinedGeometry} from '/workspace/work/source-joint-refined-allraw-diagnostic-scope-graph/factory/compiled/sourceJointRefinedGeometry.mjs';
import {prepareJointClosedBodyProbe} from '/workspace/work/source-joint-refined-allraw-diagnostic-scope-graph/factory/compiled/sourceJointClosedBodyProbe.mjs';
import {sourceJointRefinedSeamFactory} from '/workspace/work/source-joint-refined-allraw-diagnostic-scope-graph/factory/compiled/sourceJointRefinedSeamFactory.mjs';
import {physicalSeamStitchIndices,buildSeamGateLayout,packSeamGate} from '/workspace/work/source-joint-refined-allraw-diagnostic-scope-graph/factory/compiled/seamGate.mjs';
import {surfaceTopologyExclusions,surfaceSeamLinks} from '/workspace/work/source-joint-refined-factory-review/surfaceTopology-current.mjs';
const raw=a=>Buffer.from(a.buffer,a.byteOffset,a.byteLength),sha=a=>createHash('sha256').update(a).digest('hex');
const canon=a=>ArrayBuffer.isView(a)?Array.from(a):Array.isArray(a)?a.map(canon):a&&typeof a==='object'?Object.fromEntries(Object.keys(a).sort().map(k=>[k,canon(a[k])])):a;
const digest=a=>sha(JSON.stringify(canon(a))),hash=/^[a-f0-9]{64}$/;
const typed=(a,C,n)=>a instanceof C&&a.length===n;
/** Native bypass precedes even reading prepared; ordinary sources remain the
 * ordinary owner's path rather than receiving a fabricated refinement receipt. */
export async function prepareSourceJointRefinedBackend(options,mode='source'){
 if(mode==='native')return null;
 const {prepared,sourceBinding,scope='fresh-source',manualRecording=false,held=false,cached=false,explicitSettings=false}=options;
 // Snapshot before any digest/probe await. No caller arrays are transferred.
 const p=structuredClone(prepared),binding=structuredClone(sourceBinding),d=p?.simData;
 if(!d?.sourceGatherCollisionGeometry&&!d?.sourceGatherRefinement)return null;
 if(!d.sourcePhysicalMembrane||!hash.test(d.sourcePhysicalMembrane.policySha256))throw Error('Actual physical SI mass policy required; no legacy-W relabel');
 if(!binding||!hash.test(binding.sourceSha256)||!Number.isSafeInteger(binding.sourceToken)||binding.sourceToken<0||binding.sourceToken>0xffffffff||!Number.isSafeInteger(binding.bodyGeneration)||binding.bodyGeneration<0||binding.bodyGeneration>0xffffffff)throw Error('Bound immutable source/body epoch required');
 if(!validateSourcePhysicalMembrane(d))throw Error('Actual physical SI policy/W validation unavailable');
 const mobility=bindPreparedRefinedMobility({prepared:p,scope,manualRecording,held,cached,explicitSettings}),physical=mobility.capture(),physicalMassPolicySha256=d.sourcePhysicalMembrane.policySha256;
 const groups=d.seamPairsBySeam.map((g,index)=>({...g,index,pairs:Array.from(g.pairs),stitchIndices:physicalSeamStitchIndices(d.seams,d.seamOrder,[g],d.seamStitchRanges)[0],stitchIndexKinds:g.pairs.filter((_,i)=>i%2===0).map((a,i)=>a===g.pairs[i*2+1]?'identity-logical':'reciprocal-first-stamp')})),dictionary={stitchCount:d.stitchCount,seamPairsBySeam:groups},geometry=d.sourceGatherCollisionGeometry;
 const bodySha256=sha(raw(p.body.positions)),topologySha256=sha(raw(d.triangles));
 if(binding.bodySha256!==bodySha256||binding.topologySha256!==topologySha256)throw Error('Source/body declaration differs from actual prepared bytes');
 const input={scope:'fresh-source',particleCount:d.particleCount,clothTriangles:d.triangles,bodyPositions:p.body.positions,bodyTriangles:p.body.triangles,sourceTopology:surfaceTopologyExclusions(d.triangles,d.seams,d.seamOrder,groups,true,groups.map(g=>g.stitchIndices),geometry),sourceSeamLinks:surfaceSeamLinks(groups,geometry),bodyGeneration:binding.bodyGeneration,sourceToken:binding.sourceToken,sourceSha256:binding.sourceSha256,bodySha256,topologySha256,refinedBoundary:true,sourceMaterialCoordinatesSha256:sha(raw(geometry.sourceMaterialCoordinates)),sourceGatherCollisionGeometry:geometry,sourceRefinementPolicy:d.sourceGatherRefinement,dictionary,seams:d.seams,seamOrder:d.seamOrder};
 const packed=await packJointRefinedGeometry(input),closed=await prepareJointClosedBodyProbe(packed,'fresh-source'),layout=buildSeamGateLayout(dictionary.stitchCount,groups.length),packedSha256=sha(raw(packed.words));
 const factorySource=sourceJointRefinedSeamFactory(closed,layout),preflightPath='/workspace/work/source-joint-refined-classifier-diagnostic/preflight-final.json',gpuReportPath='/workspace/work/source-joint-refined-classifier-diagnostic/gpu-attempt1/report.json',preflightBytes=fs.readFileSync(preflightPath),gpuReportBytes=fs.readFileSync(gpuReportPath),preflight=JSON.parse(preflightBytes),gpuReport=JSON.parse(gpuReportBytes);
 // The diagnostic uses source token1055/body instance5. Those are runtime epochs,
 // not anatomical revision. Rebind ONLY the exact closed-body equality literals;
 // every other source byte must still equal the device-tested reference template.
 const actualMarker=`cfg.sourceToken==${binding.sourceToken}u&&cfg.bodyGeneration==${binding.bodyGeneration}u&&`,referenceMarker='cfg.sourceToken==1055u&&cfg.bodyGeneration==5u&&';
 if(factorySource.split(actualMarker).length!==2)throw Error('Closed source/body validation literal is ambiguous');
 const referenceFactorySource=toHistoricalInventoryIdentifier(factorySource).replace(actualMarker,referenceMarker);
 if(!preflight.fixtures.some(x=>x.fullFiniteShaderSha256===sha(referenceFactorySource))||gpuReport.deviceExecuted!==true||gpuReport.cases.length!==24||gpuReport.errors.length||gpuReport.resourcesClosed!==true||gpuReport.deviceLostDrained!==true||gpuReport.strongInstanceReadAfterDrain!==true||gpuReport.fitAccepted!==false)throw Error('Matching closed actual predicate source evidence required');
 const derivedFactorySource=bodyFaceFeatureLanesWGSL(factorySource),factoryDerivation={policy:BODY_FACE_FEATURE_POLICY,featureLanes:15,originalRuntimeFullFactorySourceSha256:sha(factorySource),derivedRuntimeFullFactorySourceSha256:sha(derivedFactorySource),bodyFaceDispatch:'ceil(actualClothFaces*15/64)',actualDeviceExecuted:false,compileValidated:false,whole40Validated:false,fitAccepted:false};
 const receipt={scope:'verified-source-gather-child',factoryDerivation,physicalMassPolicySha256,sourceBinding:binding,mobilityBinding:physical.binding,materialBase:packed.materialBase,materialCoordinatesSha256:packed.materialCoordinatesSha256,refinementPolicySha256:packed.refinementPolicySha256,childGeometrySha256:packed.childGeometrySha256,seamDictionarySha256:packed.seamDictionarySha256,packedSha256,sourceTopologySha256:sha(raw(input.sourceTopology)),sourceSeamLinksSha256:sha(raw(input.sourceSeamLinks)),actualFreeMidpointIds:physical.midpointIds,refinedIntervals:geometry.intervals.length,identifierCorrection:'only four jointInventoryPoint target-to-isRigidTarget identifiers; all numerical operands and operations unchanged',predicateOnlyEvidence:{reportFile:gpuReportPath,reportSha256:sha(gpuReportBytes),preflightFile:preflightPath,preflightSha256:sha(preflightBytes),matchingFullFactorySourceSha256:sha(referenceFactorySource),actualRuntimeFullFactorySourceSha256:sha(factorySource),referenceRuntimeTokens:{sourceToken:1055,bodyGeneration:5},actualRuntimeTokens:{sourceToken:binding.sourceToken,bodyGeneration:binding.bodyGeneration},tokenRebinding:'one exact closed-body equality conjunction only; all other shader bytes unchanged',actualControlledCases:24,notFullFiniteProducer:true},fullFiniteProducerValidated:false,pressureValidated:false,wholeFrameValidated:false,fullFitAccepted:false};
 const receiptSha256=digest(receipt),referenceW=new Uint32Array(physical.positions.buffer).filter((_,i)=>i%4===3);
 function assertUnchanged(value){
  if(!value||digest(value.receipt)!==receiptSha256||sha(raw(value.packed.words))!==packedSha256||digest({...value.packed,words:[]})!==digest({...packed,words:[]}))throw Error('Refined backend immutable preparation changed');
  mobility.assertBindings(value.physical);
  if(digest(value.dictionary)!==digest(dictionary))throw Error('Original knot/stamp dictionary changed');
  if(digest(value.layout)!==digest(layout))throw Error('Original knot/stamp gate layout changed');return true;
 }
 function assertRuntimeMobility({parent,history,anchors,supportTargets,supportGroups,gate,usedActivation}){
  const n=d.particleCount*4;
  if(![parent,history,anchors,supportTargets].every(a=>typed(a,Float32Array,n)&&a.every(Number.isFinite))||!Array.isArray(supportGroups))throw Error('Actual runtime typed parent/history/hold/support snapshots required');
  if(!typed(gate,Uint32Array,layout.byteLength/4)||!usedActivation||!(usedActivation.activeSeams instanceof Uint32Array)||!Number.isSafeInteger(usedActivation.revision)||usedActivation.revision<0||usedActivation.revision>0xffffffff)throw Error('Actual used activation and observed GPU gate required');
  const expectedGate=packSeamGate(layout,usedActivation.sewnUpTo,usedActivation.activeSeams,dictionary.seamPairsBySeam.map(g=>g.stitchIndices));if(!raw(gate).equals(raw(expectedGate)))throw Error('Actual observed gate differs from proof-used original stamps/mask/prefix');
  const pw=new Uint32Array(parent.buffer,parent.byteOffset,parent.length),hw=new Uint32Array(history.buffer,history.byteOffset,history.length);
  for(let id=0;id<d.particleCount;id++){
   if(pw[id*4+3]!==referenceW[id]||hw[id*4+3]!==referenceW[id])throw Error('Actual physical parent/history W differs from immutable SI mass');
   if(anchors[id*4+3]!==0)throw Error('Fresh refined runtime has an unsupported XYZ hold');
  }
  for(const id of physical.midpointIds)if(!(parent[id*4+3]>0)||anchors[id*4+3]!==0||supportTargets[id*4+1]!==0||supportGroups.some(g=>!Array.isArray(g.particles)||g.particles.includes(id)))throw Error('Runtime free midpoint is fixed/held/Y-supported');
  return Object.freeze({usedGateSha256:sha(raw(gate)),usedActivationSha256:digest(usedActivation),runtimeParentSha256:sha(raw(parent)),runtimeHistorySha256:sha(raw(history)),runtimeAnchorsSha256:sha(raw(anchors)),runtimeSupportTargetsSha256:sha(raw(supportTargets)),runtimeSupportGroupsSha256:digest(supportGroups),refinedPreparationReceiptSha256:receiptSha256,physicalMassPolicySha256});
 }
 return Object.freeze({scope:'verified-source-gather-child',receiptSha256,materialBase:packed.materialBase,sourceMaterialCoordinatesSha256:packed.materialCoordinatesSha256,physicalMassPolicySha256,
  capture:()=>structuredClone({packed,physical,dictionary,layout,receipt}),assertUnchanged,assertRuntimeMobility,
  preparedFactory(actualLayout){if(digest(actualLayout)!==digest(layout))throw Error('Actual used gate layout differs from original knot/stamp dictionary');closed.assertPackedGeometryUnchanged(packed);return bodyFaceFeatureLanesWGSL(sourceJointRefinedSeamFactory(closed,structuredClone(actualLayout)));}});
}
