/** NEW host authority; only actual frozen source preparation creates a token.
 * No device access and native returns before options are read. */
import{createHash}from'node:crypto';
import{prepareSourceJointRefinedBackend}from'./RefinedPreparation.mjs';
const prepared=new WeakMap(),tokens=new WeakMap(),hash=a=>createHash('sha256').update(Buffer.from(a.buffer,a.byteOffset,a.byteLength)).digest('hex');
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
export async function prepareVerifiedRefinedBackend(options,mode='source'){
 if(mode==='native')return null;
 const value=await prepareSourceJointRefinedBackend(options,mode);if(!value)return null;
 const capture=value.capture();value.assertUnchanged(capture);prepared.set(value,capture);return value;
}
export function createVerifiedRefinedScope(value,packed,layout,binding){
 const capture=prepared.get(value);if(!capture)throw Error('Actual source-bound refined preparation required; caller claims are insufficient');
 value.assertUnchanged(capture);
 if(hash(packed.words)!==hash(capture.packed.words)||!same({...packed,words:[]},{...capture.packed,words:[]})||!same(layout,capture.layout))throw Error('Refined packet/layout differs from immutable preparation');
 for(const key of ['sourceSha256','bodySha256','topologySha256','sourceToken','bodyGeneration'])if(binding[key]!==capture.receipt.sourceBinding[key])throw Error('Refined runtime source/body binding differs: '+key);
 const token=Object.freeze({scope:'verified-source-gather-child',receiptSha256:value.receiptSha256});tokens.set(token,{value,capture});return token;
}
export function requireVerifiedRefinedScope(token,packed,layout){
 const owned=tokens.get(token);if(!owned)throw Error('Missing actual verified refined scope token');owned.value.assertUnchanged(owned.capture);
 if(hash(packed.words)!==hash(owned.capture.packed.words)||!same({...packed,words:[]},{...owned.capture.packed,words:[]})||!same(layout,owned.capture.layout))throw Error('Verified refined geometry or layout changed');return owned;
}
export function refinedFiniteFactory(token,packed,layout){const{value}=requireVerifiedRefinedScope(token,packed,layout);return value.preparedFactory(layout);}
export function assertRefinedRuntime(token,packed,layout,runtime){return requireVerifiedRefinedScope(token,packed,layout).value.assertRuntimeMobility(runtime);}
export function validateRefinedDiscoveryScope(input){
 if(input.refinedBoundary===false)return false;
 if(input.refinedBoundary!==true||!tokens.has(input.verifiedRefinedScope))throw Error('Refined discovery requires actual verified scope');return true;
}

export function refinedCertificateBinding(token,packed,layout){const {capture}=requireVerifiedRefinedScope(token,packed,layout);return Object.freeze({refinedPreparationReceiptSha256:token.receiptSha256,sourceMaterialCoordinatesSha256:capture.receipt.materialCoordinatesSha256,sourceGatherRefinementPolicySha256:capture.receipt.refinementPolicySha256,sourceGatherChildGeometrySha256:capture.receipt.childGeometrySha256,sourceSeamDictionarySha256:capture.receipt.seamDictionarySha256,actualRefinedFactorySourceSha256:capture.receipt.factoryDerivation.derivedRuntimeFullFactorySourceSha256,originalRefinedFactoryTemplateSha256:capture.receipt.factoryDerivation.originalRuntimeFullFactorySourceSha256,bodyFaceFeaturePolicy:capture.receipt.factoryDerivation.policy,physicalMassPolicySha256:capture.receipt.physicalMassPolicySha256});}
