/** Exact four-identifier mapping only. Numerical operations/operands and every
 * other full-factory byte must retain the recorded predicate-template lineage. */
export function toHistoricalInventoryIdentifier(code){
 const marker='fn jointInventoryPoint(r:Row,isRigidTarget:bool)->vec3f{',start=code.indexOf(marker);
 if(start<0||code.indexOf(marker,start+1)>=0)throw Error('Ambiguous inventory identifier function');
 const end=code.indexOf('\n }',start);if(end<0)throw Error('Inventory point function terminator changed');
 const section=code.slice(start,end+3);
 if((section.match(/\bisRigidTarget\b/g)??[]).length!==4||/\btarget\b/.test(section))throw Error('Inventory identifier scope changed');
 return code.slice(0,start)+section.replaceAll('isRigidTarget','target')+code.slice(end+3);
}
export function assertNoReservedTargetDeclaration(code){const active=code.replace(/\/\*[\s\S]*?\*\//g,'').replace(/\/\/[^\n]*/g,'');if(/\btarget\b/.test(active))throw Error('Reserved target identifier remains in full factory');return true;}
