import fs from'node:fs';import assert from'node:assert/strict';import{sha,bytes}from'./driver-utils.mjs';
import{packJointGeometry}from'./backend/compiled/sourceJointGeometry.mjs';
import{surfaceTopologyExclusions,surfaceSeamLinks}from'/workspace/work/source-joint-runtime-integration/actual-parent-backend-review-pin5/runtime/compiled/surfaceTopology.mjs';
import{buildSeamGateLayout,packSeamGate}from'./backend/compiled/seamGate.mjs';
import{prepareJointClosedBodyProbe}from'./backend/compiled/sourceJointClosedBodyProbe.mjs';
import{sourceJointClosedRawInventoryFactory}from'./backend/compiled/sourceJointClosedRawInventory.mjs';
import{bodyFaceFeatureLanesWGSL}from'../source-body-face-feature-lanes/bodyFaceFeatureLanes.mjs';
export function functionBytes(code,name){const at=code.indexOf('fn '+name+'(');assert(at>=0);let end=code.indexOf('{',at)+1,d=1;while(d){assert(end<code.length);if(code[end]==='{')d++;if(code[end]==='}')d--;end++;}return code.slice(at,end);}
export async function prepareTeeWitnesses(){
 const w=JSON.parse(fs.readFileSync(new URL('genuine-body-witnesses.json',import.meta.url)));for(const i of Object.values(w.inputs))assert.equal(sha(fs.readFileSync(i.file)),i.sha256);
 const f=JSON.parse(fs.readFileSync(w.inputs.frozen.file)),read=p=>{const b=fs.readFileSync(p);return new Float32Array(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength));},parent=read(w.inputs.parent.file),history=read(w.inputs.history.file),triangles=Uint32Array.from(f.clothTriangles),pairs=f.collisionSeamDictionary.seamPairsBySeam,seams=Int32Array.from(f.seams),orders=new Int32Array(seams.length).fill(-1);
 for(const s of pairs)for(let i=0;i<s.pairs.length;i+=2){const[a,b]=s.pairs.slice(i,i+2);if(a===b)continue;for(const[from,to]of[[a,b],[b,a]])for(let slot=0;slot<4;slot++)if(seams[from*4+slot]===to){const index=s.stitchIndices[i/2];assert(orders[from*4+slot]===-1||orders[from*4+slot]===index);orders[from*4+slot]=index;}}
 const lineage=JSON.parse(fs.readFileSync('/workspace/work/node-dawn-source-position-observer/run-tee-all-frame-positions-attempt1/actual14-parent-and-history.json')),activation=lineage.proofUsedActivation,layout=buildSeamGateLayout(f.collisionSeamDictionary.stitchCount,pairs.length),gate=packSeamGate(layout,activation.sewnUpTo,Uint32Array.from(activation.activeSeams),pairs.map(s=>s.stitchIndices));
 const body=Float32Array.from(f.bodyPositions.flatMap((v,i)=>i%3===2?[v,0]:[v])),bodyTriangles=Uint32Array.from(f.bodyIndices.flatMap((v,i)=>i%3===2?[v,0]:[v]));
 const binding={sourceToken:1055,bodyGeneration:5,gateRevision:activation.revision,gateToken:7,historyToken:13,correctedSubstep:14,sourceSha256:w.inputs.frozen.sha256,bodySha256:sha(bytes(body)),topologySha256:sha(bytes(triangles))};
 const packed=packJointGeometry({scope:'fresh-source',particleCount:parent.length/4,clothTriangles:triangles,bodyPositions:body,bodyTriangles,sourceTopology:surfaceTopologyExclusions(triangles,seams,orders,pairs,true,pairs.map(s=>s.stitchIndices)),sourceSeamLinks:surfaceSeamLinks(pairs),...binding,refinedBoundary:false}),prepared=await prepareJointClosedBodyProbe(packed,'fresh-source');
 const full=bodyFaceFeatureLanesWGSL(sourceJointClosedRawInventoryFactory(prepared,layout)),reference=fs.readFileSync(new URL('full-finite.wgsl',import.meta.url),'utf8');
 for(const name of['jointVisitBodyPair','bodyNearRow','makeRow','finiteTrianglesCross','segmentTriangleHit','bodyFeature','materialHistoryUncertainty'])assert.equal(functionBytes(full,name),functionBytes(reference,name),'Actual895 finite body hook '+name);
 const entry='\n@compute @workgroup_size(1) fn positive_feature_probe(){if(!jointBVHReady(false)||!jointBVHReady(true)){return;}if(cfg.p0>=cfg.clothFaces||cfg.p1>=cfg.bodyFaces||cfg.reserved>=15u){atomicOr(&state[0],16u);return;}jointVisitBodyPair(cfg.p0,cfg.p1,cfg.reserved);atomicStore(&state[2],7u);}\n';
 return{parent,history,gate,packed,prepared,layout,binding,witnesses:w.witnesses,shader:full+entry,fullShader:full,referenceSourceSha256:sha(reference),positiveBodyDeviceValidated:false};
}
