import argparse, pathlib, json, hashlib, subprocess, os, time, signal
p=argparse.ArgumentParser();p.add_argument('--run-after-lease',action='store_true');p.add_argument('--output');p.add_argument('--mode',choices=['witnesses','repeat'],required=True);p.add_argument('--verify-only',action='store_true');p.add_argument('--manifest-sha256',required=True);a=p.parse_args()
if not a.run_after_lease and not a.verify_only:raise SystemExit('Explicit root graphics lease required before native import')
r=pathlib.Path(__file__).resolve().parent
if not a.output and not a.verify_only:raise SystemExit('Unique output required')
out=pathlib.Path(a.output or '/tmp/unused-body-feature-verify').resolve();log=pathlib.Path(str(out)+'.log');process_report=pathlib.Path(str(out)+'-process.json')
if any(x.exists() for x in [out,log,process_report]):raise SystemExit('Unique output/log/process paths required')
m=json.loads((r/'review-pins.json').read_text())
def verify():
 if hashlib.sha256((r/'review-pins.json').read_bytes()).hexdigest()!=a.manifest_sha256:raise RuntimeError('Caller manifest identity changed')
 for name,h in m['files'].items():
  if hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()!=h:raise RuntimeError('Changed immutable actual input/helper/source: '+name)
verify()
if a.verify_only:print(json.dumps({'verified':True,'gpuInitialized':False,'mode':a.mode,'pins':len(m['files'])}));raise SystemExit(0)
env={**os.environ,'VK_ICD_FILENAMES':'/workspace/work/vulkan-backend/lvp-local-icd.json','VK_DRIVER_FILES':'/workspace/work/vulkan-backend/lvp-local-icd.json','XDG_RUNTIME_DIR':'/workspace/work/vulkan-backend/xdg-runtime'};start=time.monotonic();timeout=False
with log.open('x') as stream:
 child=subprocess.Popen(['node',str(r/('witness-runner.mjs' if a.mode=='witnesses' else 'runner.mjs')),'--run-after-lease','--output',str(out),'--manifest-sha256',a.manifest_sha256],env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=child.wait(timeout=180)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=5)
pin_error=None
try:verify()
except Exception as e:pin_error=str(e)
receipt={'pid':child.pid,'exitCode':code,'processClosed':child.poll() is not None,'timedOut':timeout,'elapsedSeconds':time.monotonic()-start,'boundSeconds':180,'graceSeconds':5,'postRunPinError':pin_error,'deviceClosureMustComeFromChildReport':True,'mode':a.mode,'fullRawInitialQueryOnly':a.mode=='repeat','sameDeviceQueries':2 if a.mode=='repeat' else 0,'positiveFeatureCases':3 if a.mode=='witnesses' else 0,'integratedPhysicalSubsteps':0,'all40Validated':False,'all41Validated':False,'pressureValidated':False,'fitAccepted':False}
process_report.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));raise SystemExit(0 if code==0 and not timeout and pin_error is None else 1)
