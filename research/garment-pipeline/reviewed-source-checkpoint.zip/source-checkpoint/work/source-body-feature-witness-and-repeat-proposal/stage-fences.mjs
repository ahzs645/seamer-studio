/** Diagnostic-only host resubmission. Records the EXACT original exporter
 * passes/uniform offsets; no WGSL rewrite, workgroup pruning or numeric upload. */
import {performance} from 'node:perf_hooks';
export const STAGE_FENCE_TIMEOUT_MS=60000;
export function recordEnumeration(exporter,context,snapshot){
 const stages=[];let open=null;
 const encoder={beginComputePass(descriptor={}){if(open)throw Error('Nested recorded compute pass');const stage={descriptor:{...descriptor},commands:[],entry:null,groups:null};open=stage;
  return{setPipeline(pipeline){if(open!==stage)throw Error('Closed recorded pass');stage.commands.push({method:'setPipeline',args:[pipeline]});},
   setBindGroup(index,group,offsets=[]){if(open!==stage)throw Error('Closed recorded pass');stage.commands.push({method:'setBindGroup',args:[index,group,Array.from(offsets)]});},
   dispatchWorkgroups(...groups){if(open!==stage||stage.groups)throw Error('Unexpected repeated recorded dispatch');stage.groups=groups.slice();stage.commands.push({method:'dispatchWorkgroups',args:groups.slice()});},
   end(){if(open!==stage||!stage.groups)throw Error('Missing actual recorded workgroups');stage.entry=String(stage.descriptor.label??'').replace(/^joint-bvh:/,'');stages.push(stage);open=null;}};
 }};
 exporter.encode({...context,encoder},snapshot);
 if(open||stages.length!==exporter.slotsPerEnumeration||stages[0]?.entry!=='reset'||stages.at(-1)?.entry!=='complete'||stages.slice(-5).map(s=>s.entry).join(',')!=='joint_bvh_self_rows,body_points,joint_bvh_body_faces,joint_bvh_chords,complete')throw Error('Incomplete exact original dispatch plan');
 return stages;
}
export function timestampRequest(adapter){const supported=adapter.features?.has('timestamp-query')===true;return{supported,requiredFeatures:supported?['timestamp-query']:[],units:'raw WebGPU timestamp values; no device calibration/performance claim'};}
function bounded(promise,label,trace){let timer;return Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>{trace('stage-operation-timeout',{label,boundMs:STAGE_FENCE_TIMEOUT_MS});reject(Error('Diagnostic stage operation bound: '+label));},STAGE_FENCE_TIMEOUT_MS);})]).finally(()=>clearTimeout(timer));}
export async function stageFencedEnumeration(device,exporter,context,snapshot,{trace,publishStage,isCurrent,timestamps=false}){
 if(typeof trace!=='function'||typeof publishStage!=='function'||typeof isCurrent!=='function'||!isCurrent()||!context.finalEnumeration||!context.parentStart||context.stateOffset!==0)throw Error('Sealed diagnostic-only initial stage context required');
 const stages=recordEnumeration(exporter,context,snapshot),owned=[];let querySet=null,proofRead,timestampResolve,timestampRead,closeError=null;
 const make=(label,size,usage)=>{const b=device.createBuffer({label:'stage-fenced:'+label,size,usage});owned.push(b);return b;};
 trace('stage-plan-recorded',{entries:stages.map(s=>({entry:s.entry,groups:s.groups})),exactUniformOffsetSnapshots:true,timestamps});
 try{
  proofRead=make('partial-proof-readback',32,GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST);
  if(timestamps){if(device.features?.has('timestamp-query')!==true)throw Error('Timestamp feature not actually enabled');querySet=device.createQuerySet({type:'timestamp',count:2});timestampResolve=make('actual-timestamps-resolve',16,GPUBufferUsage.QUERY_RESOLVE|GPUBufferUsage.COPY_SRC);timestampRead=make('actual-timestamps-readback',16,GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST);}
  for(let index=0;index<stages.length;index++){
   if(!isCurrent())throw Error('Stale diagnostic stage lease');const stage=stages[index],started=performance.now(),encoder=device.createCommandEncoder({label:'stage-fenced:'+stage.entry}),descriptor={...stage.descriptor};
   if(querySet)descriptor.timestampWrites={querySet,beginningOfPassWriteIndex:0,endOfPassWriteIndex:1};
   trace('stage-encode-before',{index,entry:stage.entry,groups:stage.groups});const pass=encoder.beginComputePass(descriptor);
   for(const command of stage.commands)pass[command.method](...command.args);pass.end();
   encoder.copyBufferToBuffer(context.state,context.stateOffset,proofRead,0,32);
   if(querySet){encoder.resolveQuerySet(querySet,0,2,timestampResolve,0);encoder.copyBufferToBuffer(timestampResolve,0,timestampRead,0,16);}
   trace('stage-submit-before',{index,entry:stage.entry});device.queue.submit([encoder.finish()]);const submitted=performance.now();trace('stage-submit-after',{index,entry:stage.entry});
   trace('stage-fence-before',{index,entry:stage.entry});await bounded(device.queue.onSubmittedWorkDone(),stage.entry+':queue-fence',trace);const fenced=performance.now();trace('stage-fence-after',{index,entry:stage.entry,wallFenceMs:fenced-submitted});
   const read=async(buffer,label)=>{let mapped=false;try{trace('stage-map-before',{index,entry:stage.entry,label});await bounded(buffer.mapAsync(GPUMapMode.READ),stage.entry+':'+label,trace);mapped=true;const bytes=buffer.getMappedRange().slice(0);trace('stage-map-after',{index,entry:stage.entry,label});return bytes;}finally{if(mapped)buffer.unmap();}};
   const proofBytes=await read(proofRead,'partial-proof'),proof=new Uint32Array(proofBytes);let actualTimestamp=null;
   if(timestampRead){const raw=await read(timestampRead,'timestamp-values'),values=new BigUint64Array(raw);actualTimestamp={begin:values[0].toString(),end:values[1].toString(),deltaRaw:values[1]>=values[0]?(values[1]-values[0]).toString():null,usable:values[1]>values[0],units:'raw WebGPU timestamp values; not wall-clock milliseconds'};}
   if(!isCurrent())throw Error('Stale stage after actual GPU readback');
   const receipt={index,entry:stage.entry,groups:stage.groups.slice(),proof:Array.from(proof),proofBytes:proofBytes.slice(0),wallEncodeSubmitMs:submitted-started,wallFenceMs:fenced-submitted,wallUntilReadbackMs:performance.now()-started,actualTimestamp,partial:true,fullInventoryCertificate:false};
   trace('stage-artifact-publication-before',{index,entry:stage.entry});await publishStage(receipt);trace('stage-artifact-publication-after',{index,entry:stage.entry});if(!isCurrent())throw Error('Stale stage publication');trace('stage-artifacts-retained',{index,entry:stage.entry,proof:Array.from(proof)});
   // Preserve the actual bad status and every stored row before rejecting. A
   // partial proof is never decoded as a complete finite certificate.
   // Preserve original full-query behavior: record bad partial flags, execute
   // every remaining original visitor, then let final full-proof decoding reject.
   if(proof[0]!==0)trace('partial-stage-status-failed',{index,entry:stage.entry,flags:proof[0],continueOriginalQueryOrder:true});
  }
 }finally{
  trace('stage-owned-drain-before');try{await device.queue.onSubmittedWorkDone();}catch(e){closeError=e;}finally{for(const b of owned)b.destroy();querySet?.destroy();trace('stage-owned-drain-after',{ownedBuffers:owned.length,querySetCreated:!!querySet,ownedHandlesDestroyed:true,queueDrainError:closeError?.message??null});}if(closeError)throw closeError;
 }
 return{stageCount:stages.length,timestampFeatureEnabled:timestamps,querySetDestroyed:true,fullInventoryCertificate:false};
}
