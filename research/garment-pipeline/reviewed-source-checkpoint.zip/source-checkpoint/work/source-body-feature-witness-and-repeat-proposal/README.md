NEW copied feature-lane stage-fenced diagnostic of immutable stage-fenced801
(f3ea3269...), preserving its actual failed attempt and receipts. No device run or
new full-factory authority exists for this epoch.

The actual prepared complete factory is first built through the unchanged closed
body/history, approved refined child material-u, runtime token and identifier
steps. Only then bodyFaceFeatureLanesWGSL is applied. Derived actual WGSL SHA
4af03dd1861a75ee4cc34a8fed04a9d5483293d0ff2a958300cbe53a4b15a379;
original actual template SHA26ea1ed0082964cda75d3bf80dc1aaf9929a4c3f9e29cdbd983ffead17f080d1.
Exactly three visitor functions differ. All other WGSL bytes, geometry/query
operands, finite/history helpers, padding, source masks, counts and capacities are
unchanged. Twelve finite protective body features and three body-edge crossing
features each receive one lane; every lane still traverses the complete body BVH.
This repeats traversal per feature and does not claim a measured speedup.

The actual SourceJointBVHFiniteExporter checks safe integer cloth-face*15 u32
multiplication and the actual device maxComputeWorkgroupsPerDimension before any
BVH buffer allocation. It dispatches ceil(clothFaces*15/64). For genuine prepared
skirt6712 faces this is100680 invocations/1574groups, versus held105groups. Every
OTHER actual dispatch entry/group/order/dynamic offset and every400B uniform write
remains byte exact to the genuine held class. Zero groups records a stage and emits
no dispatch; malformed/unknown/insufficient device limits reject. Pipeline/layout
storage remains8; uniform contents400B/512B slots unchanged. The copied private
scope registry is shared by preparation, observer, BVH and both actual backend
factory callsites.

The old predicate24 evidence is deliberately preserved as ORIGINAL template
predicate authority only. The separate factoryDerivation receipt explicitly hashes
the actual derived factory, policy and15lane dispatch, with actualDeviceExecuted
and compileValidated=false. Factory and preparation fingerprints truthfully change;
parent/history/USEDgate/full geometry bytes stay exactly the original initial SI
skirt. There is no relabeling of an old template as an executed new factory.

Stage fencing stays byte identical: same original stage order, optional real
adapter timestamp feature, per-pass queue fence and32B partial proof read, literal
raw rows saved at every completed emitting stage. Bad partial flags remain recorded
and never crop/prune the remaining query. Only final complete ordinary decoder may
certify inventory. There is no solve, numerical callback, pressure,40/41 or fit.

Bounds remain60s each fence/map; supervisor180s+5s drain then SIGKILL. Actual child
buffer/device/lost/strong-Instance cleanup and supervisor OS closure are distinct.
A blocked native call can prevent callback cleanup; forced closure must not be
invented. No device run is authorized by this review artifact.

35 CPU controls pass. They include the29 preserved controls updated for the precise
allowed changes, actual original-vs-derived method plan/400B uniform comparison,
unknown/too-small/u32 device limit rejection with full cleanup, complete padded
15-feature coverage, factory reflection/identifier checks and genuine historical
body finite witnesses from authentic GPU data. Those witnesses include body-corner
protection, edge-edge protection and finite body-edge through cloth interior with
supported old history. Their exact original byte pins/material/body features are
retained; they are legacy-W tee CPU replay controls, not a NEW device execution or
fresh SI skirt trajectory. No synthetic geometry/proof is passed as actual input.
Before numerical whole-body/full-factory authority, genuine positive body-witness
NEW device controls are still required; an initial zero-emission branch alone
cannot prove that authority.

CPU command:
node --test controls.test.mjs scope-graph.test.mjs stage-fences.test.mjs stage-actual-method.test.mjs feature-lanes.test.mjs

Bounded launcher (ONLY after root's separate explicit graphics lease):
python3 /workspace/work/source-joint-refined-allraw-feature-lanes-stage-fenced/launch.py --run-after-lease --manifest-sha256 EXACT_FROZEN_SHA --output NEW_UNIQUE_OUTPUT

Both Vulkan ICD environment variables and XDG runtime are assigned by the unchanged
launcher. Do not rerun preflight/freezer after sealing. No shipping/live source or
held numerical70/801 artifact changed.
