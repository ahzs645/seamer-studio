/** Strict immutable packing for the unused finite joint REFERENCE exporter. */
import {buildBodyContactFeatureNormals} from './bodyContactFeatures';
import type {JointEpoch} from './sourceJointContact';
export const JOINT_GEOMETRY_MAGIC=0x4a464731,JOINT_GEOMETRY_HEADER=16;
export interface JointGeometryInput {
 scope:'fresh-source'; particleCount:number; clothTriangles:Uint32Array;
 bodyPositions:Float32Array;bodyTriangles:Uint32Array;
 sourceTopology:Uint32Array;sourceSeamLinks:Uint32Array;
 bodyGeneration:number;sourceToken:number;
 /** Full source SHA/body/topology/gate dictionaries are evidence, not replaced by u32 tokens. */
 sourceSha256:string;bodySha256:string;topologySha256:string;
 refinedBoundary:false;
}
export interface PackedJointGeometry {words:Uint32Array;particleCount:number;clothFaces:number;bodyFaces:number;bodyGeneration:number;sourceToken:number;sourceSha256:string;bodySha256:string;topologySha256:string;}
const integer=(x:number)=>Number.isSafeInteger(x)&&x>=0&&x<=0xffffffff;
export function packJointGeometry(i:JointGeometryInput):PackedJointGeometry {
 if(i.scope!=='fresh-source'||i.refinedBoundary!==false||!integer(i.particleCount)||i.particleCount===0||!integer(i.bodyGeneration)||!integer(i.sourceToken)||[i.sourceSha256,i.bodySha256,i.topologySha256].some(h=>!/^([a-f0-9]{64})$/.test(h)))throw Error('Unbound, native or refined source geometry');
 if(i.clothTriangles.length%4||i.bodyTriangles.length%4||i.bodyPositions.length%4||!i.clothTriangles.length||!i.bodyTriangles.length||Array.from(i.bodyPositions).some(v=>!Number.isFinite(v)))throw Error('Invalid finite immutable geometry layout');
 const nf=i.clothTriangles.length/4,nb=i.bodyTriangles.length/4,nv=i.bodyPositions.length/4;
 for(let at=0;at<i.clothTriangles.length;at+=4)if(new Set(i.clothTriangles.slice(at,at+3)).size!==3||Array.from(i.clothTriangles.slice(at,at+3)).some(v=>v>=i.particleCount))throw Error('Invalid cloth finite topology');
 for(let at=0;at<i.bodyTriangles.length;at+=4)if(new Set(i.bodyTriangles.slice(at,at+3)).size!==3||Array.from(i.bodyTriangles.slice(at,at+3)).some(v=>v>=nv))throw Error('Invalid body finite topology');
 const t=i.sourceTopology,l=i.sourceSeamLinks;
 if(t.length<nf+1||t[0]!==nf+1||t[nf]!==t.length||l.length<1||l[0]<1||l[0]>l.length)throw Error('Missing exact source segment topology/links');
 const seams=l[0]-1;if(l[seams]!==l.length)throw Error('Truncated actual source seam links');
 for(let s=0;s<seams;s++)if(l[s]>l[s+1]||(l[s+1]-l[s])%2)throw Error('Malformed actual source seam path');
 for(let at=l[0];at<l.length;at++)if(l[at]>=i.particleCount)throw Error('Source segment particle out of range');
 for(let f=0;f<nf;f++){if(t[f]>t[f+1]||(t[f+1]-t[f])%5)throw Error('Malformed face one-ring dictionary');let last=-1;for(let at=t[f];at<t[f+1];at+=5){const other=t[at],link=t[at+2],seam=t[at+4];if(other>=nf||other<last||seam>=seams||link<l[seam]||link+3>=l[seam+1]||(link-l[seam])%2)throw Error('Source local segment proof is not bound to actual seam path');last=other;}}
 const features=buildBodyContactFeatureNormals({positions:i.bodyPositions,triangles:i.bodyTriangles,numTriangles:nb});
 // A zero pseudonormal is not repaired with a face normal: the reference cannot certify it.
 if(Array.from(features).some((v,at)=>at%4!==3&&!Number.isFinite(v)))throw Error('Invalid finite body feature normal');
 const sections=[i.clothTriangles,i.bodyTriangles,new Uint32Array(i.bodyPositions.buffer,i.bodyPositions.byteOffset,i.bodyPositions.length),new Uint32Array(features.buffer),t,l];let total=16;const offsets=sections.map(s=>{const offset=total;total+=s.length;return offset;});
 const words=new Uint32Array(total);words.set([JOINT_GEOMETRY_MAGIC,1,i.particleCount,nf,nv,nb,offsets[0],offsets[1],offsets[2],offsets[3],offsets[4],t.length,offsets[5],l.length,i.sourceToken,i.bodyGeneration]);sections.forEach((s,n)=>words.set(s,offsets[n]));
 return {words,particleCount:i.particleCount,clothFaces:nf,bodyFaces:nb,bodyGeneration:i.bodyGeneration,sourceToken:i.sourceToken,sourceSha256:i.sourceSha256,bodySha256:i.bodySha256,topologySha256:i.topologySha256};
}
export function requireJointGeometryEpoch(g:PackedJointGeometry,e:JointEpoch){if(g.bodyGeneration!==e.bodyGeneration||g.sourceToken!==e.sourceToken)throw Error('Joint immutable body/source geometry is stale');}
