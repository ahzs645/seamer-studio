/** Static exact-coordinate closure/orientation receipt. Source-only, cloned inputs.
 * No weld tolerance, mesh repair or geometry mutation. Signature binds EVERY original
 * vec4 body position/topology byte, including metadata and signed zero.
 */
export interface JointClosedBodyReceipt {
 enabled:true;exactCoordinateClosed:true;consistentlyOriented:true;componentOutwardVolumePositive:true;
 bodyPositionSha256:string;bodyTriangleSha256:string;sourceToken:number;bodyGeneration:number;
 bodyVertices:number;bodyFaces:number;components:number;volumeM3:number;
}
async function digest(a:Float32Array|Uint32Array){const b=new Uint8Array(a.byteLength);const words=new Uint32Array(a.buffer,a.byteOffset,a.length),view=new DataView(b.buffer);for(let i=0;i<words.length;i++)view.setUint32(i*4,words[i],true);return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',b)),v=>v.toString(16).padStart(2,'0')).join('');}
export async function makeJointClosedBodyReceipt(input:{positions:Float32Array;triangles:Uint32Array;scope:'fresh-source'|'native';sourceToken:number;bodyGeneration:number}):Promise<JointClosedBodyReceipt|{enabled:false;nativeBypass:true}>{
 if(input.scope==='native')return{enabled:false,nativeBypass:true};
 const positions=input.positions.slice(),triangles=input.triangles.slice(),sourceToken=input.sourceToken,bodyGeneration=input.bodyGeneration;
 if(input.scope!=='fresh-source'||![sourceToken,bodyGeneration].every(n=>Number.isSafeInteger(n)&&n>=0&&n<=0xffffffff)||!positions.length||positions.length%4||!triangles.length||triangles.length%4||positions.some(v=>!Number.isFinite(v)))throw Error('Invalid exact static body source');
 const nf=triangles.length/4,words=new Uint32Array(positions.buffer),edges=new Map<string,{faces:number[];direction:number}>(),parent=Uint32Array.from({length:nf},(_,i)=>i),volumes=new Float64Array(nf);
 const find=(n:number):number=>{while(parent[n]!==n){parent[n]=parent[parent[n]];n=parent[n];}return n;};
 const key=(id:number)=>[0,1,2].map(k=>positions[id*4+k]===0?'0':words[id*4+k].toString(16)).join('/');
 for(let face=0;face<nf;face++){
  const ids=Array.from(triangles.slice(face*4,face*4+3));if(new Set(ids).size!==3||ids.some(i=>i>=positions.length/4))throw Error('Invalid body triangle');const keys=ids.map(key);if(new Set(keys).size!==3)throw Error('Exact body coordinate degeneracy');
  const [a,b,c]=ids.map(id=>Array.from(positions.slice(id*4,id*4+3))),e=b.map((v,k)=>v-a[k]),f=c.map((v,k)=>v-a[k]),normal=[e[1]*f[2]-e[2]*f[1],e[2]*f[0]-e[0]*f[2],e[0]*f[1]-e[1]*f[0]];if(!(Math.hypot(...normal)>0))throw Error('Degenerate body face');
  volumes[face]=(a[0]*(b[1]*c[2]-b[2]*c[1])+a[1]*(b[2]*c[0]-b[0]*c[2])+a[2]*(b[0]*c[1]-b[1]*c[0]))/6;
  for(let k=0;k<3;k++){const x=keys[k],y=keys[(k+1)%3],edge=[x,y].sort().join('|'),old=edges.get(edge)??{faces:[],direction:0};old.faces.push(face);old.direction+=x<y?1:-1;edges.set(edge,old);}
 }
 for(const edge of edges.values()){if(edge.faces.length!==2||edge.direction!==0)throw Error('Body not exactly closed consistently oriented');const x=find(edge.faces[0]),y=find(edge.faces[1]);parent[Math.max(x,y)]=Math.min(x,y);}
 const components=new Map<number,number>();for(let face=0;face<nf;face++){const root=find(face);components.set(root,(components.get(root)??0)+volumes[face]);}if([...components.values()].some(v=>!Number.isFinite(v)||v<=0))throw Error('Body component does not have outward positive volume');
 const [bodyPositionSha256,bodyTriangleSha256]=await Promise.all([digest(positions),digest(triangles)]);
 return Object.freeze({enabled:true,exactCoordinateClosed:true,consistentlyOriented:true,componentOutwardVolumePositive:true,bodyPositionSha256,bodyTriangleSha256,sourceToken,bodyGeneration,bodyVertices:positions.length/4,bodyFaces:nf,components:components.size,volumeM3:[...components.values()].reduce((a,b)=>a+b,0)});
}
