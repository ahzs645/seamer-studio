/** Separate diagnostic actual-world finite body-history producer. Native creates
 * no buffers/pipelines; no source-side row is injected from CPU. Chord bary/time
 * is derived on GPU from actual finite body intersections of the selected face.
 */
import {sourceJointBVHFiniteWGSL,packJointBVHUniform,type ObservedJointSnapshot} from './sourceJointBVHFiniteExporter';
import {jointBVHBodyInlineTraversalWGSL,packJointBVH,requireJointBVHBinding,validateJointBVH,type PackedJointBVH} from './sourceJointBVHRowExport';
import {sourceJointClosedBodyRecoveryWGSL} from './sourceJointClosedBodyRecovery';
import {makeJointClosedBodyReceipt} from './sourceJointClosedBodyReceipt';
import type {PackedJointGeometry} from './sourceJointGeometry';
import type {SeamGateLayout} from './seamGate';
import type {JointEpoch} from './sourceJointContact';
export async function prepareJointClosedBodyProbe(p:PackedJointGeometry,scope:'fresh-source'|'native'){
 if(scope==='native')return{enabled:false as const};
 const packed={...p,words:p.words.slice()},w=packed.words;
 if(w[0]!==0x4a464731||w[1]!==1||w[7]+w[5]*4>w.length||w[8]+w[4]*4>w.length||w[14]!==packed.sourceToken||w[15]!==packed.bodyGeneration)throw Error('Malformed immutable closed body geometry');
 const bodyPositions=new Float32Array(w.slice(w[8],w[8]+w[4]*4).buffer),bodyTriangles=w.slice(w[7],w[7]+w[5]*4),receipt=await makeJointClosedBodyReceipt({positions:bodyPositions,triangles:bodyTriangles,scope,sourceToken:packed.sourceToken,bodyGeneration:packed.bodyGeneration});
 if(!receipt.enabled||receipt.bodyPositionSha256!==packed.bodySha256)throw Error('Actual immutable body position SHA mismatch');
 const factory=(layout:SeamGateLayout)=>{
  const hashChecks=Array.from({length:8},(_,i)=>`bodyBVH[${40+i}u]==${parseInt(receipt.bodyPositionSha256.slice(i*8,i*8+8),16)}u&&jointBVHExpectedWord(${40+i}u)==bodyBVH[${40+i}u]`).join('&&');
  const marker=`fn jointRecoveryClosedBodyValidated()->bool{return cfg.sourceToken==${receipt.sourceToken}u&&cfg.bodyGeneration==${receipt.bodyGeneration}u&&${hashChecks};}`;
  const collector=jointBVHBodyInlineTraversalWGSL('min(a[edge],a[(edge+1u)%3u])-vec3f(jointFiniteHorizon())','max(a[edge],a[(edge+1u)%3u])+vec3f(jointFiniteHorizon())',`let b=bodyPoints(bodyFace);let hit=segmentTriangleHit(a[edge],a[(edge+1u)%3u],b[0],b[1],b[2]);if(hit.w>0.0&&hit.w<1.0){if(count>=34u){atomicOr(&state[0],1u);}else{times[count]=hit.w;count++;}}`);
  return sourceJointBVHFiniteWGSL(layout)+'\n'+marker+'\n'+sourceJointClosedBodyRecoveryWGSL()+/* wgsl */`
fn jointRecoveryStore(index:u32,sourceFace:u32,feature:u32,ids:vec3u,weights:vec3f,p:JointClosedRecovery){
 if(index*2u+1u>=cfg.capacity){atomicOr(&state[0],1u);return;}
 var r:Row;r.a=vec4u(p.valid,p.reason,p.nearestFace,p.oldFace);r.b=vec4u(p.entryFace,p.entryCount,p.exitCount,0u);r.wa=vec4f(p.closest,p.oldMargin);r.wb=vec4f(p.normal,p.currentMargin);r.n=vec4f(p.entryPoint,p.firstTime);r.q=vec4f(p.entryNormal,p.uncertainty);r.feature=p.oldRayVotes;r.proof=p.currentRayVotes;rows[index*2u]=r;
 var s:Row;s.a=p.oldRayCounts;s.b=p.currentRayCounts;s.wa=vec4f(weights,f32(feature));s.wb=vec4f(baryPoint(clothPoints(vec4u(ids,0u),false),weights),0.0);s.n=vec4f(baryPoint(clothPoints(vec4u(ids,0u),true),weights),0.0);s.feature=vec4u(ids,sourceFace);s.proof=vec4u(cfg.sourceToken,cfg.bodyGeneration,cfg.gateRevision,cfg.substep);rows[index*2u+1u]=s;
}
@compute @workgroup_size(1) fn joint_closed_body_probe(){
 let face=cfg.p0;if(face>=cfg.clothFaces||!jointRecoveryClosedBodyValidated()||!jointBVHReady(true)){atomicOr(&state[0],16u);return;}
 let ids=tri(face);let a=clothPoints(ids,false);
 for(var edge=0u;edge<3u;edge++){
  var times:array<f32,34>;times[0]=0.0;times[1]=1.0;var count=2u;${collector}
  for(var i=1u;i<count;i++){let t=times[i];var j=i;while(j>0u&&times[j-1u]>t){times[j]=times[j-1u];j--;}times[j]=t;}
  for(var interval=0u;interval+1u<count;interval++){
   if(times[interval+1u]<=times[interval]){continue;}let time=(times[interval]+times[interval+1u])*0.5;let point=mix(a[edge],a[(edge+1u)%3u],time);let near=jointNearestBody(point);if(near.face==JOINT_BVH_NONE){atomicOr(&state[0],4u);continue;}if(dot(point-near.q,near.n)>=0.0){continue;}
   var weights=vec3f(0.0);weights[edge]=1.0-time;weights[(edge+1u)%3u]=time;
   let proof=jointClosedBodyMaterialRecovery(ids.xyz,weights);let index=atomicAdd(&state[1],1u);jointRecoveryStore(index,face,edge*34u+interval,ids.xyz,weights,proof);
   if(proof.valid==0u){atomicOr(&state[0],4u);}
  }
 }atomicStore(&state[2],7u);
}
`;
 };
 const expectedWords=w.slice(),expectedMetadata=JSON.stringify({...packed,words:undefined});
 const assertPackedGeometryUnchanged=(value:PackedJointGeometry)=>{if(JSON.stringify({...value,words:undefined})!==expectedMetadata||value.words.length!==expectedWords.length||value.words.some((v,i)=>v!==expectedWords[i]))throw Error('Closed-body prepared geometry mutated');};
 return{enabled:true as const,packed,bodyPositions,bodyTriangles,receipt,factory,assertPackedGeometryUnchanged};
}
/** CPU upload ABI boundary, not a finite geometry proof. Header kind is checked
 * explicitly against the shader's body=true branch before any device allocation. */
export function requireJointClosedProbeTree(tree:PackedJointBVH,p:PackedJointGeometry,observed:ObservedJointSnapshot,kind:'body'|'cloth'){
 validateJointBVH(tree);requireJointBVHBinding(tree,observed.binding);
 const expectedFaces=kind==='body'?p.bodyFaces:p.clothFaces,expectedParticles=kind==='body'?p.words[4]:p.particleCount;
 if(tree.kind!==kind||tree.words[2]!==Number(kind==='body')||tree.faceCount!==expectedFaces||tree.particleCount!==expectedParticles||tree.words[3]!==expectedFaces||tree.words[4]!==expectedParticles)throw Error('Closed probe wrong semantic tree kind/count (GPU readiness flag16)');
}
export function packJointClosedProbeTrees(p:PackedJointGeometry,observed:ObservedJointSnapshot){
 const body=packJointBVH(p.words.slice(p.words[7],p.words[7]+p.bodyFaces*4),new Float32Array(p.words.slice(p.words[8],p.words[8]+p.words[4]*4).buffer),{...observed.binding,kind:'body',scope:'fresh-source-equal-layer',refinedBoundary:false});
 const triangles=p.words.slice(p.words[6],p.words[6]+p.clothFaces*4),cloth=packJointBVH(triangles,observed.current,{...observed.binding,kind:'cloth',scope:'fresh-source-equal-layer',refinedBoundary:false});
 requireJointClosedProbeTree(body,p,observed,'body');requireJointClosedProbeTree(cloth,p,observed,'cloth');return{body,cloth};
}
/** Diagnostic-only host. Caller actual current/history/gate arrays must be the
 * immutable observed GPU bytes and identities, not fabricated claimed hashes. */
export class SourceJointClosedBodyProbe {
 readonly productionIntegrationReady=false;private owned:GPUBuffer[]=[];private pipeline?:GPUComputePipeline;private group?:GPUBindGroup;private config?:GPUBuffer;private disposed=false;private closing=false;private initialObserved?:ObservedJointSnapshot;private physicalEpoch?:JointEpoch;private closePromise?:Promise<void>;
 constructor(private device:GPUDevice,readonly prepared:Awaited<ReturnType<typeof prepareJointClosedBodyProbe>>,observed:ObservedJointSnapshot,gate:GPUBuffer,layout:SeamGateLayout,readonly output:GPUBuffer,readonly state:GPUBuffer,physicalEpoch?:JointEpoch){
  if(!prepared.enabled)return;
  if(gate!==observed.gateBuffer||!physicalEpoch||!Number.isInteger(physicalEpoch.correctedSubstep)||physicalEpoch.correctedSubstep<1||physicalEpoch.correctedSubstep>40||physicalEpoch.sourceToken!==observed.binding.sourceToken||physicalEpoch.bodyGeneration!==observed.binding.bodyGeneration||physicalEpoch.gateRevision!==observed.binding.gateRevision)throw Error('Unbound closed-body physical parent/gate lease');
  this.physicalEpoch={bodyGeneration:physicalEpoch.bodyGeneration,sourceToken:physicalEpoch.sourceToken,gateRevision:physicalEpoch.gateRevision,correctedSubstep:physicalEpoch.correctedSubstep};
  prepared.assertPackedGeometryUnchanged(prepared.packed);this.initialObserved={...observed,binding:{...observed.binding},current:observed.current.slice(),previous:observed.previous.slice(),gateWords:observed.gateWords.slice()};
  const p={...prepared.packed,words:prepared.packed.words.slice()},make=(label:string,bytes:ArrayBufferView,usage:number)=>{const b=device.createBuffer({label:'closed-body-probe:'+label,size:Math.max(4,bytes.byteLength),usage});this.owned.push(b);device.queue.writeBuffer(b,0,bytes.buffer as ArrayBuffer,bytes.byteOffset,bytes.byteLength);return b;};
  if(device.limits.maxStorageBuffersPerShaderStage<8||output.size<12*128||state.size<32||p.bodySha256!==observed.binding.bodySha256||p.sourceSha256!==observed.binding.sourceSha256||p.topologySha256!==observed.binding.topologySha256)throw Error('Unbound closed-body probe source/shape');
  try{
   const {body,cloth}=packJointClosedProbeTrees(p,observed);
   const geometry=make('immutable-geometry',p.words,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST),cache=make('unused-owner-cache',new Uint32Array(512),GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST),cb=make('cloth',cloth.words,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST),bb=make('closed-body',body.words,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST);
   this.config=make('config',new Uint32Array(100),GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST);
   const bindings=device.createBindGroupLayout({entries:[...Array.from({length:8},(_,binding)=>({binding,visibility:GPUShaderStage.COMPUTE,buffer:{type:[0,1,2,7].includes(binding)?'read-only-storage' as const:'storage' as const}})),{binding:8,visibility:GPUShaderStage.COMPUTE,buffer:{type:'uniform'}},{binding:9,visibility:GPUShaderStage.COMPUTE,buffer:{type:'uniform'}}]});
   this.pipeline=device.createComputePipeline({layout:device.createPipelineLayout({bindGroupLayouts:[bindings]}),compute:{module:device.createShaderModule({code:prepared.factory(layout)}),entryPoint:'joint_closed_body_probe'}});
   this.group=device.createBindGroup({layout:bindings,entries:[observed.currentBuffer,observed.previousBuffer,geometry,output,state,cache,cb,bb,this.config,gate].map((buffer,binding)=>({binding,resource:{buffer}}))});
  }catch(error){for(const b of this.owned)b.destroy();this.owned=[];this.disposed=true;throw error;}
 }
 encode(encoder:GPUCommandEncoder,observed:ObservedJointSnapshot,epoch:JointEpoch,face:number){
  if(!this.prepared.enabled)return;if(this.disposed||this.closing||!Number.isSafeInteger(face)||face<0||face>=this.prepared.packed.clothFaces)throw Error('Invalid closed-body probe lifetime/face');
  if(JSON.stringify({bodyGeneration:epoch.bodyGeneration,sourceToken:epoch.sourceToken,gateRevision:epoch.gateRevision,correctedSubstep:epoch.correctedSubstep})!==JSON.stringify(this.physicalEpoch))throw Error('Closed-body physical parent epoch changed');
  const initial=this.initialObserved!;if(observed.currentBuffer!==initial.currentBuffer||observed.previousBuffer!==initial.previousBuffer||observed.gateBuffer!==initial.gateBuffer||observed.generation!==initial.generation||JSON.stringify(observed.binding)!==JSON.stringify(initial.binding))throw Error('Closed-body observed lease changed');this.prepared.assertPackedGeometryUnchanged(this.prepared.packed);
  const cfg=packJointBVHUniform(this.prepared.packed,epoch,observed.binding,64,12,false,true,{first:0,count:0,depth:0});cfg[18]=face;this.device.queue.writeBuffer(this.config!,0,new Uint32Array(cfg));encoder.clearBuffer(this.state);
  const pass=encoder.beginComputePass({label:'authentic-finite-body-history'});pass.setPipeline(this.pipeline!);pass.setBindGroup(0,this.group!);pass.dispatchWorkgroups(1);pass.end();
 }
 destroy():Promise<void>{
  if(this.closePromise)return this.closePromise;
  if(this.disposed||!this.prepared.enabled){this.disposed=true;return Promise.resolve();}
  this.closing=true;
  this.closePromise=(async()=>{let queueFailure:unknown;const destructionFailures:unknown[]=[];
   try{await this.device.queue.onSubmittedWorkDone();}catch(error){queueFailure=error;}
   finally{this.disposed=true;for(const b of this.owned){try{b.destroy();}catch(error){destructionFailures.push(error);}}this.owned=[];}
   if(queueFailure||destructionFailures.length)throw new AggregateError([...(queueFailure?[queueFailure]:[]),...destructionFailures],'Closed-body probe drained with cleanup/queue failure');
  })();return this.closePromise;
 }

}
