/** NEW isolated finite history producer proposal; no shipping import or device epoch.
 * All points/nearest features/finite segment entries are computed on actual GPU data.
 * Requires complete static-body BVH + angle-weighted welded pseudonormals and an
 * independently exact-closed/oriented immutable body/source hash validation receipt.
 * The GPU classifier is conservative nearest-sign + three finite rays + authentic finite entry, to be
 * compared against independent CPU winding/three-ray ABI2; it does NOT claim GPU
 * solid-angle evaluation; CPU winding remains the independent oracle. No supported result is a garment certificate.
 */
import {jointBVHBodyInlineTraversalWGSL} from './sourceJointBVHRowExport';
export function sourceJointClosedBodyRecoveryWGSL():string{
 const visit=/* wgsl */`
 let body=bodyPoints(bodyFace);let hit=segmentTriangleHit(oldPoint,currentPoint,body[0],body[1],body[2]);
 if(hit.w>=0.0){
  let bary=finiteBarycentric(body,hit.xyz);let edgeA=body[1]-body[0];let edgeB=body[2]-body[0];let area=length(cross(edgeA,edgeB));
  if(area<=0.0||!jointBVHFinite(bary)){uncertain=true;}else{
   let condition=length(edgeA)*length(edgeB)/area;let parameterBound=64.0*5.960464477539063e-8*(1.0+condition);
   let n=normalize(cross(edgeA,edgeB));let orientation=dot(n,direction);
   // Boundary/tangent/tied hits are conservatively unknown; never distance-dedup.
   if(any(bary<=vec3f(parameterBound))||any(bary>=vec3f(1.0-parameterBound))||abs(orientation)<=parameterBound||hit.w*travel<=margin||((1.0-hit.w)*travel)<=margin){uncertain=true;}
   if(hit.w<firstTime){secondTime=firstTime;firstTime=hit.w;entryFace=bodyFace;entryPoint=hit.xyz;entryNormal=n;firstOrientation=orientation;}else{secondTime=min(secondTime,hit.w);}
   hits+=1u;if(orientation<0.0){entries+=1u;}else{exits+=1u;}
  }
 }
 `;
 const rayVisit=/* wgsl */`
 let t=bodyPoints(bodyFace);let hit=segmentTriangleHit(point,end,t[0],t[1],t[2]);
 if(hit.w>=0.0){let e0=t[1]-t[0];let e1=t[2]-t[0];let area=length(cross(e0,e1));
  if(area<=0.0){invalid=true;}else{let condition=length(e0)*length(e1)/area;let bary=finiteBarycentric(t,hit.xyz);let pbound=64.0*5.960464477539063e-8*(1.0+condition);
   if(!jointBVHFinite(bary)||any(bary<=vec3f(pbound))||abs(dot(normalize(cross(e0,e1)),direction))<=pbound||hit.w*span<=margin){invalid=true;}
   count+=1u;
  }
 }
 `;
 return /* wgsl */`
struct JointClosedRayVote {votes:vec4u,counts:vec4u};
fn jointRecoveryParity(point:vec3f,margin:f32)->JointClosedRayVote{
 let root=bodyBVH[6];let low=jointBVHLo(true,root);let high=jointBVHHi(true,root);let center=(low+high)*0.5;
 let span=distance(point,center)+2.0*length(high-low)+1.0;
 let directions=array<vec3f,3>(normalize(vec3f(1.0,0.373,0.719)),normalize(vec3f(-0.317,1.0,0.613)),normalize(vec3f(0.537,-0.419,1.0)));
 var out:JointClosedRayVote;out.votes=vec4u(2u,2u,2u,0u);var valid=true;for(var ray=0u;ray<3u;ray++){let direction=directions[ray];let end=point+direction*span;var count=0u;var invalid=false;
 ${jointBVHBodyInlineTraversalWGSL('min(point,end)-vec3f(margin)','max(point,end)+vec3f(margin)',rayVisit)}
 out.counts[ray]=count;if(invalid){valid=false;}else{out.votes[ray]=count%2u;}
 }out.votes.w=select(0u,1u,valid&&out.votes.x==out.votes.y&&out.votes.x==out.votes.z);return out;
}
struct JointClosedRecovery {
 valid:u32, reason:u32, nearestFace:u32, oldFace:u32,
 entryFace:u32, entryCount:u32, exitCount:u32, reserved:u32,
 closest:vec3f, oldMargin:f32,
 normal:vec3f, currentMargin:f32,
 entryPoint:vec3f, firstTime:f32,
 entryNormal:vec3f, uncertainty:f32,
 oldRayVotes:vec4u, currentRayVotes:vec4u, oldRayCounts:vec4u, currentRayCounts:vec4u,
};
fn jointRecoveryBound(point:vec3f,near:Nearest)->f32{
 let body=bodyPoints(near.face);let e0=body[1]-body[0];let e1=body[2]-body[0];let area=length(cross(e0,e1));
 if(area<=0.0){return 1e30;}let condition=length(e0)*length(e1)/area;
 let scale=max(1.0,max(max(abs(point.x),abs(point.y)),max(abs(point.z),max(max(abs(near.q.x),abs(near.q.y)),abs(near.q.z)))));
 return (32.0*5.960464477539063e-8/(1.0-32.0*5.960464477539063e-8))*scale*(1.0+condition);
}
fn jointClosedBodyMaterialRecovery(ids:vec3u,weights:vec3f)->JointClosedRecovery{
 var out:JointClosedRecovery;out.valid=0u;out.reason=4u;out.nearestFace=JOINT_BVH_NONE;out.oldFace=JOINT_BVH_NONE;out.entryFace=JOINT_BVH_NONE;out.oldRayVotes=vec4u(2u,2u,2u,0u);out.currentRayVotes=vec4u(2u,2u,2u,0u);
 if(!jointRecoveryClosedBodyValidated()||!jointBVHReady(true)||any(ids>=vec3u(cfg.particles))||any(weights<vec3f(0.0))||any(weights>vec3f(1.0))||abs(dot(weights,vec3f(1.0))-1.0)>8.0*5.960464477539063e-8){return out;}
 for(var k=0u;k<3u;k++){if(bitcast<u32>(current[ids[k]].w)!=bitcast<u32>(previous[ids[k]].w)){return out;}}
 let currentPoint=baryPoint(clothPoints(vec4u(ids,0u),false),weights);let oldPoint=baryPoint(clothPoints(vec4u(ids,0u),true),weights);
 if(!jointBVHFinite(currentPoint)||!jointBVHFinite(oldPoint)){return out;}
 let now=jointNearestBody(currentPoint);let before=jointNearestBody(oldPoint);
 if(now.face==JOINT_BVH_NONE||before.face==JOINT_BVH_NONE||!jointBVHFinite(now.n)||!jointBVHFinite(before.n)||length(now.n)<0.5||length(before.n)<0.5){return out;}
 let oldBound=jointRecoveryBound(oldPoint,before);let currentBound=jointRecoveryBound(currentPoint,now);let margin=max(oldBound,currentBound);
 let oldSigned=dot(oldPoint-before.q,before.n);let nowSigned=dot(currentPoint-now.q,now.n);
 out.nearestFace=now.face;out.oldFace=before.face;out.oldMargin=oldSigned;out.currentMargin=nowSigned;out.uncertainty=margin;
 // Globally nearest finite signs on independently closed/oriented body; never use
 // OLD projection against the CURRENT nearest triangle's extended plane.
 if(oldSigned<=oldBound||nowSigned>=-currentBound||before.distance<=oldBound||now.distance<=currentBound){return out;}
 let oldRays=jointRecoveryParity(oldPoint,oldBound);let nowRays=jointRecoveryParity(currentPoint,currentBound);out.oldRayVotes=oldRays.votes;out.oldRayCounts=oldRays.counts;out.currentRayVotes=nowRays.votes;out.currentRayCounts=nowRays.counts;
 if(oldRays.votes.w!=1u||nowRays.votes.w!=1u||any(oldRays.votes.xyz!=vec3u(0u))||any(nowRays.votes.xyz!=vec3u(1u))){return out;}
 let delta=currentPoint-oldPoint;let travel=length(delta);if(travel<=margin){return out;}let direction=delta/travel;
 var firstTime=2.0;var secondTime=2.0;var firstOrientation=0.0;var entryFace=JOINT_BVH_NONE;var entryPoint=vec3f(0.0);var entryNormal=vec3f(0.0);var hits=0u;var entries=0u;var exits=0u;var uncertain=false;
 ${jointBVHBodyInlineTraversalWGSL('min(oldPoint,currentPoint)-vec3f(margin)','max(oldPoint,currentPoint)+vec3f(margin)',visit)}
 out.entryFace=entryFace;out.entryCount=entries;out.exitCount=exits;out.entryPoint=entryPoint;out.entryNormal=entryNormal;out.firstTime=firstTime;
 if(uncertain||hits==0u||(hits%2u)!=1u||entries!=exits+1u||firstTime>=1.0||firstOrientation>=0.0||(secondTime-firstTime)*travel<=margin){return out;}
 let escape=normalize(now.q-currentPoint);if(dot(escape,now.n)<=0.5){return out;}
 out.closest=now.q;out.normal=escape;out.valid=1u;out.reason=0u;return out;
}
`;
}
