/** ISOLATED source-only discovery infrastructure. This is neither a complete row exporter nor
 * a contact/CCD certificate. Finite visitor hooks own geometry/proof tests and append every raw
 * row; output/cache overflow must reject the solve. No fixed candidate array or nearest ranking.
 * Body topology is immutable. Cloth bounds are refit for each distinct current snapshot.
 */
export const JOINT_BVH_MAGIC = 0x4a425631;
export const JOINT_BVH_HEADER_WORDS = 80;
export const JOINT_BVH_NONE = 0xffffffff;
export const JOINT_BVH_HORIZON = 0.011;
const U32_MAX = 0xffffffff;
const HASH_NAMES = ['sourceSha256', 'bodySha256', 'topologySha256', 'historySha256', 'gateSha256', 'currentSha256'] as const;
export interface JointBVHSnapshot {
  sourceToken: number; bodyGeneration: number; snapshotEpoch: number;
  historyToken: number; gateRevision: number; gateToken: number;
  sourceSha256: string; bodySha256: string; topologySha256: string;
  historySha256: string; gateSha256: string; currentSha256: string;
}
export interface JointBVHPackOptions extends JointBVHSnapshot {
  kind?: 'cloth' | 'body';
  /** Unsupported native/layer/refined scopes are not silently treated as equal-layer source. */
  scope: 'fresh-source-equal-layer'; refinedBoundary: false;
}
export interface JointBVHDepthGroup { depth: number; first: number; count: number; nodes: Uint32Array }
export interface PackedJointBVH {
  words: Uint32Array; nodeCount: number; particleCount: number; faceCount: number;
  kind: 'cloth' | 'body'; snapshot: Readonly<JointBVHSnapshot>;
  /** Independent copies, never views into mutable caller inputs. */
  triangles: Uint32Array; positions: Float32Array; ordered: Uint32Array; leaves: Uint32Array;
  parentDepthGroups: readonly JointBVHDepthGroup[];
}
export interface JointBVHRefitDispatch {
  entryPoint: 'joint_bvh_begin' | 'joint_bvh_leaves' | 'joint_bvh_parents' | 'joint_bvh_complete';
  first: number; count: number; depth: number; workgroups: number;
}
const integer = (n: number) => Number.isSafeInteger(n) && n >= 0 && n <= U32_MAX;
function snapshot(input: JointBVHSnapshot): Readonly<JointBVHSnapshot> {
  const names = ['sourceToken', 'bodyGeneration', 'snapshotEpoch', 'historyToken', 'gateRevision', 'gateToken'] as const;
  for (const name of names) if (!integer(input[name])) throw Error(`Invalid BVH ${name}`);
  for (const name of HASH_NAMES) if (!/^[a-f0-9]{64}$/.test(input[name])) throw Error(`Missing exact BVH ${name}`);
  return Object.freeze(Object.fromEntries([...names, ...HASH_NAMES].map(name => [name, input[name]])) as unknown as JointBVHSnapshot);
}
function writeSnapshot(words: Uint32Array, s: JointBVHSnapshot) {
  words.set([s.sourceToken, s.bodyGeneration, s.snapshotEpoch, s.historyToken, s.gateRevision, s.gateToken], 14);
  HASH_NAMES.forEach((name, index) => {
    for (let k = 0; k < 8; k++) words[32 + index * 8 + k] = parseInt(s[name].slice(k * 8, k * 8 + 8), 16);
  });
}
function validateMesh(triangles: Uint32Array, positions: Float32Array) {
  if (!(triangles instanceof Uint32Array) || !(positions instanceof Float32Array)
    || triangles.length % 4 || positions.length % 4 || !positions.length) throw Error('Invalid vec4 BVH mesh');
  for (let i = 0; i < positions.length; i++) if (!Number.isFinite(positions[i]) || (i % 4 === 3 && positions[i] < 0)) throw Error('Nonfinite/negative BVH position/mass');
  const particles = positions.length / 4;
  for (let i = 0; i < triangles.length; i += 4) {
    const a = triangles[i], b = triangles[i + 1], c = triangles[i + 2];
    if (a >= particles || b >= particles || c >= particles || a === b || b === c || c === a) throw Error('Invalid finite BVH triangle');
  }
}
/** Packs full preorder tree with ONE actual face per leaf. Internal nodes store NONE; leaf
 * stores its ordered-face offset. Bounds are finite triangle AABBs, not centroid cells. */
export function packJointBVH(triangles: Uint32Array, positions: Float32Array, options: JointBVHPackOptions): PackedJointBVH {
  if (options.scope !== 'fresh-source-equal-layer' || options.refinedBoundary !== false
    || (options.kind !== undefined && options.kind !== 'cloth' && options.kind !== 'body')) throw Error('Unsupported native/layer/refined BVH scope');
  const bound = snapshot(options), kind = options.kind ?? 'cloth';
  validateMesh(triangles, positions);
  const faces = triangles.length / 4, particles = positions.length / 4;
  // Bit 31 is the authored outside-normal flag, not the layer. Retain the full
  // metadata words in the immutable topology; only eligibility masks the flag.
  if (kind === 'cloth') for (let f = 1; f < faces; f++) if ((triangles[f * 4 + 3] & 0x7fffffff) !== (triangles[3] & 0x7fffffff)) throw Error('Unequal source layers require authored-layer producer');
  // Preflight counts BEFORE allocation; u32 offsets and portable signed host byte sizes cannot wrap.
  if (faces > 0x00ffffff || faces * 24 + JOINT_BVH_HEADER_WORDS > 0x1fffffff) throw Error('BVH allocation/offset overflow');
  const boxes: number[][] = [], centers: number[][] = [];
  for (let f = 0; f < faces; f++) {
    const ids = triangles.subarray(f * 4, f * 4 + 3), lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
    for (const id of ids) for (let axis = 0; axis < 3; axis++) {
      lo[axis] = Math.min(lo[axis], positions[id * 4 + axis]); hi[axis] = Math.max(hi[axis], positions[id * 4 + axis]);
    }
    boxes.push([...lo, ...hi]); centers.push(lo.map((v, axis) => (v + hi[axis]) * .5));
  }
  const nodes: { box: number[]; escape: number; leaf: number; depth: number }[] = [];
  const ordered: number[] = [], leaves: number[] = [], byDepth = new Map<number, number[]>();
  const visit = (ids: number[], depth: number): number => {
    const index = nodes.length, box = [Infinity, Infinity, Infinity, -Infinity, -Infinity, -Infinity];
    for (const face of ids) for (let axis = 0; axis < 3; axis++) {
      box[axis] = Math.min(box[axis], boxes[face][axis]); box[axis + 3] = Math.max(box[axis + 3], boxes[face][axis + 3]);
    }
    nodes.push({ box, escape: 0, leaf: JOINT_BVH_NONE, depth });
    if (ids.length === 1) { nodes[index].leaf = ordered.length; ordered.push(ids[0]); leaves.push(index); }
    else {
      let axis = 0;
      for (let k = 1; k < 3; k++) if (box[k + 3] - box[k] > box[axis + 3] - box[axis]) axis = k;
      ids.sort((a, b) => centers[a][axis] - centers[b][axis] || a - b);
      const half = Math.floor(ids.length / 2); visit(ids.slice(0, half), depth + 1); visit(ids.slice(half), depth + 1);
      const group = byDepth.get(depth) ?? []; group.push(index); byDepth.set(depth, group);
    }
    nodes[index].escape = nodes.length; return index;
  };
  if (faces) visit(Array.from({ length: faces }, (_, i) => i), 0);
  const depthGroups: JointBVHDepthGroup[] = [], parentIds: number[] = [];
  for (const depth of Array.from(byDepth.keys()).sort((a, b) => b - a)) {
    const ids = byDepth.get(depth)!; depthGroups.push({ depth, first: parentIds.length, count: ids.length, nodes: Uint32Array.from(ids) }); parentIds.push(...ids);
  }
  const n = nodes.length, no = JOINT_BVH_HEADER_WORDS, oo = no + n * 8, lo = oo + ordered.length,
    go = lo + leaves.length, po = go + depthGroups.length * 3, so = po + parentIds.length, total = so + n;
  if (total > 0x1fffffff) throw Error('BVH allocation/offset overflow');
  const words = new Uint32Array(total), floats = new Float32Array(words.buffer);
  words.set([JOINT_BVH_MAGIC, 1, Number(kind === 'body'), faces, particles, n, n ? 0 : JOINT_BVH_NONE, n,
    no, oo, go, depthGroups.length * 3, total, nodes.reduce((max, node) => Math.max(max, node.depth), 0)]);
  writeSnapshot(words, bound);
  words.set([leaves.length, lo, depthGroups.length, go, po, parentIds.length, so,
    n ? nodes.reduce((max, node) => Math.max(max, node.depth), 0) : 0, 0, 1, 0, 1], 20);
  nodes.forEach((node, i) => {
    floats.set(node.box.slice(0, 3), no + i * 8); floats.set(node.box.slice(3), no + i * 8 + 4);
    words[no + i * 8 + 3] = node.escape; words[no + i * 8 + 7] = node.leaf;
    words[so + i] = bound.snapshotEpoch;
  });
  words.set(ordered, oo); words.set(leaves, lo); words.set(parentIds, po);
  depthGroups.forEach((g, i) => words.set([g.depth, g.first, g.count], go + i * 3));
  return { words, nodeCount: n, particleCount: particles, faceCount: faces, kind, snapshot: bound,
    triangles: triangles.slice(), positions: positions.slice(), ordered: Uint32Array.from(ordered), leaves: Uint32Array.from(leaves), parentDepthGroups: depthGroups };
}
/** Snapshot binding is checked against bytes too, so editing the header cannot bypass tokens. */
export function requireJointBVHBinding(bvh: PackedJointBVH, input: JointBVHSnapshot): void {
  const wanted = snapshot(input), names: (keyof JointBVHSnapshot)[] = bvh.kind === 'body'
    ? ['sourceToken', 'bodyGeneration', 'sourceSha256', 'bodySha256', 'topologySha256']
    : ['sourceToken', 'bodyGeneration', 'snapshotEpoch', 'historyToken', 'gateRevision', 'gateToken', ...HASH_NAMES];
  for (const name of names) if (bvh.snapshot[name] !== wanted[name]) throw Error(`Stale BVH ${name}`);
  const expected = new Uint32Array(JOINT_BVH_HEADER_WORDS); writeSnapshot(expected, bvh.snapshot);
  for (const at of [14, 15, ...(bvh.kind === 'cloth' ? [16, 17, 18, 19] : []),
    ...Array.from({ length: bvh.kind === 'cloth' ? 48 : 24 }, (_, i) => 32 + i)]) {
    if (bvh.words[at] !== expected[at]) throw Error('Modified BVH binding bytes');
  }
  validateJointBVH(bvh);
}
/** Full CPU structural validation; static topology is validated once before GPU upload. Every
 * query also validates escape/bounds locally on GPU and fails instead of hanging/skipping. */
export function validateJointBVH(b: PackedJointBVH): void {
  const w = b.words, n = b.nodeCount;
  if (w.length < JOINT_BVH_HEADER_WORDS || w[0] !== JOINT_BVH_MAGIC || w[1] !== 1
    || w[2] !== Number(b.kind === 'body') || w[3] !== b.faceCount || w[4] !== b.particleCount
    || w[5] !== n || w[6] !== (n ? 0 : JOINT_BVH_NONE) || w[7] !== n || w[8] !== JOINT_BVH_HEADER_WORDS
    || w[9] !== w[8] + n * 8 || w[20] !== b.faceCount || w[21] !== w[9] + b.faceCount
    || w[23] !== w[21] + w[20] || w[10] !== w[23] || w[11] !== w[22] * 3
    || w[24] !== w[23] + w[22] * 3 || w[25] !== n - b.faceCount || w[26] !== w[24] + w[25]
    || w[12] !== w[26] + n || w[12] !== w.length || w[13] !== w[27] || w[31] !== 1 || w[29] !== 1
    || n !== (b.faceCount ? 2 * b.faceCount - 1 : 0)) throw Error('Malformed/incomplete packed BVH');
  const floats = new Float32Array(w.buffer, w.byteOffset, w.length), seenFaces = new Set<number>(), seenLeaves = new Set<number>();
  const parents = new Set<number>(), leafNodes = new Set<number>();
  const depths = new Map<number, number>(); if (n) depths.set(0, 0);
  for (let node = 0; node < n; node++) {
    const o = w[8] + node * 8, escape = w[o + 3], leaf = w[o + 7], depth = depths.get(node);
    if (depth === undefined || escape <= node || escape > n || w[w[26] + node] !== w[16]) throw Error('Malformed BVH escape/stamp');
    for (let axis = 0; axis < 3; axis++) if (!Number.isFinite(floats[o + axis]) || !Number.isFinite(floats[o + axis + 4])
      || floats[o + axis] > floats[o + axis + 4]) throw Error('Nonfinite/inverted BVH bounds');
    if (leaf === JOINT_BVH_NONE) {
      const left = node + 1, right = w[w[8] + left * 8 + 3];
      if (left >= n || right <= left || right >= escape || w[w[8] + right * 8 + 3] !== escape) throw Error('Incomplete BVH children');
      for (const child of [left, right]) for (let axis = 0; axis < 3; axis++) {
        const co = w[8] + child * 8;
        if (floats[o + axis] > floats[co + axis] || floats[o + axis + 4] < floats[co + axis + 4]) throw Error('BVH parent does not enclose children');
      }
      depths.set(left, depth + 1); depths.set(right, depth + 1); parents.add(node);
    } else {
      if (escape !== node + 1 || leaf >= b.faceCount || seenLeaves.has(leaf)) throw Error('Invalid/duplicate BVH leaf');
      const face = w[w[9] + leaf]; if (face >= b.faceCount || seenFaces.has(face)) throw Error('Missing/duplicate actual BVH face');
      for (let axis = 0; axis < 3; axis++) {
        const ids = b.triangles.subarray(face * 4, face * 4 + 3);
        const low = Math.min(...Array.from(ids, id => b.positions[id * 4 + axis]));
        const high = Math.max(...Array.from(ids, id => b.positions[id * 4 + axis]));
        if (floats[o + axis] !== low || floats[o + axis + 4] !== high) throw Error('BVH leaf is not the exact current finite triangle');
      }
      seenLeaves.add(leaf); seenFaces.add(face); leafNodes.add(node);
    }
  }
  if (seenFaces.size !== b.faceCount) throw Error('Incomplete BVH coverage');
  for (let i = 0; i < w[20]; i++) if (!leafNodes.delete(w[w[21] + i])) throw Error('Malformed BVH leaf dispatch');
  if (leafNodes.size) throw Error('Missing BVH leaf dispatch');
  let previousDepth = Infinity, covered = 0;
  for (let g = 0; g < w[22]; g++) {
    const o = w[23] + g * 3, depth = w[o], first = w[o + 1], count = w[o + 2];
    if (depth >= previousDepth || first !== covered || !count || first + count > w[25]) throw Error('Malformed parent depth barriers');
    previousDepth = depth;
    for (let j = first; j < first + count; j++) {
      const node = w[w[24] + j]; if (!parents.delete(node) || depths.get(node) !== depth) throw Error('Wrong parent depth/duplicate dispatch');
    }
    covered += count;
  }
  if (parents.size || covered !== w[25]) throw Error('Incomplete parent depth dispatch');
}
/** Every pass is a SEPARATE compute pass/dispatch with storage visibility between passes.
 * Keeping these as one simultaneous depth dispatch is invalid and fails child epoch checks. */
export function jointBVHRefitDispatches(b: PackedJointBVH): JointBVHRefitDispatch[] {
  validateJointBVH(b);
  if (b.kind !== 'cloth') throw Error('Immutable body tree cannot refit');
  return [{ entryPoint: 'joint_bvh_begin', first: 0, count: 1, depth: 0, workgroups: 1 },
    { entryPoint: 'joint_bvh_leaves', first: 0, count: b.faceCount, depth: b.words[27], workgroups: Math.ceil(b.faceCount / 64) },
    ...b.parentDepthGroups.map(g => ({ entryPoint: 'joint_bvh_parents' as const, first: g.first, count: g.count, depth: g.depth, workgroups: Math.ceil(g.count / 64) })),
    { entryPoint: 'joint_bvh_complete', first: 0, count: 1, depth: 0, workgroups: 1 }];
}
/** CPU mirror of leaf + ordered parent refits; mass/topology identity is unchanged. Previous
 * history/activation and current bytes must be hashed by the trusted adapter before this call. */
export function refitJointBVH(b: PackedJointBVH, positions: Float32Array, next: JointBVHSnapshot): PackedJointBVH {
  requireJointBVHBinding(b, b.snapshot);
  if (b.kind !== 'cloth' || positions.length !== b.particleCount * 4) throw Error('Cannot refit immutable/wrong-particle BVH');
  validateMesh(b.triangles, positions); const bound = snapshot(next);
  for (let id = 0; id < b.particleCount; id++) if (!Object.is(positions[id * 4 + 3], b.positions[id * 4 + 3])) throw Error('Refit cannot change physical inverse mass');
  for (const name of ['sourceToken', 'bodyGeneration', 'sourceSha256', 'bodySha256', 'topologySha256'] as const)
    if (bound[name] !== b.snapshot[name]) throw Error('Body/source/topology change requires rebuild');
  if (bound.snapshotEpoch <= b.snapshot.snapshotEpoch) throw Error('Refit snapshot must advance without u32 wrap');
  const words = b.words.slice(), f = new Float32Array(words.buffer); writeSnapshot(words, bound); words[31] = 0;
  for (const node of b.leaves) {
    const o = words[8] + node * 8, face = words[words[9] + words[o + 7]], ids = b.triangles.subarray(face * 4, face * 4 + 3);
    for (let axis = 0; axis < 3; axis++) {
      f[o + axis] = Math.min(...Array.from(ids, id => positions[id * 4 + axis]));
      f[o + axis + 4] = Math.max(...Array.from(ids, id => positions[id * 4 + axis]));
    }
    words[words[26] + node] = bound.snapshotEpoch;
  }
  for (const group of b.parentDepthGroups) for (const node of group.nodes) {
    const o = words[8] + node * 8, left = node + 1, right = words[words[8] + left * 8 + 3];
    if (words[words[26] + left] !== bound.snapshotEpoch || words[words[26] + right] !== bound.snapshotEpoch) throw Error('Refit depth order is not complete');
    for (let axis = 0; axis < 3; axis++) {
      f[o + axis] = Math.min(f[words[8] + left * 8 + axis], f[words[8] + right * 8 + axis]);
      f[o + axis + 4] = Math.max(f[words[8] + left * 8 + axis + 4], f[words[8] + right * 8 + axis + 4]);
    }
    words[words[26] + node] = bound.snapshotEpoch;
  }
  words[31] = 1;
  const result = { ...b, words, positions: positions.slice(), snapshot: bound }; validateJointBVH(result); return result;
}
export function jointBVHDiscoveryPadding(low: readonly number[], high: readonly number[]): number {
  if (low.length !== 3 || high.length !== 3 || low.some((v, i) => !Number.isFinite(v) || !Number.isFinite(high[i]) || v > high[i])) throw Error('Invalid finite BVH query');
  // BOTH free sides may move 5mm: 1mm protection +5mm+5mm. Extra is arithmetic,
  // not relaxed clearance or proof. Large coordinates intentionally broaden discovery.
  return JOINT_BVH_HORIZON + 32 * 2 ** -24 * Math.max(1, ...low.map(Math.abs), ...high.map(Math.abs));
}
/** Shared GLOBAL finite/discovery radius. Per-face arithmetic padding is insufficient when
 * visitor predicates use root magnitude: that mismatch silently loses a thin candidate shell. */
export function jointBVHGlobalDiscoveryPadding(cloth: PackedJointBVH, body: PackedJointBVH): number {
  let padding = JOINT_BVH_HORIZON;
  for (const b of [cloth, body]) {
    validateJointBVH(b);
    if (!b.nodeCount) continue;
    const f = new Float32Array(b.words.buffer, b.words.byteOffset, b.words.length), o = b.words[8];
    padding = Math.max(padding, jointBVHDiscoveryPadding(Array.from(f.subarray(o, o + 3)), Array.from(f.subarray(o + 4, o + 7))));
  }
  return padding;
}
export function queryJointBVH(b: PackedJointBVH, low: readonly number[], high: readonly number[], binding: JointBVHSnapshot): number[] {
  requireJointBVHBinding(b, binding); jointBVHDiscoveryPadding(low, high);
  return queryUnchecked(b, low, high);
}
function queryUnchecked(b: PackedJointBVH, low: readonly number[], high: readonly number[]): number[] {
  const w = b.words, f = new Float32Array(w.buffer, w.byteOffset, w.length), result: number[] = [];
  let at = w[6];
  while (at !== JOINT_BVH_NONE && at < w[7]) {
    const o = w[8] + at * 8;
    const overlap = low.every((v, k) => f[o + k] <= high[k] && f[o + k + 4] >= v);
    if (!overlap) { at = w[o + 3]; continue; }
    const leaf = w[o + 7]; if (leaf !== JOINT_BVH_NONE) result.push(w[w[9] + leaf]);
    at = leaf === JOINT_BVH_NONE ? at + 1 : w[o + 3];
  }
  return result;
}
/** CPU integration oracle: complete finite AABB discovery, with no output capacity or ranking.
 * The callbacks must use actual finite features. Discovery is intentionally a superset. */
export function discoverJointBVHFaceCandidates(cloth: PackedJointBVH, body: PackedJointBVH, positions: Float32Array,
  binding: JointBVHSnapshot): { self: [number, number][]; body: [number, number][] } {
  requireJointBVHBinding(cloth, binding); requireJointBVHBinding(body, binding);
  validateMesh(cloth.triangles, positions);
  if (positions.length !== cloth.particleCount * 4) throw Error('Wrong discovery current particle count');
  for (let i = 0; i < positions.length; i++) if (!Object.is(positions[i], cloth.positions[i])) throw Error('Discovery positions differ from refitted current snapshot');
  const self: [number, number][] = [], skin: [number, number][] = [];
  const globalPadding = jointBVHGlobalDiscoveryPadding(cloth, body);
  for (let face = 0; face < cloth.faceCount; face++) {
    const ids = cloth.triangles.subarray(face * 4, face * 4 + 3), lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
    for (const id of ids) for (let k = 0; k < 3; k++) { lo[k] = Math.min(lo[k], positions[id * 4 + k]); hi[k] = Math.max(hi[k], positions[id * 4 + k]); }
    const low = lo.map(v => v - globalPadding), high = hi.map(v => v + globalPadding);
    for (const other of queryUnchecked(cloth, low, high)) if (other > face) self.push([face, other]);
    for (const other of queryUnchecked(body, low, high)) skin.push([face, other]);
  }
  return { self, body: skin };
}
/** Explicit counter overflow rejects rather than wraps an apparently complete certificate. */
export function reserveJointBVHRows(currentCount: number, emittedRows: number, capacity: number): { count: number; failed: boolean } {
  if (![currentCount, emittedRows, capacity].every(integer) || currentCount > capacity) throw Error('Invalid raw-row counter/capacity');
  const next = currentCount + emittedRows;
  return { count: Math.min(next, U32_MAX), failed: next > capacity || next > U32_MAX };
}

/** Adapter configuration contract (not declarations): cfg remains at uniform8, gate9. Add
 * snapshotEpoch/historyToken/gateToken, refitFirst/refitCount/refitDepth and ALL six SHA blocks.
 * jointBVHExpectedWord(headerIndex) must return the exact tokens14..19/hashes32..79 bound to
 * this dispatch. Full raw config is264B with reference fields: use512B dynamic slot stride,
 * never a silently truncated256B slot. Source/body/topology checks are static for the body;
 * dynamic cloth additionally binds current/history/gate. The adapter MUST hash actual bytes,
 * freeze inputs before awaits, reject stale/reset/dispose generations and unsupported scope.
 *
 * This snippet uses exactly TWO additional storages: existing finite exporter slots0..5,
 * clothBVH6/bodyBVH7. No candidate scratch list/ninth storage. It invokes existing finite
 * visitor functions and uses tri/clothPoints/bodyPoints/bodyFeature/getClosestPointOnTriangle.
 * Visitor near radius must be the SAME11mm+arithmetic horizon, otherwise discovery is full
 * but protections silently remain6mm. Unknown refined child proof remains failclosed.
 * State needs8 atomic u32; refit counters default3/4 (optionally6/7), existing flags/raw rows/complete are0/1/2.
 */
export function sourceJointBVHRowExportWGSL(options: { leafCounter?: number; parentCounter?: number } = {}): string {
  const leafCounter = options.leafCounter ?? 3, parentCounter = options.parentCounter ?? 4;
  if (![leafCounter, parentCounter].every(slot => Number.isInteger(slot) && slot >= 3 && slot <= 7)
    || leafCounter === parentCounter) throw Error('BVH refit counters need distinct available state slots3..7');
  const code = /* wgsl */ `
@group(0) @binding(6) var<storage, read_write> clothBVH:array<u32>;
@group(0) @binding(7) var<storage, read> bodyBVH:array<u32>;
const JOINT_BVH_MAGIC:u32=0x4a425631u;
const JOINT_BVH_NONE:u32=0xffffffffu;
const JOINT_BVH_HORIZON:f32=0.011;
fn jointBVHFail(){atomicOr(&state[0],16u);}
// Integration append() uses this instead of atomicAdd, so even u32 raw-count exhaustion
// cannot wrap back to a small apparently complete certificate. Capacity overflow remains
// explicit and count retains all representable emitted rows; saturated count is a failure.
fn jointBVHReserveRawRow()->u32{
 while(true){let count=atomicLoad(&state[1]);if(count==JOINT_BVH_NONE){atomicOr(&state[0],1u);return JOINT_BVH_NONE;}
 let claimed=atomicCompareExchangeWeak(&state[1],count,count+1u);if(claimed.exchanged){if(count>=cfg.capacity){atomicOr(&state[0],1u);return JOINT_BVH_NONE;}return count;}}
 return JOINT_BVH_NONE;
}
fn jointBVHWord(body:bool,at:u32)->u32{if(body){return bodyBVH[at];}return clothBVH[at];}
fn jointBVHLength(body:bool)->u32{if(body){return arrayLength(&bodyBVH);}return arrayLength(&clothBVH);}
fn jointBVHHeader(body:bool,dynamic:bool)->bool{
 let length=jointBVHLength(body);if(length<80u){jointBVHFail();return false;}
 let n=jointBVHWord(body,5u);let faces=jointBVHWord(body,3u);let ordered=jointBVHWord(body,9u);
 if(jointBVHWord(body,0u)!=JOINT_BVH_MAGIC||jointBVHWord(body,1u)!=1u||jointBVHWord(body,2u)!=select(0u,1u,body)||jointBVHWord(body,29u)!=1u||faces!=select(cfg.clothFaces,cfg.bodyFaces,body)||jointBVHWord(body,7u)!=n||jointBVHWord(body,8u)!=80u||jointBVHWord(body,12u)!=length||n>(length-80u)/8u||ordered!=80u+n*8u||ordered>length||faces>length-ordered||jointBVHWord(body,20u)!=faces||jointBVHWord(body,21u)!=ordered+faces||jointBVHWord(body,23u)!=ordered+faces*2u||jointBVHWord(body,10u)!=jointBVHWord(body,23u)||jointBVHWord(body,11u)!=jointBVHWord(body,22u)*3u||jointBVHWord(body,24u)!=jointBVHWord(body,23u)+jointBVHWord(body,22u)*3u||jointBVHWord(body,25u)!=n-faces||jointBVHWord(body,26u)!=jointBVHWord(body,24u)+jointBVHWord(body,25u)||jointBVHWord(body,26u)>length||n>length-jointBVHWord(body,26u)||jointBVHWord(body,26u)+n!=length||n!=select(0u,faces*2u-1u,faces>0u)||jointBVHWord(body,6u)!=select(JOINT_BVH_NONE,0u,n>0u)) {jointBVHFail();return false;}
 for(var at=14u;at<16u;at++){if(jointBVHWord(body,at)!=jointBVHExpectedWord(at)){jointBVHFail();return false;}}
 for(var at=32u;at<56u;at++){if(jointBVHWord(body,at)!=jointBVHExpectedWord(at)){jointBVHFail();return false;}}
 if(!body&&jointBVHWord(body,4u)!=cfg.particles){jointBVHFail();return false;}
 if(dynamic&&!body){for(var at=16u;at<20u;at++){if(clothBVH[at]!=jointBVHExpectedWord(at)){jointBVHFail();return false;}}for(var at=56u;at<80u;at++){if(clothBVH[at]!=jointBVHExpectedWord(at)){jointBVHFail();return false;}}}
 return true;
}
fn jointBVHReady(body:bool)->bool{if(!jointBVHHeader(body,true)||jointBVHWord(body,31u)!=1u){jointBVHFail();return false;}return true;}
fn jointBVHLo(body:bool,node:u32)->vec3f{let at=jointBVHWord(body,8u)+node*8u;return bitcast<vec3f>(vec3u(jointBVHWord(body,at),jointBVHWord(body,at+1u),jointBVHWord(body,at+2u)));}
fn jointBVHHi(body:bool,node:u32)->vec3f{let at=jointBVHWord(body,8u)+node*8u+4u;return bitcast<vec3f>(vec3u(jointBVHWord(body,at),jointBVHWord(body,at+1u),jointBVHWord(body,at+2u)));}
fn jointBVHFinite(p:vec3f)->bool{return all(abs(p)<=vec3f(3.402823466e38));}
fn jointBVHNode(body:bool,node:u32)->bool{
 let n=jointBVHWord(body,5u);if(node>=n){jointBVHFail();return false;}let at=jointBVHWord(body,8u)+node*8u;
 let escape=jointBVHWord(body,at+3u);let leaf=jointBVHWord(body,at+7u);let lo=jointBVHLo(body,node);let hi=jointBVHHi(body,node);
 if(escape<=node||escape>n||!jointBVHFinite(lo)||!jointBVHFinite(hi)||any(lo>hi)||jointBVHWord(body,jointBVHWord(body,26u)+node)!=jointBVHWord(body,16u)){jointBVHFail();return false;}
 if(leaf!=JOINT_BVH_NONE&&(escape!=node+1u||leaf>=jointBVHWord(body,3u))){jointBVHFail();return false;}
 return true;
}
fn jointBVHPadding(lo:vec3f,hi:vec3f)->f32{return JOINT_BVH_HORIZON+32.0*0.000000059604644775390625*max(1.0,max(max(max(abs(lo.x),abs(lo.y)),abs(lo.z)),max(max(abs(hi.x),abs(hi.y)),abs(hi.z))));}
// The finite visitors and ALL broadphase/chord queries must call this SAME radius.
// A root-magnitude visitor with a local-magnitude query can miss a narrow real protection shell.
fn jointBVHDiscoveryHorizon()->f32{
 if(!jointBVHReady(false)||!jointBVHReady(true)){return JOINT_BVH_HORIZON;}
 var radius=JOINT_BVH_HORIZON;
 if(clothBVH[5]>0u){radius=max(radius,jointBVHPadding(jointBVHLo(false,0u),jointBVHHi(false,0u)));}
 if(bodyBVH[5]>0u){radius=max(radius,jointBVHPadding(jointBVHLo(true,0u),jointBVHHi(true,0u)));}
 return radius;
}
fn jointBVHOverlap(body:bool,node:u32,lo:vec3f,hi:vec3f)->bool{return all(jointBVHLo(body,node)<=hi)&&all(jointBVHHi(body,node)>=lo);}
fn jointBVHFace(body:bool,node:u32)->u32{let at=jointBVHWord(body,8u)+node*8u;let leaf=jointBVHWord(body,at+7u);if(leaf==JOINT_BVH_NONE){return JOINT_BVH_NONE;}let face=jointBVHWord(body,jointBVHWord(body,9u)+leaf);if(face>=jointBVHWord(body,3u)){jointBVHFail();return JOINT_BVH_NONE;}return face;}
// Complete monotonic stackless traversal. Escape or +1 always advances; malformed metadata
// rejects instead of imposing a max candidate count or an iteration budget that skips witnesses.
fn jointBVHSelfVisit(face:u32,lo:vec3f,hi:vec3f){
 if(!jointBVHReady(false)){return;}var at=clothBVH[6];let end=clothBVH[7];
 while(at!=JOINT_BVH_NONE&&at<end){if(!jointBVHNode(false,at)){return;}let o=clothBVH[8]+at*8u;let escape=clothBVH[o+3u];if(!jointBVHOverlap(false,at,lo,hi)){at=escape;continue;}let other=jointBVHFace(false,at);if(other!=JOINT_BVH_NONE){if(other>face){jointVisitSelfPair(face,other);}at=escape;}else{at++;}}
}
fn jointBVHBodyVisit(face:u32,lo:vec3f,hi:vec3f){
 if(!jointBVHReady(true)){return;}var at=bodyBVH[6];let end=bodyBVH[7];
 while(at!=JOINT_BVH_NONE&&at<end){if(!jointBVHNode(true,at)){return;}let o=bodyBVH[8]+at*8u;let escape=bodyBVH[o+3u];if(!jointBVHOverlap(true,at,lo,hi)){at=escape;continue;}let other=jointBVHFace(true,at);if(other!=JOINT_BVH_NONE){jointVisitBodyPair(face,other);at=escape;}else{at++;}}
}
@compute @workgroup_size(64) fn joint_bvh_self_rows(@builtin(global_invocation_id) gid:vec3u){
 let face=gid.x;if(face>=cfg.clothFaces){return;}if(!jointBVHReady(false)||!jointBVHReady(true)){return;}let a=clothPoints(tri(face),false);let lo=min(a[0],min(a[1],a[2]));let hi=max(a[0],max(a[1],a[2]));if(!jointBVHFinite(lo)||!jointBVHFinite(hi)){jointBVHFail();return;}let padding=vec3f(jointBVHDiscoveryHorizon());jointBVHSelfVisit(face,lo-padding,hi+padding);
}
@compute @workgroup_size(64) fn joint_bvh_body_faces(@builtin(global_invocation_id) gid:vec3u){
 let face=gid.x;if(face>=cfg.clothFaces){return;}if(!jointBVHReady(false)||!jointBVHReady(true)){return;}let a=clothPoints(tri(face),false);let lo=min(a[0],min(a[1],a[2]));let hi=max(a[0],max(a[1],a[2]));if(!jointBVHFinite(lo)||!jointBVHFinite(hi)){jointBVHFail();return;}let padding=vec3f(jointBVHDiscoveryHorizon());jointBVHBodyVisit(face,lo-padding,hi+padding);
}
// Exact nearest finite BODY feature, not nearest candidate rank for raw row enumeration.
// Branch bound adds arithmetic slack to retain near-ties. Unknown normals remain caller failure.
fn jointNearestBody(point:vec3f)->Nearest{
 var result=Nearest(vec3f(0.0),1e30,vec3f(0.0),JOINT_BVH_NONE);
 if(!jointBVHReady(true)||!jointBVHFinite(point)){jointBVHFail();return result;}
 var at=bodyBVH[6];while(at!=JOINT_BVH_NONE&&at<bodyBVH[7]){if(!jointBVHNode(true,at)){return Nearest(vec3f(0.0),1e30,vec3f(0.0),JOINT_BVH_NONE);}let o=bodyBVH[8]+at*8u;let escape=bodyBVH[o+3u];let lo=jointBVHLo(true,at);let hi=jointBVHHi(true,at);let delta=max(max(lo-point,point-hi),vec3f(0.0));let slack=jointBVHPadding(min(point,lo),max(point,hi))-JOINT_BVH_HORIZON;
 if(length(delta)>result.distance+slack){at=escape;continue;}let face=jointBVHFace(true,at);if(face==JOINT_BVH_NONE){at++;continue;}let p=bodyPoints(face);let q=getClosestPointOnTriangle(p[0],p[1],p[2],point);let d=distance(point,q);if(d<result.distance||(d==result.distance&&face<result.face)){result=Nearest(q,d,bodyFeature(face,finiteBarycentric(p,q)),face);}at=escape;}
 return result;
}
@compute @workgroup_size(1) fn joint_bvh_begin(){
 if(!jointBVHHeader(false,false)||clothBVH[31]!=1u||jointBVHExpectedWord(16u)<=clothBVH[16]){jointBVHFail();return;}
 clothBVH[31]=0u;for(var at=16u;at<20u;at++){clothBVH[at]=jointBVHExpectedWord(at);}for(var at=56u;at<80u;at++){clothBVH[at]=jointBVHExpectedWord(at);}atomicStore(&state[3],0u);atomicStore(&state[4],0u);
}
@compute @workgroup_size(64) fn joint_bvh_leaves(@builtin(global_invocation_id) gid:vec3u){
 if(!jointBVHHeader(false,true)||clothBVH[31]!=0u||cfg.refitFirst!=0u||cfg.refitCount!=clothBVH[20]){jointBVHFail();return;}let index=gid.x;if(index>=cfg.refitCount){return;}let node=clothBVH[clothBVH[21]+index];if(node>=clothBVH[5]){jointBVHFail();return;}let o=clothBVH[8]+node*8u;let leaf=clothBVH[o+7u];if(leaf==JOINT_BVH_NONE||leaf>=cfg.clothFaces||clothBVH[o+3u]!=node+1u){jointBVHFail();return;}let face=clothBVH[clothBVH[9]+leaf];if(face>=cfg.clothFaces){jointBVHFail();return;}let ids=tri(face);if(any(ids.xyz>=vec3u(cfg.particles))){jointBVHFail();return;}let a=clothPoints(ids,false);let lo=min(a[0],min(a[1],a[2]));let hi=max(a[0],max(a[1],a[2]));if(!jointBVHFinite(lo)||!jointBVHFinite(hi)){jointBVHFail();return;}
 for(var axis=0u;axis<3u;axis++){clothBVH[o+axis]=bitcast<u32>(lo[axis]);clothBVH[o+4u+axis]=bitcast<u32>(hi[axis]);}clothBVH[clothBVH[26]+node]=clothBVH[16];atomicAdd(&state[3],1u);
}
@compute @workgroup_size(64) fn joint_bvh_parents(@builtin(global_invocation_id) gid:vec3u){
 if(!jointBVHHeader(false,true)||clothBVH[31]!=0u){jointBVHFail();return;}var groupFound=false;for(var group=0u;group<clothBVH[22];group++){let g=clothBVH[23]+group*3u;if(clothBVH[g]==cfg.refitDepth&&clothBVH[g+1u]==cfg.refitFirst&&clothBVH[g+2u]==cfg.refitCount){groupFound=true;break;}}if(!groupFound){jointBVHFail();return;}let index=gid.x;if(index>=cfg.refitCount){return;}if(cfg.refitFirst>=clothBVH[25]||cfg.refitCount>clothBVH[25]-cfg.refitFirst){jointBVHFail();return;}let node=clothBVH[clothBVH[24]+cfg.refitFirst+index];if(node>=clothBVH[5]){jointBVHFail();return;}let o=clothBVH[8]+node*8u;let left=node+1u;if(left>=clothBVH[5]||clothBVH[o+7u]!=JOINT_BVH_NONE){jointBVHFail();return;}let right=clothBVH[clothBVH[8]+left*8u+3u];if(right<=left||right>=clothBVH[o+3u]||right>=clothBVH[5]||clothBVH[clothBVH[8]+right*8u+3u]!=clothBVH[o+3u]||clothBVH[clothBVH[26]+left]!=clothBVH[16]||clothBVH[clothBVH[26]+right]!=clothBVH[16]){jointBVHFail();return;}
 let lo=min(jointBVHLo(false,left),jointBVHLo(false,right));let hi=max(jointBVHHi(false,left),jointBVHHi(false,right));if(!jointBVHFinite(lo)||!jointBVHFinite(hi)){jointBVHFail();return;}for(var axis=0u;axis<3u;axis++){clothBVH[o+axis]=bitcast<u32>(lo[axis]);clothBVH[o+4u+axis]=bitcast<u32>(hi[axis]);}clothBVH[clothBVH[26]+node]=clothBVH[16];atomicAdd(&state[4],1u);
}
@compute @workgroup_size(1) fn joint_bvh_complete(){
 if(!jointBVHHeader(false,true)||clothBVH[31]!=0u||atomicLoad(&state[0])!=0u||atomicLoad(&state[3])!=clothBVH[20]||atomicLoad(&state[4])!=clothBVH[25]||(clothBVH[5]>0u&&clothBVH[clothBVH[26]]!=clothBVH[16])){jointBVHFail();return;}clothBVH[31]=1u;
}
`;
  return code.replace(/state\[(3|4)\]/g, (_, slot) => `state[${slot === '3' ? leafCounter : parentCounter}]`);
}
/** Inline body candidate traversal for local chord-time arrays. A callback function cannot
 * mutate a caller's local array in WGSL; integration injects the ORIGINAL finite hit collector
 * as visitCode, with actual bodyFace:u32. No nearest-only/first-two-hit shortcut. Capacity
 * overflow in that collector MUST set state failure. Local names are scoped to this block. */
export function jointBVHBodyInlineTraversalWGSL(lowExpression: string, highExpression: string, visitCode: string): string {
  if (!lowExpression.trim() || !highExpression.trim() || !visitCode.trim()) throw Error('Missing actual finite body traversal hook');
  return /* wgsl */ `{
 if(jointBVHReady(true)){let jointLow=(${lowExpression});let jointHigh=(${highExpression});
 if(!jointBVHFinite(jointLow)||!jointBVHFinite(jointHigh)||any(jointLow>jointHigh)){jointBVHFail();}else{
 var jointNode=bodyBVH[6];while(jointNode!=JOINT_BVH_NONE&&jointNode<bodyBVH[7]){
 if(!jointBVHNode(true,jointNode)){break;}let jointOffset=bodyBVH[8]+jointNode*8u;let jointEscape=bodyBVH[jointOffset+3u];
 if(!jointBVHOverlap(true,jointNode,jointLow,jointHigh)){jointNode=jointEscape;continue;}
 let bodyFace=jointBVHFace(true,jointNode);if(bodyFace!=JOINT_BVH_NONE){${visitCode}\n jointNode=jointEscape;}else{jointNode++;}
 }}}
}`;
}

export function jointBVHExpectedUniformWords(binding: JointBVHSnapshot): Uint32Array {
  const words = new Uint32Array(JOINT_BVH_HEADER_WORDS); writeSnapshot(words, snapshot(binding)); return words;
}
export interface JointBVHDiscoveryInputs {
  triangles: Uint32Array; current: Float32Array; previous: Float32Array; gateWords: Uint32Array;
  sourceToken: number; bodyGeneration: number; snapshotEpoch: number; historyToken: number;
  gateRevision: number; gateToken: number; sourceSha256: string; bodySha256: string; topologySha256: string;
  scope: 'fresh-source-equal-layer'; refinedBoundary: false;
}
/** Capture ALL arrays/tokens synchronously before first digest await. Generation validation and
 * source/body/topology SHA verification against actual immutable geometry remain adapter duties.
 * The returned current/history/gate SHA are computed from the captured actual storage bytes,
 * not claimed by the caller. No external array is detached or borrowed across an await. */
export async function snapshotJointBVHDiscoveryInputs(input: JointBVHDiscoveryInputs): Promise<{
  triangles: Uint32Array; current: Float32Array; previous: Float32Array; gateWords: Uint32Array;
  binding: JointBVHPackOptions;
}> {
  const triangles = input.triangles.slice(), current = input.current.slice(), previous = input.previous.slice(), gateWords = input.gateWords.slice();
  const base = { sourceToken: input.sourceToken, bodyGeneration: input.bodyGeneration, snapshotEpoch: input.snapshotEpoch,
    historyToken: input.historyToken, gateRevision: input.gateRevision, gateToken: input.gateToken,
    sourceSha256: input.sourceSha256, bodySha256: input.bodySha256, topologySha256: input.topologySha256,
    scope: input.scope, refinedBoundary: input.refinedBoundary };
  if (base.scope !== 'fresh-source-equal-layer' || base.refinedBoundary !== false || !gateWords.length || previous.length !== current.length) throw Error('Unsupported/missing exact discovery inputs');
  validateMesh(triangles, current); validateMesh(triangles, previous);
  for (let at = 3; at < current.length; at += 4) if (!Object.is(current[at], previous[at])) throw Error('Discovery history changed physical mass');
  const encode = (array: Float32Array | Uint32Array) => {
    const source = new Uint32Array(array.buffer, array.byteOffset, array.length), bytes = new Uint8Array(source.length * 4), view = new DataView(bytes.buffer);
    for (let i = 0; i < source.length; i++) view.setUint32(i * 4, source[i], true); return bytes;
  };
  const raw = [current, previous, gateWords].map(encode);
  const digest = async (bytes: Uint8Array) => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', new Uint8Array(bytes).buffer)), b => b.toString(16).padStart(2, '0')).join('');
  // Start all independent digests after the complete immutable snapshot has been captured.
  const [currentSha256, historySha256, gateSha256] = await Promise.all(raw.map(digest));
  const binding: JointBVHPackOptions = { ...base, currentSha256, historySha256, gateSha256 };
  snapshot(binding); return { triangles, current, previous, gateWords, binding };
}
