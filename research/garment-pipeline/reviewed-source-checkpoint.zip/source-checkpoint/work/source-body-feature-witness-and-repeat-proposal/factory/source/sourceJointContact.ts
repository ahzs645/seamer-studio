/** ISOLATED SCRATCH: source-only finite joint contact operator. Never imported by shipping code. */
export const JOINT_ROW_BYTES = 128;
export const JOINT_PATCH_WORDS = 120; // header8, particles48, rows64
export const JOINT_LIMIT = 48; // particle limit
export const JOINT_ROW_LIMIT = 64;
export const JOINT_STATUS = { overflow:1, invalidRow:2, history:4, incomplete:8, sourceMismatch:16, massMismatch:32, unconverged:64 } as const;
export const JOINT_KIND = { selfCrossing:1, selfNear:2, bodyPoint:3, bodyChord:4, unsupportedBodyEdge:5, bodyNear:6 } as const;
export const JOINT_PROOF = { source:1, finite:2, confident:4, actualGate:8, canonical:16, complete:32, currentSeparation:64 } as const;
const REQUIRED = 63;
export interface JointEpoch { bodyGeneration:number; sourceToken:number; gateRevision:number; correctedSubstep:number; }
export interface JointContactRow {
 kind:1|2|3|4|5|6; sourceIds:number[]; sourceBary:number[]; targetIds?:number[]; targetBary?:number[];
 normal:[number,number,number]; clearance:number; bodyPoint?:[number,number,number];
 sourceFace:number; targetFace:number; featureToken:number;
 selectedOldGap?:number; currentFiniteGap?:number; currentlyNonintersecting?:true; uncertainty:number; proofFlags:number; epoch:JointEpoch;
}
export interface JointRowBatch { rows:JointContactRow[]; epoch:JointEpoch; complete:true; scope:'fresh-source'; particleCount:number; }
function u32(n:number):boolean{return Number.isSafeInteger(n)&&n>=0&&n<=0xffffffff;}
function validateEpoch(epoch:JointEpoch):void{if(!epoch||!Object.values(epoch).every(u32))throw Error('Invalid joint generation/activation epoch');}
function sameEpoch(a:JointEpoch,b:JointEpoch):boolean{return a.bodyGeneration===b.bodyGeneration&&a.sourceToken===b.sourceToken&&a.gateRevision===b.gateRevision&&a.correctedSubstep===b.correctedSubstep;}
export function validateJointBatch(batch:JointRowBatch):void {
 validateEpoch(batch.epoch);if(batch.scope!=='fresh-source'||batch.complete!==true||!Number.isSafeInteger(batch.particleCount)||batch.particleCount<1)throw Error('Joint finite enumeration incomplete or native scope');
 const identities=new Set<string>();
 for(const r of batch.rows){if(!sameEpoch(r.epoch,batch.epoch))throw Error('Joint row stale source/body/gate');if(![1,2,3,4,6].includes(r.kind))throw Error('Unsupported body-edge geometry must fail closed');
  const protection=r.kind===2||r.kind===6;const margin=protection?r.currentFiniteGap:r.selectedOldGap;if(protection&&r.currentlyNonintersecting!==true)throw Error('Protection lacks current finite nonintersection proof');
  if(r.proofFlags!==(REQUIRED|(protection?64:0))||!u32(r.sourceFace)||!u32(r.targetFace)||!u32(r.featureToken))throw Error('Missing actual finite source/gate proof');
  const body=r.kind>=3;if(r.sourceIds.length<1||r.sourceIds.length>3||r.sourceBary.length!==r.sourceIds.length||(!body&&((r.targetIds?.length??0)<1||(r.targetIds?.length??0)>3||r.targetIds?.length!==r.targetBary?.length))||(body&&(r.targetIds?.length??0)!==0))throw Error('Invalid joint finite feature arity');
  const ids=[...r.sourceIds,...r.targetIds??[]];if(ids.some(i=>!u32(i)||i>=batch.particleCount)||new Set(ids).size!==ids.length)throw Error('Invalid or overlapping canonical finite particles');
  for(const weights of[r.sourceBary,...body?[]:[r.targetBary!]])if(weights.some(w=>!Number.isFinite(w)||w<0)||Math.abs(weights.reduce((a,b)=>a+b,0)-1)>2e-6)throw Error('Invalid finite barycentric weights');
  if(r.normal.some(v=>!Number.isFinite(v))||Math.abs(Math.hypot(...r.normal)-1)>2e-5||Math.fround(r.clearance)!==Math.fround(.001)||!Number.isFinite(margin)||!Number.isFinite(r.uncertainty)||r.uncertainty<0||margin!<=r.uncertainty)throw Error('Uncertain finite history or changed physical clearance');
  if(body&&(!r.bodyPoint||r.bodyPoint.some(v=>!Number.isFinite(v))))throw Error('Missing actual finite body point');
  if(!body&&r.sourceFace>=r.targetFace)throw Error('Noncanonical or reciprocal duplicate self row');
  const id=[r.kind,r.sourceFace,r.targetFace,r.featureToken].join(':');if(identities.has(id))throw Error('Duplicate finite witness');identities.add(id);
 }
}
/** Primitive/evidence writer only; production dynamic rows MUST be emitted by GPU exporters. */
export function packJointRows(batch:JointRowBatch):Uint32Array {
 validateJointBatch(batch);const words=new Uint32Array(batch.rows.length*32),floats=new Float32Array(words.buffer);
 for(let i=0;i<batch.rows.length;i++){const r=batch.rows[i],o=i*32,body=r.kind>=3;
  for(let k=0;k<3;k++){words[o+k]=r.sourceIds[k]??0xffffffff;words[o+4+k]=r.targetIds?.[k]??0xffffffff;floats[o+8+k]=r.sourceBary[k]??0;floats[o+12+k]=r.targetBary?.[k]??0;floats[o+16+k]=r.normal[k];floats[o+20+k]=r.bodyPoint?.[k]??0;}
  words[o+3]=r.kind;words[o+7]=r.proofFlags;floats[o+11]=(r.kind===2||r.kind===6)?r.currentFiniteGap!:r.selectedOldGap!;floats[o+15]=r.uncertainty;floats[o+19]=r.clearance;floats[o+23]=body?1:0;
  words.set([r.sourceFace,r.targetFace,r.epoch.gateRevision,r.featureToken,r.epoch.bodyGeneration,r.epoch.correctedSubstep,r.epoch.sourceToken,r.proofFlags],o+24);
 }
 return words;
}
export function unpackJointRows(words:Uint32Array):JointContactRow[]{if(words.length%32)throw Error('Truncated joint rows');const f=new Float32Array(words.buffer,words.byteOffset,words.length),rows:JointContactRow[]=[];for(let o=0;o<words.length;o+=32){const ids=(at:number)=>Array.from(words.slice(o+at,o+at+3)).filter(i=>i!==0xffffffff),weights=(at:number,count:number)=>Array.from(f.slice(o+at,o+at+count)),a=ids(0),b=ids(4);rows.push({kind:words[o+3] as JointContactRow['kind'],sourceIds:a,sourceBary:weights(8,a.length),targetIds:b,targetBary:weights(12,b.length),normal:Array.from(f.slice(o+16,o+19)) as [number,number,number],clearance:f[o+19],bodyPoint:Array.from(f.slice(o+20,o+23)) as [number,number,number],sourceFace:words[o+24],targetFace:words[o+25],featureToken:words[o+27],...([2,6].includes(words[o+3])?{currentFiniteGap:f[o+11],currentlyNonintersecting:true as const}:{selectedOldGap:f[o+11]}),uncertainty:f[o+15],proofFlags:words[o+7],epoch:{gateRevision:words[o+26],bodyGeneration:words[o+28],correctedSubstep:words[o+29],sourceToken:words[o+30]}});}return rows;}
export function connectedJointPatches(rows:JointContactRow[],particleCount:number){const parent=Array.from({length:particleCount},(_,i)=>i),find=(id:number):number=>{let root=id;while(parent[root]!==root)root=parent[root];while(parent[id]!==id){const next=parent[id];parent[id]=root;id=next;}return root;};for(const r of rows){const ids=[...r.sourceIds,...r.targetIds??[]];for(const id of ids.slice(1)){const a=find(ids[0]),b=find(id);parent[Math.max(a,b)]=Math.min(a,b);}}const map=new Map<number,{root:number;particles:number[];rows:number[];status:number}>();rows.forEach((r,index)=>{const root=find(r.sourceIds[0]);if(!map.has(root))map.set(root,{root,particles:[],rows:[],status:0});const patch=map.get(root)!;patch.rows.push(index);for(const id of [...r.sourceIds,...r.targetIds??[]])if(!patch.particles.includes(id))patch.particles.push(id);});for(const patch of map.values())if(patch.rows.length>JOINT_ROW_LIMIT||patch.particles.length>JOINT_LIMIT)patch.status|=JOINT_STATUS.overflow;return [...map.values()];}
export function jointDispatchPlan(scope:'fresh-source'|'native',particleCount:number,rowCount:number){if(scope==='native')return[];if(!Number.isSafeInteger(particleCount)||particleCount<1||!Number.isSafeInteger(rowCount)||rowCount<0)throw Error('Invalid joint dispatch dimensions');return[{entry:'initialize',groups:Math.ceil(particleCount/64)},{entry:'union_rows',groups:Math.ceil(rowCount/64)},{entry:'collect',groups:Math.ceil(particleCount/64)},{entry:'solve',groups:particleCount},{entry:'apply',groups:Math.ceil(particleCount/64)}];}
/** Actual GPU operator. Dynamic finite geometry exporters run BEFORE these stages and must
 * set coverage/state honestly. This kernel never manufactures a row from an aggregate vector. */
export const sourceJointContactWGSL = /* wgsl */ `
struct Row { a:vec4u,b:vec4u,wa:vec4f,wb:vec4f,n:vec4f,q:vec4f,feature:vec4u,proof:vec4u };
struct Params { particles:u32,capacity:u32,bodyGeneration:u32,sourceToken:u32,gateRevision:u32,substep:u32,pgsSweeps:u32,coverage:u32,maximum:f32,clearance:f32,reserved0:u32,reserved1:u32 };
@group(0) @binding(0) var<storage,read> seed:array<vec4f>;
@group(0) @binding(1) var<storage,read> previous:array<vec4f>;
@group(0) @binding(2) var<storage,read_write> current:array<vec4f>;
@group(0) @binding(3) var<storage,read> rows:array<Row>;
@group(0) @binding(4) var<storage,read_write> labels:array<atomic<u32>>;
@group(0) @binding(5) var<storage,read_write> patches:array<u32>;
@group(0) @binding(6) var<storage,read_write> state:array<atomic<u32>>;
@group(0) @binding(7) var<storage,read_write> corrections:array<vec4f>;
@group(0) @binding(8) var<uniform> cfg:Params;
const PATCH=120u;const LIMIT=48u;const ROWS=64u;const NONE=0xffffffffu;
fn finite(x:f32)->bool{return x==x && abs(x)<1e30;}
fn validRow(r:Row)->bool {
 let isProtection=r.a.w==2u||r.a.w==6u;let required=select(63u,127u,isProtection);
 if(r.a.w<1u||r.a.w>6u||r.a.w==5u||r.b.w!=required||r.proof.w!=required||r.feature.z!=cfg.gateRevision||r.proof.x!=cfg.bodyGeneration||r.proof.y!=cfg.substep||r.proof.z!=cfg.sourceToken){return false;}
 if(!finite(r.wa.w)||!finite(r.wb.w)||r.wb.w<0.0||r.wa.w<=r.wb.w||r.n.w!=cfg.clearance||abs(dot(r.n.xyz,r.n.xyz)-1.0)>4e-5){return false;}
 var sumA=0.0;var sumB=0.0;for(var k=0u;k<3u;k++){
  if(!finite(r.wa[k])||!finite(r.wb[k])||r.wa[k]<0.0||r.wb[k]<0.0){return false;}
  if(r.a[k]!=NONE){if(r.a[k]>=cfg.particles){return false;}sumA+=r.wa[k];}else if(r.wa[k]!=0.0){return false;}
  if(r.b[k]!=NONE){if(r.b[k]>=cfg.particles||r.a.w>=3u){return false;}sumB+=r.wb[k];}else if(r.wb[k]!=0.0){return false;}
  if(!finite(r.n[k])||!finite(r.q[k])){return false;}
 }
 if(abs(sumA-1.0)>2e-6|| (r.a.w<3u && (abs(sumB-1.0)>2e-6||r.feature.x>=r.feature.y))){return false;}
 for(var i=0u;i<3u;i++){for(var j=i+1u;j<3u;j++){if((r.a[i]!=NONE&&r.a[i]==r.a[j])||(r.b[i]!=NONE&&r.b[i]==r.b[j])){return false;}}for(var j=0u;j<3u;j++){if(r.a[i]!=NONE&&r.a[i]==r.b[j]){return false;}}}
 return r.a.x!=NONE && r.q.w==select(0.0,1.0,r.a.w>=3u);
}
fn rootOf(first:u32)->u32{var id=first;for(var step=0u;step<=cfg.particles;step++){let next=atomicLoad(&labels[id]);if(next==id){return id;}if(next>=cfg.particles){atomicOr(&state[0],8u);return NONE;}id=next;}atomicOr(&state[0],8u);return NONE;}
fn unite(a:u32,b:u32){for(var attempt=0u;attempt<=cfg.particles;attempt++){let ra=rootOf(a);let rb=rootOf(b);if(ra==NONE||rb==NONE){return;}if(ra==rb){return;}let high=max(ra,rb);let low=min(ra,rb);let result=atomicCompareExchangeWeak(&labels[high],high,low);if(result.exchanged){return;}}atomicOr(&state[0],8u);}
@compute @workgroup_size(64) fn initialize(@builtin(global_invocation_id) gid:vec3u){let id=gid.x;if(id>=cfg.particles){return;}atomicStore(&labels[id],id);corrections[id]=vec4f(0.0);for(var k=0u;k<8u;k++){patches[id*PATCH+k]=0u;}
 if(bitcast<u32>(current[id].w)!=bitcast<u32>(seed[id].w)||bitcast<u32>(current[id].w)!=bitcast<u32>(previous[id].w)||current[id].w<0.0){atomicOr(&state[0],32u);}for(var k=0u;k<4u;k++){if(!finite(current[id][k])||!finite(previous[id][k])||!finite(seed[id][k])){atomicOr(&state[0],2u);}}
 if(id==0u){if(atomicLoad(&state[1])>cfg.capacity){atomicOr(&state[0],1u);}if(atomicLoad(&state[2])!=cfg.coverage||cfg.coverage!=7u){atomicOr(&state[0],8u);}if(cfg.maximum!=0.005||cfg.clearance!=0.001){atomicOr(&state[0],16u);}}
}
@compute @workgroup_size(64) fn union_rows(@builtin(global_invocation_id) gid:vec3u){let i=gid.x;let count=min(atomicLoad(&state[1]),cfg.capacity);if(i>=count){return;}let r=rows[i];if(!validRow(r)){atomicOr(&state[0],2u);return;}for(var k=0u;k<3u;k++){if(r.a[k]!=NONE){unite(r.a.x,r.a[k]);}if(r.b[k]!=NONE){unite(r.a.x,r.b[k]);}}}
fn rowLess(a:Row,b:Row)->bool{if(a.a.w!=b.a.w){return a.a.w<b.a.w;}if(a.feature.x!=b.feature.x){return a.feature.x<b.feature.x;}if(a.feature.y!=b.feature.y){return a.feature.y<b.feature.y;}return a.feature.w<b.feature.w;}
@compute @workgroup_size(64) fn collect(@builtin(global_invocation_id) gid:vec3u){let owner=gid.x;if(owner>=cfg.particles||atomicLoad(&state[0])!=0u){return;}let root=rootOf(owner);if(root==NONE||root!=owner){return;}let base=owner*PATCH;var particleCount=0u;var rowCount=0u;
 for(var i=0u;i<cfg.particles;i++){if(rootOf(i)==owner){if(particleCount<LIMIT){patches[base+8u+particleCount]=i;}particleCount++;}}
 for(var i=0u;i<min(atomicLoad(&state[1]),cfg.capacity);i++){let r=rows[i];if(rootOf(r.a.x)==owner){if(rowCount<ROWS){patches[base+56u+rowCount]=i;}rowCount++;for(var k=0u;k<3u;k++){if(r.a[k]!=NONE&&rootOf(r.a[k])!=owner){atomicOr(&state[0],8u);}if(r.b[k]!=NONE&&rootOf(r.b[k])!=owner){atomicOr(&state[0],8u);}}}}
 // An isolated unused particle is not a contact patch.
 if(rowCount==0u){return;}patches[base+1u]=particleCount;patches[base+2u]=rowCount;if(particleCount>LIMIT||rowCount>ROWS){patches[base]=1u;atomicOr(&state[0],1u);return;}
 // Atomic producer append order is not solver order. Deterministically sort actual witness keys.
 for(var i=1u;i<rowCount;i++){let selected=patches[base+56u+i];var j=i;while(j>0u&&rowLess(rows[selected],rows[patches[base+56u+j-1u]])){patches[base+56u+j]=patches[base+56u+j-1u];j--;}patches[base+56u+j]=selected;}
 for(var i=1u;i<rowCount;i++){let a=rows[patches[base+56u+i-1u]];let b=rows[patches[base+56u+i]];if(!rowLess(a,b)&&!rowLess(b,a)){atomicOr(&state[0],2u);}}

}
fn coefficient(r:Row,id:u32)->vec3f{var weight=0.0;for(var k=0u;k<3u;k++){if(r.a[k]==id){weight+=r.wa[k];}if(r.b[k]==id){weight-=r.wb[k];}}return r.n.xyz*weight;}
fn materialPoint(r:Row,side:u32)->vec3f{if(side==1u&&r.a.w>=3u){return r.q.xyz;}var result=vec3f(0.0);for(var k=0u;k<3u;k++){let id=select(r.a[k],r.b[k],side==1u);if(id!=NONE){result+=current[id].xyz*select(r.wa[k],r.wb[k],side==1u);}}return result;}
@compute @workgroup_size(1) fn solve(@builtin(workgroup_id) gid:vec3u){let owner=gid.x;if(owner>=cfg.particles||atomicLoad(&state[0])!=0u){return;}let base=owner*PATCH;let np=patches[base+1u];let nr=patches[base+2u];if(np==0u||nr==0u||patches[base]!=0u){return;}
 var gram:array<f32,4096>;var lambda:array<f32,64>;var need:array<f32,64>;var candidate:array<vec3f,48>;
 for(var i=0u;i<nr;i++){let ri=rows[patches[base+56u+i]];lambda[i]=0.0;need[i]=ri.n.w+64.0*0.000000059604644775390625*max(1.0,max(max(abs(materialPoint(ri,0u).x),max(abs(materialPoint(ri,0u).y),abs(materialPoint(ri,0u).z))),max(abs(materialPoint(ri,1u).x),max(abs(materialPoint(ri,1u).y),abs(materialPoint(ri,1u).z)))))-dot(materialPoint(ri,0u)-materialPoint(ri,1u),ri.n.xyz);for(var j=0u;j<nr;j++){let rj=rows[patches[base+56u+j]];var value=0.0;for(var k=0u;k<np;k++){let id=patches[base+8u+k];value+=current[id].w*dot(coefficient(ri,id),coefficient(rj,id));}gram[i*64u+j]=value;}}
 for(var sweep=0u;sweep<cfg.pgsSweeps;sweep++){for(var i=0u;i<nr;i++){let diagonal=gram[i*64u+i];if(diagonal<=0.0){continue;}var value=0.0;for(var j=0u;j<nr;j++){value+=gram[i*64u+j]*lambda[j];}lambda[i]=max(0.0,lambda[i]+(need[i]-value)/diagonal);}}
 var largest=0.0;var coordinate=1.0;for(var k=0u;k<np;k++){let id=patches[base+8u+k];var delta=vec3f(0.0);for(var i=0u;i<nr;i++){delta+=current[id].w*coefficient(rows[patches[base+56u+i]],id)*lambda[i];}candidate[k]=current[id].xyz+delta;largest=max(largest,length(candidate[k]-seed[id].xyz));coordinate=max(coordinate,max(abs(candidate[k].x),max(abs(candidate[k].y),abs(candidate[k].z))));}
 let reserve=4.0*0.000000059604644775390625*(coordinate+cfg.maximum);let scale=min(1.0,max(0.0,cfg.maximum-reserve)/max(largest,1e-30));patches[base+3u]=bitcast<u32>(scale);
 for(var k=0u;k<np;k++){let id=patches[base+8u+k];let output=seed[id].xyz+(candidate[k]-seed[id].xyz)*scale;corrections[id]=vec4f(output-current[id].xyz,1.0);}
 // Report algebraic failure honestly. A cap-limited response requires refreshed finite geometry;
 // linear complementarity alone is never garment/trajectory acceptance.
 for(var i=0u;i<nr;i++){var value=0.0;var magnitude=abs(need[i]);for(var j=0u;j<nr;j++){let term=gram[i*64u+j]*lambda[j];value+=term;magnitude+=abs(term);}let bound=64.0*0.000000059604644775390625*max(magnitude,1e-6);if(value-need[i]< -bound){patches[base+4u]=64u;atomicOr(&state[3],64u);}}
}
@compute @workgroup_size(64) fn apply(@builtin(global_invocation_id) gid:vec3u){let id=gid.x;if(id>=cfg.particles||atomicLoad(&state[0])!=0u){return;}let delta=corrections[id];if(delta.w>0.0){current[id]=vec4f(current[id].xyz+delta.xyz,current[id].w);}}
@compute @workgroup_size(64) fn certify(@builtin(global_invocation_id) gid:vec3u){let i=gid.x;if(i<cfg.particles&&patches[i*PATCH+4u]!=0u){atomicOr(&state[0],64u);}if(i==0u){if(atomicLoad(&state[1])>cfg.capacity){atomicOr(&state[0],1u);}if(atomicLoad(&state[2])!=7u){atomicOr(&state[0],8u);}}if(i>=min(atomicLoad(&state[1]),cfg.capacity)){return;}let r=rows[i];if(!validRow(r)){atomicOr(&state[0],2u);return;}let a=materialPoint(r,0u);let b=materialPoint(r,1u);let gap=dot(a-b,r.n.xyz);let coordinate=max(1.0,max(max(abs(a.x),max(abs(a.y),abs(a.z))),max(abs(b.x),max(abs(b.y),abs(b.z)))));let arithmetic=32.0*0.000000059604644775390625*coordinate;if(gap-arithmetic<r.n.w){atomicOr(&state[0],64u);}}
`;
/** The exporter MUST dispatch actual GPU finite self/body enumeration at the current virtual
 * positions and source gate. No CPU positions/rows callback, aggregate-vector fallback, or
 * previous-epoch reuse is accepted by this lifecycle. Coverage7 means self + finite body point
 * + ALL finite body face geometry; unsupported body-edge witnesses set state[0]|=8. */
export interface JointGpuExportContext {
 encoder:GPUCommandEncoder; current:GPUBuffer; previous:GPUBuffer; parentSeed:GPUBuffer;
 parentStart:boolean; finalEnumeration:boolean;
 rows:GPUBuffer; state:GPUBuffer; stateOffset:number; capacity:number; epoch:JointEpoch;
}
export interface JointGpuRowExporter {
 readonly sourceOnly:true;
 readonly emitsAllFiniteBodyGeometry:true;
 encode(context:JointGpuExportContext):void;
}
export interface JointGpuBuffers { positions:GPUBuffer; previous:GPUBuffer; particleCount:number; }
/** Lifecycle adapter in the COPIED engine only. Normal engine body/sewing/friction/history remain
 * owned by their existing passes; scope native performs NO allocation, writes, or dispatch. */
export class SourceJointContactPass {
 readonly enabled:boolean;
 private destroyed=false;
 private generation=0;
 private epoch:JointEpoch|null=null;
 private readonly owned:GPUBuffer[]=[];
 private readonly pipelines=new Map<string,GPUComputePipeline>();
 private readonly pending:{slot:number;generation:number;epoch:JointEpoch}[]=[];
 private readonly maxInvocations=160;
 private commitPipeline?:GPUComputePipeline;
 private commitGroup?:GPUBindGroup;
 private bindGroup?:GPUBindGroup;
 private uniform?:GPUBuffer;
 private virtual?:GPUBuffer;
 private seed?:GPUBuffer;
 private rows?:GPUBuffer;
 private state?:GPUBuffer;
 private readback?:GPUBuffer;
 readonly capacity:number;
 constructor(private device:GPUDevice,private buffers:JointGpuBuffers,scope:'fresh-source'|'native',private exporter?:JointGpuRowExporter){
  this.enabled=scope==='fresh-source';this.capacity=Math.max(64,Math.min(131072,buffers.particleCount*8));if(!this.enabled)return;
  if(!exporter?.sourceOnly||!exporter.emitsAllFiniteBodyGeometry)throw Error('Joint projection requires a complete source-only GPU finite exporter');
  if(device.limits.maxStorageBuffersPerShaderStage<8)throw Error('Joint projection needs eight storage slots');
  if(!Number.isSafeInteger(buffers.particleCount)||buffers.particleCount<1)throw Error('Invalid joint particle count');
  const make=(label:string,size:number,usage:number)=>{if(size>device.limits.maxStorageBufferBindingSize)throw Error('Joint storage limit overflow');const b=device.createBuffer({label:'source-joint:'+label,size:Math.max(4,size),usage});this.owned.push(b);return b;};
  const storage=GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST;
  this.seed=make('parent-origin',buffers.particleCount*16,storage);this.virtual=make('virtual',buffers.particleCount*16,storage);this.rows=make('finite-rows',this.capacity*JOINT_ROW_BYTES,storage);
  const labels=make('graph-labels',buffers.particleCount*4,storage),patches=make('patches',buffers.particleCount*JOINT_PATCH_WORDS*4,storage),corrections=make('corrections',buffers.particleCount*16,storage);
  this.state=make('proof-state',256*this.maxInvocations,storage);this.uniform=make('params',256*this.maxInvocations,GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST);
  this.readback=make('proof-readback',32*this.maxInvocations,GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST);
  const layout=device.createBindGroupLayout({entries:[...Array.from({length:8},(_,binding)=>({binding,visibility:GPUShaderStage.COMPUTE,buffer:{type:[0,1,3].includes(binding)?'read-only-storage' as const:'storage' as const,hasDynamicOffset:binding===6}})),{binding:8,visibility:GPUShaderStage.COMPUTE,buffer:{type:'uniform',hasDynamicOffset:true}}]});
  const pipelineLayout=device.createPipelineLayout({bindGroupLayouts:[layout]}),module=device.createShaderModule({label:'source-joint:bounded-mass-Gram',code:sourceJointContactWGSL});
  for(const entryPoint of['initialize','union_rows','collect','solve','apply','certify'])this.pipelines.set(entryPoint,device.createComputePipeline({layout:pipelineLayout,compute:{module,entryPoint}}));
  this.bindGroup=device.createBindGroup({layout,entries:[this.seed,buffers.previous,this.virtual,this.rows,labels,patches,this.state,corrections,this.uniform].map((buffer,binding)=>({binding,resource:{buffer,...(binding===6?{size:32}:binding===8?{size:48}:{})}}))});
  const commitLayout=device.createBindGroupLayout({entries:[{binding:0,visibility:GPUShaderStage.COMPUTE,buffer:{type:'read-only-storage'}},{binding:1,visibility:GPUShaderStage.COMPUTE,buffer:{type:'storage'}},{binding:2,visibility:GPUShaderStage.COMPUTE,buffer:{type:'read-only-storage',hasDynamicOffset:true}}]});
  this.commitPipeline=device.createComputePipeline({layout:device.createPipelineLayout({bindGroupLayouts:[commitLayout]}),compute:{module:device.createShaderModule({code:sourceJointCommitWGSL}),entryPoint:'main'}});
  this.commitGroup=device.createBindGroup({layout:commitLayout,entries:[{binding:0,resource:{buffer:this.virtual}},{binding:1,resource:{buffer:buffers.positions}},{binding:2,resource:{buffer:this.state,size:32}}]});
 }
 /** Body/topology/reset invalidates every row/patch/proof. Recreate for changed particle layout. */
 invalidate():void{this.generation++;this.epoch=null;this.pending.length=0;if(this.state)this.device.queue.writeBuffer(this.state,0,new Uint32Array([JOINT_STATUS.sourceMismatch,0,0,0,0,0,0,0]));}
 encode(encoder:GPUCommandEncoder,epoch:JointEpoch,{relinearizations=1,pgsSweeps=128}={}):void{
  if(!this.enabled)return;if(this.destroyed)throw Error('Joint pass disposed');validateEpoch(epoch);
  if(!Number.isSafeInteger(relinearizations)||relinearizations<1||relinearizations>8||!Number.isSafeInteger(pgsSweeps)||pgsSweeps<1||pgsSweeps>256)throw Error('Unbounded joint iteration request');
  if(this.pending.length>=this.maxInvocations)throw Error('Joint frame invocation capacity exhausted');const slot=this.pending.length;this.pending.push({slot,generation:this.generation,epoch:{...epoch}});this.epoch={...epoch};const words=new Uint32Array(12),floats=new Float32Array(words.buffer);words.set([this.buffers.particleCount,this.capacity,epoch.bodyGeneration,epoch.sourceToken,epoch.gateRevision,epoch.correctedSubstep,pgsSweeps,7]);floats[8]=.005;floats[9]=.001;this.device.queue.writeBuffer(this.uniform!,slot*256,words);
  // Queue writes happen before submitted commands. A new row exporter must set counts/coverage
  // inside each encoded iteration; do NOT use queue.writeBuffer between encoded iterations.
  this.device.queue.writeBuffer(this.state!,slot*256,new Uint32Array(8));
  encoder.copyBufferToBuffer(this.buffers.positions,0,this.seed!,0,this.buffers.particleCount*16);
  encoder.copyBufferToBuffer(this.buffers.positions,0,this.virtual!,0,this.buffers.particleCount*16);
  for(let inner=0;inner<relinearizations;inner++){
   this.exporter!.encode({encoder,current:this.virtual!,previous:this.buffers.previous,parentSeed:this.seed!,parentStart:inner===0,finalEnumeration:false,rows:this.rows!,state:this.state!,stateOffset:slot*256,capacity:this.capacity,epoch});
   for(const step of jointDispatchPlan('fresh-source',this.buffers.particleCount,this.capacity)){
    const pass=encoder.beginComputePass({label:`source-joint:${inner}:${step.entry}`});pass.setPipeline(this.pipelines.get(step.entry)!);pass.setBindGroup(0,this.bindGroup!,[slot*256,slot*256]);if(step.groups)pass.dispatchWorkgroups(step.groups);pass.end();
   }
  }
  // Requery actual FINAL finite geometry. An intermediate linear solve is not a clearance proof.
  this.exporter!.encode({encoder,current:this.virtual!,previous:this.buffers.previous,parentSeed:this.seed!,parentStart:false,finalEnumeration:true,rows:this.rows!,state:this.state!,stateOffset:slot*256,capacity:this.capacity,epoch});
  const certificate=encoder.beginComputePass({label:'source-joint:final-finite-certificate'});certificate.setPipeline(this.pipelines.get('certify')!);certificate.setBindGroup(0,this.bindGroup!,[slot*256,slot*256]);certificate.dispatchWorkgroups(Math.ceil(this.capacity/64));certificate.end();
  // Conditional GPU commit avoids a per-substep CPU map. Every invocation has its OWN uniform
  // and certificate slot; queued dispatches cannot observe a later epoch's queue.writeBuffer.
  const commit=encoder.beginComputePass({label:'source-joint:conditional-commit'});commit.setPipeline(this.commitPipeline!);commit.setBindGroup(0,this.commitGroup!,[slot*256]);commit.dispatchWorkgroups(Math.ceil(this.buffers.particleCount/64));commit.end();
  encoder.copyBufferToBuffer(this.state!,slot*256,this.readback!,slot*32,32);
 }
 /** Must be checked BEFORE the source frame's strict trajectory/publication proof is committed.
  * Failure is a source pause; clear static geometry alone cannot replace a failed row certificate. */
 async readProof():Promise<{valid:boolean;generation:number;records:{slot:number;epoch:JointEpoch;status:number;rowCount:number;coverage:number;algebraicAttempts:number}[]}>{
  if(!this.enabled)return{valid:true,generation:this.generation,records:[]};
  const generation=this.generation,pending=this.pending.map(p=>({...p,epoch:{...p.epoch}}));if(!pending.length)throw Error('Missing actual joint frame invocations');
  await this.readback!.mapAsync(GPUMapMode.READ);const words=new Uint32Array(this.readback!.getMappedRange().slice(0));this.readback!.unmap();
  const records=pending.map(p=>({slot:p.slot,epoch:p.epoch,status:words[p.slot*8],rowCount:words[p.slot*8+1],coverage:words[p.slot*8+2],algebraicAttempts:words[p.slot*8+3]}));
  const valid=!this.destroyed&&generation===this.generation&&records.every(r=>r.status===0&&r.coverage===7);this.pending.length=0;
  return{valid,generation,records};
 }
 destroy():void{if(this.destroyed)return;this.destroyed=true;this.invalidate();for(const b of this.owned)b.destroy();this.owned.length=0;}
}

/** Separate three-storage commit stage; a blocked numerical patch can never write live positions. */
export const sourceJointCommitWGSL=/* wgsl */ `
@group(0) @binding(0) var<storage,read> proposed:array<vec4f>;
@group(0) @binding(1) var<storage,read_write> live:array<vec4f>;
@group(0) @binding(2) var<storage,read> state:array<u32>;
@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) gid:vec3u){let id=gid.x;if(id>=arrayLength(&live)||state[0]!=0u||state[2]!=7u){return;}live[id]=proposed[id];}
`;
