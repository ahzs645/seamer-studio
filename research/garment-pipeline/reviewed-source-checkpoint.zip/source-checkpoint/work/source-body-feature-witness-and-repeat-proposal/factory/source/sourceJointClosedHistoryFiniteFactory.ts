/** NEW full finite exporter factory. Current-inside witnesses whose transported
 * OLD/current-nearest extended-plane margin is unsupported use the independently
 * closed-body GLOBAL history predicate. No CPU-generated recovery row is uploaded.
 * Recovery wa.w is an old-global-finite confidence margin, NOT an assertion of
 * positive OLD projection on the CURRENT infinite plane. The physical response
 * inequality still uses CURRENT material bary/nearest finite q/escape normal.
 * Every original near/edge/chord witness remains visited; unknown still rejects.
 */
import type {SeamGateLayout} from './seamGate';
import type {prepareJointClosedBodyProbe} from './sourceJointClosedBodyProbe';
function substitute(code:string,needle:string,replacement:string){
 const at=code.indexOf(needle);if(at<0||code.indexOf(needle,at+needle.length)>=0)throw Error('Finite recovery hook changed/nonunique');
 return code.slice(0,at)+replacement+code.slice(at+needle.length);
}
export function sourceJointClosedHistoryFiniteFactory(prepared:Awaited<ReturnType<typeof prepareJointClosedBodyProbe>>,layout:SeamGateLayout):string{
 if(!prepared.enabled)throw Error('Closed-history finite factory is source only');prepared.assertPackedGeometryUnchanged(prepared.packed);
 let code=prepared.factory(layout);
 code=substitute(code,
 'let gap=dot(previousPoint-near.q,n);let bound=uncertainty(point,previousPoint,near.q);if(gap<=bound){atomicOr(&state[0],4u);continue;}append(makeRow(ids.xyz,vec3u(NONE),weights,vec3f(0.0),n,near.q,4u,face,near.face,edge*34u+interval,gap,bound));',
 `let gap=dot(previousPoint-near.q,n);let bound=uncertainty(point,previousPoint,near.q);var confidence=gap;var confidenceBound=bound;var rowNormal=n;var rowPoint=near.q;var rowFeature=near.face;
 if(gap<=bound){let closed=jointClosedBodyMaterialRecovery(ids.xyz,weights);if(closed.valid==0u){atomicOr(&state[0],4u);continue;}confidence=closed.oldMargin;confidenceBound=max(bound,closed.uncertainty);rowNormal=closed.normal;rowPoint=closed.closest;rowFeature=closed.nearestFace;if(confidence<=confidenceBound){atomicOr(&state[0],4u);continue;}}
 append(makeRow(ids.xyz,vec3u(NONE),weights,vec3f(0.0),rowNormal,rowPoint,4u,face,rowFeature,edge*34u+interval,confidence,confidenceBound));`);
 code=substitute(code,
 'if(gap<=uncertaintyBound){atomicOr(&state[0],4u);return;}}\n append(makeRow(tri(face).xyz,vec3u(NONE),weights,vec3f(0.0),n,q,kind,face,targetFeature,0x20000000u+other*16u+feature,gap,uncertaintyBound));',
 `if(gap<=uncertaintyBound){let closed=jointClosedBodyMaterialRecovery(tri(face).xyz,weights);if(closed.valid==0u){atomicOr(&state[0],4u);return;}gap=closed.oldMargin;uncertaintyBound=max(uncertaintyBound,closed.uncertainty);n=closed.normal;q=closed.closest;targetFeature=closed.nearestFace;if(gap<=uncertaintyBound){atomicOr(&state[0],4u);return;}}}
 append(makeRow(tri(face).xyz,vec3u(NONE),weights,vec3f(0.0),n,q,kind,face,targetFeature,0x20000000u+other*16u+feature,gap,uncertaintyBound));`);
 // Point witnesses transport the same actual particle; no arbitrary triangle or
 // copied CPU bary is introduced. A repeated id has exactly weights(1,0,0).
 code=substitute(code,
 'let n=normalize(select(point-near.q,near.q-point,interior));var gap=near.distance;var proofBound=bound;var kind=6u;if(interior){let old=previous[id].xyz;gap=dot(old-near.q,n);proofBound=uncertainty(point,old,near.q);kind=3u;if(gap<=proofBound){atomicOr(&state[0],4u);return;}}append(makeRow(vec3u(id,NONE,NONE),vec3u(NONE),vec3f(1.0,0.0,0.0),vec3f(0.0),n,near.q,kind,id,near.face,0u,gap,proofBound));',
 `var n=normalize(select(point-near.q,near.q-point,interior));var q=near.q;var targetFeature=near.face;var gap=near.distance;var proofBound=bound;var kind=6u;
 if(interior){let old=previous[id].xyz;gap=dot(old-near.q,n);proofBound=uncertainty(point,old,near.q);kind=3u;if(gap<=proofBound){let closed=jointClosedBodyMaterialRecovery(vec3u(id),vec3f(1.0,0.0,0.0));if(closed.valid==0u){atomicOr(&state[0],4u);return;}gap=closed.oldMargin;proofBound=max(proofBound,closed.uncertainty);n=closed.normal;q=closed.closest;targetFeature=closed.nearestFace;if(gap<=proofBound){atomicOr(&state[0],4u);return;}}}
 append(makeRow(vec3u(id,NONE,NONE),vec3u(NONE),vec3f(1.0,0.0,0.0),vec3f(0.0),n,q,kind,id,targetFeature,0u,gap,proofBound));`);
 return code;
}
export const sourceJointClosedHistoryScope=Object.freeze({
 actualGpuWitnesses:true,cpuGeometryInjection:false,
 historyConfidence:'either supported original finite old-plane margin OR globally finite old-outside/current-inside with actual finite firstentry+3ray consensus',
 nonlinearProtection:'every current original finite feature plus complete BVH11mm+arith shell requery after candidate; no old affine-plane pass claimed',
 refinedChildrenSupported:false,physicalPressureReady:false,productionIntegrationReady:false,
});
