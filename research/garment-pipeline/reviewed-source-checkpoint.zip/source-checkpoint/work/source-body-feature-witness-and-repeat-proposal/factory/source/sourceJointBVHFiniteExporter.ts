/** ISOLATED adapter: complete GPU finite visitors over actual refitted BVHs.
 * A caller must capture/hash the actual GPU buffers at an ordered boundary before encode.
 * This is asynchronous diagnostic infrastructure, not a shipping engine hook. */
import {sourceJointFiniteExportWGSL} from './sourceJointFiniteExport';
import {requireJointGeometryEpoch,type PackedJointGeometry} from './sourceJointGeometry';
import {sourceJointBVHRowExportWGSL,jointBVHBodyInlineTraversalWGSL,jointBVHExpectedUniformWords,
 jointBVHRefitDispatches,packJointBVH,requireJointBVHBinding,type PackedJointBVH,type JointBVHSnapshot} from './sourceJointBVHRowExport';
import type {SeamGateLayout} from './seamGate';
import type {JointGpuExportContext,JointEpoch} from './sourceJointContact';
export const JOINT_BVH_UNIFORM_STRIDE=512;
export const JOINT_BVH_UNIFORM_BYTES=400; // 20 scalar words +20 aligned vec4u header words.
export interface ObservedJointSnapshot {
 current:Float32Array;previous:Float32Array;gateWords:Uint32Array;binding:JointBVHSnapshot;
 currentBuffer:GPUBuffer;previousBuffer:GPUBuffer;gateBuffer:GPUBuffer;generation:number;
}
function replaceFunction(code:string,name:string,replacement:string):string {
 const at=code.indexOf('fn '+name+'(');if(at<0)throw Error('Missing exact finite hook '+name);
 const start=code.lastIndexOf('@compute',at);let first=at;
 if(start>=0&&/^@compute[^{}]*$/.test(code.slice(start,at)))first=start;
 let end=code.indexOf('{',at),depth=1;if(end<0)throw Error('Invalid finite function');end++;
 for(;end<code.length&&depth;end++){if(code[end]==='{')depth++;else if(code[end]==='}')depth--;}
 if(depth)throw Error('Unbalanced finite function '+name);return code.slice(0,first)+replacement+code.slice(end);
}
export function sourceJointBVHFiniteWGSL(layout:SeamGateLayout):string {
 let code=sourceJointFiniteExportWGSL(layout);
 code=code.replace(/struct Config\{[^}]+\};/,'struct Config{particles:u32,clothFaces:u32,bodyFaces:u32,capacity:u32,bodyGeneration:u32,sourceToken:u32,gateRevision:u32,substep:u32,cacheSlots:u32,parentStart:u32,finalEnumeration:u32,reserved:u32,snapshotEpoch:u32,historyToken:u32,gateToken:u32,refitFirst:u32,refitCount:u32,refitDepth:u32,p0:u32,p1:u32,expected:array<vec4u,20>};');
 code=code.replace('@binding(6) var<uniform> cfg','@binding(8) var<uniform> cfg').replace('@binding(7) var<uniform> gate','@binding(9) var<uniform> gate');
 code=code.replace('const SEARCH=0.006;','');
 code=code.replace(/\bSEARCH\b/g,'jointFiniteHorizon()');
 code=replaceFunction(code,'append','fn append(r:Row){let index=jointBVHReserveRawRow();if(index==NONE){return;}rows[index]=r;}');
 code=replaceFunction(code,'nearestBody','fn nearestBody(point:vec3f)->Nearest{return jointNearestBody(point);}');
 // All finite body-edge rows still use their original finite visitor. Chord interval time
 // arrays need inline traversal because a WGSL callee cannot mutate caller-local arrays.
 const at=code.indexOf('@compute @workgroup_size(64) fn body_faces('),end=code.indexOf('@compute @workgroup_size(1) fn complete',at);
 if(at<0||end<0)throw Error('Missing exact chord collector');
 let chords=code.slice(at,end);
 const prefix='@compute @workgroup_size(64) fn body_faces(@builtin(global_invocation_id) gid:vec3u){let face=gid.x;if(face>=cfg.clothFaces){return;}let ids=tri(face);let a=clothPoints(ids,false);let old=clothPoints(ids,true);for(var other=0u;other<cfg.bodyFaces;other++){jointVisitBodyPair(face,other);}';
 if(!chords.startsWith(prefix))throw Error('Unexpected body chord hook');
 chords=chords.replace(prefix,'fn jointBVHBodyChords(face:u32){let ids=tri(face);let a=clothPoints(ids,false);let old=clothPoints(ids,true);');
 const collector='for(var other=0u;other<cfg.bodyFaces;other++){let b=bodyPoints(other);let hit=segmentTriangleHit(a[edge],a[(edge+1u)%3u],b[0],b[1],b[2]);if(hit.w>=0.0&&hit.w>0.0&&hit.w<1.0){if(count>=34u){atomicOr(&state[0],1u);break;}times[count]=hit.w;count++;}}';
 if(!chords.includes(collector))throw Error('Unexpected actual finite chord interval collection');
 const visit='let b=bodyPoints(bodyFace);let hit=segmentTriangleHit(a[edge],a[(edge+1u)%3u],b[0],b[1],b[2]);if(hit.w>=0.0&&hit.w>0.0&&hit.w<1.0){if(count>=34u){atomicOr(&state[0],1u);}else{times[count]=hit.w;count++;}}';
 chords=chords.replace(collector,jointBVHBodyInlineTraversalWGSL('min(a[edge],a[(edge+1u)%3u])-vec3f(jointFiniteHorizon())','max(a[edge],a[(edge+1u)%3u])+vec3f(jointFiniteHorizon())',visit));
 code=code.slice(0,at)+chords+code.slice(end);
 code=replaceFunction(code,'complete','@compute @workgroup_size(1) fn complete(){if(jointBVHReady(false)&&jointBVHReady(true)){atomicStore(&state[2],7u);}}');
 // Keep the operator's algebraic diagnostic at state[3]. Refit accounting has independent slots.
 const bvh=sourceJointBVHRowExportWGSL({leafCounter:6,parentCounter:7});
 return code+'\n'+bvh+/* wgsl */`
fn jointBVHExpectedWord(slot:u32)->u32{return cfg.expected[slot/4u][slot%4u];}
fn jointFiniteHorizon()->f32{
 return jointBVHDiscoveryHorizon();
}
@compute @workgroup_size(64) fn joint_bvh_chords(@builtin(global_invocation_id) gid:vec3u){let face=gid.x;if(face>=cfg.clothFaces){return;}if(jointBVHReady(false)&&jointBVHReady(true)){jointBVHBodyChords(face);}}
`;
}
export function packJointBVHUniform(p:PackedJointGeometry,e:JointEpoch,s:JointBVHSnapshot,
 cacheSlots:number,capacity:number,parentStart:boolean,finalEnumeration:boolean,
 refit:{first:number;count:number;depth:number}):Uint32Array {
 if(s.sourceToken!==e.sourceToken||s.bodyGeneration!==e.bodyGeneration||s.gateRevision!==e.gateRevision)throw Error('Stale observed BVH epoch');
 const words=new Uint32Array(JOINT_BVH_UNIFORM_BYTES/4);
 words.set([p.particleCount,p.clothFaces,p.bodyFaces,capacity,e.bodyGeneration,e.sourceToken,e.gateRevision,e.correctedSubstep,cacheSlots,+parentStart,+finalEnumeration,0,s.snapshotEpoch,s.historyToken,s.gateToken,refit.first,refit.count,refit.depth,0,0]);
 words.set(jointBVHExpectedUniformWords(s),20);return words;
}
export class SourceJointBVHFiniteExporter {
 readonly sourceOnly=true as const;readonly emitsAllFiniteBodyGeometry=true as const;
 readonly diagnosticOnly=true as const;
 private owned:GPUBuffer[]=[];private pipelines=new Map<string,GPUComputePipeline>();
 private geometry:GPUBuffer;private cache:GPUBuffer;private cloth:GPUBuffer;private body:GPUBuffer;
 private uniforms:GPUBuffer;private layout:GPUBindGroupLayout;private call=0;private disposed=false;
 private currentSnapshot:JointBVHSnapshot;private clothPacked:PackedJointBVH;private bodyPacked:PackedJointBVH;
 private readonly slotsPerEnumeration:number;private cacheSlots:number;
 constructor(private device:GPUDevice,private packed:PackedJointGeometry,initial:ObservedJointSnapshot,
  private gateBuffer:GPUBuffer,private gateLayout:SeamGateLayout,private validateGeneration:(generation:number)=>boolean,
  shaderFactory:(layout:SeamGateLayout)=>string=sourceJointBVHFiniteWGSL){
  if(!validateGeneration(initial.generation)||initial.gateBuffer!==gateBuffer)throw Error('Stale initial observed GPU snapshot');
  if(initial.current.length!==packed.particleCount*4||initial.previous.length!==initial.current.length)throw Error('Wrong observed GPU cloth shape');
  if([initial.binding.sourceSha256,initial.binding.bodySha256,initial.binding.topologySha256].some((v,i)=>v!==[packed.sourceSha256,packed.bodySha256,packed.topologySha256][i]))throw Error('Observed BVH immutable identity mismatch');
  const w=packed.words;
  const clothTriangles=w.slice(w[6],w[7]);
  const bodyTriangles=w.slice(w[7],w[8]);
  const bodyPositions=new Float32Array(w.slice(w[8],w[9]).buffer);
  this.clothPacked=packJointBVH(clothTriangles,initial.current,{...initial.binding,kind:'cloth',scope:'fresh-source-equal-layer',refinedBoundary:false});
  this.bodyPacked=packJointBVH(bodyTriangles,bodyPositions,{...initial.binding,kind:'body',scope:'fresh-source-equal-layer',refinedBoundary:false});
  this.currentSnapshot={...initial.binding};
  this.cacheSlots=Math.max(64,Math.min(131072,packed.particleCount*8));
  this.slotsPerEnumeration=jointBVHRefitDispatches(this.clothPacked).length+6;
  try{
  const make=(name:string,data:Uint32Array,usage=GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST|GPUBufferUsage.COPY_SRC)=>{if(data.byteLength>device.limits.maxStorageBufferBindingSize)throw Error('Joint BVH storage exceeds portable limit');const b=device.createBuffer({label:'joint-bvh:'+name,size:Math.max(4,data.byteLength),usage});this.owned.push(b);device.queue.writeBuffer(b,0,new Uint32Array(data));return b;};
  this.geometry=make('immutable-finite-geometry',packed.words.slice());this.cache=make('bounded-source-owner-cache',new Uint32Array(this.cacheSlots*8));
  this.cloth=make('complete-refitted-cloth',this.clothPacked.words);this.body=make('immutable-complete-skin',this.bodyPacked.words);
  this.uniforms=make('distinct-observed-enumeration-slots',new Uint32Array(160*9*this.slotsPerEnumeration*JOINT_BVH_UNIFORM_STRIDE/4),GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST);
  this.layout=device.createBindGroupLayout({entries:[...Array.from({length:8},(_,binding)=>({binding,visibility:GPUShaderStage.COMPUTE,buffer:{type:[0,1,2,7].includes(binding)?'read-only-storage' as const:'storage' as const,hasDynamicOffset:binding===4}})),{binding:8,visibility:GPUShaderStage.COMPUTE,buffer:{type:'uniform',hasDynamicOffset:true}},{binding:9,visibility:GPUShaderStage.COMPUTE,buffer:{type:'uniform'}}]});
  const module=device.createShaderModule({label:'joint-bvh:complete-actual-finite-rows',code:shaderFactory(gateLayout)}),layout=device.createPipelineLayout({bindGroupLayouts:[this.layout]});
  for(const entryPoint of['reset','joint_bvh_begin','joint_bvh_leaves','joint_bvh_parents','joint_bvh_complete','joint_bvh_self_rows','body_points','joint_bvh_body_faces','joint_bvh_chords','complete'])this.pipelines.set(entryPoint,device.createComputePipeline({layout,compute:{module,entryPoint}}));
  }catch(error){this.destroy();throw error;}
 }
 encode(c:JointGpuExportContext,s:ObservedJointSnapshot):void {
  if(this.disposed||!this.validateGeneration(s.generation)||s.currentBuffer!==c.current||s.previousBuffer!==c.previous||s.gateBuffer!==this.gateBuffer||s.binding.snapshotEpoch<=this.currentSnapshot.snapshotEpoch)throw Error('Unobserved/stale actual GPU enumeration');
  requireJointGeometryEpoch(this.packed,c.epoch);requireJointBVHBinding(this.bodyPacked,s.binding);
  if(s.current.length!==this.packed.particleCount*4||s.current.some((v,i)=>!Number.isFinite(v)||(i%4===3&&!Object.is(v,s.previous[i]))))throw Error('Invalid actual observed cloth/mass');
  // Source/current/history/gate bytes were captured before digest awaits. This method only
  // encodes GPU operations over those unchanged buffers; caller owns ordering/exclusion.
  const call=this.call++;if(call>=160*9||c.stateOffset%256)throw Error('Joint BVH enumeration slots exhausted');
  const group=this.device.createBindGroup({layout:this.layout,entries:[c.current,c.previous,this.geometry,c.rows,c.state,this.cache,this.cloth,this.body,this.uniforms,this.gateBuffer].map((buffer,binding)=>({binding,resource:{buffer,...binding===4?{size:32}:binding===8?{size:JOINT_BVH_UNIFORM_BYTES}:binding===9?{size:this.gateLayout.byteLength}:{}}}))});
  let index=0;
  const dispatch=(entry:string,groups:number,refit={first:0,count:1,depth:0})=>{const offset=(call*this.slotsPerEnumeration+index++)*JOINT_BVH_UNIFORM_STRIDE;this.device.queue.writeBuffer(this.uniforms,offset,new Uint32Array(packJointBVHUniform(this.packed,c.epoch,s.binding,this.cacheSlots,c.capacity,c.parentStart,c.finalEnumeration,refit)));const pass=c.encoder.beginComputePass({label:'joint-bvh:'+entry});pass.setPipeline(this.pipelines.get(entry)!);pass.setBindGroup(0,group,[c.stateOffset,offset]);if(groups)pass.dispatchWorkgroups(groups);pass.end();};
  dispatch('reset',Math.ceil(this.cacheSlots*8/64));
  for(const r of jointBVHRefitDispatches(this.clothPacked))dispatch(r.entryPoint,r.workgroups,r);
  dispatch('joint_bvh_self_rows',Math.ceil(this.packed.clothFaces/64));dispatch('body_points',Math.ceil(this.packed.particleCount/64));dispatch('joint_bvh_body_faces',Math.ceil(this.packed.clothFaces/64));dispatch('joint_bvh_chords',Math.ceil(this.packed.clothFaces/64));dispatch('complete',1);
  if(index!==this.slotsPerEnumeration)throw Error('Incomplete actual BVH enumeration plan');this.currentSnapshot={...s.binding};
 }
 destroy(){if(this.disposed)return;this.disposed=true;this.owned.forEach(b=>b.destroy());this.owned=[];}
}
