/** NEW copied actual finite row factory. Only segmentProof changes; all BVH/raw
 * witness families, closed-body history, capacity and ALLraw certificates stay. */
import {sourceJointClosedRawInventoryFactory} from './sourceJointClosedRawInventory';
import type {SeamGateLayout} from './seamGate';
import type {prepareJointClosedBodyProbe} from './sourceJointClosedBodyProbe';
import type {PackedJointRefinedGeometry} from './sourceJointRefinedGeometry';
export function sourceJointRefinedSeamFactory(prepared:Awaited<ReturnType<typeof prepareJointClosedBodyProbe>>,layout:SeamGateLayout):string{
 if(!prepared.enabled)throw Error('Refined finite factory is source only');prepared.assertPackedGeometryUnchanged(prepared.packed);const p=prepared.packed as PackedJointRefinedGeometry;
 if(p.refinedBoundary!==true||!Number.isSafeInteger(p.materialBase)||p.materialBase<16||p.materialWords!==p.particleCount*4||p.materialBase+p.materialWords!==p.words.length||[p.materialCoordinatesSha256,p.refinementPolicySha256,p.childGeometrySha256,p.seamDictionarySha256].some(s=>!/^[a-f0-9]{64}$/.test(s)))throw Error('Unbound immutable actual child material packet');
 let code=sourceJointClosedRawInventoryFactory(prepared,layout);const start=code.indexOf('fn segmentProof('),end=code.indexOf('\nfn expectedSeam(',start);if(start<0||end<=start||code.indexOf('fn segmentProof(',start+1)>=0)throw Error('Actual finite segment hook changed');
 const old=code.slice(start,end),marker='let link=geometry[t+at+2u];';if(old.split(marker).length!==2)throw Error('Original interval link hook changed');
 const ordinary=old.replace('fn segmentProof(','fn jointOrdinarySegmentProof(').replace(marker,marker+'if((link&0x80000000u)!=0u){continue;}');
 const child=/* wgsl */`
fn jointChildCoordinate(id:u32)->vec4f{return bitcast<vec4f>(vec4u(geometry[${p.materialBase}u+id*4u],geometry[${p.materialBase}u+id*4u+1u],geometry[${p.materialBase}u+id*4u+2u],geometry[${p.materialBase}u+id*4u+3u]));}
fn jointChildFaceTouches(face:u32,child:u32)->bool{if(face>=cfg.clothFaces||child>=cfg.clothFaces){return false;}let a=tri(face).xyz;let b=tri(child).xyz;return any(a==vec3u(b.x))||any(a==vec3u(b.y))||any(a==vec3u(b.z));}
fn jointChildMaterialPath(ids:vec3u)->bool{
 let A=jointChildCoordinate(ids.x);let B=jointChildCoordinate(ids.z);if(A.w!=B.w){return false;}if(ids.y==NONE){return true;}
 let M=jointChildCoordinate(ids.y);if(M.w!=A.w){return false;}let scale=max(vec2f(1e-6),max(abs(A.xy),max(abs(B.xy),abs(M.xy))));let bound=8.0*0.000000059604644775390625*scale;
 return all(abs(M.xy-(A.xy+B.xy)*0.5)<=bound);
}
fn jointChildInterval(face:u32,other:u32,point:vec3f,relative:u32)->bool{
 let l=geometry[12];let count=geometry[13];if(relative>count||count-relative<10u){atomicOr(&state[0],16u);return false;}
 let a=vec3u(geometry[l+relative],geometry[l+relative+1u],geometry[l+relative+2u]);let b=vec3u(geometry[l+relative+3u],geometry[l+relative+4u],geometry[l+relative+5u]);
 if(a.x>=cfg.particles||a.z>=cfg.particles||b.x>=cfg.particles||b.z>=cfg.particles||((a.y!=NONE)&&(a.y>=cfg.particles))||((b.y!=NONE)&&(b.y>=cfg.particles))||((a.y==NONE)==(b.y==NONE))){atomicOr(&state[0],16u);return false;}
 if(!jointChildMaterialPath(a)||!jointChildMaterialPath(b)){atomicOr(&state[0],16u);return false;}
 // A free numerical midpoint is never an activated sewing/contact identity.
 if(a.y!=NONE){if(dot(point-current[a.y].xyz,point-current[a.y].xyz)<=1e-12){return false;}}
 if(b.y!=NONE){if(dot(point-current[b.y].xyz,point-current[b.y].xyz)<=1e-12){return false;}}
 for(var cell=0u;cell<2u;cell++){
  let childA=geometry[l+relative+6u+cell];let childB=geometry[l+relative+8u+cell];
  if(!((jointChildFaceTouches(face,childA)&&jointChildFaceTouches(other,childB))||(jointChildFaceTouches(face,childB)&&jointChildFaceTouches(other,childA)))){continue;}
  let u0=f32(cell)*0.5;let u1=f32(cell+1u)*0.5;
  var a0=mix(current[a.x].xyz,current[a.z].xyz,u0);var a1=mix(current[a.x].xyz,current[a.z].xyz,u1);var b0=mix(current[b.x].xyz,current[b.z].xyz,u0);var b1=mix(current[b.x].xyz,current[b.z].xyz,u1);
  if(a.y!=NONE){a0=current[a.x].xyz;a1=current[a.y].xyz;if(cell==1u){a0=current[a.y].xyz;a1=current[a.z].xyz;}}
  if(b.y!=NONE){b0=current[b.x].xyz;b1=current[b.y].xyz;if(cell==1u){b0=current[b.y].xyz;b1=current[b.z].xyz;}}
  let mid=(a0+b0)*0.5;let edge=(a1+b1)*0.5-mid;let squared=dot(edge,edge);var t=0.0;if(squared>0.0){t=clamp(dot(point-mid,edge)/squared,0.0,1.0);}
  let A=mix(a0,a1,t);let B=mix(b0,b1,t);if(distance(point,A)<=0.005&&distance(point,B)<=0.005&&distance(A,B)<=0.003){return true;}
 }return false;
}
fn segmentProof(face:u32,other:u32,point:vec3f,seam:u32)->bool{
 if(${p.materialBase}u+cfg.particles*4u!=arrayLength(&geometry)){atomicOr(&state[0],16u);return false;}
 let t=geometry[10];for(var at=geometry[t+face];at<geometry[t+face+1u];at+=5u){
  if(geometry[t+at]!=other||geometry[t+at+4u]!=seam){continue;}let threshold=geometry[t+at+1u];if(threshold!=NONE&&gate.sewnUpTo<=i32(threshold)){continue;}
  if(!activeSourceSeam(seam)||!activeSourceSegment(geometry[t+at+3u])){continue;}let link=geometry[t+at+2u];if((link&0x80000000u)==0u){continue;}
  if(jointChildInterval(face,other,point,link&0x7fffffffu)){return true;}
 }
 return jointOrdinarySegmentProof(face,other,point,seam);
}`;
 code=code.slice(0,start)+ordinary+'\n'+child+code.slice(end);return code;
}
