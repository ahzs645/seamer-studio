/** NEW actual GPU complete finite inventory. Physical deficits do not make geometry
 * unsupported; unknown/invalid/overflow still fail closed. No CPU witness injection. */
import {sourceJointClosedHistoryFiniteFactory} from './sourceJointClosedHistoryFiniteFactory';
import {sourceJointContactWGSL} from './sourceJointContact';
import type {SeamGateLayout} from './seamGate';
import type {prepareJointClosedBodyProbe} from './sourceJointClosedBodyProbe';
export function sourceJointClosedRawInventoryFactory(prepared:Awaited<ReturnType<typeof prepareJointClosedBodyProbe>>,layout:SeamGateLayout){
 let code=sourceJointClosedHistoryFiniteFactory(prepared,layout);
 const start=sourceJointContactWGSL.indexOf('fn finite('),end=sourceJointContactWGSL.indexOf('fn rootOf(');
 if(start<0||end<=start)throw Error('Missing strict Row128 validator');
 const marker='fn append(r:Row){let index=jointBVHReserveRawRow();if(index==NONE){return;}rows[index]=r;}';
 if(!code.includes(marker))throw Error('Complete finite append changed');
 code=code.replace(marker,`fn append(r:Row){
 let index=jointBVHReserveRawRow();if(index==NONE){return;}
 rows[index]=r;if(!validRow(r)){atomicOr(&state[0],2u);return;}
 atomicAdd(&state[5],1u);let a=jointInventoryPoint(r,false);let b=jointInventoryPoint(r,true);
 let coordinate=max(1.0,max(max(abs(a.x),max(abs(a.y),abs(a.z))),max(abs(b.x),max(abs(b.y),abs(b.z)))));
 let lower=dot(a-b,r.n.xyz)-32.0*0.000000059604644775390625*coordinate;
 if(!finite(lower)){atomicOr(&state[0],2u);return;}
 atomicMin(&state[4],bitcast<u32>(max(0.0,lower)));
 if(lower<r.n.w){atomicAdd(&state[3],1u);}
 }`);
 const reset='atomicStore(&state[1],0u);atomicStore(&state[2],0u);';if(!code.includes(reset))throw Error('Inventory reset changed');
 code=code.replace(reset,reset+'atomicStore(&state[3],0u);atomicStore(&state[4],0x7f800000u);atomicStore(&state[5],0u);');
 return code+'\n'+sourceJointContactWGSL.slice(start,end).replaceAll('cfg.clearance','0.001')+`
 fn jointInventoryPoint(r:Row,isRigidTarget:bool)->vec3f{
 if(isRigidTarget&&r.q.w==1.0){return r.q.xyz;}var q=vec3f(0.0);
 for(var k=0u;k<3u;k++){let id=select(r.a[k],r.b[k],isRigidTarget);if(id!=NONE){q+=current[id].xyz*select(r.wa[k],r.wb[k],isRigidTarget);}}return q;
 }`;
}
export function decodeJointClosedRawInventory(proof:Uint32Array,capacity:number){
 if(proof.length!==8||!Number.isSafeInteger(capacity)||capacity<1)throw Error('Malformed all-raw inventory proof');
 const minimum=new Float32Array(proof.slice(4,5).buffer)[0],complete=proof[0]===0&&proof[2]===7&&proof[1]===proof[5]&&proof[1]<=capacity&&proof[1]<0xffffffff;
 return {complete,unsupportedFlags:proof[0],allRawOccurrences:proof[1],validatedOccurrences:proof[5],strictClearanceDeficits:proof[3],minimumLowerBoundM:minimum,physicalClearanceCertified:complete&&proof[3]===0&&(proof[1]===0||minimum>=Math.fround(.001)),garmentAccepted:false};
}
