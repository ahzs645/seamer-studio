import json,struct,hashlib
from pathlib import Path
base=Path('/workspace/work/source-joint-runtime-integration/actual-parent-backend-review-pin5/runtime')
files={'frozen':Path('/workspace/work/node-dawn-source-position-observer/run-tee-all-frame-positions-attempt1/rejected-attempt-7-frozen.json'),'parent':base/'actual-parent-attempt5-actual-parent.bin','history':base/'actual-parent-attempt5-actual-history.bin','raw':base/'actual-parent-attempt5-round-0-raw.bin'}
a=json.loads(files['frozen'].read_text());parent=list(struct.unpack('<'+str(files['parent'].stat().st_size//4)+'f',files['parent'].read_bytes()));old=list(struct.unpack('<'+str(files['history'].stat().st_size//4)+'f',files['history'].read_bytes()));raw=files['raw'].read_bytes();chosen={}
def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
for i in range(len(raw)//128):
 u=struct.unpack_from('<32I',raw,i*128);f=struct.unpack_from('<32f',raw,i*128);flag=u[3];feature=u[27]
 if flag==6 and u[1]!=0xffffffff and feature>=0x20000000:
  lane=(feature-0x20000000)%16;kind='body-corner-cloth-face'if lane<3 else 'edge-edge'if lane<12 else None;body=(feature-0x20000000)//16
 elif flag==4 and 0x10000000<=feature<0x20000000:
  lane=12+(feature-0x10000000)%3;kind='body-edge-cloth-face-crossing';body=(feature-0x10000000)//3
 else:continue
 if kind is None or kind in chosen:continue
 ids=list(u[:3]);bid=a['bodyIndices'][body*3:body*3+3]
 chosen[kind]={'originalGpuOrdinal':i,'kind':kind,'featureLane':lane,'clothFace':u[24],'bodyFace':body,'originalRawWords':list(u),'sourceIds':ids,'bodyIds':bid,'sourceCurrent':[parent[j*4:j*4+3]for j in ids],'sourceOld':[old[j*4:j*4+3]for j in ids],'bodyPoints':[[f32(x)for x in a['bodyPositions'][j*3:j*3+3]]for j in bid],'sourceWeights':list(f[8:11]),'normal':list(f[16:19]),'rigidPoint':list(f[20:23]),'oldOrCurrentGapM':f[11],'historyOrProtectionUncertaintyM':f[15]}
 if len(chosen)==3:break
assert len(chosen)==3
receipt={'scope':'CPU finite witness/map checks from genuine saved legacy-W body5 post-support14 tee GPU rows; NOT fresh SI skirt trajectory or NEW GPU lane execution','newDeviceExecuted':False,'inputs':{k:{'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for k,p in files.items()},'witnesses':list(chosen.values())}
Path('genuine-body-witnesses.json').write_text(json.dumps(receipt,indent=2)+'\n')
