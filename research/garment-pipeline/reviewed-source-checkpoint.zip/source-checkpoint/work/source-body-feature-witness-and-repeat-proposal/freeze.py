import pathlib,json,hashlib
r=pathlib.Path(__file__).resolve().parent;files={}
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def add(p):
 p=pathlib.Path(p).resolve()
 if not p.is_file():raise RuntimeError('Missing actual imported file: '+str(p))
 files[str(p)]=sha(p)
def add_manifest(p):
 p=pathlib.Path(p);add(p);m=json.loads(p.read_bytes())
 for name,h in m['files'].items():
  if sha(name)!=h:raise RuntimeError('Changed reviewed backend dependency: '+name)
  add(name)
for p in r.rglob('*'):
 if p.is_file() and p.name!='review-pins.json' and '__pycache__' not in p.parts:add(p)
backend=pathlib.Path('/workspace/work/source-joint-refined-backend-integration/review-pins.json');add_manifest(backend)
# The locally copied constructor/controller bundle isolates this epoch from the
# mutable whole-engine driver. Source fingerprints are checked against its build.
build=json.loads((r/'controller-build-provenance.json').read_bytes())
if sha(r/'compiled/production.js')!=build['productionBundleSha256']:raise RuntimeError('Copied actual controller bundle differs from compiled provenance')
for key,name in build['physicalSourcePaths'].items():
 if sha(name)!=build['sourceFingerprints'][key]:raise RuntimeError('Copied actual controller build source changed: '+name)
 add(name)
add(build['sourceEpochPins'])
for p in pathlib.Path('/workspace/work/node-dawn-prototype/dist/linux-x64').rglob('*'):
 if p.is_file():add(p)
for p in ['/workspace/work/node-dawn-prototype/index.js','/workspace/work/node-dawn-prototype/package.json','/workspace/work/vulkan-backend/lvp-local-icd.json'] :add(p)
add_manifest('/workspace/work/source-joint-refined-allraw-stage-fenced/review-pins.json')
add_manifest('/workspace/work/source-joint-refined-allraw-feature-lanes-stage-fenced/review-pins.json')
add('/workspace/work/source-joint-runtime-integration/actual-parent-backend-review-pin5/manifest.json')
add('/workspace/work/source-joint-runtime-integration/actual-parent-backend-review-pin5/runtime/compiled/surfaceTopology.mjs')
add('/workspace/work/node-dawn-source-position-observer/run-tee-all-frame-positions-attempt1/actual14-parent-and-history.json')
add('/workspace/work/source-body-face-feature-lanes/review-pins.json')
helper=json.loads(pathlib.Path('/workspace/work/source-body-face-feature-lanes/review-pins.json').read_bytes())
for name,h in helper['pins'].items():
 if sha(name)!=h:raise RuntimeError('Changed frozen feature-lane helper: '+name)
 add(name)
witness=json.loads((r/'genuine-body-witnesses.json').read_bytes())
for record in witness['inputs'].values():
 if sha(record['file'])!=record['sha256']:raise RuntimeError('Changed genuine saved witness input')
 add(record['file'])
pre=json.loads((r/'preflight.json').read_bytes())
manifest={'kind':'NEW authentic positive finite-body feature primitives plus same-device unchanged complete SI skirt INITIAL repeat; CPU only','stageFenceOperationBoundSeconds':60,'sameFiniteOperandsQueriesPaddingMasksCaps':True,'sameAllOtherWGSL':True,'sameWGSL':False,'skirtWGSLByteIdenticalTo895':True,'positiveFiniteBodyHooksByteIdenticalTo895':True,'original895Preserved':True,'modes':['witnesses','repeat'],'sameDeviceRepeatQueries':2,'positiveFiniteFeatureCases':3,'probeExtraEntryOnly':True,'bodyFaceDispatchOwnershipChanged':False,'sameOriginalParentHistoryGateGeometryBytes':True,'timestampFeatureOptional':True,'CPUControlsPassed':43,'genuineBodyWitnessControls':'three authentic saved body5 legacy-W tee finite witness families, CPU-only; not new factory device authority','CPUPreflight':pre,'backendManifestSha256':sha(backend),'boundSeconds':180,'graceSeconds':5,'nativeWorkerOr41Executed':False,'integratedPhysicalSubsteps':0,'fullFiniteProducerValidated':False,'pressureValidated':False,'whole40Validated':False,'fitAccepted':False,'browserPortable':False,'files':dict(sorted(files.items()))}
out=r/'review-pins.json';out.write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'manifest':str(out),'sha256':sha(out),'files':len(files)}))
