import {PHYSICAL_QUERY_CHAIN_ENCODING,physicalCertificateQueryRecord,verifyPhysicalCertificateQueryChain} from './physicalCertificateQueryChain.mjs';
import {requireSourceSelfIntervalTrajectoryProof} from './src/selfIntervalProof.mjs';
/** UNFROZEN executable adapter to the REAL GPU finite/CSR backend.
 * No imports construct a GPU object. No native factory path allocates anything.
 * Authoritative physical reaction/friction and refined child contexts remain
 * separate reviewed providers; their absence rejects, never enables frictionless
 * acceptance or falls back to legacy contacts inside a partial joint frame. */
import {createSourceJointNumericalClearanceBackend} from '/workspace/work/source-seeded-finite895-component-bound-history-gate-tokens/index.mjs';
import {requireSourceBodyFacetTrajectoryProof} from './src/bodyFacetProof.mjs';
import {physicalReceiptListSha256,physicalFrameReceiptSha256,PHYSICAL_FRAME_RECEIPT_ENCODING} from '../physical-frame-receipt-portable/frameReceiptCodec.mjs';
import {physicalCertificateSha256,canonicalPhysicalCertificateText,PHYSICAL_CERTIFICATE_HASH_ENCODING} from '../source-pressure-friction-integration-exclusive/certificateHash.mjs';
import {requirePhysicalIncomingRawProof} from '../source-pressure-friction-whole-provider/wholePhysicalAliasWGSL.mjs';
import {actualAllContactOperatorEvidence} from '../source-pressure-friction-whole-provider/actualAllContactOperatorEvidence.mjs';
import {requireExecutedAnchorPartitionPolicy,requireAnchorPartition,anchorPartitionPolicySha256} from '../source-pressure-friction-whole-provider/anchorPartitionPolicy.mjs';
const sha=x=>typeof x==='string'&&/^[a-f0-9]{64}$/.test(x);
const cloneActivation=x=>({...x,activeSeams:x.activeSeams.slice()});
const equalKey=(a,b)=>['generation','frameSequence','physicalSubstep','parentToken','gateRevision'].every(k=>a?.[k]===b?.[k]);
const digest=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),x=>x.toString(16).padStart(2,'0')).join('');
export const actualGuardProofSha256=proof=>Promise.resolve(physicalCertificateSha256(proof));
export function requireActualPhysicalDeltaByteProof(proof,frame,creation){
 const d=proof?.verifiedPhysicalDeltaTrace;if(!d||d.encoding!=='float32-le-vec4-physical-delta41-v1'||d.particleCount!==creation.simulation.particleCount||d.sampleCount!==41||d.physicalSubsteps!==40||d.sampleSha256s?.length!==41||!d.sampleSha256s.every(sha)||!sha(d.binarySha256)||d.startSha256!==d.sampleSha256s[0]||d.endSha256!==d.sampleSha256s[40]||d.sample0Meaning!=='frame-entry-ledger-not-assumed-zero'||d.materialPolicySha256!==creation.simulation.sourcePhysicalMembrane?.policySha256||d.sourceDeltaPolicySha256!==frame.sourceDeltaPolicySha256)throw Error('Missing actual mapped physical delta41 byte binding');return d;
}
export function requireActualJointWorkerByteProof(proof){
 const b=proof?.verifiedWorkerRequest;if(!b||b.encoding!=='source-guard-actual-byte-receipt-v1'||!sha(b.workerContextSha256)||!sha(b.activationSha256)||!Number.isSafeInteger(b.requestId)||b.requestId<1||b.expectedSubSteps!==40||b.sampleSha256s?.length!==41||!b.sampleSha256s.every(sha)||b.startPositionsSha256!==b.sampleSha256s[0]||b.finalPositionsSha256!==b.sampleSha256s[40])throw Error('Missing actual joint Worker41 byte binding');return b;
}
export {PHYSICAL_CERTIFICATE_HASH_ENCODING};
export function requireActualRefinedProducerProof(simulation,certificate){
 const expected=simulation.sourceGatherCollisionGeometry?'actual-child-material-u-v3':'ordinary-source-topology';
 if(certificate.refinedSeamProof!==expected)throw Error('Actual finite producer did not prove the supplied refined source child paths');
 return expected;
}

/** This checks receipt binding, not device correctness. A separately reviewed
 * provider device-validation receipt is required before the frame is started. */
export function validatePhysicalReactionReceipt(receipt,input,fresh,validation,freshCertificateSha256,operator){
 if(!receipt||!equalKey(receipt.binding?.key,input.key))throw Error('Missing/stale physical reaction receipt');
 if(receipt.reactionRecordScope!=='body-pressure-friction-only-v1'||!sha(receipt.actualAllContactOperatorReceiptSha256)||!['allContactPhysicalRowCount','bodyContactPhysicalRowCount','selfContactPhysicalRowCount'].every(k=>Number.isSafeInteger(receipt[k])&&receipt[k]>=0)||receipt.bodyContactPhysicalRowCount+receipt.selfContactPhysicalRowCount!==receipt.allContactPhysicalRowCount||receipt.allContactPhysicalRowCount>input.rawOccurrences||!Array.isArray(receipt.reactions)||receipt.reactions.length>receipt.bodyContactPhysicalRowCount)throw Error('Incomplete all-contact operator/body-pressure receipt scope');
 if(!Number.isSafeInteger(input.rawOccurrences)||input.rawOccurrences<0)throw Error('Unbound physical raw occurrence count');
 for(const name of ['originalParentSha256','historySha256','usedGateSha256','sourceSha256','bodySha256','fullRawRow128Sha256','physicalMassPolicySha256','declaredFrictionProfileSha256','executedTolerancePolicySha256','executedAnchorPartitionPolicySha256'])if(!sha(receipt.binding[name])||receipt.binding[name]!==input.binding[name])throw Error('Physical reaction binding mismatch: '+name);
 if(!operator||operator.actualGpuOperatorReadbackVerified!==true||!equalKey(operator.binding?.key,input.key))throw Error('Missing actual private ALL-contact operator readback');
 for(const name of ['packedPhysicalJacobianSha256','physicalRhsSha256'])if(!sha(operator[name])||receipt.binding[name]!==operator[name])throw Error('Physical operator binding mismatch: '+name);
 for(const name of ['actualAllContactOperatorReceiptSha256','allContactPhysicalRowCount','bodyContactPhysicalRowCount','selfContactPhysicalRowCount'])if(receipt[name]!==operator[name])throw Error('Physical ALL-contact operator receipt mismatch: '+name);
 if(receipt.binding.originalRawOccurrences!==input.rawOccurrences||receipt.binding.originalRawRow128Sha256!==input.binding.fullRawRow128Sha256||receipt.binding.originalRawProofSha256!==input.binding.originalRawProofSha256)throw Error('Original pressure inventory binding mismatch');
 for(const name of ['originalParentSha256','historySha256','usedGateSha256','sourceSha256','bodySha256'])if(receipt.binding[name]!==fresh[name])throw Error('Physical reaction differs from actual fresh finite proof: '+name);
 if(receipt.finalCandidateSha256!==fresh.candidateSha256||receipt.normalPhysicalRhs!=='exact-physical-1mm'||receipt.normalMultiplierUnit!=='kg-m'||receipt.numericalMarginIsPhysicalPressure!==false||receipt.normalReactionAuthoritative!==true||receipt.storedForceFinite!==true||receipt.fixedMassAndSignedZeroBitsPreserved!==true||receipt.all41GuardProofSha256!==null)throw Error('Incomplete physical reaction/candidate receipt');
 for(const name of ['mechanicalCandidateSha256','finalCandidateSha256','numericalClearanceDeltaSha256','idealCombinedContactDeltaSha256','actualFreshAllRawCertificateSha256'])if(!sha(receipt[name]))throw Error('Missing reaction digest: '+name);
 for(const name of ['algebraicNormalDeficitM','algebraicComplementarityResidualM','frictionResidualM','originalParentNetM'])if(!Number.isFinite(receipt[name])||receipt[name]<0)throw Error('Nonfinite physical reaction residual: '+name);
 if(receipt.originalParentNetM>.005||receipt.originalParentNetM!==fresh.maximumOriginalParentNetM||!Array.isArray(receipt.reactions))throw Error('Unbounded/incomplete physical reaction');
 if(!validation||receipt.deviceReactionReceiptSha256!==validation.receiptSha256||receipt.executedPhysicalPackShaderSha256!==validation.physicalPackShaderSha256||receipt.executedReactionShaderSha256!==validation.reactionShaderSha256)throw Error('Reaction receipt did not bind device-validated executed shaders');
 if(!sha(validation.authenticBodyBVHAnchorProbeReceiptSha256)||!sha(validation.anchorProbeShaderSha256))throw Error('Reaction lacks authentic whole-body anchor probe validation');
 if(!sha(freshCertificateSha256)||receipt.actualFreshAllRawCertificateSha256!==freshCertificateSha256)throw Error('Reaction receipt did not bind this actual fresh ALLraw certificate');
 if(receipt.actualFreshAllRawCertificateEncoding!==PHYSICAL_CERTIFICATE_HASH_ENCODING)throw Error('Physical reaction certificate encoding changed');
 if(!sha(validation.validatedTolerancePolicySha256)||receipt.binding.executedTolerancePolicySha256!==validation.validatedTolerancePolicySha256)throw Error('Reaction did not bind device-validated tolerance policy');
 for(const name of ['algebraicNormalDeficitM','algebraicComplementarityResidualM','frictionResidualM']){
  const bound=validation.validatedTolerances?.[name];if(!Number.isFinite(bound)||bound<0||receipt[name]>bound)throw Error('Reaction residual exceeds declared validated tolerance: '+name);
 }
 if(!sha(validation.validatedAnchorPartitionPolicySha256)||receipt.binding.executedAnchorPartitionPolicySha256!==validation.validatedAnchorPartitionPolicySha256)throw Error('Reaction did not bind device-validated anchor partition policy');
 const partitionBounds=requireExecutedAnchorPartitionPolicy(receipt.binding,validation);
 for(const name of ['sourceMaterialPartitionError','bodyBarycentricPartitionError'])if(!Number.isFinite(partitionBounds?.[name])||partitionBounds[name]<0||partitionBounds[name]>2e-6)throw Error('Invalid declared anchor partition bound: '+name);
 const vec3=v=>v&&v.length===3&&Array.from(v).every(Number.isFinite),functionalIds=new Set(),physicalAliases=new Set();
 for(const r of receipt.reactions){
  if(!sha(r.materialFunctionalSha256)||functionalIds.has(r.materialFunctionalSha256)||!Number.isFinite(r.physicalNormalLambdaKgM)||r.physicalNormalLambdaKgM<0||!vec3(r.normalForceN)||!vec3(r.tangentialLambdaKgM)||!['separated','stick','slide'].includes(r.mode)||!Array.isArray(r.originalRawAliases)||!r.originalRawAliases.length||r.originalRawAliases.some(i=>!Number.isSafeInteger(i)||i<0||i>=input.rawOccurrences))throw Error('Invalid actual physical reaction row');
  functionalIds.add(r.materialFunctionalSha256);
  for(const alias of r.originalRawAliases){if(physicalAliases.has(alias))throw Error('Duplicate original physical raw alias across pressure functionals');physicalAliases.add(alias);}
  if(r.mode==='separated'&&r.physicalNormalLambdaKgM!==0||r.physicalNormalLambdaKgM===0&&[...r.normalForceN,...r.tangentialLambdaKgM].some(v=>v!==0))throw Error('Nonzero separated/no-pressure physical reaction');
  const a=r.currentBodyMaterialAnchor;if(a===null||a===undefined)throw Error('A body-pressure record requires its authentic body-material anchor');if(a!==null){
   if(!a||!Array.isArray(a.sourceMaterialIds)||!a.sourceMaterialIds.length||a.sourceMaterialIds.length!==a.sourceMaterialWeights?.length||a.sourceMaterialIds.some(i=>!Number.isSafeInteger(i)||i<0)||Array.from(a.sourceMaterialWeights).some(v=>!Number.isFinite(v)||v<0||v>1)||!Number.isSafeInteger(a.bodyFace)||a.bodyFace<0||!vec3(a.bodyBarycentric)||a.bodyBarycentric.some(v=>v<0||v>1)||!vec3(a.materialOffset)||!sha(a.authenticFiniteProbeSha256)||a.producerPhysicalSubstep!==input.key.physicalSubstep)throw Error('Invalid authentic body-material pressure anchor');
   requireAnchorPartition(Array.from(a.sourceMaterialWeights),'source',partitionBounds);requireAnchorPartition(Array.from(a.bodyBarycentric),'body',partitionBounds);
   for(const name of ['bodySha256','sourceSha256','historySha256','usedGateSha256'])if(a[name]!==input.binding[name])throw Error('Physical anchor provenance differs: '+name);
  }
 }
}

/** Map the actual GPU inventory ABI without inventing finite clearance for an
 * empty inventory. Infinity is retained only for an actually complete0-row proof. */
export function bindActualInventoryCertificate(c,key){
 if(!c||c.complete!==true||c.physicalClearanceCertified!==true||c.unsupportedFlags!==0||c.strictClearanceDeficits!==0||!Number.isSafeInteger(c.allRawOccurrences)||c.allRawOccurrences<0)throw Error('Incomplete actual GPU inventory certificate');
 return{...c,key:{...key},rawOccurrences:c.allRawOccurrences,unsupported:c.unsupportedFlags,clearanceDeficits:c.strictClearanceDeficits,minimumClearanceLowerBoundM:c.minimumLowerBoundM};
}

/** Recompute private executed evidence, never derive J/RHS from pre-pack labels. */
export async function requireActualPhysicalOperatorReadback(operator,input,particles){
 operator=structuredClone(operator);input={key:{...input.key},rawOccurrences:input.rawOccurrences,binding:structuredClone(input.binding)};
 if(!operator||operator.actualGpuOperatorReadbackVerified!==true||!equalKey(operator.binding?.key,input.key))throw Error('Missing actual private physical operator lease');
 for(const name of ['originalParentSha256','historySha256','usedGateSha256','sourceSha256','bodySha256','fullRawRow128Sha256','physicalMassPolicySha256','declaredFrictionProfileSha256','executedTolerancePolicySha256','executedAnchorPartitionPolicySha256'])if(operator.binding[name]!==input.binding[name])throw Error('Actual operator input binding mismatch: '+name);
 if(operator.binding.originalRawOccurrences!==input.rawOccurrences||operator.binding.originalRawRow128Sha256!==input.binding.fullRawRow128Sha256||operator.binding.originalRawProofSha256!==input.binding.originalRawProofSha256)throw Error('Actual operator original inventory mismatch');
 if(input.rawOccurrences===0){
  requirePhysicalIncomingRawProof(operator.actualOriginalRawProof,0);
  const emptyBinding=operator.emptyHashBinding;if(!emptyBinding||!equalKey(emptyBinding.key,input.key)||emptyBinding.originalRawOccurrences!==0||emptyBinding.originalRawRow128Sha256!==input.binding.fullRawRow128Sha256||emptyBinding.originalRawProofSha256!==input.binding.originalRawProofSha256||operator.actualAllContactOperatorReceiptSha256!==await digest(new TextEncoder().encode('actual-empty-physical-operator-v1\n'+JSON.stringify(emptyBinding)+input.binding.originalRawProofSha256)))throw Error('Actual empty physical operator digest mismatch');
  if(operator.actualAuthenticatedEmptyOperator!==true||!(operator.actualOriginalRawProof instanceof Uint32Array)||operator.actualOriginalRawProof.length!==8||await digest(operator.actualOriginalRawProof)!==input.binding.originalRawProofSha256||['allContactPhysicalRowCount','bodyContactPhysicalRowCount','selfContactPhysicalRowCount'].some(k=>operator[k]!==0)||operator.packedPhysicalJacobianSha256!==await digest(new Uint8Array())||operator.physicalRhsSha256!==await digest(new Uint8Array()))throw Error('Invalid authenticated empty physical operator');
  return operator;
 }
 const rows=operator.actualPhysicalRows,terms=operator.actualPhysicalTerms,status=operator.actualStatus;
 if(!(rows instanceof Uint8Array)||!(terms instanceof Uint8Array)||!(status instanceof Uint32Array))throw Error('Missing actual physical operator arrays');
 const merged=new Uint8Array(rows.length+terms.length);merged.set(rows);merged.set(terms,rows.length);
 if(operator.packedPhysicalJacobianSha256!==await digest(merged)||operator.physicalRhsSha256!==await digest(rows))throw Error('Actual physical operator J/RHS digest mismatch');
 const evidence=actualAllContactOperatorEvidence({actualGpuPhysicalPackProducer:true,actualPhysicalRows:rows,actualPhysicalTerms:terms,proof:operator.actualPackProof},{actualGpuReactionReadback:true,physicalOperatorAccepted:true,normalMultiplierUnit:'kg-m',numericalMarginIsPhysicalPressure:false,statusCapacity:status,reaction:operator.actualReaction,idealCombinedContactDelta:operator.actualIdealPhysicalContactDelta,executed:{components:status[4]}},operator.binding,particles);
 for(const name of ['actualAllContactOperatorReceiptSha256','allContactPhysicalRowCount','bodyContactPhysicalRowCount','selfContactPhysicalRowCount'])if(evidence[name]!==operator[name])throw Error('Actual physical operator receipt digest/count mismatch');
 return operator;
}

export function createActualSourceJointEngineFactory(options){
 if(!options||!sha(options.implementationSha256)||typeof options.prepareActualGeometry!=='function')throw Error('Pinned actual joint backend geometry provider required');
 return creation=>new SourceJointWholeEngineBackend(creation,options);
}
export class SourceJointWholeEngineBackend {
 constructor(creation,options){
  this.creation=creation;this.options={...options};this.implementationSha256=options.implementationSha256;this.virtual=null;this.frame=null;this.step=null;this.closed=false;this.invalidated=false;this.receipts=[];this.acceptedFrameReceipt=null;this.activeOperations=new Set();this.closePromise=null;
  this.reaction=options.physicalReactionProvider??null;
  if(this.reaction&&(!sha(this.reaction.implementationSha256)||!Number.isSafeInteger(this.reaction.snapshotBytes)||this.reaction.snapshotBytes<0||this.reaction.snapshotBytes%4||['encodeSnapshot','encodeRestore','beforeFrame','reconcileActualReaction','readActualAllContactOperatorReceipt','acceptFrame','invalidate','resetHistory','destroy'].some(name=>typeof this.reaction[name]!=='function')))throw Error('Incomplete authoritative pressure/friction history provider');
  this.snapshotBytes=this.reaction?.snapshotBytes??0;
 }
 get acceptedFrameCommitReceipt(){return this.acceptedFrameReceipt?structuredClone(this.acceptedFrameReceipt):null;}
 get readiness(){return{concreteGpuProducerClass:'SourceJointNumericalClearanceBackend',producerWired:true,physicalReactionProviderSupplied:!!this.reaction,wholeEngineDeviceValidated:false,garmentAccepted:false};}
 encodeSnapshot(encoder,target,offset){this.reaction?.encodeSnapshot(encoder,target,offset);}
 releasePhysicalOutput(){const result=this.step?.combined;if(!result)return;this.step=null;if(typeof result.release!=='function')throw Error('Missing synchronous physical output lease release');const pending=result.release();if(pending&&typeof pending.then==='function')throw Error('Physical output lease release must be synchronous');}
 encodeRestore(encoder,target,offset){this.releasePhysicalOutput();this.reaction?.encodeRestore(encoder,target,offset);this.frame=null;this.step=null;this.receipts=[];this.invalidate();}
 beginFrame(input){return this.trackOperation(()=>this.beginFrameInner(input));}
 async beginFrameInner(input){
  if(this.closed||this.frame||!this.creation.isCurrent())throw Error('Destroyed/concurrent/stale actual joint frame');this.invalidated=false;
  this.frame={...input,usedActivation:cloneActivation(input.usedActivation)};this.receipts=[];this.acceptedFrameReceipt=null;
  if(!this.reaction)throw Error('Concrete GPU virtual response exists; authoritative physical pressure/friction provider unavailable');
  const validation=this.reaction.deviceValidation;
  if(!validation||!['receiptSha256','driverSha256','physicalPackShaderSha256','reactionShaderSha256','validatedTolerancePolicySha256','validatedAnchorPartitionPolicySha256','authenticBodyBVHAnchorProbeReceiptSha256','anchorProbeShaderSha256'].every(k=>sha(validation[k]))||!['algebraicNormalDeficitM','algebraicComplementarityResidualM','frictionResidualM'].every(k=>Number.isFinite(validation.validatedTolerances?.[k])&&validation.validatedTolerances[k]>=0)||!['sourceMaterialPartitionError','bodyBarycentricPartitionError'].every(k=>Number.isFinite(validation.validatedAnchorPartitionPolicy?.[k])&&validation.validatedAnchorPartitionPolicy[k]>=0&&validation.validatedAnchorPartitionPolicy[k]<=2e-6)||validation.actualDeviceControlsPassed!==true||validation.resourcesClosed!==true||!Array.isArray(validation.scopedCases)||validation.scopedCases.length===0)throw Error('Pressure/friction provider lacks reviewed actual-device validation receipt');
  if(validation.validatedAnchorPartitionPolicySha256!==anchorPartitionPolicySha256(validation.validatedAnchorPartitionPolicy))throw Error('Whole provider declared anchor partition policy hash changed');
  this.validatedReaction=structuredClone(validation);this.validationFingerprint=physicalCertificateSha256(validation);
  if(typeof this.options.preparePhysicalReactionInput!=='function')throw Error('Complete authentic physical row/anchor adapter unavailable');
  if(!this.virtual){
   const prepared=await this.options.prepareActualGeometry(this.creation,this.frame);
   if(!this.creation.isCurrent()||this.invalidated)throw Error('Source geometry changed during concrete backend preparation');
   if(this.creation.simulation.sourceGatherCollisionGeometry&&prepared.actualRefinedChildContextVerified!==true)throw Error('Missing actual material-coordinate refined child context; no unrefined relabel');
   this.geometry=prepared;
   const consume=prepared.backendOptions.consumeActualEnumeration;
   this.virtual=await createSourceJointNumericalClearanceBackend(this.creation.device,'fresh-source-equal-layer',{...prepared.backendOptions,creationIsCurrent:()=>!this.closed&&!this.invalidated&&this.creation.isCurrent(),exclusiveBuffersLease:true,...(prepared.actualRefinedChildContextVerified?{captureRefinedRuntimeState:key=>{if(typeof this.creation.captureRefinedRuntimeState!=='function')throw Error('Actual refined engine controller snapshot unavailable');return this.creation.captureRefinedRuntimeState(key);}}:{}),consumeActualEnumeration:async lease=>{
    if(consume)await consume(lease);this.requireCurrent();
    if(lease.numericalOnly!==true&&lease.inventory.physicalClearanceCertified===true)await this.captureFinalActualInventory(lease);
   }});
   if(!this.virtual||!this.creation.isCurrent()||this.closed||this.invalidated)throw Error('Source owner startup expired');
   await this.virtual.ready;
  }
  const usedGateSha256=await digest(await this.virtual.read(this.creation.usedGate,this.geometry.backendOptions.layout.byteLength));this.requireCurrent();
  await this.reaction.beforeFrame({generation:input.generation,frameSequence:input.frameSequence,sourceDeltaPolicySha256:input.sourceDeltaPolicySha256,usedGateSha256});this.requireCurrent();
 }
 requireCurrent(){if(this.closed||this.invalidated||!this.frame||!this.creation.isCurrent())throw Error('Actual joint frame source/body/gate generation changed');if(this.validationFingerprint&&physicalCertificateSha256(this.reaction.deviceValidation)!==this.validationFingerprint)throw Error('Actual reaction device/tolerance validation changed during frame');}
 async captureFinalActualInventory(lease){
  const input=this.pendingPhysicalInput;
  if(!input||lease.exclusiveReadLease!==true||!equalKey(lease.key,input.key)||lease.inventory.complete!==true||!lease.raw||!lease.proofBuffer||lease.rawByteLength!==lease.inventory.allRawOccurrences*128)throw Error('Missing authentic complete GPU-row/proof read lease');
  if(this.pendingPhysicalPacket)throw Error('Duplicate final physical inventory');
  const d=this.creation.device,owned=[];
  try{
   const usage=GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST;
   const alloc=(label,size)=>{if(size>d.limits.maxBufferSize||size>d.limits.maxStorageBufferBindingSize)throw Error('Physical inventory copy capacity');const b=d.createBuffer({label:'joint-physical-owned:'+label,size:Math.max(4,size),usage});owned.push(b);return b;};
   const raw=alloc('complete-Row128',lease.raw.size),proofBuffer=alloc('actual-GPU-enumeration-proof',32),current=alloc('actual-current',this.creation.simulation.particleCount*16),ideal=alloc('preserved-normal-ideal',this.creation.simulation.particleCount*16),e=d.createCommandEncoder();
   if(lease.rawByteLength)e.copyBufferToBuffer(lease.raw,0,raw,0,lease.rawByteLength);e.copyBufferToBuffer(lease.proofBuffer,0,proofBuffer,0,32);e.copyBufferToBuffer(lease.current,0,current,0,current.size);d.queue.submit([e.finish()]);await d.queue.onSubmittedWorkDone();this.requireCurrent();
   const copiedLease={...lease,raw,proofBuffer,current,proof:lease.proof.slice(),binding:{...lease.binding},inventory:{...lease.inventory},ownedActualGpuCopies:true};
   const reactionInput=await this.options.preparePhysicalReactionInput({input,creation:this.creation,actualGeometry:this.geometry,actualInventoryLease:copiedLease});this.requireCurrent();
   if(!reactionInput||reactionInput.originalParent!==this.creation.originalParent||reactionInput.history!==this.creation.materialHistory||reactionInput.actualRow128!==raw||reactionInput.actualRawProof!==proofBuffer||reactionInput.rawOccurrences!==lease.inventory.allRawOccurrences||typeof reactionInput.produceOwnedBodyAnchors!=='function'||!equalKey(reactionInput.key,input.key))throw Error('Physical row adapter did not bind owned authentic inventory/anchors');
   const rawSha256=await digest(await this.virtual.read(raw,lease.rawByteLength));this.requireCurrent();
   const originalRawProofSha256=await digest(await this.virtual.read(proofBuffer,32));this.requireCurrent();
   if(reactionInput.binding.originalRawProofSha256!==originalRawProofSha256)throw Error('Physical input binding differs from actual original GPU raw proof');
   if(reactionInput.binding.fullRawRow128Sha256!==rawSha256)throw Error('Physical binding differs from actual complete GPU Row128 bytes');
   this.pendingPhysicalPacket={reactionInput,owned,current,ideal,observedRawProof:lease.proof.slice(),expected:{rawOccurrences:lease.inventory.allRawOccurrences,parentToken:input.key.parentToken,sourceToken:lease.binding.sourceToken,bodyGeneration:lease.binding.bodyGeneration,physicalSubstep:input.key.physicalSubstep,gateRevision:input.key.gateRevision}};
  }catch(error){await d.queue.onSubmittedWorkDone().catch(()=>{});owned.forEach(b=>b.destroy());throw error;}
 }
 projectActualNumericalClearance(query,args){this.requireCurrent();if(query.originalParent!==args.parent||query.history!==args.history||query.gate!==args.gate||!equalKey(query.key,args.key)||typeof this.virtual.projectNumericalClearance!=='function')throw Error('Changed/unavailable authentic numerical seed owner');return this.virtual.projectNumericalClearance({...query,originalParent:args.parent,history:args.history,gate:args.gate,key:{...args.key},isCurrent:args.isCurrent});}
 finishPhysicalSubstep(input){return this.trackOperation(()=>this.finishPhysicalSubstepInner(input));}
 async finishPhysicalSubstepInner(input){
  this.requireCurrent();if(this.step||input.key.physicalSubstep!==this.receipts.length+1||JSON.stringify(Array.from(input.usedActivation.activeSeams))!==JSON.stringify(Array.from(this.frame.usedActivation.activeSeams))||input.usedActivation.revision!==this.frame.usedActivation.revision||input.usedActivation.sewnUpTo!==this.frame.usedActivation.sewnUpTo)throw Error('Changed actual proof-used gate/physical sequence');
  const args={parent:this.creation.originalParent,history:this.creation.materialHistory,gate:this.creation.usedGate,key:input.key,isCurrent:()=>!this.closed&&!this.invalidated&&this.creation.isCurrent()};
  this.pendingPhysicalInput=input;this.pendingPhysicalPacket=null;
  let normal,reactionInput,reactionResult,operator;
  // The reaction provider must obtain physical1mm-only λ and tangent history
  // from the actual GPU packed primitives, not reuse the numerical64u margin λ.
  try{
   normal=await this.virtual.projectPhysicalParent(args);this.requireCurrent();
   if(normal.virtualCertified!==true)throw Error('Actual autonomous GPU normal response failed: '+normal.reason);
   if(!this.pendingPhysicalPacket)throw Error('Complete authentic owned physical row/anchor packet unavailable');
   const packet=this.pendingPhysicalPacket,e=this.creation.device.createCommandEncoder();e.copyBufferToBuffer(normal.idealContactDelta,0,packet.ideal,0,packet.ideal.size);this.creation.device.queue.submit([e.finish()]);await this.creation.device.queue.onSubmittedWorkDone();this.requireCurrent();
   reactionInput={...packet.reactionInput,expected:structuredClone(packet.expected),observedRawProof:packet.observedRawProof.slice(),actualUsedGate:args.gate,actualUsedGateByteLength:this.creation.gateLayout.byteLength,isCurrent:args.isCurrent,physicalDt:input.physicalDt,projectNumericalClearance:query=>this.projectActualNumericalClearance(query,args),idealNormalDelta:packet.ideal,candidate:packet.current,inspectPhysicalCandidate:async query=>{
    if(query.originalParent!==args.parent||query.history!==args.history||!equalKey(query.key,input.key))throw Error('Changed physical requery parent/history/key');
    const fresh=await this.virtual.inspectPhysicalCandidate({...args,candidate:query.candidate});this.requireCurrent();
    if(fresh.virtualCertified!==true)throw Error('Physical provider requery failed complete actual finite certificate');
    return{certificate:fresh.certificate,raw:this.virtual.raw,rawProof:this.virtual.proof,rawOccurrences:fresh.certificate.allRawOccurrences};
   }};
   reactionResult=await this.reaction.reconcileActualReaction(reactionInput);this.requireCurrent();
   operator=await this.reaction.readActualAllContactOperatorReceipt(input.key);this.requireCurrent();
   operator=await requireActualPhysicalOperatorReadback(operator,reactionInput,this.creation.simulation.particleCount);this.requireCurrent();
   if(packet.owned.includes(reactionResult?.candidate)||packet.owned.includes(reactionResult?.idealCombinedContactDelta))throw Error('Physical provider output aliases temporary owned inputs');
  }catch(error){if(reactionResult?.release)reactionResult.release();throw error;}finally{
   const packet=this.pendingPhysicalPacket;this.pendingPhysicalPacket=null;this.pendingPhysicalInput=null;
   await this.creation.device.queue.onSubmittedWorkDone().catch(()=>{});packet?.owned.forEach(b=>b.destroy());
  }
  try{
  if(!reactionResult?.receipt||typeof reactionResult.release!=='function')throw Error('Missing actual bound physical pressure/friction receipt/output lease');
  const combined={...reactionResult,idealContactDelta:reactionResult.idealCombinedContactDelta};
  if(combined.candidate===combined.idealContactDelta||!combined.candidate||!combined.idealContactDelta)throw Error('Physical reaction lost distinct ideal/candidate buffers');
  const fresh=await this.virtual.inspectPhysicalCandidate({...args,candidate:combined.candidate});this.requireCurrent();
  if(fresh.virtualCertified!==true)throw Error('Physical pressure/tangent update failed fresh actual ALLraw certificate: '+fresh.reason);
  const c=structuredClone(fresh.certificate),r=structuredClone(combined.receipt),providerCertificate=structuredClone(combined.certificate);
  const chain={encoding:PHYSICAL_QUERY_CHAIN_ENCODING,providerBound:physicalCertificateQueryRecord(providerCertificate,physicalCertificateSha256(providerCertificate)),bridgeRequery:physicalCertificateQueryRecord(c,physicalCertificateSha256(c))};
  if(this.options.recordPhysicalCertificateEvidence){await this.options.recordPhysicalCertificateEvidence(structuredClone({stage:'provider-to-bridge-before-validation',key:input.key,reactionReceipt:r,physicalCertificateQueryChain:chain}));this.requireCurrent();}
  await verifyPhysicalCertificateQueryChain(chain,{reactionReceipt:r,requireFloor:false,certificateSha256:physicalCertificateSha256,byteSha256:digest,canonicalText:canonicalPhysicalCertificateText});this.requireCurrent();
  const refinedSeamProof=requireActualRefinedProducerProof(this.creation.simulation,c);
  validatePhysicalReactionReceipt(r,reactionInput,providerCertificate,this.validatedReaction,chain.providerBound.sha256,operator);this.requireCurrent();
  const certificate={...bindActualInventoryCertificate(c,input.key),normalReactionAuthoritative:true,normalMultiplierUnit:'kg-m',frictionReconciled:true,frictionHistoryGeneration:input.key.generation,numericalMarginIsPhysicalPressure:false,refinedSeamProof,published:false,physicalReactionReceipt:structuredClone(r),physicalCertificateQueryChain:structuredClone(chain)};
  this.step={args,certificate,combined};
  return{candidate:combined.candidate,idealContactDelta:combined.idealContactDelta,certificate};
  }catch(error){if(reactionResult?.release){const pending=reactionResult.release();if(pending&&typeof pending.then==='function')throw Error('Physical output lease release must be synchronous');}throw error;}
 }
 sealPhysicalSubstep(input){return this.trackOperation(()=>this.sealPhysicalSubstepInner(input));}
 async sealPhysicalSubstepInner(input){
  try{this.requireCurrent();if(!this.step||JSON.stringify(input.key)!==JSON.stringify(this.step.args.key))throw Error('Missing actual pending physical parent');
  const fresh=await this.virtual.inspectPhysicalCandidate({...this.step.args,candidate:input.positions});this.requireCurrent();
  if(fresh.virtualCertified!==true)throw Error('Floor/final world state failed fresh actual ALLraw certificate: '+fresh.reason);
  requireActualRefinedProducerProof(this.creation.simulation,fresh.certificate);
  if(fresh.certificate.candidateSha256!==this.step.combined.receipt.finalCandidateSha256)throw Error('Final floor changed physical reaction geometry; a new authoritative reaction is required');
  const chain={...structuredClone(this.step.certificate.physicalCertificateQueryChain),floorRequery:physicalCertificateQueryRecord(fresh.certificate,physicalCertificateSha256(fresh.certificate))};
  if(this.options.recordPhysicalCertificateEvidence){await this.options.recordPhysicalCertificateEvidence(structuredClone({stage:'bridge-to-floor-before-validation',key:input.key,reactionReceipt:this.step.combined.receipt,physicalCertificateQueryChain:chain}));this.requireCurrent();}
  await verifyPhysicalCertificateQueryChain(chain,{reactionReceipt:this.step.combined.receipt,certificateSha256:physicalCertificateSha256,byteSha256:digest,canonicalText:canonicalPhysicalCertificateText});this.requireCurrent();
  const c={...this.step.certificate,...bindActualInventoryCertificate(fresh.certificate,input.key),normalReactionAuthoritative:true,normalMultiplierUnit:'kg-m',frictionReconciled:true,frictionHistoryGeneration:input.key.generation,numericalMarginIsPhysicalPressure:false,refinedSeamProof:this.step.certificate.refinedSeamProof,published:false,physicalCertificateQueryChain:chain};await verifyPhysicalCertificateQueryChain(chain,{reactionReceipt:c.physicalReactionReceipt,outerCertificate:c,certificateSha256:physicalCertificateSha256,byteSha256:digest,canonicalText:canonicalPhysicalCertificateText});this.requireCurrent();this.receipts.push(structuredClone(c));return c;
  }finally{this.releasePhysicalOutput();}
 }
 finishFrame(){return this.trackOperation(()=>this.finishFrameInner());}
 async finishFrameInner(){this.requireCurrent();if(this.step||this.receipts.length!==40)throw Error('Incomplete actual physical40 reaction frame');}
 acceptFrame(proof){let captured;try{captured=structuredClone(proof);}catch(error){return Promise.reject(error);}return this.trackOperation(()=>this.acceptFrameInner(captured));}
 async acceptFrameInner(proof){this.requireCurrent();if(!proof.safe||!proof.finite||proof.trajectory?.valid!==true||proof.trajectory.expectedSubSteps!==40||proof.trajectory.inspectedSubsteps!==40||this.receipts.length!==40)throw Error('Missing actual complete independent41 proof');const gate=proof.seamActivation,used=this.frame.usedActivation;if(!gate||!used||gate.revision!==used.revision||gate.sewnUpTo!==used.sewnUpTo||gate.activeSeams.length!==used.activeSeams.length||gate.activeSeams.some((v,i)=>v!==used.activeSeams[i]))throw Error('Physical reaction proof used a foreign sewing activation');const deltaByteBinding=structuredClone(requireActualPhysicalDeltaByteProof(proof,this.frame,this.creation));const workerByteBinding=structuredClone(requireActualJointWorkerByteProof(proof));const frame=structuredClone(this.frame),physicalReceipts=structuredClone(this.receipts);
  for(let i=0;i<40;i++){const c=physicalReceipts[i];if(!c||c.key?.physicalSubstep!==i+1||c.key.generation!==frame.generation||c.key.frameSequence!==frame.frameSequence||c.key.gateRevision!==used.revision||c.historySha256!==workerByteBinding.sampleSha256s[i]||c.candidateSha256!==workerByteBinding.sampleSha256s[i+1]||!c.physicalReactionReceipt)throw Error('Missing owned per-substep physical reaction receipt');}
  const activationBytes=new ArrayBuffer((4+used.activeSeams.length)*8),activationView=new DataView(activationBytes);[1,used.revision,used.sewnUpTo,used.activeSeams.length,...used.activeSeams].forEach((v,i)=>activationView.setFloat64(i*8,v,true));
  if(workerByteBinding.activationSha256!==await digest(activationBytes))throw Error('Worker byte proof used a foreign activation hash');
  const proofSha256=await actualGuardProofSha256(proof);this.requireCurrent();
  requireSourceBodyFacetTrajectoryProof(proof);
  requireSourceSelfIntervalTrajectoryProof(proof);
  const pressureAcceptance=await this.reaction.acceptFrame(proofSha256);this.requireCurrent();
  if(!pressureAcceptance||pressureAcceptance.all41GuardProofSha256!==proofSha256||pressureAcceptance.generation!==frame.generation||pressureAcceptance.frameSequence!==frame.frameSequence||!sha(pressureAcceptance.pressureHistorySha256)||pressureAcceptance.usedGateSha256!==physicalReceipts[0].usedGateSha256||pressureAcceptance.physicalSubstepsCommitted!==40||pressureAcceptance.actualReactionReceiptSha256s?.length!==40||pressureAcceptance.actualReactionReceiptSha256s.some((v,i)=>v!==physicalCertificateSha256(physicalReceipts[i].physicalReactionReceipt)))throw Error('Missing actual accepted pressure-history receipt');
  const receipt={kind:'actual-source-joint-frame-commit-v1',generation:frame.generation,frameSequence:frame.frameSequence,sourceDeltaPolicySha256:frame.sourceDeltaPolicySha256,verifiedWorkerRequest:workerByteBinding,verifiedPhysicalDeltaTrace:deltaByteBinding,backendImplementationSha256:this.implementationSha256,pressureProviderImplementationSha256:this.reaction.implementationSha256,usedActivation:cloneActivation(used),all41GuardProofSha256:proofSha256,physicalSubsteps:40,geometrySamples:41,physicalReceipts,physicalReceiptsSha256:await physicalReceiptListSha256(physicalReceipts),frameReceiptEncoding:PHYSICAL_FRAME_RECEIPT_ENCODING,pressureAcceptance:structuredClone(pressureAcceptance),pressureHistorySha256:pressureAcceptance.pressureHistorySha256,accepted:true,fullFitAccepted:false};
  receipt.frameCommitSha256=await physicalFrameReceiptSha256(receipt);this.requireCurrent();this.acceptedFrameReceipt=structuredClone(receipt);this.frame=null;this.step=null;}
 invalidate(){this.acceptedFrameReceipt=null;this.invalidated=true;this.virtual?.invalidate();this.reaction?.invalidate();}
 resetHistory(){this.releasePhysicalOutput();this.invalidate();this.reaction?.resetHistory();this.frame=null;this.step=null;this.receipts=[];}
 trackOperation(run){if(this.closed)return Promise.reject(Error('Destroyed actual joint backend'));const operation=Promise.resolve().then(run);this.activeOperations.add(operation);void operation.then(()=>this.activeOperations.delete(operation),()=>this.activeOperations.delete(operation));return operation;}
 destroy(){if(this.closePromise)return this.closePromise;this.closed=true;this.invalidate();this.closePromise=(async()=>{await Promise.allSettled(Array.from(this.activeOperations));try{await this.virtual?.destroy();}finally{await this.reaction?.destroy();}})();return this.closePromise;}
}
