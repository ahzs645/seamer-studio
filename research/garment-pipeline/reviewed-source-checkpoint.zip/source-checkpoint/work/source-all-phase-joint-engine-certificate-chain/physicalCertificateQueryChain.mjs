/** Portable query lineage. V2 individual hashes retain each actual observation epoch. */
export const PHYSICAL_QUERY_CHAIN_ENCODING='source-physical-certificate-query-chain-v1';
const SHA=/^[a-f0-9]{64}$/;
const requireValue=(v,m)=>{if(!v)throw Error(m);};
const copy=v=>structuredClone(v);
export function physicalCertificateQueryRecord(certificate,sha256){requireValue(SHA.test(sha256),'Missing actual query certificate SHA');return{certificate:copy(certificate),sha256};}
function stable(c){const v=copy(c);delete v.executedGeometryDescriptor.observedSnapshotEpoch;delete v.executedGeometryDescriptor.executedGeometryDescriptorSha256;return v;}
export async function verifyPhysicalCertificateQueries(records,{certificateSha256,byteSha256,canonicalText}){
 records=copy(records);
 requireValue(Array.isArray(records)&&records.length>=1&&records.length<=3,'Invalid physical query count');
 let first=null,priorEpoch=-1;
 for(const record of records){requireValue(record&&Object.keys(record).length===2&&Object.hasOwn(record,'certificate')&&Object.hasOwn(record,'sha256'),'Unknown physical query record fields');const c=copy(record?.certificate),d=c?.executedGeometryDescriptor;
  requireValue(c&&SHA.test(record.sha256)&&await certificateSha256(c)===record.sha256,'Actual query certificate hash differs');
  requireValue(c.complete===true&&c.physicalClearanceCertified===true&&c.actualGpuFiniteProducer===true&&c.allCurrentRawOccurrencesChecked===true&&c.physicalMassAndFixedBitsUnchanged===true,'Incomplete actual query certificate');
  requireValue(Number.isSafeInteger(c.rawOccurrences)&&c.rawOccurrences>=0&&c.rawOccurrences===c.allRawOccurrences&&c.rawOccurrences===c.validatedOccurrences&&c.unsupported===0&&c.unsupportedFlags===0&&c.clearanceDeficits===0&&c.strictClearanceDeficits===0,'Invalid actual query inventory');
  requireValue(Number.isFinite(c.maximumOriginalParentNetM)&&c.maximumOriginalParentNetM>=0&&c.maximumOriginalParentNetM<=.005,'Invalid actual query NET');
  requireValue(c.rawOccurrences===0?c.minimumLowerBoundM===Infinity&&c.minimumClearanceLowerBoundM===Infinity:Number.isFinite(c.minimumLowerBoundM)&&c.minimumLowerBoundM>=.001&&Number.isFinite(c.minimumClearanceLowerBoundM)&&c.minimumClearanceLowerBoundM>=.001,'Invalid actual query clearance');
  requireValue(d&&Number.isSafeInteger(d.observedSnapshotEpoch)&&d.observedSnapshotEpoch>=0&&d.observedSnapshotEpoch<=0xffffffff&&d.observedSnapshotEpoch>priorEpoch&&d.geometryReadbackBinding==='ordered-full-owned-GPU-geometry-readback-v1','Invalid actual query observation lineage');
  const {executedGeometryDescriptorSha256,...body}=d;
  requireValue(SHA.test(executedGeometryDescriptorSha256)&&await byteSha256(new TextEncoder().encode(JSON.stringify(Object.fromEntries(Object.entries(body).sort(([a],[b])=>a.localeCompare(b))))))===executedGeometryDescriptorSha256,'Executed geometry descriptor hash differs');
  for(const name of ['sourceSha256','bodySha256','topologySha256','bodyFaceCount'])requireValue(d[name]===c[name],'Query executed geometry binding differs: '+name);
  for(const[a,b]of [['observedCurrentSha256','candidateSha256'],['observedHistorySha256','historySha256'],['observedGateSha256','usedGateSha256']])requireValue(SHA.test(c[b])&&d[a]===c[b],'Query physical observation differs: '+b);
  priorEpoch=d.observedSnapshotEpoch;const text=canonicalText(stable(c));if(first===null)first=text;else requireValue(text===first,'Physical query content changed outside its observation epoch');
 }
 return true;
}
export async function verifyPhysicalCertificateQueryChain(chain,{reactionReceipt,outerCertificate=null,requireFloor=true,...hashes}){
 chain=copy(chain);reactionReceipt=copy(reactionReceipt);outerCertificate=copy(outerCertificate);
 requireValue(chain?.encoding===PHYSICAL_QUERY_CHAIN_ENCODING,'Missing physical query chain encoding');
 requireValue(Object.keys(chain).every(k=>['encoding','providerBound','bridgeRequery','floorRequery'].includes(k)),'Unknown physical query chain fields');
 const names=['providerBound','bridgeRequery',...(requireFloor?['floorRequery']:[])],records=names.map(k=>chain[k]);
 requireValue(records.every(Boolean),'Incomplete physical query chain');
 requireValue(reactionReceipt?.actualFreshAllRawCertificateSha256===chain.providerBound.sha256,'Reaction does not bind the original provider query');
 await verifyPhysicalCertificateQueries(records,hashes);
 if(outerCertificate){const outer=copy(outerCertificate);delete outer.physicalCertificateQueryChain;delete outer.physicalReactionReceipt;outer.normalReactionAuthoritative=false;outer.frictionReconciled=false;
  requireValue(hashes.canonicalText(outer)===hashes.canonicalText(records.at(-1).certificate),'Published physical certificate differs from the final actual query');
 }
 return true;
}
