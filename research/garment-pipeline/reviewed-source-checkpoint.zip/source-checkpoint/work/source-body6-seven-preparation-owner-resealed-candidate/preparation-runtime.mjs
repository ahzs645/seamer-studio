import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
export const PREPARATION_ROOT=new URL('.',import.meta.url).pathname;
export const bytesSha256=value=>createHash('sha256').update(value).digest('hex');
const typedPrototype=Object.getPrototypeOf(Uint8Array.prototype);
const bufferGetter=Object.getOwnPropertyDescriptor(typedPrototype,'buffer').get;
const offsetGetter=Object.getOwnPropertyDescriptor(typedPrototype,'byteOffset').get;
const lengthGetter=Object.getOwnPropertyDescriptor(typedPrototype,'byteLength').get;
export const typedSha256=value=>bytesSha256(Buffer.from(bufferGetter.call(value),offsetGetter.call(value),lengthGetter.call(value)));
const file=PREPARATION_ROOT+'runtime-manifest.json';
export function readCurrentPreparationRuntime(expectedSha256){
 const bytes=fs.readFileSync(file),sha256=bytesSha256(bytes);
 if(expectedSha256)assert.equal(sha256,expectedSha256,'Preparation runtime epoch changed');
 const manifest=JSON.parse(bytes);
 assert.equal(manifest.kind,'owned-fresh-body6-source-preparation-runtime-v1');
 assert.equal(manifest.sourceBodyFitRevision,6);
 for(const [path,hash] of Object.entries(manifest.files))assert.equal(bytesSha256(fs.readFileSync(path)),hash,'Changed owned preparation runtime: '+path);
 for(const [path,hash] of Object.entries(manifest.historicalManifests??{}))assert.equal(bytesSha256(fs.readFileSync(path)),hash,'Changed historical manifest bytes');
 const freeze=value=>{if(value&&typeof value==='object'){for(const child of Object.values(value))freeze(child);Object.freeze(value);}};
 freeze(manifest);return Object.freeze({manifest,sha256});
}
