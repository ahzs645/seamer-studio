/** Test transport only: actual owned browser Worker module in a separate CPU realm. */
import {parentPort} from 'node:worker_threads';
if(!parentPort)throw Error('CPU Worker transport requires its actual isolated parent port');
const listeners=[];
globalThis.self={addEventListener(name,callback){if(name!=='message')throw Error('Unexpected Worker event');listeners.push(callback);},postMessage(message){parentPort.postMessage(message);}};
await import('./compiled/preparation-worker.mjs');
parentPort.on('message',data=>{for(const listener of listeners)listener({data});});
