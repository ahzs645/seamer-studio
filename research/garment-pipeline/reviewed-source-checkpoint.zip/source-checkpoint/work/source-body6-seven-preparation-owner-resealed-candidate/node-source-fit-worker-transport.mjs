/** CPU transport only. Execute the actual owned browser source-fit worker entry. */
import {parentPort} from 'node:worker_threads';
if(!parentPort)throw Error('Source-fit transport requires an isolated parent');
globalThis.self=globalThis;globalThis.location={href:new URL('./compiled/source-fit-worker.mjs',import.meta.url).href};
globalThis.postMessage=(value,transfers)=>parentPort.postMessage(value,transfers);
await import('./compiled/source-fit-worker.mjs');
parentPort.on('message',data=>globalThis.onmessage({data}));
