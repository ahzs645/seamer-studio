/** Freeze all actually imported bytes before the first CPU execution. */
import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
const root=new URL('.',import.meta.url).pathname,sha=b=>createHash('sha256').update(b).digest('hex'),files=new Map();
const add=(file,role,logical=path.relative(root,file))=>{const b=fs.readFileSync(file);files.set(file,{path:file,logical,role,sha256:sha(b)});};
const walk=(dir,role)=>{for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())walk(p,role);else if(e.isFile())add(p,role);}};
for(const name of ['README.md','strip-original-inputs.mjs','freeze-execution.mjs','build.mjs','regenerate.mjs','capture-anatomy.mjs','adopt-reviewed-body-graph.mjs','compare-held-numerics.mjs','node-cpu-worker-transport.mjs','node-source-fit-worker-transport.mjs','build-receipt.json','origin-copy.json','body6-source-adoption.json'])add(root+name,'owned-bootstrap');
walk(root+'compiled','compiled');walk(root+'inputs','owned-original-input');walk(root+'model-assets','owned-original-model');
const build=JSON.parse(fs.readFileSync(root+'build-receipt.json'));
for(const r of build.sourceInputs){if(sha(fs.readFileSync(r.path))!==r.sha256)throw Error('Build input changed '+r.path);add(r.path,r.path.startsWith(root)?'actual-runtime-source':'build-dependency',r.path.startsWith(root)?path.relative(root,r.path):r.path);}
const body6=JSON.parse(fs.readFileSync(root+'body6-source-adoption.json'));
for(const r of body6.files){if(sha(fs.readFileSync(r.owned))!==r.sha256)throw Error('Frozen body6 copied source differs '+r.owned);add(r.owned,'actual-body6-source');}
const manifest={kind:'owned-genuine-body6-preparation-execution-v1',CPUOnly:true,GPUInitialized:false,browserLaunched:false,sourceFitRevision:6,actualMainAndWorkerGraph:true,ownedRuntimeFrozenBeforeImport:true,allocationAuthorized:false,fitAccepted:false,body6OriginManifest:{path:body6.manifestPath,sha256:body6.manifestSha256,historicalOnly:true},files:[...files.values()].sort((a,b)=>a.path.localeCompare(b.path))};
const file=root+'execution-pins.json';fs.writeFileSync(file,JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({path:file,sha256:sha(fs.readFileSync(file)),files:manifest.files.length}));
