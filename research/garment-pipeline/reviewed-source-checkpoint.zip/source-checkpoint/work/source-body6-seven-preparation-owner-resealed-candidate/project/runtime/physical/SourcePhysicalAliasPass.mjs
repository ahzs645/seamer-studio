import{wholePhysicalAliasWGSL,groupActualPhysicalAliasKeys,requirePhysicalIncomingRawProof}from'./wholePhysicalAliasWGSL.mjs';
const SHA=/^[a-f0-9]{64}$/,u32=n=>Number.isSafeInteger(n)&&n>=0&&n<=0xffffffff;
/** NEW whole-provider resource, NOT device validated. Authentic ALLraw lease is
 * supplied by the finite backend; this stage never manufactures geometry. */
export function createSourcePhysicalAliasPass(device,scope,options){return scope==='fresh-source-physical-profile'?new SourcePhysicalAliasPass(device,options):null;}
export class SourcePhysicalAliasPass{
 #device;#options;#owned=[];#closing=false;#closed=false;#busy=false;#pending=null;#closePromise=null;#generation=0;#records;#state;#params;#readback;#layout;#pipelines;
 constructor(device,options,assertCurrent=()=>true){assertCurrent();
  this.#device=device;this.#options=Object.freeze(structuredClone(options));const {rawCapacity,particles}=this.#options;
  if(!u32(rawCapacity)||rawCapacity<1||rawCapacity>0xffffffff/40||!u32(particles)||particles<1||device.limits.maxStorageBuffersPerShaderStage<4)throw Error('Invalid complete physical alias capacity');
  const make=(label,size,usage)=>{if(size>device.limits.maxStorageBufferBindingSize)throw Error('Complete physical aliases exceed binding limit');const b=device.createBuffer({label,size,usage});this.#owned.push(b);return b;};
  try{const writable=GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST;
   this.#records=make('physical ALLraw exact keys',rawCapacity*160,writable);this.#state=make('physical ALLraw key proof',32,writable);this.#params=make('physical immutable key epoch',32,GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST);this.#readback=make('physical ALLraw keys readback',32+rawCapacity*160,GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ);
   const entries=Array.from({length:5},(_,binding)=>({binding,visibility:GPUShaderStage.COMPUTE,buffer:{type:binding===4?'uniform':binding<2?'read-only-storage':'storage'}}));this.#layout=device.createBindGroupLayout({entries});const pipelineLayout=device.createPipelineLayout({bindGroupLayouts:[this.#layout]}),module=device.createShaderModule({code:wholePhysicalAliasWGSL});
   this.ready=(async()=>{const info=await module.getCompilationInfo();assertCurrent();const errors=info.messages.filter(x=>x.type==='error');if(errors.length)throw Error(errors.map(x=>`${x.lineNum}:${x.linePos} ${x.message}`).join('\n'));if(this.#closing)throw Error('Physical alias pass closed during ready');this.#pipelines=Object.fromEntries(['reset','emit','complete'].map(entryPoint=>[entryPoint,device.createComputePipeline({layout:pipelineLayout,compute:{module,entryPoint}})]));})();this.ready.catch(()=>{});
  }catch(error){for(const b of this.#owned)b.destroy();this.#owned=[];throw error;}
 }
 invalidate(){this.#generation++;}
 get keyRecordsBuffer(){return this.#records;}
 inspectAllRaw(input){
  if(this.#closed||this.#closing||this.#busy)return Promise.reject(Error('Physical alias pass concurrent/closed'));
  const generation=this.#generation,handles={raw:input.raw,rawProof:input.rawProof},expected=structuredClone(input.expected),binding=structuredClone(input.binding),incomingProof=structuredClone(input.observedRawProof),isCurrent=input.isCurrent;this.#busy=true;
  const work=(async()=>{let mapped=false;try{
   await this.ready;if(this.#closing||generation!==this.#generation||isCurrent?.()!==true)throw Error('Physical alias lease stale before encode');
   if(!expected||Object.values(expected).some(x=>!u32(x))||expected.rawOccurrences>this.#options.rawCapacity||expected.physicalSubstep<1||expected.physicalSubstep>40||expected.bodyGeneration<1||expected.sourceToken<1||expected.parentToken<1||!binding||['fullRawRow128Sha256','originalParentSha256','historySha256','usedGateSha256','bodySha256','sourceSha256','physicalMassPolicySha256'].some(k=>!SHA.test(binding[k]))||binding.authenticAllRawReadLease!==true)throw Error('Missing complete physical alias binding');
   requirePhysicalIncomingRawProof(incomingProof,expected.rawOccurrences);
   if(!handles.raw||handles.raw.size%128||handles.raw.size<expected.rawOccurrences*128||!handles.rawProof||handles.rawProof.size!==32||handles.raw===handles.rawProof||this.#owned.includes(handles.raw)||this.#owned.includes(handles.rawProof))throw Error('Incomplete/aliased physical raw packet');
   const rawCapacity=handles.raw.size/128,words=Uint32Array.of(expected.rawOccurrences,this.#options.particles,rawCapacity,expected.parentToken,expected.sourceToken,expected.bodyGeneration,expected.physicalSubstep,expected.gateRevision);this.#device.queue.writeBuffer(this.#params,0,words);
   const e=this.#device.createCommandEncoder();e.clearBuffer(this.#state);const group=this.#device.createBindGroup({layout:this.#layout,entries:[{binding:0,resource:{buffer:handles.raw}},{binding:1,resource:{buffer:handles.rawProof}},{binding:2,resource:{buffer:this.#records,size:Math.max(160,expected.rawOccurrences*160)}},{binding:3,resource:{buffer:this.#state}},{binding:4,resource:{buffer:this.#params}}]});
   if(expected.rawOccurrences===0){throw Error('Empty inventory uses explicit no-contact provider branch; no fabricated zero-sized alias storage');}
   for(const [entryPoint,groups]of[['reset',1],['emit',Math.ceil(expected.rawOccurrences/64)],['complete',1]]){const pass=e.beginComputePass();pass.setPipeline(this.#pipelines[entryPoint]);pass.setBindGroup(0,group);pass.dispatchWorkgroups(groups);pass.end();}
   e.copyBufferToBuffer(this.#state,0,this.#readback,0,32);e.copyBufferToBuffer(this.#records,0,this.#readback,32,expected.rawOccurrences*160);this.#device.queue.submit([e.finish()]);await this.#readback.mapAsync(GPUMapMode.READ);mapped=true;
   const bytes=this.#readback.getMappedRange().slice(0,32+expected.rawOccurrences*160);if(this.#closing||generation!==this.#generation||isCurrent()!==true)throw Error('Physical alias lease stale during readback');
   const proof=new Uint32Array(bytes,0,8).slice(),records=new Uint32Array(bytes,32).slice(),groups=groupActualPhysicalAliasKeys(records,proof,expected);
   return{...groups,records,proof,binding:structuredClone(binding),expected,actualGpuKeyReceipt:true,physicalPressureAuthoritative:false};
  }finally{if(mapped)this.#readback.unmap();this.#busy=false;}})();this.#pending=work;work.then(()=>{if(this.#pending===work)this.#pending=null;},()=>{if(this.#pending===work)this.#pending=null;});return work;
 }
 destroy(){if(this.#closePromise)return this.#closePromise;this.#closing=true;this.invalidate();this.#closePromise=(async()=>{const errors=[];await this.ready.catch(e=>errors.push(e));if(this.#pending)await this.#pending.catch(e=>errors.push(e));try{await this.#device.queue.onSubmittedWorkDone();}catch(e){errors.push(e);}finally{for(const b of this.#owned)try{b.destroy();}catch(e){errors.push(e);}this.#owned=[];this.#closed=true;}if(errors.length)throw new AggregateError(errors,'Physical alias cleanup failed');})();return this.#closePromise;}
}
