/** Actual GPU-only source/anchor handoff. No CPU geometry rows, ray votes, old
 * anchors or readiness booleans are supplied by this portable adapter. */
import {createSourceExecutedBodyAnchorV2} from './anchor-source/SourceExecutedBodyAnchorV2.mjs';
import {physicalBytesSha256 as digest,physicalCertificateSha256} from './portablePhysicalHashes.mjs';
import {copyData,equalData} from './snapshots.mjs';
import {sourceDeclaredFrictionProfileSha256} from './physical/declaredFrictionProfile.mjs';
import {requirePhysicalIncomingRawProof} from './physical/wholePhysicalAliasWGSL.mjs';
const exact=x=>x instanceof ArrayBuffer?new Uint8Array(x.slice(0)):ArrayBuffer.isView(x)?new Uint8Array(x.buffer,x.byteOffset,x.byteLength).slice():(()=>{throw Error('Actual exact GPU bytes required');})();
const fields=['generation','frameSequence','physicalSubstep','parentToken','gateRevision'],sameKey=(a,b)=>fields.every(k=>a?.[k]===b?.[k]);
const keySnapshot=k=>{const key=Object.fromEntries(fields.map(f=>[f,k?.[f]]));if(!Object.values(key).every(v=>Number.isSafeInteger(v)&&v>=0&&v<=0xffffffff)||!key.parentToken||!key.frameSequence||key.physicalSubstep<1||key.physicalSubstep>40)throw Error('Actual physical anchor key required');return Object.freeze(key);};
export function createActualOwnedBodyAnchorHandoff(options,scope='fresh-source-equal-layer'){
 if(scope!=='fresh-source-equal-layer')return null;
 const {device,readGpuBytes}=options;
 if(typeof readGpuBytes!=='function')throw Error('Actual GPU readback callback required');
 const owner=createSourceExecutedBodyAnchorV2(device,scope);let closed=false;
 return Object.freeze({bindActualInventory({lease,originalParent,history,isCurrent}){
  if(closed||lease?.exclusiveReadLease!==true||lease.inventory?.complete!==true||lease.inventory?.physicalClearanceCertified!==true||!lease.executedGeometryOwner||!lease.executedGeometryReadbackReceipt||!lease.preparedAnchorGeometry||!lease.observedSnapshot||typeof isCurrent!=='function'||isCurrent()!==true)throw Error('Authentic complete original GPU inventory/descriptor required');
  const key=keySnapshot(lease.key),count=lease.inventory.allRawOccurrences,gate=lease.gate,raw=lease.raw,proofBuffer=lease.proofBuffer,parentSha=lease.originalParentSha256;
  if(!Number.isSafeInteger(count)||count<0||count>262144||originalParent!==lease.originalParent||history!==lease.history)throw Error('Original physical anchor inventory changed');
  const metadata={prepared:lease.preparedAnchorGeometry,descriptor:lease.executedGeometryOwner,receipt:lease.executedGeometryReadbackReceipt,layout:copyData(lease.gateLayout),binding:copyData(lease.binding),observed:{...lease.observedSnapshot,current:lease.observedSnapshot.current.slice(),previous:lease.observedSnapshot.previous.slice(),gateWords:lease.observedSnapshot.gateWords.slice(),binding:copyData(lease.observedSnapshot.binding)}};
  let running=false,rawSha=null,proofSha=null;
  return async request=>{
   if(closed||running||isCurrent()!==true||!sameKey(request.key,key)||request.originalParent!==originalParent||request.history!==history||request.actualRow128!==raw||request.actualRawProof!==proofBuffer||request.rawOccurrences!==count||!request.current)throw Error('Stale/foreign/concurrent original body anchor request');
   if(count===0)throw Error('Empty inventory has no material anchor query');
   const current=request.current,binding=copyData(request.binding),requestKey=keySnapshot(request.key);
   for(const name of ['sourceSha256','bodySha256','topologySha256'])if(binding[name]!==metadata.binding[name])throw Error('Body anchor source/body/topology binding changed');
   const valid=()=>{if(closed||isCurrent()!==true||request.current!==current||request.originalParent!==originalParent||request.history!==history||request.actualRow128!==raw||request.actualRawProof!==proofBuffer||request.rawOccurrences!==count||!sameKey(request.key,requestKey)||!equalData(copyData(request.binding,false),binding))throw Error('Body anchor request changed across await');return true;};
   running=true;try{
    const read=async(b,n)=>{const bytes=exact(await readGpuBytes(b,n));valid();if(bytes.byteLength!==n)throw Error('Truncated actual anchor readback');return bytes;};
    const hashes=async bytes=>{const h=await digest(bytes);valid();return h;};
    const now=await read(current,metadata.observed.current.byteLength),old=await read(history,metadata.observed.previous.byteLength),gateBytes=await read(gate,metadata.layout.byteLength),rows=await read(raw,count*128),proof=await read(proofBuffer,32);
    const rowHash=await hashes(rows),proofHash=await hashes(proof),historyHash=await hashes(old),gateHash=await hashes(gateBytes),currentHash=await hashes(now);
    if(rawSha!==null&&(rawSha!==rowHash||proofSha!==proofHash))throw Error('Original raw weights/proof changed across anchor queries');rawSha=rowHash;proofSha=proofHash;
    if(binding.currentSha256!==currentHash||binding.fullRawRow128Sha256!==rowHash||binding.historySha256!==historyHash||binding.originalParentSha256!==parentSha||binding.usedGateSha256!==gateHash)throw Error('Body anchor request differs from actual GPU byte hashes');
    const observed={...metadata.observed,currentBuffer:current,previousBuffer:history,gateBuffer:gate,current:new Float32Array(now.buffer),previous:new Float32Array(old.buffer),gateWords:new Uint32Array(gateBytes.buffer),binding:{...metadata.binding,currentSha256:currentHash,historySha256:historyHash,gateSha256:gateHash}};
    const out=await owner.produceActual({prepared:metadata.prepared,observed,gate,gateLayout:metadata.layout,raw,rawProof:proofBuffer,count,originalParent,originalParentSha256:parentSha,key,epoch:{sourceToken:metadata.binding.sourceToken,bodyGeneration:metadata.binding.bodyGeneration,gateRevision:key.gateRevision,correctedSubstep:key.physicalSubstep},executedGeometryOwner:metadata.descriptor,executedGeometryReadbackReceipt:metadata.receipt,readGpuBytes:read,isCurrent:()=>{try{return valid();}catch{return false;}},exclusiveReadLease:true});
    try{valid();}catch(error){await owner.releaseOutput(out.token);throw error;}
    let release;return Object.freeze({...out,release(){if(!release)release=owner.releaseOutput(out.token);return release;}});
   }finally{running=false;}
  };
 },destroy(){closed=true;return owner.destroy();}});
}
export async function readActualGPUAnchorBytes(device,buffer,n){
 if(!Number.isSafeInteger(n)||n<0||n%4||n>buffer.size)throw Error('Actual GPU readback range invalid');if(!n)return new Uint8Array(0);
 let staging,mapped=false;try{staging=device.createBuffer({label:'app-owned-anchor-readback',size:n,usage:GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ});const e=device.createCommandEncoder();e.copyBufferToBuffer(buffer,0,staging,0,n);device.queue.submit([e.finish()]);await staging.mapAsync(GPUMapMode.READ);mapped=true;const bytes=exact(staging.getMappedRange());if(bytes.byteLength!==n)throw Error('Truncated actual GPU anchor byte readback');return bytes;}finally{if(mapped)staging.unmap();staging?.destroy();}
}
export function createActualPhysicalReactionInputAdapter({prepared,sourceBinding,rawCapacity,frictionProfile,deviceValidation,anchorHandoff}){
 const own=(o,k)=>{const d=Object.getOwnPropertyDescriptor(o,k);if(!d||!d.enumerable||!Object.hasOwn(d,'value'))throw Error('Actual own SI preparation input required');return d.value;};
 const sim=own(prepared,'simData'),material=own(sim,'sourcePhysicalMembrane');
 // Only these actual immutable fields are consumed; production edgeRuns is an
 // unrelated intrinsic Map, not a copied geometry or an alternate registry.
 const s=copyData({particleCount:own(sim,'particleCount'),positions:own(sim,'positions'),sourcePhysicalMembrane:{policySha256:own(material,'policySha256')}}),source=copyData(sourceBinding),friction=copyData(frictionProfile),validation=copyData(deviceValidation);
 if(!Number.isSafeInteger(rawCapacity)||rawCapacity<1||rawCapacity>262144||!Number.isSafeInteger(s.particleCount)||s.particleCount<1||!(s.positions instanceof Float32Array)||s.positions.length!==s.particleCount*4||!s.positions.every((v,i)=>Number.isFinite(v)&&(i%4!==3||v>=0))||!s.sourcePhysicalMembrane?.policySha256||typeof anchorHandoff?.bindActualInventory!=='function')throw Error('Actual SI pressure/input owner required');
 const massWords=new Uint32Array(s.positions.buffer,s.positions.byteOffset,s.positions.length),massBits=Uint32Array.from({length:s.particleCount},(_,i)=>massWords[i*4+3]);
 return async ({input,creation,actualInventoryLease:lease})=>{
  const key=keySnapshot(input.key),inventory=copyData(lease.inventory),observed=copyData(lease.binding),proof=lease.proof.slice(),parent=creation.originalParent,history=creation.materialHistory,current=lease.current,gate=creation.usedGate,raw=lease.raw,proofBuffer=lease.proofBuffer;
  const valid=()=>{if(creation.isCurrent()!==true||creation.originalParent!==parent||creation.materialHistory!==history||creation.usedGate!==gate||lease.current!==current||lease.raw!==raw||lease.proofBuffer!==proofBuffer||!sameKey(lease.key,key)||!equalData(copyData(lease.binding,false),observed)||!sameKey(input.key,key))throw Error('Actual physical input generation/handles/key changed');return true;};valid();
  if(!sameKey(lease.key,key)||lease.originalParent!==parent||lease.history!==history||lease.gate!==gate||observed.historyToken!==key.parentToken||observed.gateToken!==key.gateRevision)throw Error('Actual physical inventory key/history/gate owner changed');
  if(lease.ownedActualGpuCopies!==true||lease.exclusiveReadLease!==true||inventory.complete!==true||inventory.physicalClearanceCertified!==true||lease.raw.size!==rawCapacity*128)throw Error('Actual complete owned raw GPU inventory required');requirePhysicalIncomingRawProof(proof,inventory.allRawOccurrences);
  const seen={},read=async(buffer,n)=>{const a=exact(await readActualGPUAnchorBytes(creation.device,buffer,n));valid();return a;},hash=async a=>{const h=await digest(a);valid();return h;};
  for(const[name,buffer,n]of [['parent',parent,s.particleCount*16],['history',history,s.particleCount*16],['current',current,s.particleCount*16],['raw',lease.raw,inventory.allRawOccurrences*128],['proof',lease.proofBuffer,32],['gate',gate,creation.gateLayout.byteLength]])seen[name]=await read(buffer,n);
  for(const name of ['parent','history','current']){const w=new Uint32Array(seen[name].buffer);for(let i=0;i<s.particleCount;i++)if(w[i*4+3]!==massBits[i])throw Error('Actual SI/fixed W bits differ');}
  const hashes={};for(const name of Object.keys(seen))hashes[name]=await hash(seen[name]);
  if(hashes.current!==observed.currentSha256||hashes.history!==observed.historySha256||hashes.gate!==observed.gateSha256||hashes.parent!==lease.originalParentSha256||hashes.proof!==await hash(proof)||observed.sourceSha256!==source.sourceSha256||observed.bodySha256!==source.bodySha256||observed.topologySha256!==source.topologySha256)throw Error('Actual original SI/raw/body/topology byte binding changed');
  const declaredFrictionProfileSha256=await sourceDeclaredFrictionProfileSha256(friction);valid();
  const binding={...observed,key,rawOccurrences:inventory.allRawOccurrences,originalParentSha256:hashes.parent,historySha256:hashes.history,currentSha256:hashes.current,usedGateSha256:hashes.gate,fullRawRow128Sha256:hashes.raw,originalRawOccurrences:inventory.allRawOccurrences,originalRawRow128Sha256:hashes.raw,originalRawProofSha256:hashes.proof,physicalMassPolicySha256:s.sourcePhysicalMembrane.policySha256,declaredFrictionProfileSha256,executedTolerancePolicySha256:validation.validatedTolerancePolicySha256,executedAnchorPartitionPolicySha256:validation.validatedAnchorPartitionPolicySha256};
  let actualEmptyCertificate;if(inventory.allRawOccurrences===0){if(hashes.current!==hashes.parent)throw Error('Empty corrected inventory cannot substitute for original-parent emptiness');actualEmptyCertificate={...inventory,key,rawOccurrences:0,unsupported:inventory.unsupportedFlags,clearanceDeficits:inventory.strictClearanceDeficits,minimumClearanceLowerBoundM:inventory.minimumLowerBoundM,originalParentSha256:hashes.parent,historySha256:hashes.history,candidateSha256:hashes.current,sourceSha256:source.sourceSha256,bodySha256:source.bodySha256,usedGateSha256:hashes.gate,actualGpuFiniteProducer:true,allCurrentRawOccurrencesChecked:true,physicalMassAndFixedBitsUnchanged:true,maximumOriginalParentNetM:0};binding.emptyInventoryCertificateSha256=await physicalCertificateSha256(actualEmptyCertificate);valid();}
  // Authenticate the actual immutable GPU inputs a second time after all async
  // policy/certificate work. This flag records this completed read lease only.
  for(const [name,buffer,n]of [['parent',parent,s.particleCount*16],['history',history,s.particleCount*16],['current',current,s.particleCount*16],['raw',raw,inventory.allRawOccurrences*128],['proof',proofBuffer,32],['gate',gate,creation.gateLayout.byteLength]]){const after=await read(buffer,n);if(await hash(after)!==hashes[name])throw Error('Actual owned raw/proof or parent/history/current/gate changed during input capture');}
  binding.authenticAllRawReadLease=true;
  const produceOwnedBodyAnchors=anchorHandoff.bindActualInventory({lease,originalParent:parent,history,isCurrent:()=>{try{return valid();}catch{return false;}}});
  return {key,binding,rawOccurrences:inventory.allRawOccurrences,originalParent:parent,history,actualRow128:lease.raw,actualRawProof:lease.proofBuffer,produceOwnedBodyAnchors,actualEmptyCertificate};
 };
}
