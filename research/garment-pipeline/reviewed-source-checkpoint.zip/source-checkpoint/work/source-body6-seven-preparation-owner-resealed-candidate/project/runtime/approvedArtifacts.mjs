/** Immutable approved component identities. Assets contain literal approved
 * JSON bytes; fetch or deployment changes cannot substitute their contents. */
import { physicalBytesSha256 } from './portablePhysicalHashes.mjs';
const components = Object.freeze({
 finite: Object.freeze({file:'finite-component.json',sha256:'406b0a4e6ce88aa8ee32467577679dc66183a3d29e5e4240f00345443a2af466'}),
 numerical: Object.freeze({file:'seeded-numerical.json',sha256:'f71c4dc1a0488c3d514af6f0ca54088f6f562cb298705873fc352767e3298b81'}),
 physical: Object.freeze({file:'physical-kernels.json',sha256:'1c2b9aff028d79d5876fb87ad81e6ce2c1b337ede5ccb84e1b218d282f810575'}),
});
export async function loadApprovedComponentArtifacts(isCurrent,fetchBytes=globalThis.fetch) {
 if (typeof isCurrent !== 'function' || typeof fetchBytes !== 'function') throw Error('Private source generation and artifact loader required');
 const current=()=>{if(isCurrent()!==true)throw Error('Source generation changed while loading approved components');};
 /** @type {Record<string,{bytes:Uint8Array,sha256:string}>} */
 const out={};
 for (const [name,component] of Object.entries(components)) {
  current();
  const response=await fetchBytes(new URL('./artifacts/'+component.file,import.meta.url));current();
  if (!response?.ok) throw Error('Approved '+name+' component artifact unavailable');
  const bytes=new Uint8Array(await response.arrayBuffer());current();
  if (await physicalBytesSha256(bytes)!==component.sha256) throw Error('Approved '+name+' artifact byte identity differs');current();
  out[name]=Object.freeze({bytes,sha256:component.sha256});
 }
 return Object.freeze(out);
}
