/** Eventual app startup composition, COPIED ONLY. Both providers import SOURCE
 * into this graph. It returns component-owned providers, not execution/fit
 * readiness. Actual engine construction and forty-step proof stay separate. */
import { createAppSourceNumericalFactory, type AppNumericalOwner } from './appFactory.ts';
import { createAppWholePhysicalFactory, type PhysicalAppOwner } from './physical/appEntry.ts';
import { loadApprovedComponentArtifacts } from './approvedArtifacts.mjs';
import { copyData, equalData } from './snapshots.mjs';

interface DeliveryOwner extends AppNumericalOwner {
 providerOptions:PhysicalAppOwner['providerOptions'];
}
export function createAppSourceDelivery(readCurrentOwner:()=>DeliveryOwner) {
 const numerical=createAppSourceNumericalFactory(readCurrentOwner);
 return Object.freeze({
  createNumerical(device:GPUDevice,scope:string){return numerical(device,scope);},
  createPhysical(device:GPUDevice,scope:string) {
   if(scope!=='fresh-source-physical-profile')return null;
   const owner=readCurrentOwner(),initial=copyData(owner.providerOptions),callback=owner.stillCurrent,current=()=>{
    const before=readCurrentOwner();if(before.stillCurrent!==callback||callback()!==true)return false;
    const now=readCurrentOwner();return now.pattern===owner.pattern&&now.prepared===owner.prepared&&now.stillCurrent===callback&&equalData(now.providerOptions,initial);
   };
   return (async()=>{
    const artifacts=await loadApprovedComponentArtifacts(current);
    if(!current())throw Error('App physical startup owner changed');
    const override={deviceValidationArtifact:artifacts.physical.bytes,approvedDeviceValidationSha256:artifacts.physical.sha256};
    for(const [key,value] of Object.entries(override))if(Object.hasOwn(initial,key)&&!equalData(initial[key],value))throw Error('Provider option overrides privately approved physical artifact');
    const providerOptions={...initial,...override};
    // Lookup the genuine renderer state on every check; prepared/source/registry
    // protection is retained in the physical graph's private startup boundary.
    const factory=createAppWholePhysicalFactory(()=>({...readCurrentOwner(),providerOptions}));
    const provider=await factory(device,scope);
    try{await provider?.ready;if(!current())throw Error('App physical startup owner changed');return provider;}
    catch(error){try{await provider?.destroy();}catch(cleanup){throw new AggregateError([error,cleanup],'App physical startup and cleanup failed',{cause:error});}throw error;}
   })();
  },
 });
}
