import{portableDigest as hash}from'./portableByteTools.mjs';
import{requireWholePhysicalPreparation,createPreparedWholePhysicalFactory}from'./privateWholePreparation.mjs';
import{SourcePhysicalMechanicalController}from'./SourcePhysicalMechanicalController.mjs';
import{SourcePhysicalAnchorArena}from'./SourcePhysicalAnchorArena.mjs';
import{PhysicalMaterialHistoryIndex}from'./PhysicalMaterialHistoryIndex.mjs';
import{physicalResponsiveMaskFromReadback}from'./physicalResponsiveMask.mjs';
import{actualPhysicalBodyReactions}from'./actualPhysicalBodyReactions.mjs';
import{readActualPhysicalOperatorEvidence}from'./actualPhysicalOperatorReadback.mjs';
import{wholePhysicalCombinationWGSL}from'./wholePhysicalProviderValidation.mjs';
import{requirePhysicalIncomingRawProof}from'./wholePhysicalAliasWGSL.mjs';
import{physicalCertificateSha256 as certificateSha256,PHYSICAL_CERTIFICATE_HASH_ENCODING}from'./certificateHash.mjs';
async function physicalCertificateSha256(value,isCurrent){const sha=await certificateSha256(value);if(typeof isCurrent!=='function'||isCurrent()!==true)throw Error('Physical certificate owner changed across digest');return sha;}
const SHA=/^[a-f0-9]{64}$/,NONE=0xffffffff,u32=x=>Number.isSafeInteger(x)&&x>=0&&x<=NONE;
const view=x=>new Uint8Array(x.buffer,x.byteOffset,x.byteLength);
const clone=x=>structuredClone(x),sameKey=(a,b)=>['generation','frameSequence','physicalSubstep','parentToken','gateRevision'].every(k=>a?.[k]===b?.[k]);
/** Integer lookup only. Existing dormant slots stay addressable; actual positive
 * physical lambda alone can allocate a NEW material slot after the solve. */
export function existingPhysicalMaterialSlots(records,snapshot){
 if(!(records instanceof Uint32Array)||records.length%40||!snapshot||!Array.isArray(snapshot.entries))throw Error('Exact GPU material-key/history lookup required');
 const map=new Map(snapshot.entries),out=new Uint32Array(records.length/40).fill(NONE);
 for(let ordinal=0;ordinal<out.length;ordinal++){
  const r=records.subarray(ordinal*40,(ordinal+1)*40);
  if(r[0]!==1||r[1]!==ordinal||r[2]>1||r[3]<1||r[3]>6||r[39]!==0)throw Error('Unknown exact original material key');
  if(r[2]===1)continue;
  const k=Array.from(r.subarray(8,8+r[3]*2)).join(',');if(map.has(k))out[ordinal]=map.get(k);
 }
 return out;
}
export function requireFinalPhysicalCertificate(certificate,binding,key){
 const c=clone(certificate);
 if(!c||!sameKey(c.key,key)||c.actualGpuFiniteProducer!==true||c.allCurrentRawOccurrencesChecked!==true||c.complete!==true||
  !u32(c.rawOccurrences)||c.allRawOccurrences!==c.rawOccurrences||c.validatedOccurrences!==c.rawOccurrences||
  c.unsupported!==0||c.unsupportedFlags!==0||c.clearanceDeficits!==0||c.strictClearanceDeficits!==0||
  !Number.isFinite(c.maximumOriginalParentNetM)||c.maximumOriginalParentNetM<0||c.maximumOriginalParentNetM>.005||
  !['sourceSha256','bodySha256','historySha256','usedGateSha256','originalParentSha256'].every(k=>SHA.test(c[k])&&c[k]===binding[k])||
  !SHA.test(c.candidateSha256)||c.physicalMassAndFixedBitsUnchanged!==true||
  !(c.rawOccurrences===0?c.minimumLowerBoundM===Infinity&&c.minimumClearanceLowerBoundM===Infinity:
   Number.isFinite(c.minimumLowerBoundM)&&c.minimumLowerBoundM>=.001&&Number.isFinite(c.minimumClearanceLowerBoundM)&&c.minimumClearanceLowerBoundM>=.001))
  throw Error('Final combined candidate lacks authentic complete physical1mm/NET certificate');
 return c;
}
export function createSourceWholePhysicalReactionProvider(device,scope,options){
 if(scope!=='fresh-source-physical-profile')return null;
 return createPreparedWholePhysicalFactory(SourceWholePhysicalReactionProvider)(device,scope,options);
}
/** NEW concrete composition; no live integration/device readiness is implied.
 * The factory rejects before allocations unless a pinned ACTUAL-device artifact
 * validates these NEW whole kernels. The historic six fixtures cannot satisfy
 * the validation schema. Numerical projection and full-body anchor callbacks
 * are authentic producer owners, never CPU geometry/force injection hooks.
 */
export class SourceWholePhysicalReactionProvider{
 #assertOwner;#device;#o;#validation;#controller;#arena;#index;#owned=[];#candidate;#combined;#layout;#pipe;
 #busy=false;#pending=null;#closing=false;#closePromise=null;#generation=0;#frame=null;#staged=[];#snapshots=new WeakMap();#output=null;
 constructor(device,token){const prepared=requireWholePhysicalPreparation(token),options=prepared.options;this.#assertOwner=prepared.assertCurrent;
  // Validation precedes ANY device read/allocation, including malformed source.
  this.#validation=prepared.validation;
  this.#o=clone({...options,deviceValidationArtifact:undefined});this.#device=device;const o=this.#o;
  if(!u32(o.materialCapacity)||o.materialCapacity<1||!u32(o.particles)||o.particles<1||!SHA.test(o.implementationSha256)||
   !Number.isFinite(o.dt)||o.dt<=0||typeof o.projectNumericalClearance!=='undefined')throw Error('Invalid immutable whole physical provider configuration');
  const identity={sourceSha256:o.sourceSha256,bodySha256:o.bodySha256,physicalMassPolicySha256:o.physicalMassPolicySha256,declaredFrictionProfileSha256:prepared.frictionSha256};
  this.#index=new PhysicalMaterialHistoryIndex(o.materialCapacity,identity);
  try{
   this.#controller=new SourcePhysicalMechanicalController(device,token);
   this.#arena=new SourcePhysicalAnchorArena(device,{...o,identity,validatedTolerances:this.#validation.validatedTolerances,
    executedTolerancePolicySha256:this.#validation.validatedTolerancePolicySha256},prepared.assertCurrent);
   for(const label of['FINAL combined contact candidate','direct combined physical+numerical contact delta']){
    prepared.assertCurrent();const b=device.createBuffer({label,size:o.particles*16,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST});this.#owned.push(b);
   }
   [this.#candidate,this.#combined]=this.#owned;
   this.#layout=device.createBindGroupLayout({entries:Array.from({length:5},(_,binding)=>({binding,visibility:GPUShaderStage.COMPUTE,buffer:{type:binding<3?'read-only-storage':'storage'}}))});
   const module=device.createShaderModule({code:wholePhysicalCombinationWGSL}),layout=device.createPipelineLayout({bindGroupLayouts:[this.#layout]});
   this.ready=(async()=>{await Promise.all([this.#controller.ready,this.#arena.ready]);const errors=(await module.getCompilationInfo()).messages.filter(x=>x.type==='error');prepared.assertCurrent();if(errors.length)throw Error(errors.map(x=>`${x.lineNum}:${x.linePos} ${x.message}`).join('\n'));if(this.#closing)throw Error('Physical provider closed during ready');this.#pipe=device.createComputePipeline({layout,compute:{module,entryPoint:'combine_contact'}});})();this.ready.catch(()=>{});
  }catch(e){for(const b of this.#owned)b.destroy();if(this.#controller)void this.#controller.destroy().catch(()=>{});if(this.#arena)void this.#arena.destroy().catch(()=>{});throw e;}
 }
 get snapshotBytes(){return this.#arena.snapshotBytes;}
 get implementationSha256(){return this.#o.implementationSha256;}
 get deviceValidation(){return clone(this.#validation);}
 get acceptedFrameReceipt(){return this.#arena.acceptedFrameReceipt;}
 #idle(){this.#assertOwner();if(this.#busy||this.#output||this.#closing)throw Error('Whole physical provider busy/output leased/closed');}
 #run(action){try{this.#idle();}catch(e){return Promise.reject(e);}this.#busy=true;const g=this.#generation;
  const work=(async()=>{try{await this.ready;if(this.#assertOwner()!==true||this.#closing||g!==this.#generation)throw Error('Physical provider generation changed');return await action(()=>{this.#assertOwner();return !this.#closing&&g===this.#generation;});}finally{this.#busy=false;}})();
  this.#pending=work;work.then(()=>{if(this.#pending===work)this.#pending=null;},()=>{if(this.#pending===work)this.#pending=null;});return work;
 }
 encodeSnapshot(encoder,target,offset=0){this.#idle();this.#arena.encodeSnapshot(encoder,target,offset);let ranges=this.#snapshots.get(target);if(!ranges){ranges=new Map();this.#snapshots.set(target,ranges);}ranges.set(offset,clone({index:this.#index.captureTransaction(),frame:this.#frame,staged:this.#staged}));}
 encodeRestore(encoder,source,offset=0){this.#idle();const s=this.#snapshots.get(source)?.get(offset);if(!s)throw Error('Unbound whole pressure host/GPU snapshot');this.#arena.encodeRestore(encoder,source,offset);this.#index.restoreTransaction(s.index);this.#frame=clone(s.frame);this.#staged=clone(s.staged);this.#generation++;}
 beforeFrame(key){const k=clone(key);return this.#run(async valid=>{if(this.#frame||!k||!u32(k.generation)||!u32(k.frameSequence)||k.frameSequence<1||!SHA.test(k.usedGateSha256)||!SHA.test(k.sourceDeltaPolicySha256))throw Error('Unbound/concurrent physical frame');
  await this.#arena.beforeFrame(k);if(!valid())throw Error('Physical frame changed before history setup');this.#index.beforeFrame(k);this.#frame=k;this.#staged=[];});}
 async #read(buffer,n,offset=0){if(n===0)return new Uint8Array();const r=this.#device.createBuffer({label:'whole physical owned-byte observation',size:n,usage:GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ});let mapped=false;
  try{const e=this.#device.createCommandEncoder();e.copyBufferToBuffer(buffer,offset,r,0,n);this.#device.queue.submit([e.finish()]);await r.mapAsync(GPUMapMode.READ);mapped=true;return new Uint8Array(r.getMappedRange().slice(0,n));}finally{if(mapped)r.unmap();r.destroy();}}
 reconcileActualReaction(input){
  const key=clone(input.key),binding=clone(input.binding),expected=clone(input.expected),proof=input.observedRawProof?.slice();
  const handles={parent:input.originalParent,history:input.history,current:input.candidate,raw:input.actualRow128,proof:input.actualRawProof,gate:input.actualUsedGate};
  const produce=input.produceOwnedBodyAnchors,project=input.projectNumericalClearance,inspect=input.inspectPhysicalCandidate,isCurrent=input.isCurrent,gateBytes=input.actualUsedGateByteLength,physicalDt=input.physicalDt,rawOccurrences=input.rawOccurrences;
  const emptyCertificate=input.actualEmptyCertificate?clone(input.actualEmptyCertificate):null;
  return this.#run(async valid=>{
   const current=()=>valid()&&isCurrent?.()===true;
   if(!this.#frame||!sameKey(binding?.key,key)||key.generation!==this.#frame.generation||key.frameSequence!==this.#frame.frameSequence||key.physicalSubstep!==this.#staged.length+1||
    binding.usedGateSha256!==this.#frame.usedGateSha256||physicalDt!==this.#o.dt||!expected||expected.rawOccurrences!==rawOccurrences||
    typeof inspect!=='function'||typeof project!=='function'||typeof produce!=='function'||!u32(gateBytes)||gateBytes<16||
    !handles.gate||handles.gate.size<gateBytes||new Set(Object.values(handles)).size!==6||!current())throw Error('Actual source parent/owned producers/gate not bound');
   requirePhysicalIncomingRawProof(proof,expected.rawOccurrences);
   const seal=async()=>{const s={};for(const[name,b,n]of[['parent',handles.parent,this.#o.particles*16],['history',handles.history,this.#o.particles*16],['current',handles.current,this.#o.particles*16],['raw',handles.raw,expected.rawOccurrences*128],['proof',handles.proof,32],['gate',handles.gate,gateBytes]]){s[name]=(await hash(await this.#read(b,n),current));if(!current())throw Error('Physical authentic read lease changed');}
    for(const[k,h]of[['parent','originalParentSha256'],['history','historySha256'],['current','currentSha256'],['raw','fullRawRow128Sha256'],['gate','usedGateSha256']])if(s[k]!==binding[h])throw Error('Physical source bytes do not match binding: '+k);return s;};
   const incoming=await seal();
   for(const[k,v]of[['originalRawOccurrences',expected.rawOccurrences],['originalRawRow128Sha256',incoming.raw],['originalRawProofSha256',incoming.proof]])
    if(binding[k]!==undefined&&binding[k]!==v)throw Error('Original physical inventory binding differs from actual bytes: '+k);
   binding.originalRawOccurrences=expected.rawOccurrences;binding.originalRawRow128Sha256=incoming.raw;binding.originalRawProofSha256=incoming.proof;
   let mechanical,initialAnchor,finalAnchor,numerical;
   try{
    const anchorRequest=async(candidate)=>{const out=await produce({originalParent:handles.parent,history:handles.history,current:candidate,actualRow128:handles.raw,actualRawProof:handles.proof,rawOccurrences:expected.rawOccurrences,key,binding:clone(binding),isCurrent:current});if(!current())throw Error('Physical anchor owner returned stale output');return out;};
    mechanical=await this.#controller.solveActualPhysicalParent({originalParent:handles.parent,current:handles.current,history:handles.history,
     actualRow128:handles.raw,actualRawProof:handles.proof,observedRawProof:proof,expected,binding,isCurrent:current,actualEmptyCertificate:emptyCertificate,
     prepareRelativeTargets:async ctx=>{initialAnchor=await anchorRequest(ctx.current);
      const keysSha=(await hash(view(ctx.aliases.records),current)),arenaBinding={...ctx.binding,...initialAnchor.probe.binding,exactMaterialKeysSha256:keysSha,
       authenticAllRawReadLease:true,executedTolerancePolicySha256:this.#validation.validatedTolerancePolicySha256,declaredFrictionProfileSha256:binding.declaredFrictionProfileSha256,
       physicalMassPolicySha256:binding.physicalMassPolicySha256};
      return this.#arena.prepareRelativeTargets({probe:initialAnchor.probe,actualRaw:ctx.actualRow128,actualExactKeyRecords:ctx.actualExactKeyRecords,history:ctx.history,
       ordinalToExistingSlot:existingPhysicalMaterialSlots(ctx.aliases.records,this.#index.snapshot()),key,binding:arenaBinding,isCurrent:current});}});
    if(!current())throw Error('Physical mechanical owner became stale');
    if(expected.rawOccurrences===0)return await this.#finishEmpty({mechanical,key,binding,proof,handles,inspect,current,seal,incoming});
    // Mechanical is physical-only. Numerical controller receives this seed but
    // retains TRUE original-parent protections; augmented lambda never pressure.
    numerical=await project({mechanicalCandidate:mechanical.candidate,mechanicalIdeal:mechanical.idealPhysicalContactDelta,originalParent:handles.parent,history:handles.history,
   originalParentSha256:binding.originalParentSha256,key,gate:handles.gate,isCurrent:current});
    if(!current()||!numerical?.numericalIdealDelta||typeof numerical.release!=='function'||numerical.numericalOnly!==true||!sameKey(numerical.key,key)||numerical.originalParentSha256!==binding.originalParentSha256||numerical.historySha256!==binding.historySha256||numerical.usedGateSha256!==binding.usedGateSha256)
     throw Error('Authentic numerical-only original-parent correction unavailable');
    const parentBytes=await this.#read(mechanical.originalParent,this.#o.particles*16),parentU=new Uint32Array(parentBytes.buffer),parentF=new Float32Array(parentBytes.buffer);
    const physicalBytes=await this.#read(mechanical.idealPhysicalContactDelta,this.#o.particles*16),numericalBytes=await this.#read(numerical.numericalIdealDelta,this.#o.particles*16);
    for(const b of[physicalBytes,numericalBytes]){const f=new Float32Array(b.buffer);if(f.some(x=>!Number.isFinite(x)))throw Error('Nonfinite direct contact delta');for(let p=0;p<this.#o.particles;p++)if(f[p*4+3]!==0||parentF[p*4+3]===0&&f.subarray(p*4,p*4+3).some(x=>x!==0))throw Error('Physical/numerical delta changed fixed particle/W');}
    const resources=[mechanical.originalParent,mechanical.idealPhysicalContactDelta,numerical.numericalIdealDelta,this.#combined,this.#candidate],e=this.#device.createCommandEncoder();
    const g=this.#device.createBindGroup({layout:this.#layout,entries:resources.map((buffer,binding)=>({binding,resource:{buffer,size:this.#o.particles*16}}))}),pass=e.beginComputePass();pass.setPipeline(this.#pipe);pass.setBindGroup(0,g);pass.dispatchWorkgroups(Math.ceil(this.#o.particles/64));pass.end();this.#device.queue.submit([e.finish()]);
    const candidateBytes=await this.#read(this.#candidate,this.#o.particles*16),combinedBytes=await this.#read(this.#combined,this.#o.particles*16),cu=new Uint32Array(candidateBytes.buffer),cf=new Float32Array(candidateBytes.buffer),df=new Float32Array(combinedBytes.buffer);
    if(cf.some(x=>!Number.isFinite(x))||df.some(x=>!Number.isFinite(x)))throw Error('Combined contact storage overflow');for(let p=0;p<this.#o.particles;p++)if(cu[p*4+3]!==parentU[p*4+3]||df[p*4+3]!==0||parentF[p*4+3]===0&&[0,1,2].some(k=>cu[p*4+k]!==parentU[p*4+k]))throw Error('Combined contact fixed/mass bits changed');
    const fresh=await inspect({candidate:this.#candidate,originalParent:handles.parent,history:handles.history,key});if(!current())throw Error('Fresh finite producer stale');
    const certificate=requireFinalPhysicalCertificate(fresh.certificate,binding,key),finalSha=(await hash(candidateBytes,current));if(certificate.candidateSha256!==finalSha)throw Error('Final finite certificate candidate differs from actual stored contact');
    finalAnchor=await anchorRequest(this.#candidate);
    const rawBytes=await this.#read(mechanical.actualRaw,expected.rawOccurrences*128),packetBytes=await this.#read(finalAnchor.probe.packet,finalAnchor.probe.layout.byteLength);
    const body=(await actualPhysicalBodyReactions({mechanical,anchor:finalAnchor,rawBytes,packetBytes,physicalDt:this.#o.dt,finalCandidateSha256:finalSha},{isCurrent:current}));
    const limits=this.#validation.validatedTolerances,residuals={};for(const name of Object.keys(limits)){residuals[name]=Math.max(0,...mechanical.actualReaction.components.map(c=>c[name]));if(!Number.isFinite(residuals[name])||residuals[name]>limits[name])throw Error('Actual physical residual exceeds validated policy');}
    const receipt={binding:{...clone(mechanical.binding),originalRawOccurrences:expected.rawOccurrences},mechanicalCandidateSha256:(await hash(await this.#read(mechanical.candidate,this.#o.particles*16),current)),finalCandidateSha256:finalSha,
     normalPhysicalRhs:'exact-physical-1mm',normalMultiplierUnit:'kg-m',numericalMarginIsPhysicalPressure:false,normalReactionAuthoritative:true,...residuals,
     storedForceFinite:true,fixedMassAndSignedZeroBitsPreserved:true,reactionRecordScope:body.reactionRecordScope,
     actualAllContactOperatorReceiptSha256:body.actualAllContactOperatorReceiptSha256,allContactPhysicalRowCount:body.allContactPhysicalRowCount,bodyContactPhysicalRowCount:body.bodyContactPhysicalRowCount,selfContactPhysicalRowCount:body.selfContactPhysicalRowCount,reactions:body.reactions,
     numericalClearanceDeltaSha256:(await hash(numericalBytes,current)),idealCombinedContactDeltaSha256:(await hash(combinedBytes,current)),actualFreshAllRawCertificateSha256:(await physicalCertificateSha256(certificate,current)),
     originalParentNetM:certificate.maximumOriginalParentNetM,mechanicalOriginalParentNetM:mechanical.actualFixedCertificate.originalParentNetM,
     actualFreshAllRawCertificateEncoding:PHYSICAL_CERTIFICATE_HASH_ENCODING,all41GuardProofSha256:null,deviceReactionReceiptSha256:this.#validation.receiptSha256,
     executedPhysicalPackShaderSha256:this.#validation.physicalPackShaderSha256,executedReactionShaderSha256:this.#validation.reactionShaderSha256};
    const arenaBinding={...receipt.binding,...finalAnchor.probe.binding,exactMaterialKeysSha256:(await hash(view(mechanical.actualAliases.records),current)),
     authenticAllRawReadLease:true,actualGpuReactionReadback:true,deviceReactionReceiptSha256:this.#validation.receiptSha256,finalCandidateSha256:finalSha,
     actualFreshAllRawCertificateSha256:receipt.actualFreshAllRawCertificateSha256,actualPhysicalReactionReceiptSha256:(await physicalCertificateSha256(receipt,current)),
     actualReactionBufferSha256:body.actualReactionBufferSha256,actualReactionStatusBufferSha256:body.actualReactionStatusBufferSha256};
    const responsive=physicalResponsiveMaskFromReadback(mechanical.physicalRows.actualPhysicalRows,mechanical.actualReaction,expected.rawOccurrences);
    const slots=this.#index.stageActualMaterials({...mechanical.actualAliases,actualResponsiveMask:responsive,actualPhysicalReactionMaskReceiptSha256:(await hash(view(responsive),current))},arenaBinding);
    await this.#arena.stageActualResponse({key,binding:arenaBinding,finalProbe:finalAnchor.probe,actualRaw:mechanical.actualRaw,actualExactKeyRecords:mechanical.actualExactKeyRecords,history:mechanical.history,
     ordinalToSlot:slots.ordinalToHistorySlot,rows48:mechanical.physicalRows.rows,rowCount:mechanical.physicalRows.executedRows,components:mechanical.actualReaction.executed.components,
     actualReaction:mechanical.actualReactionBuffer,actualStatus:mechanical.actualStatusBuffer,rowModeOffsetBytes:mechanical.rowModeOffsetBytes,finalCandidate:this.#candidate,actualPhysicalReactionReceipt:receipt,isCurrent:current});
    if(JSON.stringify(await seal())!==JSON.stringify(incoming)||!current())throw Error('Original pressure inventory changed before publication');
    this.#staged.push({receipt:clone(receipt),certificate:clone(certificate),hash:(await physicalCertificateSha256(receipt,current))});this.#output={key:clone(key),mechanical,receipt:clone(receipt)};
    return Object.freeze({candidate:this.#candidate,idealCombinedContactDelta:this.#combined,receipt:clone(receipt),certificate:clone(certificate),release:()=>this.releaseOutput(key)});
   }catch(e){this.#output=null;throw e;}finally{const errors=[];for(const owned of[finalAnchor,initialAnchor,numerical])if(owned?.release)try{await owned.release();}catch(e){errors.push(e);}if(mechanical)try{this.#controller.releaseOutput(mechanical.token);}catch(e){errors.push(e);}if(errors.length){this.#output=null;throw new AggregateError(errors,'Pressure producer release failed');}}
  });
 }
 async #finishEmpty({mechanical,key,binding,proof,handles,inspect,current,seal,incoming}){
  // No body anchor, mode, lambda, numerical or history allocation on actual0 rows.
  const e=this.#device.createCommandEncoder();e.copyBufferToBuffer(mechanical.candidate,0,this.#candidate,0,this.#o.particles*16);e.clearBuffer(this.#combined);this.#device.queue.submit([e.finish()]);
  const fresh=await inspect({candidate:this.#candidate,originalParent:handles.parent,history:handles.history,key}),c=requireFinalPhysicalCertificate(fresh.certificate,binding,key);
  if(c.rawOccurrences!==0||c.candidateSha256!==binding.originalParentSha256||c.maximumOriginalParentNetM!==0||!current())throw Error('Empty pressure path changed original parent');
  const zeroSha=(await hash(new Uint8Array(this.#o.particles*16),current)),receipt={binding:{...binding,originalRawOccurrences:0,packedPhysicalJacobianSha256:(await hash(new Uint8Array(),current)),physicalRhsSha256:(await hash(new Uint8Array(),current)),
    executedTolerancePolicySha256:this.#validation.validatedTolerancePolicySha256,executedAnchorPartitionPolicySha256:this.#validation.validatedAnchorPartitionPolicySha256},
   mechanicalCandidateSha256:binding.originalParentSha256,finalCandidateSha256:binding.originalParentSha256,normalPhysicalRhs:'exact-physical-1mm',normalMultiplierUnit:'kg-m',numericalMarginIsPhysicalPressure:false,normalReactionAuthoritative:true,
   algebraicNormalDeficitM:0,algebraicComplementarityResidualM:0,frictionResidualM:0,storedForceFinite:true,fixedMassAndSignedZeroBitsPreserved:true,
   reactionRecordScope:'body-pressure-friction-only-v1',actualAllContactOperatorReceiptSha256:(await hash('actual-empty-physical-operator-v1\n'+JSON.stringify(binding)+(await hash(view(proof),current)),current)),allContactPhysicalRowCount:0,bodyContactPhysicalRowCount:0,selfContactPhysicalRowCount:0,reactions:[],
   numericalClearanceDeltaSha256:zeroSha,idealCombinedContactDeltaSha256:zeroSha,actualFreshAllRawCertificateSha256:(await physicalCertificateSha256(c,current)),originalParentNetM:0,mechanicalOriginalParentNetM:0,
   actualFreshAllRawCertificateEncoding:PHYSICAL_CERTIFICATE_HASH_ENCODING,all41GuardProofSha256:null,deviceReactionReceiptSha256:this.#validation.receiptSha256,executedPhysicalPackShaderSha256:this.#validation.physicalPackShaderSha256,executedReactionShaderSha256:this.#validation.reactionShaderSha256};
  const b={...receipt.binding,emptyInventoryCertificateSha256:binding.emptyInventoryCertificateSha256,actualPhysicalReactionReceiptSha256:(await physicalCertificateSha256(receipt,current)),actualFreshAllRawCertificateSha256:receipt.actualFreshAllRawCertificateSha256,deviceReactionReceiptSha256:receipt.deviceReactionReceiptSha256,finalCandidateSha256:receipt.finalCandidateSha256};
  this.#index.stageActualEmptyInventory({authenticAllRawReadLease:true,actualProducerReceiptSha256:b.emptyInventoryCertificateSha256,observedRawProof:proof},b);
  await this.#arena.stageActualEmptyResponse({key,binding:b,actualEmptyCertificate:c,actualPhysicalReactionReceipt:receipt,observedRawProof:proof,actualRaw:handles.raw,actualRawProof:handles.proof,originalParent:handles.parent,history:handles.history,finalCandidate:this.#candidate,isCurrent:current});
  if(JSON.stringify(await seal())!==JSON.stringify(incoming)||!current())throw Error('Authentic empty pressure source changed');
  this.#staged.push({receipt:clone(receipt),certificate:clone(c),hash:(await physicalCertificateSha256(receipt,current))});this.#output={key:clone(key),empty:true,proof:proof.slice(),proofBuffer:handles.proof,emptyHashBinding:clone(binding),receipt:clone(receipt)};
  return Object.freeze({candidate:this.#candidate,idealCombinedContactDelta:this.#combined,receipt:clone(receipt),certificate:clone(c),release:()=>this.releaseOutput(key)});
 }
 readActualAllContactOperatorReceipt(key){
  const k=clone(key),output=this.#output,generation=this.#generation;
  if(!output||!sameKey(output.key,k)||this.#busy||this.#closing)return Promise.reject(Error('Actual operator output lease unavailable'));
  this.#busy=true;const valid=()=>!this.#closing&&this.#generation===generation&&this.#output===output;
  const work=(async()=>{try{
   if(!output.empty)return await readActualPhysicalOperatorEvidence({mechanical:output.mechanical,particles:this.#o.particles,
    readBytes:(b,n,offset)=>this.#read(b,n,offset),isCurrent:valid});
   const proof=await this.#read(output.proofBuffer,32),r=output.receipt,b=output.emptyHashBinding;
   requirePhysicalIncomingRawProof(new Uint32Array(proof.buffer),0);
   if(!valid()||(await hash(proof,valid))!==r.binding.originalRawProofSha256||(await hash(view(output.proof),valid))!==(await hash(proof,valid))||
    (await hash('actual-empty-physical-operator-v1\n'+JSON.stringify(b)+(await hash(proof,valid)),valid))!==r.actualAllContactOperatorReceiptSha256)
    throw Error('Actual empty operator proof changed');
   return Object.freeze({actualGpuOperatorReadbackVerified:true,actualAuthenticatedEmptyOperator:true,binding:clone(r.binding),emptyHashBinding:clone(b),
    reactionRecordScope:r.reactionRecordScope,actualAllContactOperatorReceiptSha256:r.actualAllContactOperatorReceiptSha256,
    allContactPhysicalRowCount:0,bodyContactPhysicalRowCount:0,selfContactPhysicalRowCount:0,
    packedPhysicalJacobianSha256:r.binding.packedPhysicalJacobianSha256,physicalRhsSha256:r.binding.physicalRhsSha256,
    actualOriginalRawProof:new Uint32Array(proof.buffer)});
  }finally{this.#busy=false;}})();
  this.#pending=work;work.then(()=>{if(this.#pending===work)this.#pending=null;},()=>{if(this.#pending===work)this.#pending=null;});return work;
 }
 releaseOutput(key){if(!this.#output||!sameKey(this.#output.key,key)||this.#busy||this.#closing)throw Error('Unknown/busy physical output release');this.#output=null;}
 acceptFrame(actualAll41GuardProofSha256){return this.#run(async valid=>{if(!this.#frame||this.#staged.length!==40||!SHA.test(actualAll41GuardProofSha256))throw Error('Pressure history requires exact40 and actual41 guard');
  const empty=this.#staged.every(x=>x.certificate.rawOccurrences===0),minimum=Math.min(...this.#staged.map(x=>x.certificate.minimumClearanceLowerBoundM));
  const proof={...this.#frame,all41GuardProofSha256:actualAll41GuardProofSha256,actualAll41GuardProofSha256,physicalSubstepsCommitted:40,actualReactionReceiptSha256s:this.#staged.map(x=>x.hash),safe:true,samplesChecked:41,segmentsChecked:40,
   unsupportedWitnesses:0,clearanceFailures:0,minimumClearanceLowerBoundM:minimum,rawOccurrences:empty?0:this.#staged.reduce((n,x)=>n+x.certificate.rawOccurrences,0),validatedRows:empty?0:this.#staged.reduce((n,x)=>n+x.certificate.validatedOccurrences,0),emptyBoundsEncoding:PHYSICAL_CERTIFICATE_HASH_ENCODING};
  // Validate CPU dictionary first with a reversible checkpoint, then GPU commit.
  const checkpoint=this.#index.captureTransaction();this.#index.acceptFrame(proof);
  try{const receipt=await this.#arena.acceptFrame(proof,valid);if(!valid())throw Error('Stale pressure frame publication');this.#frame=null;this.#staged=[];return receipt;}catch(e){this.#index.restoreTransaction(checkpoint);throw e;}});}
 invalidate(){this.#generation++;this.#index.rejectFrame();this.#frame=null;this.#staged=[];this.#controller.invalidate();this.#arena.invalidate();}
 resetHistory(){this.#idle();this.invalidate();this.#index.invalidate();this.#arena.resetHistory();}
 destroy(){if(this.#closePromise)return this.#closePromise;this.#closing=true;this.#generation++;this.#closePromise=(async()=>{const errors=[];await this.ready.catch(e=>errors.push(e));if(this.#pending)await this.#pending.catch(e=>errors.push(e));
  for(const owner of[this.#controller,this.#arena])await owner.destroy().catch(e=>errors.push(e));try{await this.#device.queue.onSubmittedWorkDone();}catch(e){errors.push(e);}finally{for(const b of this.#owned)try{b.destroy();}catch(e){errors.push(e);}this.#owned=[];this.#output=null;}if(errors.length)throw new AggregateError(errors,'Whole physical provider cleanup failed');})();return this.#closePromise;}
}
