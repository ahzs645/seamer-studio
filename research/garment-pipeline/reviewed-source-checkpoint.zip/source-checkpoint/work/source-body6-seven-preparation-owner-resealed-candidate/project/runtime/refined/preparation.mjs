import{bodyFaceFeatureLanesWGSL,BODY_FACE_FEATURE_POLICY}from'./bodyFaceFeatureLanes.mjs';
import{toHistoricalInventoryIdentifier}from'./inventoryIdentifier.mjs';
import {validateSourcePhysicalMembrane} from './vendor/sourcePhysicalProduction.mjs';
import {bindPreparedRefinedMobility} from './mobility.mjs';
import {packJointRefinedGeometry} from './vendor/sourceJointRefinedGeometry.mjs';
import {prepareJointClosedBodyProbe} from './vendor/sourceJointClosedBodyProbe.mjs';
import {sourceJointRefinedSeamFactory} from './vendor/sourceJointRefinedSeamFactory.mjs';
import {physicalSeamStitchIndices,buildSeamGateLayout,packSeamGate} from './vendor/seamGate.mjs';
import {surfaceTopologyExclusions,surfaceSeamLinks} from './vendor/surfaceTopology.mjs';
import {sha,digest,equalBytes,equalData} from './bytes.mjs';
import {predicateEvidence} from './predicateEvidence.mjs';
const hash=/^[a-f0-9]{64}$/;
const typed=(a,C,n)=>a instanceof C&&a.length===n;
/** Native bypass precedes even reading prepared; ordinary sources remain the
 * ordinary owner's path rather than receiving a fabricated refinement receipt. */
async function prepareFromCapturedApp(options,mode='source'){
 if(mode==='native')return null;
 const {prepared,sourceBinding,scope='fresh-source',manualRecording=false,held=false,cached=false,explicitSettings=false}=options;
 // Snapshot before any digest/probe await. No caller arrays are transferred.
 const p=structuredClone(prepared),binding=structuredClone(sourceBinding),d=p?.simData;
 if(!d?.sourceGatherCollisionGeometry&&!d?.sourceGatherRefinement)return null;
 if(!d.sourcePhysicalMembrane||!hash.test(d.sourcePhysicalMembrane.policySha256))throw Error('Actual physical SI mass policy required; no legacy-W relabel');
 if(!binding||!hash.test(binding.sourceSha256)||!Number.isSafeInteger(binding.sourceToken)||binding.sourceToken<0||binding.sourceToken>0xffffffff||!Number.isSafeInteger(binding.bodyGeneration)||binding.bodyGeneration<0||binding.bodyGeneration>0xffffffff)throw Error('Bound immutable source/body epoch required');
 if(!validateSourcePhysicalMembrane(d))throw Error('Actual physical SI policy/W validation unavailable');
 const mobility=await bindPreparedRefinedMobility({prepared:p,scope,manualRecording,held,cached,explicitSettings}),physical=mobility.capture(),physicalMassPolicySha256=d.sourcePhysicalMembrane.policySha256;
 const groups=d.seamPairsBySeam.map((g,index)=>({...g,index,pairs:Array.from(g.pairs),stitchIndices:physicalSeamStitchIndices(d.seams,d.seamOrder,[g],d.seamStitchRanges)[0],stitchIndexKinds:g.pairs.filter((_,i)=>i%2===0).map((a,i)=>a===g.pairs[i*2+1]?'identity-logical':'reciprocal-first-stamp')})),dictionary={stitchCount:d.stitchCount,seamPairsBySeam:groups},geometry=d.sourceGatherCollisionGeometry;
 const bodySha256=await sha(p.body.positions),topologySha256=await sha(d.triangles);
 if(binding.bodySha256!==bodySha256||binding.topologySha256!==topologySha256)throw Error('Source/body declaration differs from actual prepared bytes');
 const input={scope:'fresh-source',particleCount:d.particleCount,clothTriangles:d.triangles,bodyPositions:p.body.positions,bodyTriangles:p.body.triangles,sourceTopology:surfaceTopologyExclusions(d.triangles,d.seams,d.seamOrder,groups,true,groups.map(g=>g.stitchIndices),geometry),sourceSeamLinks:surfaceSeamLinks(groups,geometry),bodyGeneration:binding.bodyGeneration,sourceToken:binding.sourceToken,sourceSha256:binding.sourceSha256,bodySha256,topologySha256,refinedBoundary:true,sourceMaterialCoordinatesSha256:await sha(geometry.sourceMaterialCoordinates),sourceGatherCollisionGeometry:geometry,sourceRefinementPolicy:d.sourceGatherRefinement,dictionary,seams:d.seams,seamOrder:d.seamOrder};
 const packed=await packJointRefinedGeometry(input),closed=await prepareJointClosedBodyProbe(packed,'fresh-source'),layout=buildSeamGateLayout(dictionary.stitchCount,groups.length),packedSha256=await sha(packed.words);
 const factorySource=sourceJointRefinedSeamFactory(closed,layout);
 // The diagnostic uses source token1055/body instance5. Those are runtime epochs,
 // not anatomical revision. Rebind ONLY the exact closed-body equality literals;
 // every other source byte must still equal the device-tested reference template.
 const actualMarker=`cfg.sourceToken==${binding.sourceToken}u&&cfg.bodyGeneration==${binding.bodyGeneration}u&&`,referenceMarker='cfg.sourceToken==1055u&&cfg.bodyGeneration==5u&&';
 if(factorySource.split(actualMarker).length!==2)throw Error('Closed source/body validation literal is ambiguous');
 const referenceFactorySource=toHistoricalInventoryIdentifier(factorySource).replace(actualMarker,referenceMarker);
 if(!predicateEvidence.referenceFullFactorySha256.includes(await sha(referenceFactorySource)))throw Error('Matching packaged actual predicate shader evidence required');
 const derivedFactorySource=bodyFaceFeatureLanesWGSL(factorySource),factoryDerivation={policy:BODY_FACE_FEATURE_POLICY,featureLanes:15,originalRuntimeFullFactorySourceSha256:await sha(factorySource),derivedRuntimeFullFactorySourceSha256:await sha(derivedFactorySource),bodyFaceDispatch:'ceil(actualClothFaces*15/64)',actualDeviceExecuted:false,compileValidated:false,whole40Validated:false,fitAccepted:false};
 const receipt={factoryDerivation,scope:'verified-source-gather-child',physicalMassPolicySha256,sourceBinding:binding,mobilityBinding:physical.binding,materialBase:packed.materialBase,materialCoordinatesSha256:packed.materialCoordinatesSha256,refinementPolicySha256:packed.refinementPolicySha256,childGeometrySha256:packed.childGeometrySha256,seamDictionarySha256:packed.seamDictionarySha256,packedSha256,sourceTopologySha256:await sha(input.sourceTopology),sourceSeamLinksSha256:await sha(input.sourceSeamLinks),actualFreeMidpointIds:physical.midpointIds,refinedIntervals:geometry.intervals.length,predicateOnlyEvidence:{...structuredClone(predicateEvidence),actualRuntimeFullFactorySourceSha256:await sha(factorySource),actualRuntimeTokens:{sourceToken:binding.sourceToken,bodyGeneration:binding.bodyGeneration},tokenRebinding:'one exact closed-body equality conjunction only; all other shader bytes unchanged'},fullFiniteProducerValidated:false,pressureValidated:false,wholeFrameValidated:false,fullFitAccepted:false};
 const receiptSha256=await digest(receipt),referenceW=new Uint32Array(physical.positions.buffer).filter((_,i)=>i%4===3);
 const immutableCapture=structuredClone({packed,physical,dictionary,layout,receipt});
 function assertUnchanged(value){if(!equalData(value,immutableCapture))throw Error('Refined backend immutable preparation changed');return true;}
 async function assertRuntimeMobility(runtime){
  const snapshot=structuredClone(runtime),{parent,history,anchors,supportTargets,supportGroups,gate,usedActivation}=snapshot;
  const n=d.particleCount*4;
  if(![parent,history,anchors,supportTargets].every(a=>typed(a,Float32Array,n)&&a.every(Number.isFinite))||!Array.isArray(supportGroups))throw Error('Actual runtime typed parent/history/hold/support snapshots required');
  if(!typed(gate,Uint32Array,layout.byteLength/4)||!usedActivation||!(usedActivation.activeSeams instanceof Uint32Array)||!Number.isSafeInteger(usedActivation.revision)||usedActivation.revision<0||usedActivation.revision>0xffffffff)throw Error('Actual used activation and observed GPU gate required');
  const expectedGate=packSeamGate(layout,usedActivation.sewnUpTo,usedActivation.activeSeams,dictionary.seamPairsBySeam.map(g=>g.stitchIndices));if(!equalBytes(gate,expectedGate))throw Error('Actual observed gate differs from proof-used original stamps/mask/prefix');
  const pw=new Uint32Array(parent.buffer,parent.byteOffset,parent.length),hw=new Uint32Array(history.buffer,history.byteOffset,history.length);
  for(let id=0;id<d.particleCount;id++){
   if(pw[id*4+3]!==referenceW[id]||hw[id*4+3]!==referenceW[id])throw Error('Actual physical parent/history W differs from immutable SI mass');
   if(anchors[id*4+3]!==0)throw Error('Fresh refined runtime has an unsupported XYZ hold');
  }
  for(const id of physical.midpointIds)if(!(parent[id*4+3]>0)||anchors[id*4+3]!==0||supportTargets[id*4+1]!==0||supportGroups.some(g=>!Array.isArray(g.particles)||g.particles.includes(id)))throw Error('Runtime free midpoint is fixed/held/Y-supported');
  const receipt=Object.freeze({usedGateSha256:await sha(gate),usedActivationSha256:await digest(usedActivation),runtimeParentSha256:await sha(parent),runtimeHistorySha256:await sha(history),runtimeAnchorsSha256:await sha(anchors),runtimeSupportTargetsSha256:await sha(supportTargets),runtimeSupportGroupsSha256:await digest(supportGroups),refinedPreparationReceiptSha256:receiptSha256,physicalMassPolicySha256});
  if(!equalData(runtime,snapshot))throw Error('Runtime snapshots changed across WebCrypto binding');
  return receipt;
 }
 return Object.freeze({scope:'verified-source-gather-child',receiptSha256,materialBase:packed.materialBase,sourceMaterialCoordinatesSha256:packed.materialCoordinatesSha256,physicalMassPolicySha256,
  capture:()=>structuredClone({packed,physical,dictionary,layout,receipt}),assertUnchanged,assertRuntimeMobility,
  preparedOriginalFactory(actualLayout){if(!equalData(actualLayout,layout))throw Error('Actual used gate layout differs from original knot/stamp dictionary');closed.assertPackedGeometryUnchanged(packed);return sourceJointRefinedSeamFactory(closed,structuredClone(actualLayout));},
  preparedFactory(actualLayout){if(!equalData(actualLayout,layout))throw Error('Actual used gate layout differs from original knot/stamp dictionary');closed.assertPackedGeometryUnchanged(packed);return bodyFaceFeatureLanesWGSL(sourceJointRefinedSeamFactory(closed,structuredClone(actualLayout)));}});
}

/** App composition root supplies an INTERNAL current-scene capture closure. It must
 * lookup the genuine approved registry and check current generation before return.
 * Never expose this constructor or capture closure through window automation. */
const preparers=new WeakSet();
export const isBrowserOwnedPreparer=value=>preparers.has(value);
export function createBrowserRefinedPreparer(captureCurrentApp) {
 if(typeof captureCurrentApp!=='function')throw Error('Current app capture closure required');
 const owned=new WeakMap();
 const api=Object.freeze({async prepare(sourceBinding,mode='source'){
  if(mode==='native')return null;
  const binding=structuredClone(sourceBinding);
  const captured=await captureCurrentApp();
  if(captured?.prepared?.simData&&!captured.prepared.simData.sourceGatherRefinement&&!captured.prepared.simData.sourceGatherCollisionGeometry)return null;
  if(!captured||captured.registryApproved!==true||typeof captured.stillCurrent!=='function'||!captured.stillCurrent())throw Error('Genuine current app registry preparation required');
  if(!equalData(binding,captured.sourceBinding))throw Error('Caller source/body binding differs from actual app owner');
  const observedPrepared=structuredClone(captured.prepared);
  const options={...captured,prepared:observedPrepared,sourceBinding:binding};
  const value=await prepareFromCapturedApp(options,mode);
  if(!captured.stillCurrent()||!equalData(captured.prepared,observedPrepared))throw Error('App source/body/preparation changed across digest');
  if(value)owned.set(value,{captured,observedPrepared,binding});return value;
 },owns(value){const record=owned.get(value);return !!record&&record.captured.stillCurrent()&&equalData(record.captured.prepared,record.observedPrepared)&&equalData(record.captured.sourceBinding,record.binding);}});
 preparers.add(api);return api;
}
