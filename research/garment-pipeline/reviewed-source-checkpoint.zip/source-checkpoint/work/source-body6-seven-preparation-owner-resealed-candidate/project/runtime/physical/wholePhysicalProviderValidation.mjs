import{physicalMechanicalCandidateWGSL}from'./physicalMechanicalCandidateWGSL.mjs';
import{physicalBytesSha256,canonicalPhysicalCertificateText}from'./portablePhysicalHashes.mjs';
import{packagedPhysicalPolicy}from'./packagedPhysicalPolicy.mjs';
import{copyData,equalData}from'./snapshots.mjs';
import{wholePhysicalAliasWGSL}from'./wholePhysicalAliasWGSL.mjs';
import{wholePhysicalRowPackWGSL}from'./wholePhysicalRowPackWGSL.mjs';
import{wholeRelativeReactionWGSL}from'./wholeRelativeReactionWGSL.mjs';
import{wholePhysicalFixedCertificateWGSL}from'./wholePhysicalFixedCertificateWGSL.mjs';
import{wholePhysicalSelectionWGSL}from'./wholePhysicalSelectionWGSL.mjs';
import{physicalAnchorArenaWGSL}from'./physicalAnchorArenaWGSL.mjs';
import{PHYSICAL_REACTION_TOLERANCES,PHYSICAL_REACTION_TOLERANCE_POLICY_SHA256}from'./tolerancePolicy.mjs';
import{SOURCE_ANCHOR_PARTITION_POLICY,SOURCE_ANCHOR_PARTITION_POLICY_SHA256}from'./anchorPartitionPolicy.mjs';

const digest=x=>physicalBytesSha256(typeof x==='string'?new TextEncoder().encode(x):x),SHA=/^[a-f0-9]{64}$/;
export const wholePhysicalCombinationWGSL=String.raw`
@group(0) @binding(0) var<storage,read> parent:array<vec4f>;
@group(0) @binding(1) var<storage,read> physical:array<vec4f>;
@group(0) @binding(2) var<storage,read> numerical:array<vec4f>;
@group(0) @binding(3) var<storage,read_write> combined:array<vec4f>;
@group(0) @binding(4) var<storage,read_write> candidate:array<vec4f>;
@compute @workgroup_size(64) fn combine_contact(@builtin(global_invocation_id) gid:vec3u){
 let p=gid.x;if(p>=arrayLength(&parent)){return;}
 var q=parent[p];var d=vec4f(0.);
 if(q.w>0.){d=vec4f(physical[p].xyz+numerical[p].xyz,0.);for(var k=0u;k<3u;k++){if(d[k]!=0.){q[k]+=d[k];}}}
 combined[p]=d;candidate[p]=q;
}`;
export const WHOLE_PHYSICAL_EXECUTED_SHADER_SHA256S=packagedPhysicalPolicy.shaderSha256s;
const actualShaderSources={mechanicalCandidateShaderSha256:physicalMechanicalCandidateWGSL,physicalAliasShaderSha256:wholePhysicalAliasWGSL,physicalPackShaderSha256:wholePhysicalRowPackWGSL,reactionShaderSha256:wholeRelativeReactionWGSL,fixedCertificateShaderSha256:wholePhysicalFixedCertificateWGSL,selectionShaderSha256:wholePhysicalSelectionWGSL,arenaShaderSha256:physicalAnchorArenaWGSL,combinedContactShaderSha256:wholePhysicalCombinationWGSL};
export async function requireActualPackagedPhysicalPolicies(isCurrent){if(typeof isCurrent!=='function'||isCurrent()!==true)throw Error('Current physical policy owner required');for(const[k,code]of Object.entries(actualShaderSources)){const sha=await digest(code);if(isCurrent()!==true||sha!==WHOLE_PHYSICAL_EXECUTED_SHADER_SHA256S[k])throw Error('Actual packaged physical shader/policy changed');}return WHOLE_PHYSICAL_EXECUTED_SHADER_SHA256S;}

/** A frozen actual-device artifact must validate THESE kernels and policies.
 * The historic six-case world-coordinate shader cannot authorize this owner.
 * Approval digest is supplied by the pinned experiment adapter, never inferred
 * from a pass constructor, compiled shader, or caller readiness booleans.
 */
async function checkDeviceArtifact(artifact,approvedDigest){
 if(!(artifact instanceof Uint8Array)||!SHA.test(approvedDigest)||(await digest(artifact))!==approvedDigest)throw Error('Missing approved exact whole physical device artifact');
 const proof=JSON.parse(new TextDecoder().decode(artifact));
 if(proof.actualDeviceControlsPassed!==true||proof.resourcesClosed!==true||proof.scope!=='whole-physical-reaction-kernels-v1'||
  !SHA.test(proof.driverSha256)||!SHA.test(proof.authenticBodyBVHAnchorProbeReceiptSha256)||!SHA.test(proof.anchorProbeShaderSha256)||
  !Array.isArray(proof.scopedCases)||!['physical-normal','coupled-tangent','curved-body-material-anchor','all-fixed-protection','exact-functional-alias','fixed-signed-zero','persistent-anchor-stage-rollback'].every(c=>proof.scopedCases.includes(c))||
  Object.entries(WHOLE_PHYSICAL_EXECUTED_SHADER_SHA256S).some(([k,v])=>proof[k]!==v)||
  proof.validatedTolerancePolicySha256!==PHYSICAL_REACTION_TOLERANCE_POLICY_SHA256||
  canonicalPhysicalCertificateText(proof.validatedTolerances)!==canonicalPhysicalCertificateText(PHYSICAL_REACTION_TOLERANCES)||
  proof.validatedAnchorPartitionPolicySha256!==SOURCE_ANCHOR_PARTITION_POLICY_SHA256||
  canonicalPhysicalCertificateText(proof.validatedAnchorPartitionPolicy)!==canonicalPhysicalCertificateText(SOURCE_ANCHOR_PARTITION_POLICY))
  throw Error('Whole physical validation does not cover executed kernels/anchor/residual policies');
 return Object.freeze({...structuredClone(proof),receiptSha256:approvedDigest});
}

export async function requireWholePhysicalDeviceValidation(artifact,approvedDigest,{isCurrent}={}){if(!(artifact instanceof Uint8Array)||!SHA.test(approvedDigest)||typeof isCurrent!=="function"||isCurrent()!==true)throw Error("Missing actual current physical device artifact owner");const original={artifact,approvedDigest},snapshot=copyData(original);const proof=await checkDeviceArtifact(snapshot.artifact,snapshot.approvedDigest);if(isCurrent()!==true||!equalData(original,snapshot))throw Error("Device artifact owner/bytes changed across hash");return proof;}
