import {physicalBytesSha256} from './portablePhysicalHashes.mjs';
import {copyData,equalData} from './snapshots.mjs';
import{decodeWholePhysicalSelection}from'./wholePhysicalSelectionWGSL.mjs';
import{decodePhysicalFixedCertificate}from'./wholePhysicalFixedCertificateWGSL.mjs';
import{physicalInventoryReceiptSha256}from'./physicalInventoryHash.mjs';
const u32 = n => Number.isSafeInteger(n) && n >= 0 && n <= 0xffffffff;
const sha = /^[a-f0-9]{64}$/;
const hash = physicalBytesSha256;
const NONE = 0xffffffff;
/** Integer graph over actual GPU physical48B rows/32B terms. Host never creates
 * J, RHS, normals, masses or contact points. W is read ONLY for exact mobility.
 * All packed inequalities stay intact; this graph merely assigns selected
 * response rows to disjoint writable owners. Parent memberships are monotone,
 * including dormant groups, until the one physical parent ends. */
export async function graphActualPhysicalRows(input,isCurrent) {
 if(typeof isCurrent!=='function')throw Error('Actual physical graph generation lease required');
 const original=input;input=copyData(input);
 const current=()=>{if(isCurrent()!==true||!equalData(original,input))throw Error('Physical graph input/generation changed across async hashes');};
 current();
 const { rowBytes, termBytes, originalParentBytes, selectedPhysicalOrdinals, retainedComponents = [], expected,
  observedPackProof, binding, limits, selectionEvidence } = input;
 if (!(rowBytes instanceof Uint8Array) || rowBytes.byteLength % 48 ||
     !(termBytes instanceof Uint8Array) || termBytes.byteLength !== rowBytes.byteLength * 4 ||
     !(originalParentBytes instanceof Uint8Array) || originalParentBytes.byteLength % 16 ||
     !(selectedPhysicalOrdinals instanceof Uint32Array) ||
     !(observedPackProof instanceof Uint32Array) || observedPackProof.length !== 8 ||
     !expected || !['rows','rawOccurrences','particles','parentToken','sourceToken','bodyGeneration','physicalSubstep','gateRevision']
      .every(k => u32(expected[k])) || expected.rows < 1 || expected.particles < 1 ||
     expected.rows !== rowBytes.byteLength / 48 || expected.particles !== originalParentBytes.byteLength / 16 ||
     expected.parentToken < 1 || expected.sourceToken < 1 || expected.bodyGeneration < 1 ||
     expected.physicalSubstep < 1 || expected.physicalSubstep > 40 || !limits ||
     !['maximumRowsPerComponent','maximumParticlesPerComponent','maximumComponents'].every(k => u32(limits[k]) && limits[k] > 0) ||
     !binding || binding.actualGpuPhysicalPackProducer !== true || binding.actualGpuSelectionReadback !== true ||
     !['originalParentSha256','packedPhysicalRowsSha256','packedPhysicalTermsSha256','physicalSelectionReceiptSha256'].every(k => sha.test(binding[k])) ||
     await hash(originalParentBytes) !== binding.originalParentSha256 || await hash(rowBytes) !== binding.packedPhysicalRowsSha256 ||
     await hash(termBytes) !== binding.packedPhysicalTermsSha256)
  throw Error('Unbound actual physical row graph');
 // Replay the privately obtained complete GPU masks/proofs, not a caller's
 // authority boolean. Added rows must be exactly the union of real failed
 // ALL-fixed protection masks. Every byte digest and parent/epoch is checked.
 if(!Array.isArray(selectionEvidence)||!selectionEvidence.length)throw Error('Missing owned physical selection evidence');
 const actualSelected=new Set(),selectionHashes=[];
 for(let i=0;i<selectionEvidence.length;i++){
  const receipt=selectionEvidence[i];
  if(!receipt||await physicalInventoryReceiptSha256(receipt.proof,receipt.mask,receipt.binding)!==receipt.actualInventoryReceiptSha256||
   !['rows','rawOccurrences','parentToken','sourceToken','bodyGeneration','physicalSubstep','gateRevision'].every(k=>receipt.expected?.[k]===expected[k])||
   !['originalParentSha256','packedPhysicalRowsSha256','packedPhysicalTermsSha256'].every(k=>receipt.binding?.[k]===binding[k]))throw Error('Physical selection evidence was mutated/rebound');
  const decoded=i===0?decodeWholePhysicalSelection(receipt.mask,receipt.proof,receipt.expected):decodePhysicalFixedCertificate(receipt.mask,receipt.proof,receipt.expected);
  if(i>0&&decoded.accepted)throw Error('Accepted fixed certificate cannot invent added rows');
  const ordinals=i===0?decoded.selectedPhysicalOrdinals:decoded.additionalPhysicalOrdinals;
  for(const ordinal of ordinals)actualSelected.add(ordinal);selectionHashes.push(receipt.actualInventoryReceiptSha256);
 }
 if(await hash(new TextEncoder().encode(selectionHashes.join('\n')))!==binding.physicalSelectionReceiptSha256||
  actualSelected.size!==selectedPhysicalOrdinals.length||selectedPhysicalOrdinals.some(r=>!actualSelected.has(r)))throw Error('Selected graph differs from complete actual GPU masks');
 current();
 const wanted = [0, expected.rows, expected.rawOccurrences, expected.rows * 6, expected.parentToken,
  expected.sourceToken, expected.bodyGeneration, expected.gateRevision];
 if (observedPackProof.some((x,i) => x !== wanted[i]) || new Set(selectedPhysicalOrdinals).size !== selectedPhysicalOrdinals.length ||
     selectedPhysicalOrdinals.some(r => r >= expected.rows)) throw Error('Stale/incomplete physical graph proof');
 const R = new Uint32Array(rowBytes.slice().buffer), F = new Float32Array(R.buffer);
 const T = new Uint32Array(termBytes.slice().buffer), TF = new Float32Array(T.buffer);
 const P = new Float32Array(originalParentBytes.slice().buffer), parent = Array.from({length:expected.particles},(_,i)=>i);
 for(let p=0;p<expected.particles;p++) if (!Number.isFinite(P[p*4+3]) || P[p*4+3]<0)
  throw Error('Invalid actual physical mobility');
 const find = p => {while(parent[p]!==p){parent[p]=parent[parent[p]];p=parent[p];}return p;};
 const unite = (a,b) => {a=find(a);b=find(b);parent[Math.max(a,b)]=Math.min(a,b);};
 const touched=new Set(), selected=new Set(selectedPhysicalOrdinals), responsive=[], feasibleZero=[];
 for(const group of retainedComponents){
  if(!group || !Array.isArray(group.ids) || new Set(group.ids).size!==group.ids.length ||
      group.ids.some(id => !u32(id) || id>=expected.particles || P[id*4+3]<=0)) throw Error('Invalid retained physical members');
  group.ids.forEach(id=>touched.add(id));group.ids.slice(1).forEach(id=>unite(group.ids[0],id));
 }
 const allOriginalRawOrdinals = new Uint32Array(expected.rows);
 for(let r=0;r<expected.rows;r++){
  const at=r*12,first=R[at+4],count=R[at+5],kind=R[at+6],original=R[at+7];
  if(first!==r*6 || count>6 || kind>1 || original>=expected.rawOccurrences || F[at+3]!==Math.fround(.001) ||
      F.slice(at,at+3).some(x=>!Number.isFinite(x)) || F.slice(at+8,at+12).some(x=>!Number.isFinite(x)) ||
      F[at+9]<0 || F[at+10]<F[at+11] || F[at+11]<0) throw Error('Malformed actual physical row');
  allOriginalRawOrdinals[r]=original;
  const ids=[], seen=new Set();
  for(let k=0;k<6;k++){
   const t=(first+k)*8,id=T[t+3];
   if(k>=count){if(id!==NONE || TF.slice(t,t+3).some(x=>x!==0) || TF[t+4]!==0) throw Error('Nonempty physical term padding');continue;}
   if(id>=expected.particles || seen.has(id) || TF.slice(t,t+3).some(x=>!Number.isFinite(x)) ||
       !Number.isFinite(TF[t+4])) throw Error('Malformed actual physical term');
   seen.add(id);
   // Signed +/-0 is exactly inactive; no small-weight threshold.
   if(P[id*4+3]>0 && TF.slice(t,t+3).some(x=>x!==0)) ids.push(id);
  }
  if(!selected.has(r)) continue;
  if(!ids.length){if(F[at+9]!==0 || F[at+8]>0) throw Error('Unresponsive physical deficit');feasibleZero.push(r);continue;}
  if(F[at+9]<=0) throw Error('Missing responsive physical diagonal');
  ids.forEach(id=>touched.add(id));ids.slice(1).forEach(id=>unite(ids[0],id));responsive.push({ordinal:r,ids});
 }
 const groups=new Map();for(const id of Array.from(touched).sort((a,b)=>a-b)){
  const root=find(id);if(!groups.has(root))groups.set(root,{root,ids:[],rows:[]});groups.get(root).ids.push(id);
 }
 for(const r of responsive)groups.get(find(r.ids[0])).rows.push(r.ordinal);
 const retained=Array.from(groups.values()), active=retained.filter(g=>g.rows.length);
 if(active.length>limits.maximumComponents)throw Error('Physical component count overflow');
 for(const g of retained)if(g.ids.length>limits.maximumParticlesPerComponent || g.rows.length>limits.maximumRowsPerComponent)
  throw Error('Explicit retained physical component overflow');
 const descriptors=[], members=[], owners=new Uint32Array(expected.particles).fill(NONE), base=active.length*4;
 active.forEach((g,c)=>{
  const firstRow=base+members.length;members.push(...g.rows);const firstNode=base+members.length;members.push(...g.ids);
  descriptors.push(firstRow,g.rows.length,firstNode,g.ids.length);g.ids.forEach(id=>{owners[id]=c;});
 });
 const ownerOffset=base+members.length,membership=new Uint32Array(base+members.length+owners.length);
 membership.set(descriptors);membership.set(members,base);membership.set(owners,ownerOffset);
 current();
 return {membership,descriptorOffset:0,ownerOffset,components:active.length,
  retainedComponents:structuredClone(retained),feasibleZeroOrdinals:Uint32Array.from(feasibleZero),
  allOriginalRawOrdinals,allFixedPhysicalInequalitiesRequired:true,physicalPressureAuthoritative:false};
}
