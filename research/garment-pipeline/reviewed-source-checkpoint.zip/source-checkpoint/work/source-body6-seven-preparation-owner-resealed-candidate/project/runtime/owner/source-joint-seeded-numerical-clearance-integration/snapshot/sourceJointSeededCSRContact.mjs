/** Copied isolated CSR operator. Native factory returns no allocation.
 * Actual GPU producer/complete requery/controller integration is NOT ready. */
export const SOURCE_JOINT_CSR_OPERATOR_ABI = 4;
export const sourceJointSeededCSRContactWGSL = String.raw `// NEW numerical-only seeded CSR ABI4. Not a finite geometry or garment certificate.
// Eight storage bindings, dynamic row/participant lengths, no private 1024/48 arrays.
// Host must validate immutable exact partitions, source/history/body hashes and all raw rows.
struct Row { first: u32, count: u32, need: f32, diagonal: f32 }
struct Term { gradient: vec3f, particle: u32 }
struct Component { firstRow: u32, rowCount: u32, firstNode: u32, nodeCount: u32 }
struct Config {
  counts: vec4u, // particles, original rows, terms, components
  limits: vec4u, // membership words, sweeps (1..256), owner offset, unsupported witnesses
  proof: vec4u,  // original-parent token, source token, body generation, gate revision
}
@group(0) @binding(0) var<storage, read> parent: array<vec4f>;
@group(0) @binding(1) var<storage, read> rows: array<Row>;
@group(0) @binding(2) var<storage, read> terms: array<Term>;
@group(0) @binding(3) var<storage, read> components: array<Component>;
@group(0) @binding(4) var<storage, read> membership: array<u32>;
@group(0) @binding(5) var<storage, read_write> delta: array<vec4f>;
@group(0) @binding(6) var<storage, read_write> lambda: array<f32>;
@group(0) @binding(7) var<storage, read_write> status: array<u32>;
@group(0) @binding(8) var<uniform> cfg: Config;
fn finite3(x: vec3f) -> bool { return all(abs(x) <= vec3f(3.402823466e38)); }
fn finite1(x: f32) -> bool { return abs(x) <= 3.402823466e38; }
fn fail(c: u32, reason: u32) { let base=8u+c*4u; status[base]=reason; status[base+1u]=0u; status[base+2u]=0u; status[base+3u]=cfg.proof.x; }
@compute @workgroup_size(1)
fn main(@builtin(global_invocation_id) gid: vec3u) {
  let c = gid.x;
  if (c >= cfg.counts.w || 8u+c*4u+3u >= arrayLength(&status)) { return; }
  // Header is actual GPU CSR producer proof: flags/rows/coverage/terms/components/
  // parent token/source token/reserved. A host-selected count cannot replace this gate.
  if(arrayLength(&status)<8u || status[0]!=0u || status[1]!=cfg.counts.y || status[2]!=7u || status[3]!=cfg.counts.z || status[4]!=cfg.counts.w || status[5]!=cfg.proof.x || status[6]!=cfg.proof.y){fail(c,16u);return;}
  // No unknown feature may be hidden by a supported-row solve.
  if (cfg.limits.w != 0u) { fail(c,32u); return; }
  if (cfg.counts.x*3u != arrayLength(&parent) || cfg.counts.x != arrayLength(&delta) || cfg.counts.y != arrayLength(&rows) || cfg.counts.y > arrayLength(&lambda) || cfg.counts.z != arrayLength(&terms) || cfg.counts.w != arrayLength(&components) || cfg.limits.x != arrayLength(&membership) || cfg.limits.y < 1u || cfg.limits.y > 256u || cfg.limits.z > cfg.limits.x || cfg.counts.x > cfg.limits.x-cfg.limits.z) { fail(c,1u); return; }
  let g = components[c];
  if (g.firstRow > cfg.limits.x || g.rowCount > cfg.limits.x-g.firstRow || g.firstNode > cfg.limits.x || g.nodeCount > cfg.limits.x-g.firstNode) { fail(c,1u); return; }
  // Dedicated validation pass before any mutable write. Host checks duplicates as well.
  for (var i=0u; i<g.nodeCount; i++) {
    let p=membership[g.firstNode+i];
    if (p>=cfg.counts.x) { fail(c,1u); return; }
    if (membership[cfg.limits.z+p]!=c || !finite3(parent[p].xyz) || !finite1(parent[p].w) || parent[p].w<0. || !finite3(parent[cfg.counts.x+p].xyz) || bitcast<u32>(parent[cfg.counts.x+p].w)!=bitcast<u32>(parent[p].w) || !finite3(parent[2u*cfg.counts.x+p].xyz) || parent[2u*cfg.counts.x+p].w!=0.) { fail(c,2u); return; }
  }
  for (var i=0u; i<g.rowCount; i++) {
    let r=membership[g.firstRow+i]; if (r>=cfg.counts.y) { fail(c,1u); return; }
    let q=rows[r];
    if(q.first>cfg.counts.z || q.count>cfg.counts.z-q.first || q.count>6u || !finite1(q.need) || !finite1(q.diagonal) || q.diagonal<=0.) { fail(c,2u); return; }
    for (var j=0u;j<q.count;j++) {
      let t=terms[q.first+j];
      if(t.particle>=cfg.counts.x) { fail(c,1u); return; }
      if(membership[cfg.limits.z+t.particle]!=c || parent[t.particle].w<=0. || !finite3(t.gradient)) { fail(c,2u); return; }
    }
  }
  for(var i=0u;i<g.nodeCount;i++){delta[membership[g.firstNode+i]]=vec4f(0.);}
  for(var i=0u;i<g.rowCount;i++){lambda[membership[g.firstRow+i]]=0.;}
  // Global storage streams arbitrary validated component size. Each component owns its
  // nodes/rows exclusively; no float atomics, no cross-workgroup barriers required.
  for(var sweep=0u;sweep<cfg.limits.y;sweep++) {
    for(var i=0u;i<g.rowCount;i++) {
      let r=membership[g.firstRow+i];let q=rows[r];var effect=0.;
      for(var j=0u;j<q.count;j++){let t=terms[q.first+j];effect+=dot(t.gradient,delta[t.particle].xyz);}
      let next=max(0.,lambda[r]+(q.need-effect)/q.diagonal);let change=next-lambda[r];
      if(!finite1(next)||!finite1(change)){fail(c,2u);return;}
      lambda[r]=next;
      for(var j=0u;j<q.count;j++){let t=terms[q.first+j];let d=delta[t.particle].xyz+parent[t.particle].w*t.gradient*change;if(!finite3(d)){fail(c,2u);return;}delta[t.particle]=vec4f(d,0.);}
    }
  }
  var maximumNet=0.;var maximumDeficit=0.;
  for(var i=0u;i<g.nodeCount;i++) {
    let p=membership[g.firstNode+i];
    // Actual stored f32 candidate, not a double norm of the ideal correction.
    var candidate=parent[cfg.counts.x+p].xyz;
    for(var k=0u;k<3u;k++){if(delta[p][k]!=0.){let total=parent[2u*cfg.counts.x+p][k]+delta[p][k];candidate[k]=select(parent[p][k]+total,parent[p][k],total==0.);}}
    if(!finite3(candidate)){fail(c,2u);return;}
    let net=length(candidate-parent[p].xyz);maximumNet=max(maximumNet,net);
    let world=max(1.,max(max(abs(parent[p].x),abs(parent[p].y)),max(abs(parent[p].z),max(max(abs(candidate.x),abs(candidate.y)),abs(candidate.z)))));
    if(net>0.005-8.*5.960464477539063e-8*(world+0.005)){fail(c,4u);return;}
  }
  for(var i=0u;i<g.rowCount;i++) {
    let r=membership[g.firstRow+i];let q=rows[r];var effect=0.;
    for(var j=0u;j<q.count;j++){let t=terms[q.first+j];effect+=dot(t.gradient,delta[t.particle].xyz);}
    maximumDeficit=max(maximumDeficit,q.need-effect);
  }
  // Exact strict physical/finite raw certificate and fresh full requery remain mandatory.
  // This status proves only finite streamed arithmetic and a conservative packed NET bound. Host must
  // independently verify actual stored f32 displacement<=5mm before publication.
  let base=8u+c*4u;status[base]=0u;status[base+1u]=bitcast<u32>(maximumNet);status[base+2u]=bitcast<u32>(maximumDeficit);status[base+3u]=cfg.proof.x;
}

// A separate dispatch barrier precedes apply. ANY component error prevents the
// ENTIRE response; failed output is byte-preserved mechanical seed, never a partial patch.
@compute @workgroup_size(64)
fn apply(@builtin(global_invocation_id) gid:vec3u){
 let p=gid.x;if(p>=cfg.counts.x){return;}var valid=status[0]==0u&&status[2]==7u;
 for(var c=0u;c<cfg.counts.w;c++){let base=8u+c*4u;if(base+3u>=arrayLength(&status)||status[base]!=0u||status[base+3u]!=cfg.proof.x){valid=false;}}
 var out=parent[cfg.counts.x+p];if(valid&&parent[p].w>0.){for(var k=0u;k<3u;k++){if(delta[p][k]!=0.){let total=parent[2u*cfg.counts.x+p][k]+delta[p][k];out[k]=select(parent[p][k]+total,parent[p][k],total==0.);}}}
 delta[p]=out;
}
`;
