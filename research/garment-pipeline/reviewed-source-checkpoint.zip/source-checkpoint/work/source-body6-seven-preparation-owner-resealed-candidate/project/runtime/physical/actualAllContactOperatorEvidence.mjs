import{physicalBytesSha256}from'./portablePhysicalHashes.mjs';
import{copyData,equalData}from'./snapshots.mjs';
const sha=/^[a-f0-9]{64}$/;
/** Complete operator receipt. Pressure records are body-only; positive self
 * multipliers remain HERE, bound with every unselected zero-pressure protection
 * and actual direct delta. This does not infer fresh finite/path acceptance. */
async function decodeOperator(packet,reaction,binding,particles){
 if(packet?.actualGpuPhysicalPackProducer!==true||reaction?.actualGpuReactionReadback!==true||reaction.physicalOperatorAccepted!==true||
  reaction.normalMultiplierUnit!=='kg-m'||reaction.numericalMarginIsPhysicalPressure!==false||!(packet.actualPhysicalRows instanceof Uint8Array)||packet.actualPhysicalRows.byteLength%48||
  !(packet.actualPhysicalTerms instanceof Uint8Array)||packet.actualPhysicalTerms.byteLength!==packet.actualPhysicalRows.byteLength*4||
  !(packet.proof instanceof Uint32Array)||packet.proof.length!==8||!(reaction.statusCapacity instanceof Uint32Array)||
  !(reaction.reaction instanceof Float32Array)||!(reaction.idealCombinedContactDelta instanceof Float32Array)||
  !Number.isSafeInteger(particles)||particles<1||reaction.idealCombinedContactDelta.length!==particles*4||
  reaction.reaction.length!==packet.actualPhysicalRows.byteLength/12||reaction.reaction.some(x=>!Number.isFinite(x))||
  reaction.idealCombinedContactDelta.some(x=>!Number.isFinite(x))||
  !binding||!['originalParentSha256','historySha256','sourceSha256','bodySha256','usedGateSha256','fullRawRow128Sha256','physicalMassPolicySha256','declaredFrictionProfileSha256',
   'executedTolerancePolicySha256','executedAnchorPartitionPolicySha256'].every(k=>sha.test(binding[k])))throw Error('Incomplete actual ALL-contact physical operator evidence');
 const R=packet.actualPhysicalRows.byteLength/48,header=reaction.statusCapacity,proof=packet.proof;
 if(header.length<16||[0,R,7,R*6,reaction.executed?.components,binding.key?.parentToken,binding.sourceToken,1].some((v,i)=>header[i]!==v)||
  [0,R,binding.rawOccurrences,R*6,binding.key?.parentToken,binding.sourceToken,binding.bodyGeneration,binding.key?.gateRevision].some((v,i)=>proof[i]!==v))
  throw Error('ALL-contact operator count/header mismatch');
 const rows=new Uint32Array(packet.actualPhysicalRows.slice().buffer);let body=0,self=0;
 for(let r=0;r<R;r++){
  if(rows[r*12+6]===0)body++;else if(rows[r*12+6]===1)self++;else throw Error('Unknown physical contact kind');
  if(reaction.reaction[r*4]<0)throw Error('Negative ALL-contact physical lambda');
 }
 for(let p=0;p<particles;p++)if(reaction.idealCombinedContactDelta[p*4+3]!==0)throw Error('Physical operator changed W');
 const parts=[new TextEncoder().encode('actual-all-contact-physical-operator-v1\n'),new TextEncoder().encode(JSON.stringify(binding)),...[packet.actualPhysicalRows,packet.actualPhysicalTerms,proof,header,reaction.reaction,reaction.idealCombinedContactDelta].map(bytes=>new Uint8Array(bytes.buffer,bytes.byteOffset,bytes.byteLength))];
 const all=new Uint8Array(parts.reduce((n,b)=>n+b.byteLength,0));let offset=0;for(const bytes of parts){all.set(bytes,offset);offset+=bytes.byteLength;}const hash=await physicalBytesSha256(all);
 return{reactionRecordScope:'body-pressure-friction-only-v1',actualAllContactOperatorReceiptSha256:hash,
  allContactPhysicalRowCount:R,bodyContactPhysicalRowCount:body,selfContactPhysicalRowCount:self,
  normalReactionAuthoritative:false,freshAllRawPhysicalCertificateRequired:true};
}

function consume(packet,reaction,binding,particles){return{packet:{actualGpuPhysicalPackProducer:packet?.actualGpuPhysicalPackProducer,actualPhysicalRows:packet?.actualPhysicalRows,actualPhysicalTerms:packet?.actualPhysicalTerms,proof:packet?.proof},reaction:{actualGpuReactionReadback:reaction?.actualGpuReactionReadback,physicalOperatorAccepted:reaction?.physicalOperatorAccepted,normalMultiplierUnit:reaction?.normalMultiplierUnit,numericalMarginIsPhysicalPressure:reaction?.numericalMarginIsPhysicalPressure,statusCapacity:reaction?.statusCapacity,reaction:reaction?.reaction,idealCombinedContactDelta:reaction?.idealCombinedContactDelta,executed:reaction?.executed},binding,particles};}
export async function actualAllContactOperatorEvidence(packet,reaction,binding,particles,{isCurrent}={}){if(typeof isCurrent!=="function"||isCurrent()!==true)throw Error("Actual current operator owner required");const snapshot=copyData(consume(packet,reaction,binding,particles));const result=await decodeOperator(snapshot.packet,snapshot.reaction,snapshot.binding,snapshot.particles);if(isCurrent()!==true||!equalData(consume(packet,reaction,binding,particles),snapshot))throw Error("Operator owner/input changed across hash");return result;}
