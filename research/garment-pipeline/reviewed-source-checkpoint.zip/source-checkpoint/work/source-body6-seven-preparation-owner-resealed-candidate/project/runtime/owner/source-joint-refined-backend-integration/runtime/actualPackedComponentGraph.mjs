/** Host integer graph only, from actual GPU CSR packing. ALL finite rows remain
 * outside this response graph and must be rechecked. No CPU geometry arithmetic. */
export function graphActualPackedRows(rowBytes,termBytes,originalIds,particleCount,retained=[],limits={maximumRows:32768,maximumParticles:particleCount}){
 const R=new Uint32Array(rowBytes),F=new Float32Array(rowBytes),T=new Uint32Array(termBytes),TF=new Float32Array(termBytes);
 if(R.length!==originalIds.length*4||T.length!==originalIds.length*24||new Set(originalIds).size!==originalIds.length||!Number.isSafeInteger(particleCount)||particleCount<1)throw Error('Truncated actual GPU row graph');
 const parent=Array.from({length:particleCount},(_,i)=>i),touched=new Set(),find=p=>{while(parent[p]!==p)p=parent[p];return p;},union=(a,b)=>{a=find(a);b=find(b);parent[Math.max(a,b)]=Math.min(a,b);};
 for(const g of retained){if(!Array.isArray(g.ids)||new Set(g.ids).size!==g.ids.length)throw Error('Invalid dormant membership');for(const id of g.ids){if(!Number.isSafeInteger(id)||id<0||id>=particleCount)throw Error('Invalid parent member');touched.add(id);}for(const id of g.ids.slice(1))union(g.ids[0],id);}
 const responsive=[],zero=[];
 for(let i=0;i<originalIds.length;i++){
  const first=R[i*4],count=R[i*4+1],need=F[i*4+2],diag=F[i*4+3];
  if(first!==i*6||count>6||!Number.isFinite(need)||!Number.isFinite(diag)||diag<0)throw Error('Malformed actual packed response');
  const ids=[];
  for(let j=0;j<6;j++){const at=(first+j)*4,id=T[at+3];if(j>=count){if(id!==0xffffffff||TF.slice(at,at+3).some(v=>v!==0))throw Error('Unused slot not zero');continue;}
   if(id>=particleCount||TF.slice(at,at+3).some(v=>!Number.isFinite(v))||TF.slice(at,at+3).every(v=>v===0))throw Error('Invalid/nonresponsive term');ids.push(id);touched.add(id);
  }
  if(!count){if(diag!==0||need>0)throw Error('Kinematic deficit');zero.push(i);continue;}if(diag<=0)throw Error('Missing positive diagonal');
  for(const id of ids.slice(1))union(ids[0],id);responsive.push({ordinal:i,ids});
 }
 const groups=new Map();for(const id of touched){const root=find(id);if(!groups.has(root))groups.set(root,{ids:[],rows:[]});groups.get(root).ids.push(id);}
 for(const r of responsive)groups.get(find(r.ids[0])).rows.push(r.ordinal);
 const componentWords=[],members=[],owner=new Uint32Array(particleCount).fill(0xffffffff),metadata=[];
 // Empty dormant groups survive but are not dispatched as solver components.
 for(const[root,g]of groups){if(g.ids.length>limits.maximumParticles||g.rows.length>limits.maximumRows)throw Error('Explicit retained CSR capacity overflow');metadata.push({root,ids:g.ids.slice(),rows:g.rows.slice()});if(!g.rows.length)continue;const c=componentWords.length/4,firstRow=members.length;members.push(...g.rows);const firstNode=members.length;members.push(...g.ids);componentWords.push(firstRow,g.rows.length,firstNode,g.ids.length);g.ids.forEach(id=>{owner[id]=c;});}
 const ownerOffset=members.length;members.push(...owner);
 return {components:Uint32Array.from(componentWords),membership:Uint32Array.from(members),ownerOffset,retainedComponents:metadata,feasibleZeroOrdinals:zero,allOriginalIdsPreserved:originalIds.slice(),geometryCertified:false};
}
