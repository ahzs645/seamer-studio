const SHA = /^[a-f0-9]{64}$/;
const u32 = n => Number.isSafeInteger(n) && n >= 0 && n <= 0xffffffff;
const clone = x => structuredClone(x);
import { requirePhysicalIncomingRawProof } from './wholePhysicalAliasWGSL.mjs';

/** Integer bookkeeping for authentic GPU material anchor slots. This does NOT
 * manufacture q, barycentrics, offsets, anchors, multipliers or corrections.
 * The companion GPU arena must snapshot the actual anchor bytes at these slots.
 * Slots survive dormant contact and remain monotonic within a frame; rejected
 * frames restore their exact pre-frame dictionary rather than advancing history.
 */
export class PhysicalMaterialHistoryIndex {
 #capacity; #identity; #slots = new Map(); #frame = null; #acceptedProof = null;
 constructor(capacity, identity) {
  if (!u32(capacity) || capacity < 1 || !identity ||
      !['sourceSha256', 'bodySha256', 'physicalMassPolicySha256', 'declaredFrictionProfileSha256']
       .every(k => SHA.test(identity[k]))) throw Error('Invalid material history identity');
  this.#capacity = capacity; this.#identity = Object.freeze(clone(identity));
 }
 beforeFrame(key) {
  if (this.#frame || !key || !u32(key.generation) || !u32(key.frameSequence) ||
      !SHA.test(key.usedGateSha256) || !SHA.test(key.sourceDeltaPolicySha256))
   throw Error('Concurrent/unbound material history frame');
  this.#frame = { key: clone(key), checkpoint: this.snapshot(), lastPhysicalSubstep: 0, stagedPackets: [] };
 }
 stageActualMaterials(actual, binding) {
  const authenticEmpty = actual?.actualGpuEmptyInventoryReceipt === true &&
   actual.records instanceof Uint32Array && actual.records.length === 0 && SHA.test(actual.actualProducerReceiptSha256);
  if (!this.#frame || actual?.actualGpuKeyReceipt !== true && !authenticEmpty || !(actual.records instanceof Uint32Array) ||
      !(actual.proof instanceof Uint32Array) || actual.records.length % 40 ||
      actual.proof.length !== 8 || actual.proof[0] !== 0 ||
      actual.proof[1] !== actual.records.length / 40 || !binding?.key ||
      actual.proof[3] !== binding.key.parentToken || actual.proof[4] !== binding.sourceToken ||
      actual.proof[5] !== binding.bodyGeneration || actual.proof[6] !== binding.key.physicalSubstep ||
      actual.proof[7] !== binding.key.gateRevision ||
      binding.key.generation !== this.#frame.key.generation ||
      binding.key.frameSequence !== this.#frame.key.frameSequence ||
      binding.usedGateSha256 !== this.#frame.key.usedGateSha256 ||
      !u32(binding.key.physicalSubstep) || binding.key.physicalSubstep < 1 || binding.key.physicalSubstep > 40 ||
      binding.key.physicalSubstep < this.#frame.lastPhysicalSubstep ||
      !['sourceSha256', 'bodySha256', 'physicalMassPolicySha256', 'declaredFrictionProfileSha256']
       .every(k => binding[k] === this.#identity[k]) ||
      !['historySha256', 'originalParentSha256', 'fullRawRow128Sha256'].every(k => SHA.test(binding[k])) ||
      actual.records.length > 0 && !SHA.test(binding.finiteAnchorProbeSha256))
   throw Error('Material history lacks authentic bound GPU packet');
  if (!authenticEmpty && (!(actual.actualResponsiveMask instanceof Uint32Array) ||
      actual.actualResponsiveMask.length !== actual.records.length / 40 ||
      actual.actualResponsiveMask.some(v => v !== 0 && v !== 1) ||
      !SHA.test(actual.actualPhysicalReactionMaskReceiptSha256)))
   throw Error('Material history requires actual physical responsive mask');
  // Build a complete transaction first. Capacity/schema failure cannot partially
  // mutate the retained dictionary or publish an anchor slot for an unknown row.
  const slots = new Map(this.#slots), result = new Uint32Array(actual.records.length / 40).fill(0xffffffff);
  let bodyCount = 0;
  for (let ordinal = 0; ordinal < result.length; ordinal++) {
   const r = actual.records.subarray(ordinal * 40, (ordinal + 1) * 40);
   if (r[0] !== 1 || r[1] !== ordinal || r[2] > 1 || r[3] < 1 || r[3] > 6 || r[39] !== 0)
    throw Error('Invalid authentic material key');
   if (r[2] === 1) continue;
   bodyCount++;
   for (let k = 0; k < r[3]; k++) {
    const id = r[8 + k * 2], beta = r[9 + k * 2];
    if (id === 0xffffffff || k && id <= r[8 + (k - 1) * 2] ||
        beta === 0 || (beta & 0x80000000) || (beta & 0x7f800000) === 0x7f800000)
     throw Error('Malformed exact body material key');
   }
   // The actual GPU key already merged, sorted and rounded exact F32 betas.
   // Normal and plane are deliberately excluded from material persistence.
   const key = Array.from(r.subarray(8, 8 + r[3] * 2)).join(',');
   if (actual.actualResponsiveMask[ordinal] === 0) {
    // An existing dormant material target remains addressable; a new zero-
    // pressure ALLraw protection does not consume a persistent history slot.
    if (slots.has(key)) result[ordinal] = slots.get(key);
    continue;
   }
   if (!slots.has(key)) {
    if (slots.size >= this.#capacity) throw Error('Explicit material anchor history overflow');
    slots.set(key, slots.size);
   }
   result[ordinal] = slots.get(key);
  }
  if (bodyCount !== actual.proof[2]) throw Error('Incomplete actual body material inventory');
  this.#slots = slots; this.#frame.lastPhysicalSubstep = binding.key.physicalSubstep;
  this.#frame.stagedPackets.push({ key: clone(binding.key), fullRawRow128Sha256: binding.fullRawRow128Sha256,
   finiteAnchorProbeSha256: binding.finiteAnchorProbeSha256 ?? null, historySha256: binding.historySha256,
   rawOccurrences: result.length });
  return Object.freeze({ ordinalToHistorySlot: result, retainedSlotCount: slots.size,
   physicalHistoryAccepted: false, authenticGpuAnchorBytesRequired: true });
 }
 stageActualEmptyInventory(actual, binding) {
  // No key shader/anchor is needed for zero rows. Preserve the authentic GPU
  // full-inventory receipt instead of pretending a finite minimum was measured.
  if (actual?.authenticAllRawReadLease !== true || !SHA.test(actual.actualProducerReceiptSha256) ||
      !binding?.key || !u32(binding.sourceToken) || !u32(binding.bodyGeneration))
   throw Error('Empty material history lacks authentic producer receipt');
  requirePhysicalIncomingRawProof(actual.observedRawProof, 0);
  const keyProof = Uint32Array.of(0, 0, 0, binding.key.parentToken, binding.sourceToken,
   binding.bodyGeneration, binding.key.physicalSubstep, binding.key.gateRevision);
  const result = this.stageActualMaterials({ actualGpuEmptyInventoryReceipt: true,
   actualProducerReceiptSha256: actual.actualProducerReceiptSha256,
   records: new Uint32Array(0), proof: keyProof }, binding);
  this.#frame.stagedPackets.at(-1).actualEmptyProducerReceiptSha256 = actual.actualProducerReceiptSha256;
  return result;
 }
 acceptFrame(proof) {
  const minimumValid = proof && (Number.isFinite(proof.minimumClearanceLowerBoundM) &&
   proof.minimumClearanceLowerBoundM >= .001 || proof.minimumClearanceLowerBoundM === Infinity &&
   proof.rawOccurrences === 0 && proof.validatedRows === 0 &&
   proof.emptyBoundsEncoding === 'canonical-sorted-json-v2-empty-contact-bounds' &&
   this.#frame?.stagedPackets.every(p => p.rawOccurrences === 0 && SHA.test(p.actualEmptyProducerReceiptSha256)));
  if (!this.#frame || this.#frame.lastPhysicalSubstep !== 40 || this.#frame.stagedPackets.length < 40 ||
      !proof || proof.generation !== this.#frame.key.generation || proof.frameSequence !== this.#frame.key.frameSequence ||
      proof.usedGateSha256 !== this.#frame.key.usedGateSha256 || !SHA.test(proof.actualAll41GuardProofSha256) ||
      proof.samplesChecked !== 41 || proof.segmentsChecked !== 40 || proof.safe !== true ||
      !minimumValid ||
      proof.unsupportedWitnesses !== 0 || proof.clearanceFailures !== 0)
   throw Error('Material history requires complete actual41 and finite physical proof');
  const seen = new Set(this.#frame.stagedPackets.map(p => p.key.physicalSubstep));
  if (seen.size !== 40) throw Error('Skipped physical history substep');
  this.#acceptedProof = clone(proof); this.#frame = null;
 }
 rejectFrame() {
  if (!this.#frame) return;
  const checkpoint = this.#frame.checkpoint; this.#frame = null; this.restore(checkpoint);
 }
 snapshot() { return clone({ identity: this.#identity, capacity: this.#capacity,
  entries: Array.from(this.#slots), acceptedProof: this.#acceptedProof }); }
 captureTransaction() { return clone({revision:1,current:this.snapshot(),frame:this.#frame}); }
 restoreTransaction(input) {
  const s=clone(input),f=s?.frame;
  if(s?.revision!==1)throw Error('Unbound material history transaction revision');
  // Validate the whole candidate before touching retained/accepted state.
  const validator=new PhysicalMaterialHistoryIndex(this.#capacity,this.#identity);validator.restore(s.current);
  if(f!==null){
   if(!f||!f.key||!u32(f.key.generation)||!u32(f.key.frameSequence)||
    !SHA.test(f.key.usedGateSha256)||!SHA.test(f.key.sourceDeltaPolicySha256)||
    !u32(f.lastPhysicalSubstep)||f.lastPhysicalSubstep>40||!Array.isArray(f.stagedPackets)||
    f.stagedPackets.some(p=>!p?.key||!u32(p.key.physicalSubstep)||p.key.physicalSubstep<1||p.key.physicalSubstep>f.lastPhysicalSubstep||
     p.key.generation!==f.key.generation||p.key.frameSequence!==f.key.frameSequence||
     !['fullRawRow128Sha256','historySha256'].every(k=>SHA.test(p[k]))||
     !u32(p.rawOccurrences)||p.rawOccurrences===0&&!SHA.test(p.actualEmptyProducerReceiptSha256))||
    (f.stagedPackets.length===0?f.lastPhysicalSubstep!==0:Math.max(...f.stagedPackets.map(p=>p.key.physicalSubstep))!==f.lastPhysicalSubstep))
    throw Error('Malformed material history transaction frame');
   validator.restore(f.checkpoint);
  }
  this.#frame=null;this.restore(s.current);this.#frame=f;
 }
 restore(snapshot) {
  if (this.#frame) throw Error('Material history restore during active frame');
  const s = clone(snapshot);
  if (s?.capacity !== this.#capacity || JSON.stringify(s.identity) !== JSON.stringify(this.#identity) ||
      !Array.isArray(s.entries) || s.entries.length > this.#capacity ||
      s.entries.some((x, i) => !Array.isArray(x) || typeof x[0] !== 'string' || x[1] !== i) ||
      new Set(s.entries.map(x => x[0])).size !== s.entries.length) throw Error('History snapshot identity/capacity mismatch');
  this.#slots = new Map(s.entries); this.#acceptedProof = s.acceptedProof;
 }
 invalidate() { this.#frame = null; this.#slots.clear(); this.#acceptedProof = null; }
 get retainedSlotCount() { return this.#slots.size; }
}
