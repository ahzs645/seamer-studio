/** NEW ALL-fixed physical-inequality/KKT pass, seven? exactly EIGHT storage.
 * No finite-discovery pruning and no response-only certificate. Numerical work
 * margin never enters physical RHS or lambda. A separate complete FRESH finite
 * producer must still certify actual 1mm physical clearance and parent NET. */
export const wholePhysicalFixedCertificateWGSL=String.raw`
struct PhysicalRow{normal:vec4f,span:vec4u,data:vec4f}
struct PhysicalTerm{gradient:vec3f,particle:u32,scalar:vec4f}
struct Config{counts:vec4u,epoch:vec4u,policy:vec4f,proof:vec4u}
// particles,rows,terms,parent; source,body,step,gate; algebra,comp,NET,physical;
// packproof wordoffset,rawOccurrences,0,0
@group(0) @binding(0) var<storage,read> parent:array<vec4f>;
@group(0) @binding(1) var<storage,read> rows:array<PhysicalRow>;
@group(0) @binding(2) var<storage,read> terms:array<PhysicalTerm>;
@group(0) @binding(3) var<storage,read> ideal:array<vec4f>;
@group(0) @binding(4) var<storage,read> reaction:array<vec4f>;
@group(0) @binding(5) var<storage,read> packedProof:array<u32>;
@group(0) @binding(6) var<storage,read_write> additions:array<u32>;
@group(0) @binding(7) var<storage,read_write> state:array<atomic<u32>>;
@group(0) @binding(8) var<uniform> cfg:Config;
fn finite1(x:f32)->bool{return abs(x)<=3.402823466e38;}
fn finite3(x:vec3f)->bool{return all(abs(x)<=vec3f(3.402823466e38));}
@compute @workgroup_size(1) fn fixed_reset(){
 for(var k=0u;k<16u;k++){atomicStore(&state[k],0u);}
 atomicStore(&state[3],cfg.counts.w);atomicStore(&state[4],cfg.epoch.x);atomicStore(&state[5],cfg.epoch.y);
 atomicStore(&state[6],cfg.epoch.z);atomicStore(&state[7],cfg.epoch.w);atomicStore(&state[12],cfg.proof.y);atomicStore(&state[13],cfg.counts.y);
 if(arrayLength(&parent)!=cfg.counts.x||arrayLength(&rows)!=cfg.counts.y||arrayLength(&terms)!=cfg.counts.z||arrayLength(&ideal)!=cfg.counts.x||arrayLength(&reaction)!=cfg.counts.y||arrayLength(&additions)!=cfg.counts.y||cfg.counts.w==0u||cfg.epoch.x==0u||cfg.epoch.y==0u||cfg.epoch.z<1u||cfg.epoch.z>40u||cfg.policy.x<=0.0||cfg.policy.y<=0.0||cfg.policy.z!=.005||cfg.policy.w!=.001||!finite1(cfg.policy.x)||!finite1(cfg.policy.y)||cfg.proof.x>arrayLength(&packedProof)||arrayLength(&packedProof)-cfg.proof.x<8u){atomicOr(&state[0],16u);return;}
 let o=cfg.proof.x;
 if(packedProof[o]!=0u||packedProof[o+1u]!=cfg.counts.y||packedProof[o+2u]!=cfg.proof.y||packedProof[o+3u]!=cfg.counts.z||packedProof[o+4u]!=cfg.counts.w||packedProof[o+5u]!=cfg.epoch.x||packedProof[o+6u]!=cfg.epoch.y||packedProof[o+7u]!=cfg.epoch.w){atomicOr(&state[0],8u);}
}
@compute @workgroup_size(64) fn fixed_particles(@builtin(global_invocation_id) gid:vec3u){
 let p=gid.x;if(p>=cfg.counts.x||atomicLoad(&state[0])!=0u){return;}
 let q=parent[p];let d=ideal[p];
 if(!finite3(q.xyz)||!finite1(q.w)||q.w<0.0||!finite3(d.xyz)||d.w!=0.0||(q.w==0.0&&any(d.xyz!=vec3f(0.0)))){atomicOr(&state[0],2u);return;}
 var stored=q.xyz;for(var k=0u;k<3u;k++){if(d[k]!=0.0){stored[k]+=d[k];}}
 let net=length(stored-q.xyz);if(!finite3(stored)||!finite1(net)){atomicOr(&state[0],2u);return;}
 atomicMax(&state[11],bitcast<u32>(net));if(net>cfg.policy.z){atomicOr(&state[0],4u);}
}
@compute @workgroup_size(64) fn fixed_rows(@builtin(global_invocation_id) gid:vec3u){
 let r=gid.x;if(r>=cfg.counts.y){return;}additions[r]=0u;
 if(atomicLoad(&state[0])!=0u){return;}let row=rows[r];let multiplier=reaction[r];
 if(row.normal.w!=cfg.policy.w||!finite3(row.normal.xyz)||abs(length(row.normal.xyz)-1.0)>.00002||!finite1(row.data.x)||!finite1(row.data.y)||row.data.y<0.0||!finite1(multiplier.x)||multiplier.x<0.0||!finite3(multiplier.yzw)||row.span.z>1u||row.span.y>6u||row.span.x>cfg.counts.z||row.span.y>cfg.counts.z-row.span.x){atomicOr(&state[0],2u);return;}
 if(multiplier.x==0.0&&any(multiplier.yzw!=vec3f(0.0))){atomicOr(&state[0],2u);return;}
 var effect=0.0;
 for(var k=0u;k<row.span.y;k++){
  let term=terms[row.span.x+k];if(term.particle>=cfg.counts.x||!finite3(term.gradient)){atomicOr(&state[0],2u);return;}
  effect+=dot(term.gradient,ideal[term.particle].xyz);
 }
 let gap=effect-row.data.x;if(!finite1(gap)){atomicOr(&state[0],2u);return;}
 let deficit=max(0.0,-gap);let complement=select(0.0,abs(gap),multiplier.x>0.0);
 atomicMax(&state[8],bitcast<u32>(deficit));atomicMax(&state[9],bitcast<u32>(complement));
 let failed=deficit>cfg.policy.x||complement>cfg.policy.y;
 if(failed){atomicAdd(&state[2],1u);}
 if(deficit>cfg.policy.x&&multiplier.x==0.0){additions[r]=1u;atomicAdd(&state[10],1u);}
 if(row.data.y==0.0&&deficit>cfg.policy.x){atomicOr(&state[0],32u);}
 atomicAdd(&state[1],1u);
}
@compute @workgroup_size(1) fn fixed_complete(){
 if(atomicLoad(&state[1])!=cfg.counts.y){atomicOr(&state[0],8u);}
 // Bit64 is an honest failed fixed certificate. New protective rows may be
 // appended and the ENTIRE original-parent solve repeated; never accept it.
 if(atomicLoad(&state[2])!=0u){atomicOr(&state[0],64u);}
 atomicStore(&state[15],7u);
}
`;

export function decodePhysicalFixedCertificate(mask,proof,expected){
 const validU32=n=>Number.isSafeInteger(n)&&n>=0&&n<=0xffffffff;
 if(!(mask instanceof Uint32Array)||!(proof instanceof Uint32Array)||proof.length!==16||!expected||
  !['rows','rawOccurrences','parentToken','sourceToken','bodyGeneration','physicalSubstep','gateRevision'].every(k=>validU32(expected[k]))||
  expected.parentToken<1||expected.sourceToken<1||expected.bodyGeneration<1||expected.physicalSubstep<1||expected.physicalSubstep>40||
  mask.length!==expected.rows||mask.some(x=>x>1)||proof[1]!==expected.rows||proof[3]!==expected.parentToken||proof[4]!==expected.sourceToken||
  proof[5]!==expected.bodyGeneration||proof[6]!==expected.physicalSubstep||proof[7]!==expected.gateRevision||proof[12]!==expected.rawOccurrences||proof[13]!==expected.rows||proof[15]!==7||
  proof[10]!==mask.reduce((a,b)=>a+b,0))throw Error('Incomplete/stale ALL-fixed physical certificate');
 const F=new Float32Array(proof.slice().buffer),d=F[8],c=F[9],net=F[11];
 if(![d,c,net].every(x=>Number.isFinite(x)&&x>=0)||net>.005||
  !Number.isFinite(expected.algebraicNormalDeficitM)||!Number.isFinite(expected.algebraicComplementarityResidualM)||
  expected.algebraicNormalDeficitM<=0||expected.algebraicComplementarityResidualM<=0||
  (proof[0]!==0&&proof[0]!==64)||proof[2]>expected.rows||
  (proof[0]===0&&(proof[2]!==0||d>expected.algebraicNormalDeficitM||c>expected.algebraicComplementarityResidualM))||
  (proof[0]===64&&proof[2]===0))throw Error('Invalid/unusable ALL-fixed physical result');
 return {accepted:proof[0]===0,algebraicNormalDeficitM:d,algebraicComplementarityResidualM:c,originalParentNetM:net,
  additionalPhysicalOrdinals:Uint32Array.from(Array.from(mask,(v,i)=>v?i:-1).filter(i=>i>=0)),
  allFixedRowsChecked:expected.rows,freshAllRawPhysicalCertificateStillRequired:true,physicalPressureAuthoritative:false};
}
