import{acquireExactFiniteKernelBundle}from'../FiniteKernelCache.mjs';
/** NEW complete-body-BVH material-anchor producer. Actual source weights/IDs
 * come from authentic ALLraw Row128 ordinals. No CPU nearest/body-row upload.
 * Diagnostic scope until independent device replay and controller wiring.
 */
import { packJointBVHUniform } from '../owner/source-joint-executed-topology-anchor-integration/snapshot/SourceJointBVHFiniteExporter.mjs';
import { packJointClosedProbeTrees } from './ExecutedAnchorTrees.mjs';
import { sourceJointContactWGSL } from '../refined/vendor/sourceJointContact.mjs';
export const JOINT_BODY_ANCHOR_ABI = 2;
export const JOINT_BODY_ANCHOR_WORDS = 40;
export const JOINT_BODY_ANCHOR_PROOF_WORDS = 64;
export function jointBodyAnchorLayout(count, alignment = 256) {
    if (!Number.isSafeInteger(count) || count < 1 || count > 262144)
        throw Error('Explicit complete raw anchor capacity');
    if (!Number.isSafeInteger(alignment) || alignment < 16 || alignment > 16384 || (alignment & (alignment - 1)) !== 0)
        throw Error('Invalid portable storage alignment');
    const align = (x) => Math.ceil(x / alignment) * alignment, anchorsOffset = align(count * 160), proofOffset = align(anchorsOffset + count * 16);
    return Object.freeze({ count, alignment, recordWords: 40, recordByteLength: count * 160, anchorsOffset, anchorsByteLength: count * 16, proofOffset, proofByteLength: count * 256, byteLength: proofOffset + count * 256 });
}
/** Deterministic two-triple policy; no majority vote or arithmetic threshold change. */
export function certifyAnchorRayConsensus(primary, fallback, attempted) {
    const valid = (v) => v.length === 4 && v.every(Number.isInteger) && v.slice(0, 3).every(x => x === 0 || x === 1 || x === 2) && (v[3] === 0 || v[3] === 1) && (v[3] !== 1 || v[0] === v[1] && v[0] === v[2] && v[0] !== 2);
    if (!valid(primary) || !valid(fallback))
        throw Error('Malformed finite ray votes');
    if (!attempted && fallback.some((x, i) => x !== (i === 3 ? 0 : 2)))
        throw Error('Unattempted ray triple invented evidence');
    const contradiction = primary.slice(0, 3).includes(1) || (attempted && fallback.slice(0, 3).includes(1));
    const which = primary[3] === 1 ? 0 : attempted && fallback[3] === 1 ? 1 : -1;
    return Object.freeze({ supported: which >= 0 && !contradiction, which, contradiction });
}
function validateAnchorRayPolicy(packet, p, ready) {
    if (packet[p + 60] !== 2 || packet[p + 61] !== 1 || packet[p + 62] !== 64 || packet[p + 63] !== 40)
        throw Error('Finite ray/target policy lost');
    for (let side = 0; side < 2; side++) {
        const primary = Array.from(packet.slice(p + 24 + side * 4, p + 28 + side * 4)), fallback = Array.from(packet.slice(p + 40 + side * 4, p + 44 + side * 4)), attempt = packet[p + 58 + side];
        if (attempt > 1)
            throw Error('Invalid fallback attempt metadata');
        const c = certifyAnchorRayConsensus(primary, fallback, attempt === 1), which = packet[p + 56 + side];
        if (ready && !c.supported)
            throw Error('Unsupported/contradictory finite ray proof claimed ready');
        if (c.supported) {
            if (which !== c.which)
                throw Error('Canonical ray triple selection lost');
            const v = which === 0 ? 24 : 40, k = which === 0 ? 32 : 48;
            for (let i = 0; i < 4; i++)
                if (packet[p + 8 + side * 4 + i] !== packet[p + v + side * 4 + i] || packet[p + 16 + side * 4 + i] !== packet[p + k + side * 4 + i])
                    throw Error('Used ray votes/counts differ from preserved triple');
        }
    }
}
/** Strict receipt decoding only. Geometry authority is actual GPU finite query,
 * independently compared to CPU on device controls; not an asserted hash. */
export function decodeJointBodyAnchorReceipt(summary, packet, raw, layout, epoch, bodyFaces) {
    if (summary.length !== 24 || packet.byteLength !== layout.byteLength || raw.length !== layout.count * 32)
        throw Error('Truncated actual material anchor receipt');
    if (!Number.isSafeInteger(bodyFaces) || bodyFaces < 1)
        throw Error('Actual immutable body face count required');
    const f = new Float32Array(packet.buffer, packet.byteOffset, packet.length), rawf = new Float32Array(raw.buffer, raw.byteOffset, raw.length);
    if (summary[0] !== 0 || summary[1] !== layout.count || summary[2] !== 7 || summary[3] !== 0 || summary[5] !== layout.count)
        throw Error('Uncertified actual incoming raw inventory');
    if (summary[13] !== layout.count || summary[14] !== epoch.sourceToken || summary[15] !== epoch.correctedSubstep || summary[16] !== 2 || summary[17] !== 40 || summary[18] * 4 !== layout.anchorsOffset || summary[19] * 4 !== layout.proofOffset || summary[20] * 4 !== layout.byteLength || summary[21] !== epoch.sourceToken || summary[22] !== epoch.bodyGeneration || summary[23] !== epoch.gateRevision)
        throw Error('Actual anchor ABI/count/epoch/offset mismatch');
    if ((summary[8] & ~22) !== 0)
        throw Error('Unknown anchor proof flags');
    let body = 0, self = 0, ready = 0, unsupported = 0, processedBody = 0, processedSelf = 0;
    for (let ordinal = 0; ordinal < layout.count; ordinal++) {
        const p = layout.proofOffset / 4 + ordinal * 64, r = ordinal * 40, a = layout.anchorsOffset / 4 + ordinal * 4;
        if (packet[p] !== ordinal || packet[p + 1] !== epoch.sourceToken || packet[p + 2] !== epoch.bodyGeneration || packet[p + 3] !== epoch.correctedSubstep || packet[p + 4] !== epoch.gateRevision)
            throw Error('Original material ordinal/epoch lost');
        const flags = packet[p + 5];
        if (flags !== 0 && flags !== 4 && flags !== 16)
            throw Error('Invalid/unknown actual finite anchor row flags');
        if (flags === 16) {
            if (summary[8] === 0)
                throw Error('Header unsupported row under clear summary');
            for (let k = 0; k < 40; k++)
                if (packet[r + k] !== 0)
                    throw Error('Unprocessed anchor has invented data');
            for (let k = 0; k < 4; k++)
                if (packet[a + k] !== 0)
                    throw Error('Unprocessed compatible anchor invented');
            if (rawf[ordinal * 32 + 23] === 0)
                self++;
            else
                body++;
            continue;
        }
        if (rawf[ordinal * 32 + 23] === 0) {
            self++;
            processedSelf++;
            for (let k = 0; k < 40; k++)
                if (packet[r + k] !== 0)
                    throw Error('Self row invented body record');
            for (let k = 0; k < 4; k++)
                if (packet[a + k] !== 0)
                    throw Error('Self row invented body anchor');
            if (flags !== 0)
                throw Error('Self row has body-only unsupported proof');
            continue;
        }
        if (rawf[ordinal * 32 + 23] !== 1)
            throw Error('Unknown actual rigid/body discriminant');
        body++;
        processedBody++;
        for (let k = 0; k < 40; k++)
            if (k !== 3 && k !== 15 && k !== 35 && !Number.isFinite(f[r + k]))
                throw Error('Nonfinite actual body record');
        if (flags !== 0 || f[r + 39] !== 1 || f[a + 3] !== 1) {
            if (flags !== 4 || f[r + 39] !== 0 || f[a + 3] !== 0 || packet[r + 35] !== 0)
                throw Error('Unsupported record falsely ready');
            validateAnchorRayPolicy(packet, p, false);
            unsupported++;
            continue;
        }
        validateAnchorRayPolicy(packet, p, true);
        if (packet[r + 35] !== 1 || packet[p + 6] !== 0 || packet[p + 7] !== 0 || packet[p + 11] !== 1 || packet[p + 15] !== 1)
            throw Error('Body anchor confidence/class mismatch');
        if (packet[r + 3] >= bodyFaces || packet[r + 15] >= bodyFaces)
            throw Error('Returned nearest skin face outside immutable body');
        for (let k = 0; k < 3; k++)
            if (packet[p + 8 + k] !== 0 || packet[p + 12 + k] !== 0)
                throw Error('Confident body anchor without all-three outside votes');
        for (let k = 0; k < 40; k++)
            if (k !== 3 && k !== 15 && k !== 35 && !Number.isFinite(f[r + k]))
                throw Error('Nonfinite material anchor packet');
        if (!(f[r + 27] > 0 && f[r + 31] > 0 && f[r + 7] > f[r + 27] && f[r + 19] > f[r + 31] && f[r + 11] > f[r + 27] && f[r + 23] > f[r + 31]))
            throw Error('Body nearest sign lacks positive arithmetic margin');
        for (const at of [8, 20])
            if (Math.abs(Math.hypot(f[r + at], f[r + at + 1], f[r + at + 2]) - 1) > 2e-5)
                throw Error('Actual pseudonormal lacks unit witness');
        for (const at of [4, 16]) {
            let sum = 0;
            for (let k = 0; k < 3; k++) {
                if (f[r + at + k] < 0 || f[r + at + k] > 1)
                    throw Error('Body material partition outside finite simplex');
                sum += f[r + at + k];
            }
            if (Math.abs(sum - 1) > 2e-6)
                throw Error('Body material partition lost');
        }
        for (let k = 0; k < 3; k++) {
            const offset = Math.fround(f[r + 24 + k] - f[r + k]);
            if (new Uint32Array(Float32Array.of(offset).buffer)[0] !== packet[r + 32 + k])
                throw Error('Offset is not actual old material point minus old skin q');
            if (packet[a + k] !== packet[r + 36 + k])
                throw Error('Compatible anchor tail differs from record');
            if (packet[r + 24 + k] !== packet[a + k])
                throw Error('Canonical target is not actual OLD material point');
        }
        ready++;
    }
    if (summary[9] !== processedBody || summary[10] !== processedSelf || summary[11] !== ready || summary[12] !== unsupported || (summary[8] === 0 && (unsupported !== 0 || processedBody !== body || processedSelf !== self)) || (unsupported > 0 && (summary[8] & 4) === 0))
        throw Error('Incomplete ALLraw body anchor classification');
    return Object.freeze({ abi: 2, count: layout.count, bodyRows: body, selfRows: self, readyBodyRows: ready, unsupportedBodyRows: unsupported, unsupportedFlags: summary[8], allBodyAnchorsReady: summary[8] === 0 && ready === body && unsupported === 0, anchorOffsetBytes: layout.anchorsOffset, anchorByteLength: layout.anchorsByteLength, proofOffsetBytes: layout.proofOffset, recordByteLength: layout.recordByteLength, totalPacketByteLength: layout.byteLength, sourceToken: epoch.sourceToken, bodyGeneration: epoch.bodyGeneration, gateRevision: epoch.gateRevision, physicalSubstep: epoch.correctedSubstep, partitionPolicy: 'finite-simplex-[0,1]-sum-error-2e-6-dimensionless-v1', rayPolicy: 'complete-primary-or-one-alternate-triple-no-contradiction-v2', canonicalTarget: 'actual-old-material-point-bit-exact-v2', geometryAuthority: 'Requires authentic GPU buffer/hash/exclusive-lease binding; decoder alone is not a producer', physicalPressureReady: false, garmentAccepted: false });
}
export function sourceJointBodyMaterialAnchorWGSL(prepared, layout) {
    if (!prepared.enabled)
        throw Error('Closed fresh source anchor receipt required');
    const begin = sourceJointContactWGSL.indexOf('fn finite('), end = sourceJointContactWGSL.indexOf('fn rootOf(');
    if (begin < 0 || end <= begin)
        throw Error('Strict authentic Row128 validator missing');
    let finite = prepared.factory(layout);
    const signature = 'fn jointRecoveryParity(point:vec3f,margin:f32)->JointClosedRayVote{', directions = 'let directions=array<vec3f,3>(normalize(vec3f(1.0,0.373,0.719)),normalize(vec3f(-0.317,1.0,0.613)),normalize(vec3f(0.537,-0.419,1.0)));';
    if (!finite.includes(signature) || !finite.includes(directions))
        throw Error('Reviewed finite ray helper changed');
    finite = finite.replace(signature, 'fn jointAnchorRayTriple(point:vec3f,margin:f32,alternate:u32)->JointClosedRayVote{').replace(directions, 'var directions=array<vec3f,3>(normalize(vec3f(1.0,0.373,0.719)),normalize(vec3f(-0.317,1.0,0.613)),normalize(vec3f(0.537,-0.419,1.0)));if(alternate==1u){directions=array<vec3f,3>(normalize(vec3f(1.0,0.527,0.193)),normalize(vec3f(-0.683,1.0,0.271)),normalize(vec3f(0.239,-0.761,1.0)));}');
    finite += '\nfn jointRecoveryParity(point:vec3f,margin:f32)->JointClosedRayVote{return jointAnchorRayTriple(point,margin,0u);}\n';
    return finite + '\n' + sourceJointContactWGSL.slice(begin, end).replaceAll('cfg.clearance', '0.001') + /* wgsl */ `
// cache is a NEW isolated output packet at binding5; owner-cache functions are
// unreachable from these two entrypoints. Original raw rows at binding3 unchanged.
fn anchorV(ordinal:u32,slot:u32,v:vec4f){let base=ordinal*40u+slot*4u;for(var k=0u;k<4u;k++){atomicStore(&cache[base+k],bitcast<u32>(v[k]));}}
fn anchorProof(ordinal:u32,slot:u32,v:vec4u){let base=cfg.p1+ordinal*64u+slot*4u;for(var k=0u;k<4u;k++){atomicStore(&cache[base+k],v[k]);}}
@compute @workgroup_size(1) fn joint_anchor_reset(){
 for(var k=8u;k<24u;k++){atomicStore(&state[k],0u);}
 if(atomicLoad(&state[0])!=0u||atomicLoad(&state[2])!=7u||atomicLoad(&state[3])!=0u||atomicLoad(&state[1])!=cfg.capacity||atomicLoad(&state[5])!=cfg.capacity||arrayLength(&rows)<cfg.capacity||cfg.p0<cfg.capacity*40u||cfg.p1<cfg.p0+cfg.capacity*4u||arrayLength(&cache)!=cfg.p1+cfg.capacity*64u||!jointRecoveryClosedBodyValidated()||!jointBVHReady(true)){atomicOr(&state[8],16u);}
}
@compute @workgroup_size(64) fn joint_body_material_anchors(@builtin(global_invocation_id) gid:vec3u){
 let ordinal=gid.x;if(ordinal>=cfg.capacity){return;}
 for(var k=0u;k<40u;k++){atomicStore(&cache[ordinal*40u+k],0u);}
 for(var k=0u;k<4u;k++){atomicStore(&cache[cfg.p0+ordinal*4u+k],0u);}
 for(var k=0u;k<64u;k++){atomicStore(&cache[cfg.p1+ordinal*64u+k],0u);}
 anchorProof(ordinal,0u,vec4u(ordinal,cfg.sourceToken,cfg.bodyGeneration,cfg.substep));
 anchorProof(ordinal,1u,vec4u(cfg.gateRevision,0u,2u,2u));
 for(var slot=2u;slot<=3u;slot++){anchorProof(ordinal,slot,vec4u(2u,2u,2u,0u));}
 for(var slot=6u;slot<=7u;slot++){anchorProof(ordinal,slot,vec4u(2u,2u,2u,0u));}
 for(var slot=10u;slot<=11u;slot++){anchorProof(ordinal,slot,vec4u(2u,2u,2u,0u));}
 anchorProof(ordinal,14u,vec4u(0u,0u,0u,0u));anchorProof(ordinal,15u,vec4u(2u,1u,64u,40u));
 if((atomicLoad(&state[8])&16u)!=0u){anchorProof(ordinal,1u,vec4u(cfg.gateRevision,16u,2u,2u));return;}
 let r=rows[ordinal];if(!validRow(r)){anchorProof(ordinal,1u,vec4u(cfg.gateRevision,2u,2u,2u));atomicOr(&state[8],2u);return;}
 if(r.q.w==0.0){atomicAdd(&state[10],1u);return;}
 atomicAdd(&state[9],1u);
 var oldPoint=vec3f(0.0);var currentPoint=vec3f(0.0);
 for(var k=0u;k<3u;k++){let id=r.a[k];if(id==NONE){continue;}
  if(id>=cfg.particles||bitcast<u32>(current[id].w)!=bitcast<u32>(previous[id].w)||current[id].w<0.0){atomicOr(&state[8],2u);anchorProof(ordinal,1u,vec4u(cfg.gateRevision,2u,2u,2u));return;}
  oldPoint+=previous[id].xyz*r.wa[k];currentPoint+=current[id].xyz*r.wa[k];
 }
 if(!jointBVHFinite(oldPoint)||!jointBVHFinite(currentPoint)){atomicOr(&state[8],2u);return;}
 let before=jointNearestBody(oldPoint);let now=jointNearestBody(currentPoint);
 if(before.face==JOINT_BVH_NONE||now.face==JOINT_BVH_NONE||!jointBVHFinite(before.n)||!jointBVHFinite(now.n)||length(before.n)<0.5||length(now.n)<0.5){atomicOr(&state[8],4u);atomicAdd(&state[12],1u);anchorProof(ordinal,1u,vec4u(cfg.gateRevision,4u,2u,2u));return;}
 let oldBound=jointRecoveryBound(oldPoint,before);let nowBound=jointRecoveryBound(currentPoint,now);
 let oldGap=dot(oldPoint-before.q,before.n);let nowGap=dot(currentPoint-now.q,now.n);
 let oldBody=bodyPoints(before.face);let nowBody=bodyPoints(now.face);
 let oldBary=finiteBarycentric(oldBody,before.q);let nowBary=finiteBarycentric(nowBody,now.q);
 let oldPrimary=jointRecoveryParity(oldPoint,oldBound);let nowPrimary=jointRecoveryParity(currentPoint,nowBound);
 var oldVotes=oldPrimary;var nowVotes=nowPrimary;var oldFallback:JointClosedRayVote;var nowFallback:JointClosedRayVote;
 oldFallback.votes=vec4u(2u,2u,2u,0u);oldFallback.counts=vec4u(0u);nowFallback.votes=vec4u(2u,2u,2u,0u);nowFallback.counts=vec4u(0u);
 var oldAttempt=0u;var nowAttempt=0u;var oldUsed=0u;var nowUsed=0u;
 if(oldPrimary.votes.w!=1u){oldAttempt=1u;oldFallback=jointAnchorRayTriple(oldPoint,oldBound,1u);if(oldFallback.votes.w==1u&&!any(oldPrimary.votes.xyz==vec3u(1u))&&!any(oldFallback.votes.xyz==vec3u(1u))){oldVotes=oldFallback;oldUsed=1u;}}
 if(nowPrimary.votes.w!=1u){nowAttempt=1u;nowFallback=jointAnchorRayTriple(currentPoint,nowBound,1u);if(nowFallback.votes.w==1u&&!any(nowPrimary.votes.xyz==vec3u(1u))&&!any(nowFallback.votes.xyz==vec3u(1u))){nowVotes=nowFallback;nowUsed=1u;}}
 anchorProof(ordinal,6u,oldPrimary.votes);anchorProof(ordinal,7u,nowPrimary.votes);anchorProof(ordinal,8u,oldPrimary.counts);anchorProof(ordinal,9u,nowPrimary.counts);
 anchorProof(ordinal,10u,oldFallback.votes);anchorProof(ordinal,11u,nowFallback.votes);anchorProof(ordinal,12u,oldFallback.counts);anchorProof(ordinal,13u,nowFallback.counts);anchorProof(ordinal,14u,vec4u(oldUsed,nowUsed,oldAttempt,nowAttempt));
 let oldClass=select(2u,oldVotes.votes.x,oldVotes.votes.w==1u);let nowClass=select(2u,nowVotes.votes.x,nowVotes.votes.w==1u);
 let offset=oldPoint-before.q;let anchor=oldPoint;
 anchorV(ordinal,0u,vec4f(before.q,bitcast<f32>(before.face)));
 anchorV(ordinal,1u,vec4f(oldBary,before.distance));
 anchorV(ordinal,2u,vec4f(before.n,oldGap));
 anchorV(ordinal,3u,vec4f(now.q,bitcast<f32>(now.face)));
 anchorV(ordinal,4u,vec4f(nowBary,now.distance));
 anchorV(ordinal,5u,vec4f(now.n,nowGap));
 anchorV(ordinal,6u,vec4f(oldPoint,oldBound));anchorV(ordinal,7u,vec4f(currentPoint,nowBound));
 anchorV(ordinal,8u,vec4f(offset,bitcast<f32>(0u)));anchorV(ordinal,9u,vec4f(anchor,0.0));
 anchorProof(ordinal,2u,oldVotes.votes);anchorProof(ordinal,3u,nowVotes.votes);
 anchorProof(ordinal,4u,oldVotes.counts);anchorProof(ordinal,5u,nowVotes.counts);
 let baryValid=jointBVHFinite(oldBary)&&jointBVHFinite(nowBary)&&all(oldBary>=vec3f(0.0))&&all(nowBary>=vec3f(0.0))&&all(oldBary<=vec3f(1.0))&&all(nowBary<=vec3f(1.0))&&abs(dot(oldBary,vec3f(1.0))-1.0)<=2e-6&&abs(dot(nowBary,vec3f(1.0))-1.0)<=2e-6;
 if(!baryValid||oldClass!=0u||nowClass!=0u||oldGap<=oldBound||nowGap<=nowBound||before.distance<=oldBound||now.distance<=nowBound){atomicOr(&state[8],4u);atomicAdd(&state[12],1u);anchorProof(ordinal,1u,vec4u(cfg.gateRevision,4u,oldClass,nowClass));return;}
 // Exact actual old material point - old finite skin q. A rotating normal must
 // never discard this offset and invent tangential slip from skin q alone.
 anchorV(ordinal,8u,vec4f(offset,bitcast<f32>(1u)));anchorV(ordinal,9u,vec4f(anchor,1.0));
 for(var k=0u;k<3u;k++){atomicStore(&cache[cfg.p0+ordinal*4u+k],bitcast<u32>(anchor[k]));}atomicStore(&cache[cfg.p0+ordinal*4u+3u],bitcast<u32>(1.0));
 anchorProof(ordinal,1u,vec4u(cfg.gateRevision,0u,oldClass,nowClass));atomicAdd(&state[11],1u);
}
@compute @workgroup_size(1) fn joint_anchor_complete(){
 if(atomicLoad(&state[9])+atomicLoad(&state[10])!=cfg.capacity||atomicLoad(&state[11])!=atomicLoad(&state[9])){atomicOr(&state[8],4u);}
 atomicStore(&state[13],cfg.capacity);atomicStore(&state[14],cfg.sourceToken);atomicStore(&state[15],cfg.substep);
 atomicStore(&state[16],2u);atomicStore(&state[17],40u);atomicStore(&state[18],cfg.p0);atomicStore(&state[19],cfg.p1);
 atomicStore(&state[20],arrayLength(&cache));atomicStore(&state[21],cfg.sourceToken);atomicStore(&state[22],cfg.bodyGeneration);atomicStore(&state[23],cfg.gateRevision);
}
`;
}
/** Caller owns authentic Row128/current/history/gate read lease across dispatch,
 * map and downstream receipt. Host only packs static BVH topology/bytes. */
export class SourceJointBodyMaterialAnchorProbe {
    device;
    prepared;
    layout;
    rawProof;
    count;
    epoch;
    productionIntegrationReady = false;
    packet;
    proof;
    outputLayout;
    owned = [];
    config;
    group;
    pipelines;
    initial;
    closed = false;
    closing = false;
    closePromise;
    constructor(device, prepared, observed, gate, layout, raw, rawProof, count, epoch, kernelAuthority = null) {
        this.device = device;
        this.prepared = prepared;
        this.layout = layout;
        this.rawProof = rawProof;
        this.count = count;
        this.epoch = epoch;
        if (!prepared.enabled || device.limits.maxStorageBuffersPerShaderStage < 8 || gate !== observed.gateBuffer || raw === observed.currentBuffer || raw === observed.previousBuffer || raw.size < count * 128 || rawProof.size < 32)
            throw Error('Unbound actual allraw anchor inputs');
        this.outputLayout = jointBodyAnchorLayout(count, device.limits.minStorageBufferOffsetAlignment ?? 256);
        if (this.outputLayout.byteLength > device.limits.maxStorageBufferBindingSize)
            throw Error('Complete anchor packet exceeds binding capacity');
        this.initial = { ...observed, binding: { ...observed.binding }, current: observed.current.slice(), previous: observed.previous.slice(), gateWords: observed.gateWords.slice() };
        this.epoch = { ...epoch };
        if (!Object.values(epoch).every(v => Number.isSafeInteger(v) && v >= 0 && v <= 0xffffffff) || epoch.sourceToken !== observed.binding.sourceToken || epoch.bodyGeneration !== observed.binding.bodyGeneration || epoch.gateRevision !== observed.binding.gateRevision || epoch.correctedSubstep < 1 || epoch.correctedSubstep > 40)
            throw Error('Unbound material anchor physical epoch');
        const make = (label, size, usage = GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST) => { const b = device.createBuffer({ label: 'joint-body-anchor:' + label, size: Math.max(4, size), usage }); this.owned.push(b); return b; };
        try {
            const p = prepared.packed;
            prepared.assertPackedGeometryUnchanged(p);
            const trees = packJointClosedProbeTrees(p, observed, prepared.verifiedRefinedScope, layout);
            const geometry = make('immutable-geometry', p.words.byteLength), cloth = make('actual-cloth-BVH', trees.cloth.words.byteLength), body = make('complete-body-BVH', trees.body.words.byteLength);
            device.queue.writeBuffer(geometry, 0, new Uint32Array(p.words));
            device.queue.writeBuffer(cloth, 0, new Uint32Array(trees.cloth.words));
            device.queue.writeBuffer(body, 0, new Uint32Array(trees.body.words));
            this.packet = make('all-ordinal160-plus-target-and-proof', this.outputLayout.byteLength);
            this.proof = make('actual-input-proof-and-anchor-summary', 96);
            this.config = make('immutable-snapshot512', 512, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST);
            const layoutEntries = [...Array.from({ length: 8 }, (_, binding) => ({ binding, visibility: GPUShaderStage.COMPUTE, buffer: { type: [0, 1, 2, 7].includes(binding) ? 'read-only-storage' : 'storage' } })), { binding: 8, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'uniform' } }, { binding: 9, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'uniform' } }];
            this.compilationSource=sourceJointBodyMaterialAnchorWGSL(prepared,layout);
            const entryPoints=['joint_anchor_reset','joint_body_material_anchors','joint_anchor_complete'];
            // Only exact compiled objects are shared. Query trees, input bindings,
            // uniform, packet and proofs above remain separately owned and fresh.
            const kernels=acquireExactFiniteKernelBundle(device,{authority:kernelAuthority??this,code:this.compilationSource,layoutEntries,entryPoints});
            this.compilationPromise=kernels.compilationPromise;this.compilationPromise.catch(()=>{});
            this.pipelines=entryPoints.map(entryPoint=>kernels.pipelines[entryPoint]);
            const l=kernels.layout;
            this.group = device.createBindGroup({ layout: l, entries: [observed.currentBuffer, observed.previousBuffer, geometry, raw, this.proof, this.packet, cloth, body, this.config, gate].map((buffer, binding) => ({ binding, resource: { buffer } })) });
        }
        catch (error) {
            for (const b of this.owned)
                b.destroy();
            this.owned = [];
            this.closed = true;
            throw error;
        }
    }
    async verifyCompilationBeforeDispatch(){if(this.closed||this.closing)throw Error('Anchor closed before compilation');const r=await this.compilationPromise;if(this.closed||this.closing)throw Error('Anchor closed during compilation');this.compilationVerified=r;return r;}
    encode(encoder, observed) {
        if(!this.compilationVerified?.actualModuleCompilationChecked)throw Error('Anchor actual compilation barrier not completed');
        if (this.closed || this.closing || observed.currentBuffer !== this.initial.currentBuffer || observed.previousBuffer !== this.initial.previousBuffer || observed.gateBuffer !== this.initial.gateBuffer || observed.generation !== this.initial.generation || JSON.stringify(observed.binding) !== JSON.stringify(this.initial.binding))
            throw Error('Anchor immutable observed lease changed');
        if (!this.prepared.enabled)
            throw Error('Native anchor probe is not allocated');
        this.prepared.assertPackedGeometryUnchanged(this.prepared.packed);
        const cfg = packJointBVHUniform(this.prepared.packed, this.epoch, observed.binding, 64, this.count, false, true, { first: 0, count: 0, depth: 0 });
        cfg[18] = this.outputLayout.anchorsOffset / 4;
        cfg[19] = this.outputLayout.proofOffset / 4;
        this.device.queue.writeBuffer(this.config, 0, new Uint32Array(cfg));
        encoder.clearBuffer(this.proof);
        encoder.copyBufferToBuffer(this.rawProof, 0, this.proof, 0, 32);
        for (let i = 0; i < this.pipelines.length; i++) {
            const pass = encoder.beginComputePass();
            pass.setPipeline(this.pipelines[i]);
            pass.setBindGroup(0, this.group);
            pass.dispatchWorkgroups(i === 1 ? Math.ceil(this.count / 64) : 1);
            pass.end();
        }
    }
    destroy() { if (this.closePromise)
        return this.closePromise; this.closing = true; this.closePromise = (async () => { const failures = []; try {
        await this.device.queue.onSubmittedWorkDone();
    }
    catch (error) {
        failures.push(error);
    }
    finally {
        for (const b of this.owned) {
            try {
                b.destroy();
            }
            catch (error) {
                failures.push(error);
            }
        }
        this.owned = [];
        this.closed = true;
    } if (failures.length)
        throw new AggregateError(failures, 'Anchor probe queue/cleanup failure'); })(); return this.closePromise; }
}
export function createSourceJointBodyMaterialAnchorProbe(device, scope, ...args) { if (scope !== 'fresh-source-equal-layer')
    return null; return new SourceJointBodyMaterialAnchorProbe(device, ...args); }
