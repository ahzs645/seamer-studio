/** COPIED actual-app request -> SI -> source bytes -> private component providers
 * -> genuine SOURCE simulation. No automation API or live default promotion. */
import type {SceneSourceInputOwner,SceneSourceInputRequest} from './sceneSourceInputs.ts';
import {prepareActualSceneSourceInputsInWorker} from './preparation-worker/client.ts';
import type {SourceSheetAssignment} from './source/sourcePhysicalMembrane.ts';
import {createActualAppSourceSimulation} from './SceneSourceStartup.ts';
import type {EngineSceneOwner} from './appEngineDelivery.ts';
import {createActualOwnedBodyAnchorHandoff,createActualPhysicalReactionInputAdapter,readActualGPUAnchorBytes} from './ownedBodyAnchorInput.mjs';
import {loadApprovedComponentArtifacts} from './approvedArtifacts.mjs';
import {requireWholePhysicalDeviceValidation} from './physical/wholePhysicalProviderValidation.mjs';
import {copyData,equalData} from './snapshots.mjs';
import {ownPreparationRecord} from './appSIPreparation.ts';
export interface ExplicitAppPhysicalParameters {
 parameterOrigin:'explicit-illustrative-pressure-benchmark';measuredGarmentFriction:false;
 rawCapacity:number;rowCapacity:number;componentCapacity:number;materialCapacity:number;
 sweeps:number;maximumActiveSetRounds:number;maximumRowsPerComponent:number;maximumParticlesPerComponent:number;
 frictionProfile:{muStatic:number;muKinetic:number;declaredApproximate:true};
}
export interface AppSourceSessionRequest extends SceneSourceInputRequest {
 physicalParameters:ExplicitAppPhysicalParameters;
 backendOptions:Record<string,unknown>;
 implementationSha256:string;
}
interface Creation {device:GPUDevice;isCurrent:()=>boolean;captureRefinedRuntimeState:(key:unknown)=>unknown}
/** Source only. Explicit parameters remain unmeasured experimental inputs. */
export function prepareActualAppSourceSession(readCurrentOwner:()=>SceneSourceInputOwner,assignments:readonly SourceSheetAssignment[],request:AppSourceSessionRequest,scope:string){
 if(scope!=='fresh-source-physical-profile')return null;
 const frozen=copyData(request),owner=ownPreparationRecord(readCurrentOwner()) as unknown as SceneSourceInputOwner,callback=owner.stillCurrent;
 const currentRequest=()=>{const before=ownPreparationRecord(readCurrentOwner()) as unknown as SceneSourceInputOwner;if(before.stillCurrent!==callback||callback()!==true)throw Error('App physical request superseded');const after=ownPreparationRecord(readCurrentOwner()) as unknown as SceneSourceInputOwner;if(after.pattern!==owner.pattern||after.prepared!==owner.prepared||after.stillCurrent!==callback||!equalData(copyData(request,false),frozen))throw Error('App physical request/owner changed');return true;};
 currentRequest();
 return (async()=>{
  const inputs=await prepareActualSceneSourceInputsInWorker(readCurrentOwner,assignments,frozen,scope);currentRequest();if(!inputs)throw Error('Actual app source preparation unavailable');
  const parameters=frozen.physicalParameters,config=inputs.simulationConfig,n=inputs.prepared.simData.particleCount;
  if(parameters.parameterOrigin!=='explicit-illustrative-pressure-benchmark'||parameters.measuredGarmentFriction!==false)throw Error('Explicit unmeasured physical parameters required');
  const capacities=['rawCapacity','rowCapacity','componentCapacity','materialCapacity','sweeps','maximumActiveSetRounds','maximumRowsPerComponent','maximumParticlesPerComponent'] as const;
  for(const key of capacities)if(!Number.isSafeInteger(parameters[key])||parameters[key]<1)throw Error('Explicit positive physical parameter required: '+key);
  if(parameters.maximumActiveSetRounds>64||parameters.rawCapacity>262144||parameters.componentCapacity>n||parameters.maximumParticlesPerComponent>n||parameters.rowCapacity>parameters.rawCapacity||parameters.materialCapacity>parameters.rawCapacity)throw Error('Physical capacities exceed actual source/ABI bounds');
  if(config.subSteps!==40||typeof config.deltaT!=='number'||!Number.isFinite(config.deltaT)||config.deltaT<=0)throw Error('Actual configured forty-substep time required');
  const friction=parameters.frictionProfile;
  if(friction.declaredApproximate!==true||![friction.muStatic,friction.muKinetic].every(v=>Number.isFinite(v)&&v>=0)||friction.muKinetic>friction.muStatic)throw Error('Explicit approximate Coulomb parameters required');
  if(!/^[a-f0-9]{64}$/.test(frozen.implementationSha256))throw Error('Actual engine implementation SHA required');
  const assertCurrent=()=>{inputs.assertCurrent();return currentRequest();};
  const artifacts=await loadApprovedComponentArtifacts(assertCurrent);assertCurrent();
  const validation=await requireWholePhysicalDeviceValidation(artifacts.physical.bytes,artifacts.physical.sha256,{isCurrent:assertCurrent});assertCurrent();
  const providerOptions={...Object.fromEntries(capacities.map(k=>[k,parameters[k]])),dt:config.deltaT,frictionProfile:friction,implementationSha256:frozen.implementationSha256};
  let consumed=false,closed=false;
  return Object.freeze({prepared:inputs.prepared,descriptor:inputs.descriptor,assertCurrent,
   async create(device:GPUDevice){
    assertCurrent();if(consumed||closed)throw Error('App source session already consumed/closed');consumed=true;
    let anchor:ReturnType<typeof createActualOwnedBodyAnchorHandoff>|null=null,creation:Creation|undefined;
    // Anchor allocation is lazy: only an actual complete inventory inside the
    // privately validated numerical producer can reach this callback.
    const lazyAnchor={bindActualInventory(input:Parameters<NonNullable<ReturnType<typeof createActualOwnedBodyAnchorHandoff>>['bindActualInventory']>[0]){assertCurrent();if(closed)throw Error('App anchor owner closed');if(!anchor)anchor=createActualOwnedBodyAnchorHandoff({device,readGpuBytes:(buffer:GPUBuffer,size:number)=>readActualGPUAnchorBytes(device,buffer,size)});return anchor!.bindActualInventory(input);}};
    const physicalInput=createActualPhysicalReactionInputAdapter({prepared:inputs.prepared,sourceBinding:inputs.descriptor.sourceBinding,rawCapacity:parameters.rawCapacity,frictionProfile:friction,deviceValidation:validation,anchorHandoff:lazyAnchor});
    const capture=(key:unknown)=>{assertCurrent();if(!creation||creation.isCurrent()!==true)throw Error('Actual engine controller ownership unavailable');return creation.captureRefinedRuntimeState(key);};
    const numericalOwner={pattern:inputs.pattern,prepared:inputs.prepared,sourceBinding:inputs.descriptor.sourceBinding,sourceExecutionBytes:inputs.descriptor.sourceExecutionBytes,sourceExecutionEncoding:inputs.descriptor.sourceExecutionEncoding,styleId:inputs.styleId,backendOptions:frozen.backendOptions,captureRefinedRuntimeState:capture,manualRecording:false,held:false,cached:false,explicitSettings:false,stillCurrent:assertCurrent,providerOptions,simulationConfig:inputs.simulationConfig,implementationSha256:frozen.implementationSha256,preparePhysicalReactionInput:physicalInput};
    const readEngineOwner=(actual?:Creation)=>{assertCurrent();if(actual){if(creation&&creation!==actual)throw Error('Foreign actual engine controller');creation=actual;}return numericalOwner as unknown as EngineSceneOwner;};
    let simulation:Awaited<ReturnType<typeof createActualAppSourceSimulation>>|null=null;
    const destroy=async()=>{closed=true;const errors:unknown[]=[];try{await simulation?.dispose();}catch(e){errors.push(e);}try{await anchor?.destroy();}catch(e){errors.push(e);}if(errors.length)throw new AggregateError(errors,'App simulation/anchor drain failed');};
    try{
     simulation=await createActualAppSourceSimulation(device,scope,readEngineOwner);assertCurrent();if(!simulation)throw Error('Actual source constructor unavailable');
     const actual=simulation;
     return Object.freeze({...actual,assertCurrent(){assertCurrent();return actual.assertCurrent();},dispose:destroy,parameterScope:inputs.parameterScope,measuredGarmentParameters:false,wholeFrameExecuted:false,fitAccepted:false});
    }catch(error){try{await destroy();}catch(cleanup){throw new AggregateError([error,cleanup],'App source session startup/drain failed',{cause:error});}throw error;}
   },
   scope:'approved-components-only',measuredGarmentParameters:false,wholeFrameExecuted:false,fitAccepted:false});
 })();
}
