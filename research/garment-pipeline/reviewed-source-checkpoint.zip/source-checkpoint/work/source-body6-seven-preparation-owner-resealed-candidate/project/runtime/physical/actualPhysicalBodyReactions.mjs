import{portableDigest as digest,physicalViewBytes}from'./portableByteTools.mjs';
import{copyData,equalData}from'./snapshots.mjs';
import{requireAnchorPartition,SOURCE_ANCHOR_PARTITION_POLICY}from'./anchorPartitionPolicy.mjs';
const SHA=/^[a-f0-9]{64}$/,NONE=0xffffffff;

const bytes=x=>new Uint8Array(x.buffer,x.byteOffset,x.byteLength);
/** Decode BODY reactions only, from the actual complete physical operator and
 * the authentic final V2 probe over the SAME original material witnesses.
 * This function performs no nearest query, solve, anchor upload or authority
 * upgrade. Every self multiplier remains in the complete operator receipt.
 */
async function decodeBodyReaction(input,isCurrent){
 const{mechanical,anchor,rawBytes,packetBytes,physicalDt}=input;
 const b=mechanical?.binding,a=anchor?.receipt,layout=anchor?.probe?.layout;
 if(!b||!a||!layout||!(rawBytes instanceof Uint8Array)||!(packetBytes instanceof Uint8Array)||
  !Number.isFinite(physicalDt)||physicalDt<=0||!Number.isFinite(physicalDt*physicalDt)||physicalDt*physicalDt===0||
  mechanical.actualReaction?.actualGpuReactionReadback!==true||mechanical.actualReaction.physicalOperatorAccepted!==true||
  mechanical.actualReaction.numericalMarginIsPhysicalPressure!==false||mechanical.actualReaction.normalMultiplierUnit!=='kg-m'||
  mechanical.actualAllContactOperatorEvidence?.reactionRecordScope!=='body-pressure-friction-only-v1'||
  !SHA.test(mechanical.actualAllContactOperatorEvidence.actualAllContactOperatorReceiptSha256)||
  a.allBodyAnchorsReady!==true||a.unsupportedFlags!==0||!SHA.test(a.receiptSha256)||
  !SHA.test(input.finalCandidateSha256)||a.currentSha256!==input.finalCandidateSha256||
  !['sourceSha256','bodySha256','historySha256','usedGateSha256','originalParentSha256'].every(k=>SHA.test(b[k])&&a[k]===b[k])||
  a.rawSha256!==b.fullRawRow128Sha256||a.key?.physicalSubstep!==b.key?.physicalSubstep||
  ['generation','frameSequence','parentToken','gateRevision'].some(k=>a.key?.[k]!==b.key?.[k])||
  layout.count!==b.rawOccurrences||layout.recordWords!==40||layout.recordByteLength!==layout.count*160||
  layout.proofByteLength!==layout.count*256||layout.byteLength!==layout.proofOffset+layout.proofByteLength||
  packetBytes.byteLength!==layout.byteLength||rawBytes.byteLength!==layout.count*128||
  (await digest(rawBytes,isCurrent))!==b.fullRawRow128Sha256||(await digest(packetBytes,isCurrent))!==a.packetSha256)
  throw Error('Actual body reaction requires exact original raw and FINAL complete V2 anchor receipt');
 const rawU=new Uint32Array(rawBytes.slice().buffer),rawF=new Float32Array(rawU.buffer),packetU=new Uint32Array(packetBytes.slice().buffer),packetF=new Float32Array(packetU.buffer);
 const packet=mechanical.physicalRows,rowsU=new Uint32Array(packet.actualPhysicalRows.slice().buffer),rowsF=new Float32Array(rowsU.buffer);
 const reaction=mechanical.actualReaction,aliases=mechanical.actualAliases,R=packet.executedRows;
 if(rowsU.length!==R*12||reaction.reaction?.length!==R*4||reaction.rowModes?.length!==R||
  aliases?.groups?.length!==R||packet.selectedOriginalIds?.length!==R||
  !Array.isArray(aliases.groups)||!(aliases.records instanceof Uint32Array)||aliases.records.length!==layout.count*40)
  throw Error('Incomplete canonical physical reaction rows');
 const records=[],ownedOrdinals=new Set();let body=0,self=0;
 for(let row=0;row<R;row++){
  const kind=rowsU[row*12+6],ordinal=rowsU[row*12+7],lambda=reaction.reaction[row*4],tangent=Array.from(reaction.reaction.subarray(row*4+1,row*4+4));
  if(kind>1||ordinal>=layout.count||ordinal!==packet.selectedOriginalIds[row]||!Number.isFinite(lambda)||lambda<0||tangent.some(x=>!Number.isFinite(x)))throw Error('Malformed actual physical reaction');
  const group=aliases.groups[row],list=group.originalRawAliases;
  if(!Array.isArray(list)||!list.length||list[0]!==ordinal||new Set(list).size!==list.length)throw Error('Malformed physical alias partition');
  const key=aliases.records.subarray(ordinal*40,(ordinal+1)*40);
  if(key[0]!==1||key[1]!==ordinal||key[2]!==kind||key[39]!==0)throw Error('Physical kind/key mismatch');
  for(const id of list){if(!Number.isSafeInteger(id)||id<0||id>=layout.count||ownedOrdinals.has(id)||
    Array.from(aliases.records.subarray(id*40+2,(id+1)*40)).some((v,i)=>v!==key[i+2]))throw Error('Original raw ordinal has conflicting physical ownership');ownedOrdinals.add(id);}
  if(kind===1){self++;continue;}body++;
  if(lambda===0){if(tangent.some(x=>x!==0)||reaction.rowModes[row]!==0)throw Error('Zero-pressure body row has tangential reaction');continue;}
  if(reaction.rowModes[row]!==1&&reaction.rowModes[row]!==2)throw Error('Positive body pressure lacks actual stick/sliding mode');
  const o=ordinal*40,rawOffset=ordinal*32;
  if(rawU[rawOffset+3]<3||rawF[rawOffset+23]!==1||packetF[o+39]!==1)throw Error('Positive body reaction lacks authentic finite skin anchor');
  const ids=[],weights=[];for(let k=0;k<3;k++){const id=rawU[rawOffset+k],weight=rawF[rawOffset+8+k];if(id===NONE){if(weight!==0)throw Error('Absent source material lane has weight');continue;}ids.push(id);weights.push(weight);}
  const bary=Array.from(packetF.subarray(o+16,o+19));requireAnchorPartition(weights,'source',SOURCE_ANCHOR_PARTITION_POLICY);requireAnchorPartition(bary,'body',SOURCE_ANCHOR_PARTITION_POLICY);
  const normal=Array.from(rowsF.subarray(row*12,row*12+3)),normalForceN=normal.map(n=>lambda/(physicalDt*physicalDt)*n);
  if(normal.some(x=>!Number.isFinite(x))||normalForceN.some(x=>!Number.isFinite(x))||tangent.some(x=>!Number.isFinite(x/(physicalDt*physicalDt))))throw Error('Actual physical force conversion overflow');
  const bodyFace=packetU[o+15];if(!Number.isSafeInteger(a.bodyFaceCount)||bodyFace>=a.bodyFaceCount)throw Error('Final finite skin face out of bounds');
  const materialOffset=Array.from(packetF.subarray(o+32,o+35));if(materialOffset.some(x=>!Number.isFinite(x)))throw Error('Nonfinite actual body material offset');
  records.push({materialFunctionalSha256:(await digest(physicalViewBytes(key.buffer,key.byteOffset+8,38*4),isCurrent)),originalRawAliases:list.slice(),
   physicalNormalLambdaKgM:lambda,normalForceN,tangentialLambdaKgM:tangent,mode:reaction.rowModes[row]===1?'stick':'slide',
   currentBodyMaterialAnchor:{sourceMaterialIds:ids,sourceMaterialWeights:weights,bodyFace,bodyBarycentric:bary,
    bodySha256:b.bodySha256,sourceSha256:b.sourceSha256,historySha256:b.historySha256,usedGateSha256:b.usedGateSha256,
    authenticFiniteProbeSha256:a.receiptSha256,producerPhysicalSubstep:b.key.physicalSubstep,materialOffset}});
 }
 if(ownedOrdinals.size!==layout.count||body!==mechanical.actualAllContactOperatorEvidence.bodyContactPhysicalRowCount||self!==mechanical.actualAllContactOperatorEvidence.selfContactPhysicalRowCount)
  throw Error('Incomplete ALL physical functional partition');
 return{reactions:records,reactionRecordScope:'body-pressure-friction-only-v1',...mechanical.actualAllContactOperatorEvidence,
  actualReactionBufferSha256:(await digest(bytes(reaction.reaction),isCurrent)),actualReactionStatusBufferSha256:(await digest(bytes(reaction.statusCapacity),isCurrent)),
  finiteAnchorProbeSha256:a.receiptSha256,normalReactionAuthoritative:false};
}

function consume(input){const m=input?.mechanical,a=input?.anchor;return{mechanical:{binding:m?.binding,actualReaction:m?.actualReaction,actualAllContactOperatorEvidence:m?.actualAllContactOperatorEvidence,actualAliases:m?.actualAliases,physicalRows:{actualPhysicalRows:m?.physicalRows?.actualPhysicalRows,executedRows:m?.physicalRows?.executedRows,selectedOriginalIds:m?.physicalRows?.selectedOriginalIds}},anchor:{receipt:a?.receipt,probe:{layout:a?.probe?.layout}},rawBytes:input?.rawBytes,packetBytes:input?.packetBytes,physicalDt:input?.physicalDt,finalCandidateSha256:input?.finalCandidateSha256};}
export async function actualPhysicalBodyReactions(input,{isCurrent}={}){if(typeof isCurrent!=='function'||isCurrent()!==true)throw Error('Actual body reaction owner required');const snapshot=copyData(consume(input));const current=()=>isCurrent()===true&&equalData(consume(input),snapshot);const result=await decodeBodyReaction(snapshot,current);if(!current())throw Error('Body reaction inputs/owner changed across hash');return result;}
