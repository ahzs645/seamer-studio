/** NEW seeded selector ABI3, six storage bindings. CURRENT finite inequalities
 * select if CURRENT, ORIGINAL physical parent, or immutable mechanical arithmetic
 * seed needs clearance. No previous-epoch affine planes are copied. */
import { sourceJointRawOrdinalSelectionWGSL } from '../../source-joint-refined-backend-integration/runtime/compiled/sourceJointRawOrdinalSelection.mjs';
function replaceOnce(code, old, next) {
    if (code.split(old).length !== 2)
        throw new Error('Parent-aware ordinal ABI drift');
    return code.replace(old, next);
}
let code = sourceJointRawOrdinalSelectionWGSL;
code = replaceOnce(code, '@group(0) @binding(4) var<uniform> cfg:Params;', '@group(0) @binding(4) var<storage,read> originalParent:array<vec4f>;\n@group(0) @binding(5) var<storage,read> mechanicalSeed:array<vec4f>;\n@group(0) @binding(6) var<uniform> cfg:Params;');
code = replaceOnce(code, 'fn ordinalPoint(r:Row,isTarget:bool)->vec3f', 'fn ordinalPoint(r:Row,isTarget:bool,atParent:bool)->vec3f');
code = replaceOnce(code, 'q+=current[id].xyz*select(r.wa[k],r.wb[k],isTarget);', 'let p=select(current[id].xyz,originalParent[id].xyz,atParent);q+=p*select(r.wa[k],r.wb[k],isTarget);');
code = replaceOnce(code, 'let a=ordinalPoint(r,false);let b=ordinalPoint(r,true);let gap=dot(a-b,r.n.xyz);', `if(arrayLength(&current)!=cfg.particles||arrayLength(&originalParent)!=cfg.particles){flags[id]=2u;return;}
 for(var k=0u;k<3u;k++){for(var side=0u;side<2u;side++){
  let p=select(r.a[k],r.b[k],side==1u);if(p==NONE){continue;}
  if(bitcast<u32>(current[p].w)!=bitcast<u32>(originalParent[p].w)||current[p].w<0.0){flags[id]=2u;return;}
  for(var axis=0u;axis<4u;axis++){if(!finite(current[p][axis])||!finite(originalParent[p][axis])){flags[id]=2u;return;}}
 }}
 let a=ordinalPoint(r,false,false);let b=ordinalPoint(r,true,false);let gap=dot(a-b,r.n.xyz);
 let pa=ordinalPoint(r,false,true);let pb=ordinalPoint(r,true,true);let parentGap=dot(pa-pb,r.n.xyz);
 let parentScale=max(1.0,max(max(abs(pa.x),max(abs(pa.y),abs(pa.z))),max(abs(pb.x),max(abs(pb.y),abs(pb.z)))));`);
code = replaceOnce(code, 'if(!finite(gap)){flags[id]=2u;return;}', 'if(!finite(gap)||!finite(parentGap)){flags[id]=2u;return;}');
code = replaceOnce(code, 'if(gap<r.n.w+64.0*0.000000059604644775390625*scale){flags[id]=1u;}', 'if(gap<r.n.w+64.0*0.000000059604644775390625*scale||parentGap<r.n.w+64.0*0.000000059604644775390625*parentScale){flags[id]=1u;}');
code=replaceOnce(code,'fn ordinalPoint(r:Row,isTarget:bool,atParent:bool)->vec3f','fn ordinalPoint(r:Row,isTarget:bool,which:u32)->vec3f');
code=replaceOnce(code,'let p=select(current[id].xyz,originalParent[id].xyz,atParent);','let p=select(select(current[id].xyz,originalParent[id].xyz,which==1u),mechanicalSeed[id].xyz,which==2u);');
code=code.replaceAll('ordinalPoint(r,false,false)','ordinalPoint(r,false,0u)').replaceAll('ordinalPoint(r,true,false)','ordinalPoint(r,true,0u)').replaceAll('ordinalPoint(r,false,true)','ordinalPoint(r,false,1u)').replaceAll('ordinalPoint(r,true,true)','ordinalPoint(r,true,1u)');
code=replaceOnce(code,'if(arrayLength(&current)!=cfg.particles||arrayLength(&originalParent)!=cfg.particles)','if(arrayLength(&current)!=cfg.particles||arrayLength(&originalParent)!=cfg.particles||arrayLength(&mechanicalSeed)!=cfg.particles)');
code=replaceOnce(code,'current[p].w<0.0','current[p].w<0.0||bitcast<u32>(current[p].w)!=bitcast<u32>(mechanicalSeed[p].w)');
code=replaceOnce(code,'!finite(originalParent[p][axis])','!finite(originalParent[p][axis])||!finite(mechanicalSeed[p][axis])');
code=replaceOnce(code,'if(!finite(gap)||!finite(parentGap))','let ma=ordinalPoint(r,false,2u);let mb=ordinalPoint(r,true,2u);let seedGap=dot(ma-mb,r.n.xyz);let seedScale=max(1.0,max(max(abs(ma.x),max(abs(ma.y),abs(ma.z))),max(abs(mb.x),max(abs(mb.y),abs(mb.z)))));if(!finite(gap)||!finite(parentGap)||!finite(seedGap))');
code=replaceOnce(code,'parentGap<r.n.w+64.0*0.000000059604644775390625*parentScale)','parentGap<r.n.w+64.0*0.000000059604644775390625*parentScale||seedGap<r.n.w+64.0*0.000000059604644775390625*seedScale)');
export const sourceJointSeededOrdinalSelectionWGSL=code;
