/** Internal copied browser preparation. No token is accepted from callers and
 * no promised hash/readiness flag substitutes for actual completed validation. */
import{copyData,equalData}from'./snapshots.mjs';
import{physicalBytesSha256}from'./portablePhysicalHashes.mjs';
import{sourceDeclaredFrictionProfileSha256}from'./declaredFrictionProfile.mjs';
import{requireActualPackagedPhysicalPolicies,requireWholePhysicalDeviceValidation}from'./wholePhysicalProviderValidation.mjs';
import{PHYSICAL_REACTION_TOLERANCE_POLICY_TEXT,PHYSICAL_REACTION_TOLERANCE_POLICY_SHA256}from'./tolerancePolicy.mjs';
import{SOURCE_ANCHOR_PARTITION_POLICY,anchorPartitionPolicySha256,SOURCE_ANCHOR_PARTITION_POLICY_SHA256}from'./anchorPartitionPolicy.mjs';
const SHA=/^[a-f0-9]{64}$/,u32=x=>Number.isSafeInteger(x)&&x>=0&&x<=0xffffffff,records=new WeakMap();
function observeOptions(options,copyBytes=true){if(!options||Object.getPrototypeOf(options)!==Object.prototype)throw Error('Actual plain owned physical configuration required');const descriptors=Object.getOwnPropertyDescriptors(options);if(Reflect.ownKeys(descriptors).some(k=>typeof k!=='string'||!descriptors[k].enumerable||!Object.hasOwn(descriptors[k],'value')))throw Error('Physical option accessors/symbols unsupported');const isCurrent=descriptors.isCurrent?.value;if(typeof isCurrent!=='function')throw Error('Actual current owner callback required');return{isCurrent,data:copyData(Object.fromEntries(Object.entries(descriptors).filter(([k])=>k!=='isCurrent').map(([k,d])=>[k,d.value])),copyBytes)};}
function validateOptions(o){if(!['particles','rawCapacity','rowCapacity','componentCapacity','materialCapacity','sweeps','maximumActiveSetRounds','maximumRowsPerComponent','maximumParticlesPerComponent'].every(k=>u32(o[k])&&o[k]>0)||o.rowCapacity>o.rawCapacity||o.componentCapacity>o.particles||o.maximumActiveSetRounds>64||!Number.isFinite(o.dt)||o.dt<=0||!u32(o.sourceToken)||!o.sourceToken||!u32(o.bodyGeneration)||!o.bodyGeneration||!['sourceSha256','bodySha256','physicalMassPolicySha256','implementationSha256','approvedDeviceValidationSha256'].every(k=>SHA.test(o[k]))||!(o.physicalInverseMassBits instanceof Uint32Array)||o.physicalInverseMassBits.length!==o.particles||!(o.deviceValidationArtifact instanceof Uint8Array)||o.projectNumericalClearance!==undefined)throw Error('Invalid immutable source physical factory preparation');if(new Float32Array(o.physicalInverseMassBits.buffer,o.physicalInverseMassBits.byteOffset,o.physicalInverseMassBits.length).some(w=>!Number.isFinite(w)||w<0))throw Error('Invalid exact actual SI inverse mass bits');}
async function prepare(options){const observed=observeOptions(options),snapshot=observed.data,isCurrent=observed.isCurrent;const assert=()=>{const before=observeOptions(options,false);if(before.isCurrent!==isCurrent||isCurrent()!==true)throw Error('Physical preparation owner/options changed across await');const now=observeOptions(options,false);if(now.isCurrent!==isCurrent||!equalData(now.data,snapshot))throw Error('Physical preparation owner/options changed across await');return true;};assert();validateOptions(snapshot);
 // Every private validation finishes and is resealed before a constructor sees
 // its token. Policy constants are independently recomputed from actual bytes.
 await requireActualPackagedPhysicalPolicies(assert);assert();
 const toleranceSha=await physicalBytesSha256(new TextEncoder().encode(PHYSICAL_REACTION_TOLERANCE_POLICY_TEXT));assert();if(toleranceSha!==PHYSICAL_REACTION_TOLERANCE_POLICY_SHA256)throw Error('Actual residual policy byte mismatch');
 const partitionSha=await anchorPartitionPolicySha256(SOURCE_ANCHOR_PARTITION_POLICY);assert();if(partitionSha!==SOURCE_ANCHOR_PARTITION_POLICY_SHA256)throw Error('Actual anchor partition byte mismatch');
 const frictionSha256=await sourceDeclaredFrictionProfileSha256(snapshot.frictionProfile);assert();
 const validation=await requireWholePhysicalDeviceValidation(snapshot.deviceValidationArtifact,snapshot.approvedDeviceValidationSha256,{isCurrent:assert});assert();
 const token=Object.freeze({});records.set(token,{options:snapshot,validation,frictionSha256,assert});return token;
}
/** Source constructor's sole options entry. Opaque claims/replayed metadata fail.
 * Copy returned arrays; callers cannot mutate the retained private preparation. */
export function requireWholePhysicalPreparation(token){const record=records.get(token);if(!record)throw Error('Actual private completed physical preparation token required');record.assert();return{options:copyData(record.options),validation:copyData(record.validation),frictionSha256:record.frictionSha256,assertCurrent:record.assert};}
/** Internal composition helper: pass the actual class, not a browser automation
 * callback. Native/OFF returns synchronously before even observing options/device. */
export function createPreparedWholePhysicalFactory(SourceClass){if(typeof SourceClass!=='function')throw Error('Actual owned physical source class required');return function create(device,scope,options){if(scope!=='fresh-source-physical-profile')return null;return prepare(options).then(token=>{requireWholePhysicalPreparation(token);return new SourceClass(device,token);});};}
