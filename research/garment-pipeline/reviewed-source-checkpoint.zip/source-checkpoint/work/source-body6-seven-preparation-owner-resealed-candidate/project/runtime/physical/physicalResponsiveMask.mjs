/** Exact nonzero physical multiplier selection over real GPU readback. This
 * performs no geometry, normal solve or anchor construction. Augmented/work
 * multipliers are explicitly excluded. Every raw protection remains available
 * for complete fixed-row and fresh geometry certification. */
export function physicalResponsiveMaskFromReadback(rowBytes, reactionReceipt, rawOccurrences) {
 if (!(rowBytes instanceof Uint8Array) || rowBytes.byteLength % 48 ||
     !Number.isSafeInteger(rawOccurrences) || rawOccurrences < 0 || rawOccurrences > 0xffffffff ||
     reactionReceipt?.actualGpuReactionReadback !== true || reactionReceipt.physicalOperatorAccepted !== true ||
     reactionReceipt.normalMultiplierUnit !== 'kg-m' || reactionReceipt.numericalMarginIsPhysicalPressure !== false ||
     !(reactionReceipt.reaction instanceof Float32Array) || reactionReceipt.reaction.length !== rowBytes.byteLength / 12 ||
     reactionReceipt.reaction.some(v => !Number.isFinite(v)))
  throw Error('Authentic physical-only reaction readback required for history mask');
 const rows = new Uint32Array(rowBytes.slice().buffer), mask = new Uint32Array(rawOccurrences);
 for (let r = 0; r < rows.length / 12; r++) {
  const lambda = reactionReceipt.reaction[r * 4], kind = rows[r * 12 + 6], ordinal = rows[r * 12 + 7];
  if (lambda < 0 || kind > 1 || ordinal >= rawOccurrences) throw Error('Malformed physical history reaction row');
  if (kind === 0 && lambda > 0) mask[ordinal] = 1;
 }
 return mask;
}
