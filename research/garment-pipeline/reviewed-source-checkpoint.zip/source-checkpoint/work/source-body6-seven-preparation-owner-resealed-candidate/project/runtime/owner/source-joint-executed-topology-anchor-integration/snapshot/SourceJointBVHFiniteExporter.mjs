import {acquireExactFiniteKernelBundle} from '../../../FiniteKernelCache.mjs';
import{bodyFaceFeatureDispatchGroups,BODY_FACE_FEATURE_POLICY}from'../../../refined/bodyFaceFeatureLanes.mjs';
import{requireVerifiedRefinedScope,refinedFiniteFactory}from'../../../refined/RefinedBackendScope.mjs';
/** ISOLATED adapter: complete GPU finite visitors over actual refitted BVHs.
 * A caller must capture/hash the actual GPU buffers at an ordered boundary before encode.
 * This is asynchronous diagnostic infrastructure, not a shipping engine hook. */
import { sourceJointFiniteExportWGSL } from '../../source-joint-refined-backend-integration/runtime/compiled/sourceJointFiniteExport.mjs';
import { requireJointGeometryEpoch } from '../../source-joint-refined-backend-integration/runtime/compiled/sourceJointGeometry.mjs';
import { sourceJointBVHRowExportWGSL, jointBVHBodyInlineTraversalWGSL, jointBVHExpectedUniformWords, jointBVHRefitDispatches, packJointBVH, requireJointBVHBinding } from '../../source-joint-refined-backend-integration/runtime/compiled/sourceJointBVHRowExport.mjs';
export const JOINT_BVH_UNIFORM_STRIDE = 512;
export const JOINT_BVH_UNIFORM_BYTES = 400; // 20 scalar words +20 aligned vec4u header words.
function replaceFunction(code, name, replacement) {
    const at = code.indexOf('fn ' + name + '(');
    if (at < 0)
        throw Error('Missing exact finite hook ' + name);
    const start = code.lastIndexOf('@compute', at);
    let first = at;
    if (start >= 0 && /^@compute[^{}]*$/.test(code.slice(start, at)))
        first = start;
    let end = code.indexOf('{', at), depth = 1;
    if (end < 0)
        throw Error('Invalid finite function');
    end++;
    for (; end < code.length && depth; end++) {
        if (code[end] === '{')
            depth++;
        else if (code[end] === '}')
            depth--;
    }
    if (depth)
        throw Error('Unbalanced finite function ' + name);
    return code.slice(0, first) + replacement + code.slice(end);
}
export function sourceJointBVHFiniteWGSL(layout) {
    let code = sourceJointFiniteExportWGSL(layout);
    code = code.replace(/struct Config\{[^}]+\};/, 'struct Config{particles:u32,clothFaces:u32,bodyFaces:u32,capacity:u32,bodyGeneration:u32,sourceToken:u32,gateRevision:u32,substep:u32,cacheSlots:u32,parentStart:u32,finalEnumeration:u32,reserved:u32,snapshotEpoch:u32,historyToken:u32,gateToken:u32,refitFirst:u32,refitCount:u32,refitDepth:u32,p0:u32,p1:u32,expected:array<vec4u,20>};');
    code = code.replace('@binding(6) var<uniform> cfg', '@binding(8) var<uniform> cfg').replace('@binding(7) var<uniform> gate', '@binding(9) var<uniform> gate');
    code = code.replace('const SEARCH=0.006;', '');
    code = code.replace(/\bSEARCH\b/g, 'jointFiniteHorizon()');
    code = replaceFunction(code, 'append', 'fn append(r:Row){let index=jointBVHReserveRawRow();if(index==NONE){return;}rows[index]=r;}');
    code = replaceFunction(code, 'nearestBody', 'fn nearestBody(point:vec3f)->Nearest{return jointNearestBody(point);}');
    // All finite body-edge rows still use their original finite visitor. Chord interval time
    // arrays need inline traversal because a WGSL callee cannot mutate caller-local arrays.
    const at = code.indexOf('@compute @workgroup_size(64) fn body_faces('), end = code.indexOf('@compute @workgroup_size(1) fn complete', at);
    if (at < 0 || end < 0)
        throw Error('Missing exact chord collector');
    let chords = code.slice(at, end);
    const prefix = '@compute @workgroup_size(64) fn body_faces(@builtin(global_invocation_id) gid:vec3u){let face=gid.x;if(face>=cfg.clothFaces){return;}let ids=tri(face);let a=clothPoints(ids,false);let old=clothPoints(ids,true);for(var other=0u;other<cfg.bodyFaces;other++){jointVisitBodyPair(face,other);}';
    if (!chords.startsWith(prefix))
        throw Error('Unexpected body chord hook');
    chords = chords.replace(prefix, 'fn jointBVHBodyChords(face:u32){let ids=tri(face);let a=clothPoints(ids,false);let old=clothPoints(ids,true);');
    const collector = 'for(var other=0u;other<cfg.bodyFaces;other++){let b=bodyPoints(other);let hit=segmentTriangleHit(a[edge],a[(edge+1u)%3u],b[0],b[1],b[2]);if(hit.w>=0.0&&hit.w>0.0&&hit.w<1.0){if(count>=34u){atomicOr(&state[0],1u);break;}times[count]=hit.w;count++;}}';
    if (!chords.includes(collector))
        throw Error('Unexpected actual finite chord interval collection');
    const visit = 'let b=bodyPoints(bodyFace);let hit=segmentTriangleHit(a[edge],a[(edge+1u)%3u],b[0],b[1],b[2]);if(hit.w>=0.0&&hit.w>0.0&&hit.w<1.0){if(count>=34u){atomicOr(&state[0],1u);}else{times[count]=hit.w;count++;}}';
    chords = chords.replace(collector, jointBVHBodyInlineTraversalWGSL('min(a[edge],a[(edge+1u)%3u])-vec3f(jointFiniteHorizon())', 'max(a[edge],a[(edge+1u)%3u])+vec3f(jointFiniteHorizon())', visit));
    code = code.slice(0, at) + chords + code.slice(end);
    code = replaceFunction(code, 'complete', '@compute @workgroup_size(1) fn complete(){if(jointBVHReady(false)&&jointBVHReady(true)){atomicStore(&state[2],7u);}}');
    // Keep the operator's algebraic diagnostic at state[3]. Refit accounting has independent slots.
    const bvh = sourceJointBVHRowExportWGSL({ leafCounter: 6, parentCounter: 7 });
    return code + '\n' + bvh + /* wgsl */ `
fn jointBVHExpectedWord(slot:u32)->u32{return cfg.expected[slot/4u][slot%4u];}
fn jointFiniteHorizon()->f32{
 return jointBVHDiscoveryHorizon();
}
@compute @workgroup_size(64) fn joint_bvh_chords(@builtin(global_invocation_id) gid:vec3u){let face=gid.x;if(face>=cfg.clothFaces){return;}if(jointBVHReady(false)&&jointBVHReady(true)){jointBVHBodyChords(face);}}
`;
}
export function packJointBVHUniform(p, e, s, cacheSlots, capacity, parentStart, finalEnumeration, refit) {
    if (s.sourceToken !== e.sourceToken || s.bodyGeneration !== e.bodyGeneration || s.gateRevision !== e.gateRevision)
        throw Error('Stale observed BVH epoch');
    const words = new Uint32Array(JOINT_BVH_UNIFORM_BYTES / 4);
    words.set([p.particleCount, p.clothFaces, p.bodyFaces, capacity, e.bodyGeneration, e.sourceToken, e.gateRevision, e.correctedSubstep, cacheSlots, +parentStart, +finalEnumeration, 0, s.snapshotEpoch, s.historyToken, s.gateToken, refit.first, refit.count, refit.depth, 0, 0]);
    words.set(jointBVHExpectedUniformWords(s), 20);
    return words;
}
export class SourceJointBVHFiniteExporter {
    device;
    packed;
    gateBuffer;
    gateLayout;
    validateGeneration;
    diagnosticTrace;
    sourceOnly = true;
    emitsAllFiniteBodyGeometry = true;
    diagnosticOnly = true;
    owned = [];
    pipelines = new Map();
    geometry;
    cache;
    cloth;
    body;
    uniforms;
    layout;
    call = 0;
    disposed = false;
    currentSnapshot;
    clothPacked;
    bodyPacked;
    slotsPerEnumeration;
    cacheSlots;
    constructor(device, packed, initial, gateBuffer, gateLayout, validateGeneration, shaderFactory = sourceJointBVHFiniteWGSL, diagnosticTrace, verifiedRefinedScope, kernelAuthority) {
        this.device = device;
        this.packed = packed;
        this.gateBuffer = gateBuffer;
        this.gateLayout = gateLayout;
        this.validateGeneration = validateGeneration;
        this.diagnosticTrace = diagnosticTrace;
        if (!validateGeneration(initial.generation) || initial.gateBuffer !== gateBuffer)
            throw Error('Stale initial observed GPU snapshot');
        if (initial.current.length !== packed.particleCount * 4 || initial.previous.length !== initial.current.length)
            throw Error('Wrong observed GPU cloth shape');
        if ([initial.binding.sourceSha256, initial.binding.bodySha256, initial.binding.topologySha256].some((v, i) => v !== [packed.sourceSha256, packed.bodySha256, packed.topologySha256][i]))
            throw Error('Observed BVH immutable identity mismatch');
        if(packed.refinedBoundary===true){requireVerifiedRefinedScope(verifiedRefinedScope,packed,gateLayout);if(initial.binding.refinedBoundary!==true||initial.binding.verifiedRefinedScope!==verifiedRefinedScope)throw Error('Observed refined scope differs from actual packet');}else if(verifiedRefinedScope)throw Error('Ordinary source cannot inherit refined scope');
        const verifiedCode=packed.refinedBoundary===true?refinedFiniteFactory(verifiedRefinedScope,packed,gateLayout):null;
        const code=shaderFactory(gateLayout);if(verifiedCode!==null&&code!==verifiedCode)throw Error('Refined exporter factory differs from actual bound child source');
        if(packed.refinedBoundary===true){if(device.limits.maxComputeWorkgroupsPerDimension>0xffffffff)throw Error('Invalid actual body-feature device u32 dispatch bounds');this.bodyFaceFeatureGroups=bodyFaceFeatureDispatchGroups(packed.clothFaces,device.limits.maxComputeWorkgroupsPerDimension);if(!code.endsWith('\n// BODY_FACE_FEATURE_LANES:15; dispatch ceil(originalClothFaces*15/64).\n'))throw Error('Body-feature dispatch requires actual derived full factory');this.actualBodyFaceFeaturePolicy=BODY_FACE_FEATURE_POLICY;}
        const w = packed.words;
        const clothTriangles = w.slice(w[6], w[7]);
        const bodyTriangles = w.slice(w[7], w[8]);
        const bodyPositions = new Float32Array(w.slice(w[8], w[9]).buffer);
        this.clothPacked = packJointBVH(clothTriangles, initial.current, { ...initial.binding, kind: 'cloth', scope: 'fresh-source-equal-layer', refinedBoundary: packed.refinedBoundary===true, ...(packed.refinedBoundary===true?{verifiedRefinedScope}:{}) });
        this.bodyPacked = packJointBVH(bodyTriangles, bodyPositions, { ...initial.binding, kind: 'body', scope: 'fresh-source-equal-layer', refinedBoundary: false });
        this.currentSnapshot = { ...initial.binding };
        this.cacheSlots = Math.max(64, Math.min(131072, packed.particleCount * 8));
        this.slotsPerEnumeration = jointBVHRefitDispatches(this.clothPacked).length + 6;
        try {
            const make = (name, data, usage = GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC) => { if (data.byteLength > device.limits.maxStorageBufferBindingSize)
                throw Error('Joint BVH storage exceeds portable limit'); const b = device.createBuffer({ label: 'joint-bvh:' + name, size: Math.max(4, data.byteLength), usage }); this.owned.push(b); device.queue.writeBuffer(b, 0, new Uint32Array(data)); return b; };
            this.geometry = make('immutable-finite-geometry', packed.words.slice());
            this.cache = make('bounded-source-owner-cache', new Uint32Array(this.cacheSlots * 8));
            this.cloth = make('complete-refitted-cloth', this.clothPacked.words);
            this.body = make('immutable-complete-skin', this.bodyPacked.words);
            this.uniforms = make('distinct-observed-enumeration-slots', new Uint32Array(160 * 9 * this.slotsPerEnumeration * JOINT_BVH_UNIFORM_STRIDE / 4), GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST);
            const layoutEntries = [...Array.from({ length: 8 }, (_, binding) => ({ binding, visibility: GPUShaderStage.COMPUTE, buffer: { type: [0, 1, 2, 7].includes(binding) ? 'read-only-storage' : 'storage', hasDynamicOffset: binding === 4 } })), { binding: 8, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'uniform', hasDynamicOffset: true } }, { binding: 9, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'uniform' } }];
            const bundle=acquireExactFiniteKernelBundle(device,{authority:kernelAuthority??this,code,layoutEntries,entryPoints:['reset','joint_bvh_begin','joint_bvh_leaves','joint_bvh_parents','joint_bvh_complete','joint_bvh_self_rows','body_points','joint_bvh_body_faces','joint_bvh_chords','complete'],diagnosticTrace});
            this.layout=bundle.layout;this.pipelines=new Map(Object.entries(bundle.pipelines));this.compilationSource=code;this.compilationPromise=bundle.compilationPromise;

        }
        catch (error) {
            this.destroy();
            throw error;
        }
    }
    async verifyCompilationBeforeDispatch(){if(this.disposed)throw Error('Disposed finite exporter');this.diagnosticTrace?.('exporter-compilation-before',{});const result=await this.compilationPromise;if(this.disposed)throw Error('Exporter disposed during compilation');this.compilationVerified=result;this.diagnosticTrace?.('exporter-compilation-after',result);return result;}
    encode(c, s) {
        if(!this.compilationVerified?.actualModuleCompilationChecked)throw Error('Actual module compilation barrier required before finite dispatch');
        if (this.disposed || !this.validateGeneration(s.generation) || s.currentBuffer !== c.current || s.previousBuffer !== c.previous || s.gateBuffer !== this.gateBuffer || s.binding.snapshotEpoch <= this.currentSnapshot.snapshotEpoch)
            throw Error('Unobserved/stale actual GPU enumeration');
        requireJointGeometryEpoch(this.packed, c.epoch);
        requireJointBVHBinding(this.bodyPacked, s.binding);
        if (s.current.length !== this.packed.particleCount * 4 || s.current.some((v, i) => !Number.isFinite(v) || (i % 4 === 3 && !Object.is(v, s.previous[i]))))
            throw Error('Invalid actual observed cloth/mass');
        // Source/current/history/gate bytes were captured before digest awaits. This method only
        // encodes GPU operations over those unchanged buffers; caller owns ordering/exclusion.
        const call = this.call++;
        if (call >= 160 * 9 || c.stateOffset % 256)
            throw Error('Joint BVH enumeration slots exhausted');
        const group = this.device.createBindGroup({ layout: this.layout, entries: [c.current, c.previous, this.geometry, c.rows, c.state, this.cache, this.cloth, this.body, this.uniforms, this.gateBuffer].map((buffer, binding) => ({ binding, resource: { buffer, ...binding === 4 ? { size: 32 } : binding === 8 ? { size: JOINT_BVH_UNIFORM_BYTES } : binding === 9 ? { size: this.gateLayout.byteLength } : {} } })) });
        let index = 0;
        const dispatch = (entry, groups, refit = { first: 0, count: 1, depth: 0 }) => { const offset = (call * this.slotsPerEnumeration + index++) * JOINT_BVH_UNIFORM_STRIDE; this.diagnosticTrace?.('exporter-dispatch-encode-before', { entry, groups, uniformOffset: offset, refit }); this.device.queue.writeBuffer(this.uniforms, offset, new Uint32Array(packJointBVHUniform(this.packed, c.epoch, s.binding, this.cacheSlots, c.capacity, c.parentStart, c.finalEnumeration, refit))); const pass = c.encoder.beginComputePass({ label: 'joint-bvh:' + entry }); pass.setPipeline(this.pipelines.get(entry)); pass.setBindGroup(0, group, [c.stateOffset, offset]); if (groups)
            pass.dispatchWorkgroups(groups); pass.end(); this.diagnosticTrace?.('exporter-dispatch-encode-after', { entry, groups }); };
        dispatch('reset', Math.ceil(this.cacheSlots * 8 / 64));
        for (const r of jointBVHRefitDispatches(this.clothPacked))
            dispatch(r.entryPoint, r.workgroups, r);
        dispatch('joint_bvh_self_rows', Math.ceil(this.packed.clothFaces / 64));
        dispatch('body_points', Math.ceil(this.packed.particleCount / 64));
        dispatch('joint_bvh_body_faces', this.bodyFaceFeatureGroups??Math.ceil(this.packed.clothFaces / 64));
        dispatch('joint_bvh_chords', Math.ceil(this.packed.clothFaces / 64));
        dispatch('complete', 1);
        if (index !== this.slotsPerEnumeration)
            throw Error('Incomplete actual BVH enumeration plan');
        this.currentSnapshot = { ...s.binding };
    }
    destroy() { if (this.disposed)
        return; this.disposed = true; this.owned.forEach(b => b.destroy()); this.owned = []; }
}
