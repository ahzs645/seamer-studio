import { sourcePhysicalReactionWGSL } from './physicalReactionWGSL.mjs';

/** NEW whole-coordinate variant; NOT covered by the frozen six-case device
 * receipt. Parent binding0 contains exact ORIGINAL-parent then exact material
 * history vec4 arrays (2*particles); no extra storage binding. Anchor binding3
 * contains authenticated `oldMaterialPoint - persistentAnchorTarget`, not world
 * XYZ targets. The GPU history/probe adapter must supply that direct difference
 * and a bound receipt. Native and the validated primitive remain byte unchanged.
 * The normal RHS is still the exact physical1mm row; numerical reserve remains
 * outside the force multiplier. */
const point = 'point+=t.scalar.x*(parent[t.particle].xyz+ideal[t.particle].xyz);';
const relative = 'let relative=point-anchors[q.span.w].xyz;';
if (sourcePhysicalReactionWGSL.split(point).length !== 3 || sourcePhysicalReactionWGSL.split(relative).length !== 3)
 throw Error('Validated primitive tangential structure changed; review required');
export const wholeRelativeReactionWGSL = sourcePhysicalReactionWGSL
 .replace('epoch:vec4u, // bodyGeneration,gateRevision,full raw count,actual packproof offset',
  'epoch:vec4u, // bodyGeneration,gateRevision,full raw count,actual packproof offset\n history:vec4u, // actual rowMode word offset; reserved')
 .replace('cfg.counts.x!=arrayLength(&parent)', 'cfg.counts.x>0xffffffffu/2u || cfg.counts.x*2u!=arrayLength(&parent)')
 .replaceAll(point, 'point+=t.scalar.x*(parent[t.particle].xyz-parent[cfg.counts.x+t.particle].xyz);point+=t.scalar.x*ideal[t.particle].xyz;')
 .replaceAll(relative, 'let relative=point+anchors[q.span.w].xyz;')
 .replace('anchors:array<vec4f>; // authentic body q + OLD material offset, w finite-proof1',
  'anchors:array<vec4f>; // authentic OLD material point minus persistent anchor target, w finite-proof1')
 .replace('if(membership[cfg.arrangement.z+p]!=c || !finite3(parent[p].xyz) || !finite1(parent[p].w) || parent[p].w<0.)',
  'if(membership[cfg.arrangement.z+p]!=c || !finite3(parent[p].xyz) || !finite1(parent[p].w) || parent[p].w<0. || !finite3(parent[cfg.counts.x+p].xyz) || bitcast<u32>(parent[p].w)!=bitcast<u32>(parent[cfg.counts.x+p].w))')
 .replace('if((parent[t.particle].w>0. && membership[cfg.arrangement.z+t.particle]!=c) || !finite3(t.gradient)',
  'if(!finite3(parent[cfg.counts.x+t.particle].xyz) || bitcast<u32>(parent[t.particle].w)!=bitcast<u32>(parent[cfg.counts.x+t.particle].w) || (parent[t.particle].w>0. && membership[cfg.arrangement.z+t.particle]!=c) || !finite3(t.gradient)')
 .replace('var tangent=vec3f(0.);', 'var tangent=vec3f(0.);var mode=0u;')
 .replace('if(size<=q.data.z*lambda*length(q.normal.xyz)){tangent=required;}',
  'if(size<=q.data.z*lambda*length(q.normal.xyz)){tangent=required;mode=1u;}')
 .replace('else if(size>0.){tangent=required*', 'else if(size>0.){mode=2u;tangent=required*')
 .replace('reaction[r]=vec4f(lambda,tangent);', 'reaction[r]=vec4f(lambda,tangent);status[cfg.history.x+r]=mode;')
 .replace('if(arrayLength(&status)<8u+cfg.counts.w*8u){return;}',
  'if(arrayLength(&status)<8u+cfg.counts.w*8u || cfg.history.x>arrayLength(&status) || cfg.counts.y>arrayLength(&status)-cfg.history.x){return;}');

/** Explicit execution diagnostic, not an independent geometric proof. All
 * inputs are F32-packed, each binary32 arithmetic operation is represented. */
export function representedRelativeMaterialSlip(parent, history, ideal, terms, oldMinusAnchor) {
 if (!(parent instanceof Float32Array) || !(history instanceof Float32Array) || !(ideal instanceof Float32Array) ||
     parent.length !== history.length || parent.length !== ideal.length || parent.length % 4 ||
     !Array.isArray(terms) || !Array.isArray(oldMinusAnchor) || oldMinusAnchor.length !== 3 ||
     [...parent, ...history, ...ideal, ...oldMinusAnchor].some(x => !Number.isFinite(x))) throw Error('Invalid relative material operands');
 const p = [0, 0, 0];
 for (const t of terms) {
  if (!Number.isSafeInteger(t.id) || t.id < 0 || t.id >= parent.length / 4 || !Number.isFinite(t.beta) ||
      parent[t.id * 4 + 3] < 0 || new Uint32Array(parent.buffer, parent.byteOffset)[t.id * 4 + 3] !==
      new Uint32Array(history.buffer, history.byteOffset)[t.id * 4 + 3] || ideal[t.id * 4 + 3] !== 0)
   throw Error('Invalid material history/W/ideal');
  for (let k = 0; k < 3; k++) {
   const beta = Math.fround(t.beta);
   p[k] = Math.fround(p[k] + Math.fround(beta * Math.fround(parent[t.id * 4 + k] - history[t.id * 4 + k])));
   p[k] = Math.fround(p[k] + Math.fround(beta * ideal[t.id * 4 + k]));
  }
 }
 return p.map((x, k) => Math.fround(x + oldMinusAnchor[k]));
}
