/** Actual copied source getter -> portable validator. No receipt-derived context. */
import type {ClothSimulation,PreparedCloth} from './engine-source/simulator.ts';
import {collisionGuardWorkerBinding,collisionGuardActivationBinding} from './engine-source/collisionGuardWorkerProtocol.ts';
import {buildSeamGateLayout,packSeamGate,physicalSeamStitchIndices} from './engine-source/webgpu/seamGate.ts';
import {actualPhysicalInverseMassBits} from './actualPhysicalMassBits.mjs';
import {validateActualSourceFrameCommit,byteSha256} from './frameCommitValidator.mjs';
import {equalData} from './refined/bytes.mjs';
export async function verifyActualAppFrame({simulation,prepared,sourceBinding,captureExecutedFrameOwner,isCurrent}: {
 simulation:ClothSimulation;prepared:PreparedCloth;sourceBinding:Record<string,unknown>;
 captureExecutedFrameOwner:()=>{frame:Record<string,unknown>;validation:Record<string,unknown>;providerImplementationSha256:string;backendImplementationSha256:string};isCurrent:()=>boolean;
}){
 const check=()=>{if(isCurrent()!==true)throw Error('App frame publication generation changed');};check();
 const acceptedPositions=simulation.positions,owner=captureExecutedFrameOwner(),used=structuredClone(simulation.lastCollisionSeamActivation),dictionary=structuredClone(simulation.collisionSeamDictionary),data=prepared.simData;
 if(!used||!dictionary||!simulation.sourceJointEnginePolicy||!equalData(owner.frame.usedActivation,used))throw Error('Actual used app gate/owner absent');
 const proof=structuredClone(simulation.safetyReport),receipt=structuredClone(simulation.sourceJointAcceptedFrameReceipt),q=simulation.collisionTrajectoryPositions.map(p=>p.slice()),delta=simulation.sourcePhysicalDeltaTrace.map(p=>p.slice());
 const options=structuredClone(simulation.collisionGuardExecutionOptions);if(!options)throw Error('Actual app Worker options absent');
 const input={bodyPositions:prepared.body.positions.slice(),bodyIndices:prepared.body.triangles.slice(),bodyPositionStride:4,bodyTriangleStride:4,clothTriangles:data.triangles.slice(),particleCount:data.particleCount,seams:data.seams.slice(),...dictionary,...(data.sourceGatherRefinement||data.sourceGatherCollisionGeometry?{sourceGatherRefinementRevision:data.sourceGatherRefinement?.revision,sourceGatherCollisionGeometry:structuredClone(data.sourceGatherCollisionGeometry)}:{})};
 const workerContextSha256=await collisionGuardWorkerBinding(input as Parameters<typeof collisionGuardWorkerBinding>[0],options);check();
 const indices=physicalSeamStitchIndices(data.seams,data.seamOrder,data.seamPairsBySeam,data.seamStitchRanges);
 if(dictionary.stitchCount!==data.stitchCount||dictionary.seamPairsBySeam.length!==indices.length)throw Error('App stitch dictionary differs');
 for(let i=0;i<indices.length;i++){const g=dictionary.seamPairsBySeam[i],expected=data.seamPairsBySeam[i];if(g.index!==i||g.seamId!==expected.seamId||!equalData(Array.from(g.pairs),Array.from(expected.pairs))||!equalData(Array.from(g.stitchIndices),indices[i]))throw Error('App original physical stitch stamps differ');}
 const layout=buildSeamGateLayout(data.stitchCount,indices.length),words=packSeamGate(layout,used.sewnUpTo,used.activeSeams,indices),usedGateSha256=await byteSha256(new Uint8Array(words.buffer));check();
 const validation=owner.validation,context={...structuredClone(sourceBinding),particleCount:data.particleCount,bodyFaceCount:prepared.body.numTriangles,generation:owner.frame.generation,frameSequence:owner.frame.frameSequence,workerContextSha256,usedGateSha256,usedActivation:used,physicalMassPolicySha256:data.sourcePhysicalMembrane?.policySha256,physicalInverseMassBitsFloat32:actualPhysicalInverseMassBits(data),sourceDeltaPolicySha256:simulation.sourceDeltaPolicy?.policySha256,backendImplementationSha256:owner.backendImplementationSha256,pressureProviderImplementationSha256:owner.providerImplementationSha256,pressureDeviceReceiptSha256:validation.receiptSha256,physicalPackShaderSha256:validation.physicalPackShaderSha256,reactionShaderSha256:validation.reactionShaderSha256,tolerancePolicySha256:validation.validatedTolerancePolicySha256,anchorPartitionPolicySha256:validation.validatedAnchorPartitionPolicySha256,validatedTolerances:validation.validatedTolerances,usedGateEncoding:'uint32-le-source-sewing-uniform-v1',usedGateByteLength:words.byteLength,workerSemanticActivationSha256:await collisionGuardActivationBinding(used)};
 check();const result=await validateActualSourceFrameCommit({context,receipt,acceptedReceipt:simulation.sourceJointAcceptedFrameReceipt,proof,positionSamples:q,physicalDeltaSamples:delta});check();
 if(!equalData(simulation.sourceJointAcceptedFrameReceipt,receipt)||!equalData(simulation.safetyReport,proof)||simulation.positions!==acceptedPositions)throw Error('Accepted app frame changed during validation');
 return Object.freeze({result,context,frameCommitSha256:receipt?.frameCommitSha256,fitAccepted:false});
}
