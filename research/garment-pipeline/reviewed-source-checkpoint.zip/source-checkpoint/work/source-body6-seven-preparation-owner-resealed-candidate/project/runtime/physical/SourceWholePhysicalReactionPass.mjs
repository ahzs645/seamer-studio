import { sourcePhysicalReactionWGSL } from './physicalReactionWGSL.mjs';
import { wholeRelativeReactionWGSL } from './wholeRelativeReactionWGSL.mjs';
import { decodePhysicalReactionReceipt } from './SourcePhysicalReactionPass.mjs';
import { requirePhysicalTolerancePolicy } from './tolerancePolicy.mjs';

const SHA = /^[a-f0-9]{64}$/;
const u32 = x => Number.isSafeInteger(x) && x >= 0 && x <= 0xffffffff;
const clone = x => structuredClone(x);
const hashFields = ['originalParentSha256', 'historySha256', 'usedGateSha256', 'sourceSha256', 'bodySha256',
 'fullRawRow128Sha256', 'packedPhysicalJacobianSha256', 'physicalMassPolicySha256',
 'declaredFrictionProfileSha256', 'physicalRhsSha256', 'finiteAnchorProbeSha256',
 'executedTolerancePolicySha256', 'executedAnchorPartitionPolicySha256'];

/** Scratch whole-provider resource. Same numerical shader as the six validated
 * fixtures, but this capacity/anchor-range adapter is NEW and not device tested.
 * Fixed capacities make snapshot size invariant across changing inventories.
 * Geometry, row packing, body history and ALLraw certification belong to their
 * authentic producers; this class never upgrades their authority. */
export function createSourceWholePhysicalReactionPass(device, scope, options) {
 return scope === 'fresh-source-physical-profile' ? new SourceWholePhysicalReactionPass(device, options) : null;
}

export class SourceWholePhysicalReactionPass {
 #device; #options; #owned = []; #reaction; #ideal; #status; #params; #readback;
 #layout; #pipes; #closing = false; #closed = false; #lease = null;
 #pendingEncode = null; #pendingMap = null; #closePromise = null;
 #generation = 0; #token = 0;
 constructor(device, options, assertCurrent=()=>true) {assertCurrent();
  this.#device = device;
  this.#options = Object.freeze(clone(options));
  const o = this.#options;
  if (![o.particles, o.rowCapacity, o.componentCapacity, o.sweeps].every(u32) || o.particles < 1 ||
      o.rowCapacity < 1 || o.rowCapacity > Math.floor(0xffffffff / 6) ||
      o.componentCapacity < 1 || o.componentCapacity > o.particles ||
      o.sweeps < 1 || o.sweeps > 8192 || !Number.isFinite(o.dt) || o.dt <= 0 ||
      !Number.isFinite(o.dt * o.dt) || o.dt * o.dt === 0 ||
      !Number.isFinite(o.algebraTolerance) || o.algebraTolerance <= 0 ||
      !['world-material-point', 'relative-material-history'].includes(o.coordinateRepresentation) ||
      device.limits.maxStorageBuffersPerShaderStage < 8) throw Error('Invalid whole physical reaction capacities');
  const allocate = (label, size, usage) => {
   if (!Number.isSafeInteger(size) || size < 4 || size > device.limits.maxStorageBufferBindingSize)
    throw Error('Whole physical reaction exceeds portable buffer bound');
   const b = device.createBuffer({ label, size, usage }); this.#owned.push(b); return b;
  };
  try {
   const writable = GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST;
   this.#reaction = allocate('whole physical lambda/tangent capacity', o.rowCapacity * 16, writable);
   this.#ideal = allocate('whole ideal contact delta', o.particles * 16, writable);
   this.#status = allocate('whole component proof capacity', (16 + o.componentCapacity * 8 +
    (o.coordinateRepresentation === 'relative-material-history' ? o.rowCapacity : 0)) * 4, writable);
   this.#params = allocate('whole executed private policy', 96, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST);
   this.#readback = allocate('whole physical receipt capacity', this.#status.size + this.#reaction.size + this.#ideal.size,
    GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ);
   this.#layout = device.createBindGroupLayout({ entries: Array.from({ length: 9 }, (_, binding) => ({
    binding, visibility: GPUShaderStage.COMPUTE,
    buffer: { type: binding === 8 ? 'uniform' : binding < 5 ? 'read-only-storage' : 'storage' }
   })) });
   const layout = device.createPipelineLayout({ bindGroupLayouts: [this.#layout] });
   const module = device.createShaderModule({ code: o.coordinateRepresentation === 'relative-material-history' ? wholeRelativeReactionWGSL : sourcePhysicalReactionWGSL });
   this.ready = (async () => {
    const info = await module.getCompilationInfo();assertCurrent();
    const errors = info.messages.filter(m => m.type === 'error');
    if (errors.length) throw Error(errors.map(m => `${m.lineNum}:${m.linePos} ${m.message}`).join('\n'));
    if (this.#closing) throw Error('Whole reaction closed during compilation');
    this.#pipes = Object.fromEntries(['seal_header', 'solve', 'validate_output'].map(entryPoint => [entryPoint,
     device.createComputePipeline({ layout, compute: { module, entryPoint } })]));
   })();
   this.ready.catch(() => {});
  } catch (e) { for (const b of this.#owned) b.destroy(); this.#owned = []; throw e; }
 }
 get snapshotBytes() { return this.#reaction.size + this.#ideal.size + this.#status.size; }
 get idealCombinedContactDelta() { return this.#ideal; }
 get reactionBuffer() { return this.#reaction; }
 get statusBuffer() { return this.#status; }
 get rowModeOffsetBytes() { return this.#options.coordinateRepresentation === 'relative-material-history' ?
  (16 + this.#options.componentCapacity * 8) * 4 : null; }
 #assertIdle() { if (this.#closing || this.#closed || this.#lease) throw Error('Whole reaction closed or leased'); }
 #snapshotRange(buffer, offset) {
  if (!buffer || this.#owned.includes(buffer) || !u32(offset) || offset % 4 ||
      !Number.isSafeInteger(buffer.size) || buffer.size < offset + this.snapshotBytes)
   throw Error('Invalid/aliased complete physical snapshot');
 }
 encodeSnapshot(encoder, target, offset = 0) {
  this.#assertIdle(); this.#snapshotRange(target, offset);
  for (const b of [this.#reaction, this.#ideal, this.#status]) {
   encoder.copyBufferToBuffer(b, 0, target, offset, b.size); offset += b.size;
  }
 }
 encodeRestore(encoder, source, offset = 0) {
  this.#assertIdle(); this.#snapshotRange(source, offset); this.invalidate();
  for (const b of [this.#reaction, this.#ideal, this.#status]) {
   encoder.copyBufferToBuffer(source, offset, b, 0, b.size); offset += b.size;
  }
 }
 invalidate() { this.#generation++; }
 encode(encoder, input, binding, isCurrent) {
  try { this.#assertIdle(); } catch (e) { return Promise.reject(e); }
  // Snapshot metadata AND the resource descriptors before ready can yield.
  const b = clone(binding), executed = clone(input.executed);
  const handles = { parent: input.parent, rows: input.rows, terms: input.terms,
   anchors: input.anchors, membership: input.membership, packProof: input.packProof };
  const anchor = clone(input.anchorRange), packProofOffset = input.packProofOffset ?? 0;
  const lease = { generation: this.#generation, token: ++this.#token, binding: b, executed, isCurrent, phase: 'preparing' };
  this.#lease = lease;
  const work = (async () => {
   try {
    await this.ready;
    this.#checkLease(lease);
    const o = this.#options, x = executed;
    if (!x || ![x.rows, x.components, x.membershipWords, x.descriptorOffset, x.ownerOffset, x.anchorCount].every(u32) ||
        x.rows < 1 || x.rows > o.rowCapacity || x.components > o.componentCapacity ||
        x.anchorCount < 1 || x.descriptorOffset + x.components * 4 > x.membershipWords ||
        x.ownerOffset + o.particles > x.membershipWords) throw Error('Incomplete executed physical capacities');
    if (hashFields.some(k => !SHA.test(b?.[k])) || !b.key ||
        !['generation', 'frameSequence', 'physicalSubstep', 'parentToken', 'gateRevision'].every(k => u32(b.key[k])) ||
        b.key.physicalSubstep < 1 || b.key.physicalSubstep > 40 || b.key.parentToken < 1 ||
        !u32(b.sourceToken) || !b.sourceToken || !u32(b.bodyGeneration) || !b.bodyGeneration ||
        !u32(b.rawOccurrences) || x.anchorCount !== b.rawOccurrences ||
        b.exclusiveBuffersLease !== true || b.actualGpuPhysicalPackProducer !== true ||
        b.actualGpuBodyBVHAnchorProducer !== true) throw Error('Missing authentic whole physical lease');
    const relative = o.coordinateRepresentation === 'relative-material-history';
    const align = this.#device.limits.minStorageBufferOffsetAlignment ?? 256;
    if (!anchor || !u32(anchor.offsetBytes) || anchor.offsetBytes % align ||
        anchor.byteLength !== x.anchorCount * 16 || anchor.rawOccurrences !== b.rawOccurrences ||
        !SHA.test(anchor.authenticProbeReceiptSha256) || anchor.authenticProbeReceiptSha256 !== b.finiteAnchorProbeSha256 ||
        anchor.outputAbi !== (relative ? 'full-body-material-anchor-relative-v1' : 'full-body-material-anchor-v1') ||
        anchor.bodySha256 !== b.bodySha256 || anchor.sourceSha256 !== b.sourceSha256 ||
        anchor.historySha256 !== b.historySha256 || anchor.usedGateSha256 !== b.usedGateSha256 ||
        anchor.physicalSubstep !== b.key.physicalSubstep)
     throw Error('Unbound/misaligned whole-body anchor subrange');
    if (relative && (!SHA.test(b.packedPhysicalParentHistorySha256) || !SHA.test(anchor.authenticRelativeAnchorHistorySha256)))
     throw Error('Relative material history bytes are unbound');
    const sizes = { parent: o.particles * (relative ? 32 : 16), rows: x.rows * 48, terms: x.rows * 6 * 32,
     anchors: anchor.offsetBytes + anchor.byteLength, membership: x.membershipWords * 4, packProof: packProofOffset + 32 };
    if (!u32(packProofOffset) || packProofOffset % 4 || new Set(Object.values(handles)).size !== 6)
     throw Error('Aliased/misaligned physical inputs');
    for (const [name, size] of Object.entries(sizes))
     if (!handles[name] || this.#owned.includes(handles[name]) || !Number.isSafeInteger(handles[name].size) ||
         handles[name].size < size) throw Error('Incomplete/aliased physical resource');
    requirePhysicalTolerancePolicy({ ...o, ...x }, b);
    const tail = 8 + o.componentCapacity * 8;
    const words = new Uint32Array(24);
    words.set([o.particles, x.rows, x.rows * 6, x.components, x.descriptorOffset,
     x.membershipWords, x.ownerOffset, x.anchorCount, o.sweeps, b.key.parentToken, b.sourceToken, 0]);
    new Float32Array(words.buffer).set([.001, .005, o.algebraTolerance, o.dt], 12);
    words.set([b.bodyGeneration, b.key.gateRevision, b.rawOccurrences, tail], 16);
    if (relative) words[20] = tail + 8;
    this.#device.queue.writeBuffer(this.#params, 0, words);
    encoder.clearBuffer(this.#ideal); encoder.clearBuffer(this.#reaction); encoder.clearBuffer(this.#status);
    encoder.copyBufferToBuffer(handles.packProof, packProofOffset, this.#status, tail * 4, 32);
    // Bind exact executed ranges: WGSL arrayLength is an input invariant.
    const resources = [
     { buffer: handles.parent, size: sizes.parent }, { buffer: handles.rows, size: sizes.rows },
     { buffer: handles.terms, size: sizes.terms },
     { buffer: handles.anchors, offset: anchor.offsetBytes, size: anchor.byteLength },
     { buffer: handles.membership, size: sizes.membership },
     { buffer: this.#reaction, size: x.rows * 16 }, { buffer: this.#ideal },
     { buffer: this.#status }, { buffer: this.#params }
    ];
    const group = this.#device.createBindGroup({ layout: this.#layout,
     entries: resources.map((resource, binding) => ({ binding, resource })) });
    for (const [name, count] of [['seal_header', 1], ['solve', x.components], ['validate_output', Math.ceil(o.particles / 64)]]) {
     if (count === 0) continue; // Authentic idle inventory: pack header + zero output still certified.
     const p = encoder.beginComputePass(); p.setPipeline(this.#pipes[name]); p.setBindGroup(0, group);
     p.dispatchWorkgroups(count); p.end();
    }
    lease.phase = 'encoded';
   } catch (e) { if (this.#lease === lease) this.#lease = null; throw e; }
  })();
  this.#pendingEncode = work;
  work.then(() => { if (this.#pendingEncode === work) this.#pendingEncode = null; },
   () => { if (this.#pendingEncode === work) this.#pendingEncode = null; });
  return work;
 }
 #checkLease(lease) {
  if (this.#closing || this.#closed || this.#lease !== lease ||
      lease.generation !== this.#generation || lease.isCurrent?.() !== true) throw Error('Whole physical parent lease changed');
 }
 readReceipt() {
  const lease = this.#lease;
  if (!lease || lease.phase !== 'encoded' || this.#pendingMap || this.#closing || this.#closed)
   return Promise.reject(Error('Missing/concurrent whole reaction receipt'));
  lease.phase = 'mapping';
  const work = (async () => {
   let mapped = false;
   try {
    this.#checkLease(lease);
    const e = this.#device.createCommandEncoder(); let offset = 0;
    for (const b of [this.#status, this.#reaction, this.#ideal]) {
     e.copyBufferToBuffer(b, 0, this.#readback, offset, b.size); offset += b.size;
    }
    this.#device.queue.submit([e.finish()]);
    await this.#readback.mapAsync(GPUMapMode.READ); mapped = true;
    const bytes = this.#readback.getMappedRange().slice(0);
    this.#checkLease(lease);
    const x = lease.executed, statusCapacity = new Uint32Array(bytes, 0, this.#status.size / 4);
    const status = new Uint32Array(16 + x.components * 8);
    status.set(statusCapacity.subarray(0, 8 + x.components * 8));
    const tail = 8 + this.#options.componentCapacity * 8;
    status.set(statusCapacity.subarray(tail, tail + 8), 8 + x.components * 8);
    const reaction = new Float32Array(bytes, this.#status.size, x.rows * 4).slice();
    const ideal = new Float32Array(bytes, this.#status.size + this.#reaction.size, this.#options.particles * 4).slice();
    const decoded = decodePhysicalReactionReceipt(status, reaction, ideal,
     { ...this.#options, ...x, terms: x.rows * 6 }, lease.binding);
    const rowModes = this.#options.coordinateRepresentation === 'relative-material-history' ?
     statusCapacity.slice(tail + 8, tail + 8 + x.rows) : null;
    if (rowModes?.some(mode => mode > 2)) throw Error('Invalid actual physical stick/sliding mode');
    return { ...decoded, binding: clone(lease.binding), executed: clone(x), status, statusCapacity:statusCapacity.slice(), reaction, rowModes,
     idealCombinedContactDelta: ideal, actualGpuReactionReadback: true,
     numericalMarginIsPhysicalPressure: false, normalReactionAuthoritative: false,
     freshAllRawCertificateRequired: true, actual41ProofRequired: true };
   } finally {
    if (mapped) this.#readback.unmap();
    if (this.#lease === lease) this.#lease = null;
   }
  })();
  this.#pendingMap = work;
  work.then(() => { if (this.#pendingMap === work) this.#pendingMap = null; },
   () => { if (this.#pendingMap === work) this.#pendingMap = null; });
  return work;
 }
 destroy() {
  if (this.#closePromise) return this.#closePromise;
  this.#closing = true; this.invalidate();
  this.#closePromise = (async () => {
   const errors = [];
   await this.ready.catch(e => errors.push(e));
   if (this.#pendingEncode) await this.#pendingEncode.catch(e => errors.push(e));
   if (this.#pendingMap) await this.#pendingMap.catch(e => errors.push(e));
   try { await this.#device.queue.onSubmittedWorkDone(); } catch (e) { errors.push(e); }
   finally { for (const b of this.#owned) try { b.destroy(); } catch (e) { errors.push(e); }
    this.#owned = []; this.#closed = true; this.#lease = null; }
   if (errors.length) throw new AggregateError(errors, 'Whole physical reaction cleanup failed');
  })();
  return this.#closePromise;
 }
}
