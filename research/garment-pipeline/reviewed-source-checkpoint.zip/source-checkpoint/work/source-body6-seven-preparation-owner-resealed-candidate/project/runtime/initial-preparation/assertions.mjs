/** Portable assertions; no geometry or acceptance policy. */
export const assert=(condition,message='Actual source preparation assertion failed')=>{if(!condition)throw Error(message);};
assert.equal=(a,b,message)=>assert(Object.is(a,b),message??'Actual source value differs');
