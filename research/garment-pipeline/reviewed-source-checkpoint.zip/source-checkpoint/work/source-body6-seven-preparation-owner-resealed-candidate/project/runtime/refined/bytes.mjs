/** No fs, Buffer, Node crypto, process, or GPU access. Copy before digest awaits. */
export const canonical = value => ArrayBuffer.isView(value) ? Array.from(value) : Array.isArray(value) ? value.map(canonical) : value && typeof value === 'object' ? Object.fromEntries(Object.keys(value).sort().map(k=>[k,canonical(value[k])])) : value;
export const canonicalText = value => JSON.stringify(canonical(value));
export const raw = value => new Uint8Array(value.buffer,value.byteOffset,value.byteLength);
export async function sha(value) {
 const bytes=typeof value==='string'?new TextEncoder().encode(value):value instanceof ArrayBuffer?new Uint8Array(value):raw(value);
 const snapshot=bytes.slice();
 if(!globalThis.crypto?.subtle)throw Error('Secure WebCrypto is required');
 return Array.from(new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256',snapshot)),n=>n.toString(16).padStart(2,'0')).join('');
}
export const digest = value => sha(canonicalText(value));
export function equalBytes(a,b){if(!ArrayBuffer.isView(a)||!ArrayBuffer.isView(b)||a.constructor!==b.constructor||a.byteLength!==b.byteLength)return false;const x=raw(a),y=raw(b);for(let i=0;i<x.length;i++)if(x[i]!==y[i])return false;return true;}
export function equalData(a,b){if(a instanceof Map||b instanceof Map){if(!(a instanceof Map)||!(b instanceof Map)||a.size!==b.size)return false;const x=[...a],y=[...b];return x.every((entry,i)=>equalData(entry,y[i]));}if(a instanceof Set||b instanceof Set){if(!(a instanceof Set)||!(b instanceof Set)||a.size!==b.size)return false;return equalData([...a],[...b]);}if(ArrayBuffer.isView(a)||ArrayBuffer.isView(b))return equalBytes(a,b);if(Object.is(a,b))return true;if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return false;const ak=Object.keys(a).sort(),bk=Object.keys(b).sort();return ak.length===bk.length&&ak.every((k,i)=>k===bk[i]&&equalData(a[k],b[k]));}
