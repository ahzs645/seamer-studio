/** Immutable packaged diagnostic hashes; no browser/device validation implied. */
const freeze=value=>{if(value&&typeof value==='object'){Object.values(value).forEach(freeze);Object.freeze(value);}return value;};
export const predicateEvidence = freeze({
  "kind": "packaged-refined-predicate-evidence-v1",
  "preflightSha256": "fb7c8009f8dbf53a6d96778fcaa318deedcd57aa8b10bfa5d973578ce69aae40",
  "reportSha256": "0a141cbb8cefe7d1797ace2544541a9bcca438bbc30f7e8ac19fd466d6e11f37",
  "referenceRuntimeTokens": {
    "sourceToken": 1055,
    "bodyGeneration": 5
  },
  "referenceFullFactorySha256": [
    "a5d5107d2ffad446c2f7da2e1e0c2c9532725269a3078a8de4afe891e5a8d480",
    "4b2d80907b032a0f0d02aa6c7290d2f4b4374cc0f36fd6539466d6344992b4c2",
    "deef13f1309c40aea4ea6ef891527cf46fb8e5a141eb426410b42493e6eda140"
  ],
  "predicateDeviceControlledCases": 24,
  "predicateOnlyDeviceExecuted": true,
  "fullFiniteProducerValidated": false,
  "pressureValidated": false,
  "wholeFrameValidated": false,
  "fullFitAccepted": false
});
