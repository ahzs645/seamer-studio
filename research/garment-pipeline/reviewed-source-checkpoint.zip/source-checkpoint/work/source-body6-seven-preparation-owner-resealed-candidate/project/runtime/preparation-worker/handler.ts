/** Genuine computational app preparation in a separate realm. No GPU API,
 * constructor, approval ledger, completion marker, or private provider token. */
import {prepareActualSceneSourceInputs} from '../sceneSourceInputs.ts';
import {sourceGatherRegistry} from '$lib/utils/sourceGatherPreparation';
import {decodeOriginalGatherDocument,type GatherTrust} from '$lib/utils/sourceGatherEvidence';
import {snapshotPreparationPacket,preparationPacketSha256} from './packet.mjs';
import type {SceneSourceInputOwner,SceneSourceInputRequest} from '../sceneSourceInputs.ts';
import type {SourceSheetAssignment} from '../source/sourcePhysicalMembrane.ts';
export interface ComputationalPreparationPacket {
 prepared:SceneSourceInputOwner['prepared'];owner:Omit<SceneSourceInputOwner,'prepared'|'stillCurrent'>;
 assignments:readonly SourceSheetAssignment[];request:SceneSourceInputRequest;deploymentTrust?:GatherTrust;
}
export async function executeComputationalPreparation(request:ComputationalPreparationPacket,expectedRequestSha256:string,current:()=>boolean){
 const packet=snapshotPreparationPacket(request) as ComputationalPreparationPacket;
 const check=()=>{if(current()!==true)throw Error('CPU preparation cancelled');return true;};
 check();if(await preparationPacketSha256(packet)!==expectedRequestSha256)throw Error('CPU request byte binding differs');check();
 if(packet.prepared.simData.sourceGatherRefinement){
  const source=packet.owner.pattern.garmentCodeSource as typeof packet.owner.pattern.garmentCodeSource & {gatherSourceDocument?:unknown};
  if(!packet.deploymentTrust||!source?.gatherSourceDocument)throw Error('Actual approved original gather input/pins required');
  // This worker independently verifies the same original evidence using the
  // actual deployment pins; it never consumes a caller readiness boolean.
  const raw=decodeOriginalGatherDocument(source.gatherSourceDocument);
  if(!await sourceGatherRegistry.register(raw,packet.owner.pattern,packet.deploymentTrust,check))throw Error('Original source evidence did not revalidate in CPU worker');check();
 }
 const started=performance.now();
 const inputs=await prepareActualSceneSourceInputs(()=>({...packet.owner,prepared:packet.prepared,stillCurrent:check}),packet.assignments,packet.request,'fresh-source-physical-profile');check();
 if(!inputs)throw Error('Computational source preparation unavailable');inputs.assertCurrent();
 const result={prepared:inputs.prepared,descriptor:inputs.descriptor.capture(),preflight:inputs.preflight,
  CPUWorkerPreparationOnly:true,wholeFrameExecuted:false,fitAccepted:false,requestSha256:expectedRequestSha256,
  computationMilliseconds:performance.now()-started};
 const owned=snapshotPreparationPacket(result);const sha256=await preparationPacketSha256(owned);check();inputs.assertCurrent();
 return {result:owned,sha256};
}
