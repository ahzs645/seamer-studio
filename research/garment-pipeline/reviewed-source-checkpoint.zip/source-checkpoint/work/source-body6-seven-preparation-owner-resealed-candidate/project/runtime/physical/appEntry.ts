/** Copied proposal only: import this SOURCE into the renderer's actual app graph.
 * Do not separately bundle/load a second registry. This does not register source
 * approval, validate a device artifact origin, or expose a browser automation API. */
import { sourceGatherRegistry } from '$lib/utils/sourceGatherPreparation';
import { sourceGatherIdentity } from '@seamer/cloth-sim';
import { activeGarmentCodeBody } from '@seamer/avatar';
import type { Pattern } from '@seamer/pattern-model';
import { validateSourcePhysicalMembrane, type CandidateSim } from './source/sourcePhysicalMembrane.ts';
import { createSourceWholePhysicalReactionProvider } from './SourceWholePhysicalReactionProvider.mjs';
import { copyData, equalData } from './snapshots.mjs';
import { physicalBytesSha256 } from './portablePhysicalHashes.mjs';
interface Binding { sourceSha256:string;bodySha256:string;topologySha256:string;sourceToken:number;bodyGeneration:number }
interface Prepared { simData:CandidateSim & {triangles:Uint32Array;edgeRuns?:Map<string,unknown>;sourceGatherRefinement?:{approvedEvidence:Record<string,unknown>}}; body:{positions:Float32Array;triangles:Uint32Array};collisionSafety:boolean }
export interface PhysicalAppOwner {
 pattern:Pattern;prepared:Prepared;sourceBinding:Binding;
 /** Pinned experiment-owner metadata, never an automation supplied artifact. */
 providerOptions:Record<string,unknown>;
 manualRecording:boolean;held:boolean;cached:boolean;explicitSettings:boolean;
 stillCurrent:()=>boolean;
}
/** No option binding may override actual prepared source/body/SI mass. The
 * returning async source factory preserves native immediate null semantics. */
function preparedDataSnapshot(data:Prepared['simData']){const {edgeRuns,...numerical}=data;return {...numerical,edgeRuns:edgeRuns instanceof Map?Array.from(edgeRuns.entries()):edgeRuns};}
export function createAppWholePhysicalFactory(readCurrentOwner:()=>PhysicalAppOwner) {
 return function create(device:GPUDevice,scope:string) {
  if(scope!=='fresh-source-physical-profile')return null;
  const owner=readCurrentOwner(),{pattern,prepared}=owner,data=prepared.simData;
  if(!prepared.collisionSafety||!activeGarmentCodeBody(pattern.body))throw Error('Actual active source body/preparation required');
  if(owner.manualRecording||owner.held||owner.cached||owner.explicitSettings||pattern.assembly||pattern.settings3d.fixTop
   ||pattern.pieces.some(p=>p.settings3d.frozen||p.settings3d.savedDrapeState==='held'||p.settings3d.savedPositions.length>0))
   throw Error('Fresh free implicit source owner required');
  const intent={manualRecording:owner.manualRecording,held:owner.held,cached:owner.cached,explicitSettings:owner.explicitSettings},identity=sourceGatherIdentity(pattern),scopeRecord=sourceGatherRegistry.lookup(pattern),body=copyData(pattern.body),source=copyData(pattern.garmentCodeSource),initial=copyData({data:preparedDataSnapshot(data),bodyMesh:prepared.body,binding:owner.sourceBinding,options:owner.providerOptions});
  const approved=scopeRecord?.approvedEvidence;
  if(data.sourceGatherRefinement){const numerical=approved?Object.fromEntries(Object.entries(approved).filter(([k])=>k!=='sourceIdentity')):undefined;
   if(!scopeRecord?.enabled||!scopeRecord.sourceBodyActive||!approved||!equalData(numerical,data.sourceGatherRefinement.approvedEvidence))throw Error('Actual same-app registry source refinement approval required');}
  const callback=owner.stillCurrent;
  const current=()=>{const before=readCurrentOwner();if(before.stillCurrent!==callback||callback()!==true)return false;const now=readCurrentOwner();return now.pattern===pattern&&now.prepared===prepared&&now.stillCurrent===callback
   &&now.manualRecording===intent.manualRecording&&now.held===intent.held&&now.cached===intent.cached&&now.explicitSettings===intent.explicitSettings
   &&sourceGatherIdentity(pattern)===identity&&equalData(pattern.body,body)&&equalData(pattern.garmentCodeSource,source)
   &&equalData(sourceGatherRegistry.lookup(pattern),scopeRecord)&&equalData({data:preparedDataSnapshot(now.prepared.simData),bodyMesh:now.prepared.body,binding:now.sourceBinding,options:now.providerOptions},initial);};
  const assertCurrent=()=>{if(!current())throw Error('Genuine app preparation/source/registry generation changed');return true;};
  assertCurrent();const material=validateSourcePhysicalMembrane(data);if(!material)throw Error('Actual executed SI policy and inverse masses required');
  return (async()=>{
   const bodySha256=await physicalBytesSha256(prepared.body.positions);assertCurrent();
   const topologySha256=await physicalBytesSha256(data.triangles);assertCurrent();
   if(bodySha256!==owner.sourceBinding.bodySha256||topologySha256!==owner.sourceBinding.topologySha256)throw Error('Actual app body/topology SHA differs from renderer binding');
   const massBits=new Uint32Array(data.positions.filter((_,i)=>i%4===3).buffer);
   const options={...copyData(owner.providerOptions),particles:data.particleCount,
    sourceSha256:owner.sourceBinding.sourceSha256,bodySha256,sourceToken:owner.sourceBinding.sourceToken,bodyGeneration:owner.sourceBinding.bodyGeneration,
    physicalMassPolicySha256:material.policySha256,physicalInverseMassBits:massBits,isCurrent:assertCurrent};
   for(const field of['particles','sourceSha256','bodySha256','sourceToken','bodyGeneration','physicalMassPolicySha256','physicalInverseMassBits'] as const)
    if(Object.hasOwn(owner.providerOptions,field)&&!equalData(owner.providerOptions[field],options[field]))throw Error('Provider option attempts to override actual source/body/SI binding');
   assertCurrent();const provider=await createSourceWholePhysicalReactionProvider(device,scope,options);try{assertCurrent();return provider;}catch(error){try{await provider?.destroy();}catch(cleanup){throw new AggregateError([error,cleanup],'Stale app physical provider cleanup failed',{cause:error});}throw error;}
  })();
 };
}
