/** NEW scope adapter. Complete finite nearest query remains the frozen V2
 * shader; verified refined triangles are never labeled ordinary geometry. */
import{packJointClosedProbeTrees as ordinaryTrees,requireJointClosedProbeTree}from'../owner/source-joint-refined-backend-integration/runtime/compiled/sourceJointClosedBodyProbe.mjs';
import{packJointBVH}from'../owner/source-joint-refined-backend-integration/runtime/compiled/sourceJointBVHRowExport.mjs';
import{requireVerifiedRefinedScope}from'../refined/RefinedBackendScope.mjs';
export function packJointClosedProbeTrees(p,observed,verifiedRefinedScope,layout){
 if(p.refinedBoundary!==true){if(verifiedRefinedScope)throw Error('Ordinary anchor cannot borrow refined scope');return ordinaryTrees(p,observed);}
 requireVerifiedRefinedScope(verifiedRefinedScope,p,layout);
 const body=packJointBVH(p.words.slice(p.words[7],p.words[7]+p.bodyFaces*4),new Float32Array(p.words.slice(p.words[8],p.words[8]+p.words[4]*4).buffer),{...observed.binding,kind:'body',scope:'fresh-source-equal-layer',refinedBoundary:false});
 const cloth=packJointBVH(p.words.slice(p.words[6],p.words[6]+p.clothFaces*4),observed.current,{...observed.binding,kind:'cloth',scope:'fresh-source-equal-layer',refinedBoundary:true,verifiedRefinedScope});
 requireJointClosedProbeTree(body,p,observed,'body');requireJointClosedProbeTree(cloth,p,observed,'cloth');return{body,cloth};
}
