/** NEW browser-only port of the reviewed151 bounded rigid initial screen.
 * No fixture IDs, saved q, approval writes, device allocation or fit authority. */
import {assert} from './assertions.mjs';
import {copyData,equalData} from './snapshots.mjs';
import {proposeSourceInitialDepenetration} from './preflightDepenetration.mjs';
import {SourceSelfIntervalGuard} from './selfIntervalClearance.mjs';
import {SourceBodyFacetClearanceGuard} from './bodyFacetClearance.mjs';
const seeds=new WeakMap();
const canonical=x=>Array.isArray(x)?x.map(canonical):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,canonical(x[k])])):x;
const sha=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
const numericSha=a=>sha(new Uint8Array(a.buffer,a.byteOffset,a.byteLength));
const policySha=p=>sha(new TextEncoder().encode(JSON.stringify(canonical(p))));
// Binding data numbers uses represented Float64 bits, including signed zero.
const numberBits=n=>{assert(Number.isFinite(n),'Nonfinite source identity');const b=new ArrayBuffer(8);new DataView(b).setFloat64(0,n,false);return Array.from(new Uint8Array(b),x=>x.toString(16).padStart(2,'0')).join('');};
const sourceIdentityValue=x=>typeof x==='number'?{representedFloat64:numberBits(x)}:Array.isArray(x)?x.map(sourceIdentityValue):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,sourceIdentityValue(x[k])])):x;
const sourceIdentitySha=x=>sha(new TextEncoder().encode(JSON.stringify(sourceIdentityValue(x))));
function snapshot(prepared){const {edgeRuns,...data}=prepared.simData,result=copyData({...prepared,simData:data});if(edgeRuns instanceof Map){assert(Object.getPrototypeOf(edgeRuns)===Map.prototype&&Reflect.ownKeys(edgeRuns).length===0,'Plain original edge map required');result.simData.edgeRuns=new Map(Array.from(Map.prototype.entries.call(edgeRuns),([k,v])=>[k,copyData(v)]));}else result.simData.edgeRuns=copyData(edgeRuns);return result;}
function same(a,b){const {edgeRuns:x,...ad}=a.simData,{edgeRuns:y,...bd}=b.simData;return equalData({...a,simData:ad},{...b,simData:bd})&&equalData(x instanceof Map?Array.from(x):x,y instanceof Map?Array.from(y):y);}
function checkBody(p,vertices,indices){const b=p.body;assert(vertices.length%3===0&&indices.length%3===0&&b.positions.length===vertices.length/3*4&&b.triangles.length===indices.length/3*4,'Actual posed body shape differs');for(let i=0;i<vertices.length/3;i++){for(let k=0;k<3;k++)assert(Object.is(b.positions[i*4+k],vertices[i*3+k]),'Actual posed avatar/body XYZ differs');assert(Object.is(b.positions[i*4+3],0),'Actual body padding differs');}for(let i=0;i<indices.length/3;i++){for(let k=0;k<3;k++)assert(b.triangles[i*4+k]===indices[i*3+k],'Actual posed body topology differs');assert(b.triangles[i*4+3]===0,'Body topology padding differs');}}
/** Call before SI and before arm placement. Callback is the actual SAME graph
 * dictionary/first-stamp/controller/finite guard owner, not caller metadata. */
export function prepareBrowserInitialSpacing(readCurrentOwner,scope,{createActualGuards}={}){
 if(scope!=='fresh-source-physical-profile')return null;
 assert(typeof readCurrentOwner==='function'&&typeof createActualGuards==='function','Actual source owner and guard constructor required');
 const first=readCurrentOwner(),prepared=first.prepared,pattern=first.pattern,vertices=first.avatarVertices,indices=first.avatarIndices,callback=first.stillCurrent;
 assert(typeof callback==='function'&&prepared.collisionSafety===true&&!prepared.simData.sourcePhysicalMembrane,'Actual finalized source must be captured BEFORE SI');
 const original=snapshot(prepared),p=snapshot(prepared),pat=copyData(pattern),v=copyData(vertices),ix=copyData(indices),flags={manual:first.manual===true,explicitConfiguration:first.explicitConfiguration===true};
 const assertOwner=()=>{const now=readCurrentOwner();assert(now.prepared===prepared&&now.pattern===pattern&&now.avatarVertices===vertices&&now.avatarIndices===indices&&now.stillCurrent===callback&&callback()===true,'Actual source/body generation changed');assert(same(snapshot(prepared),original)&&equalData(copyData(pattern),pat)&&equalData(copyData(vertices),v)&&equalData(copyData(indices),ix)&&(now.manual===true)===flags.manual&&(now.explicitConfiguration===true)===flags.explicitConfiguration,'Actual source/body input changed');return true;};
 assertOwner();checkBody(p,v,ix);
 const actual=createActualGuards(p);assert(same(p,original),'Guard constructor changed captured preparation');assert(actual?.finiteGuard&&actual.activation,'Actual first-stamped initial guard context required');
 const activation=copyData(actual.activation),input={particleCount:p.simData.particleCount,clothTriangles:p.simData.triangles,clothTriangleStride:4,bodyPositions:p.body.positions,bodyPositionStride:4,bodyIndices:p.body.triangles,bodyTriangleStride:4};
 const guards={selfGuard:new SourceSelfIntervalGuard(input,{maxDepth:16,maxIntervals:512}),bodyFacetGuard:new SourceBodyFacetClearanceGuard(input),finiteGuard:actual.finiteGuard,activation,...flags};
 return(async()=>{const proposal=await proposeSourceInitialDepenetration(p,pat,guards);assertOwner();
  const result=proposal.prepared,d=result.simData,base=original.simData;
  for(const field of ['positions2d','sourceArrangedPositions','triangles','seams','seamOrder','particleLayers','neighborIndices','incidentTriangles','assemblySupport','stretchColors','bendColors'])assert(equalData(d[field],base[field]),'Rigid spacing changed source/rest/stamps/support: '+field);
  assert(equalData(result.body,original.body),'Rigid spacing changed body');for(const field of ['positions','arrangedPositions','anchors']){assert(d[field].length===base[field].length,'Rigid spacing array shape differs');for(let i=0;i<d[field].length;i++)if(i%4!==0)assert(Object.is(d[field][i],base[field][i]),'Rigid spacing changed non-X source lane');}
  const captured=snapshot(result),ownedProposal=copyData(proposal.policy??null),publicPolicy=copyData(ownedProposal),publicActivation=copyData(activation),checkSeed=()=>{assertOwner();assert(same(snapshot(result),captured),'Returned rigid seed changed');assert(equalData(publicPolicy,ownedProposal)&&equalData(publicActivation,activation),'Returned rigid policy or activation changed');return true;};
  const seed=Object.freeze({prepared:result,changed:proposal.changed,reason:proposal.reason??null,proposalPolicy:publicPolicy,assertCurrent:checkSeed,preparationOnly:true,fullPreflightRequired:true,actualInitialRequestedActivation:publicActivation,activationOrigin:'actual-current-app-CPU-requested-initial-mask',deviceExecuted:false,cacheWarmEligible:false,sourceAssemblyComplete:false,fitAccepted:false});
  seeds.set(seed,{original,captured,pattern:pat,vertices:v,indices:ix,proposalPolicy:ownedProposal,initialActivation:copyData(activation),assertOwner,checkSeed});return seed;
 })();
}
/** Use genuine first SI output to bind physical W/rest, then execute the SAME
 * material routine with the NEW app profile installed before sealing. */
export async function sealBrowserInitialSpacingMaterial(seed,prepared,{prepareSourcePhysicalMembrane,validateSourcePhysicalMembrane}={}){
 const owned=seeds.get(seed);assert(owned,'Private actual app rigid seed required');owned.checkSeed();assert(typeof prepareSourcePhysicalMembrane==='function'&&typeof validateSourcePhysicalMembrane==='function','Actual material owner required');
 const captured=snapshot(prepared),current=snapshot(prepared),d=current.simData,initial=owned.captured.simData;validateSourcePhysicalMembrane(d);
 assert(equalData(current.body,owned.captured.body),'Material changed actual body');
 for(const field of ['anchors','positions2d','triangles','seams','seamOrder','assemblySupport','sourceStaging','arrangementSourceStaging','sourceGatherRefinement','sourceGatherCollisionGeometry'])assert(equalData(d[field],initial[field]),'Material changed rigid source: '+field);
 for(const field of ['positions','arrangedPositions','sourceArrangedPositions']){assert(d[field].length===initial[field].length,'Material source array shape differs');for(let i=0;i<d[field].length;i++)if(i%4!==3||initial[field][i]===0)assert(Object.is(d[field][i],initial[field][i]),'Material changed source XYZ/fixed W');}
 const check=()=>{owned.checkSeed();assert(same(snapshot(prepared),captured),'Actual material input changed during digest');return true;};
 if(!seed.changed){const output=snapshot(current),out=snapshot(output);return Object.freeze({prepared:output,changed:false,sourceInitialArrangementPolicySha256:d.sourceInitialArrangementPolicySha256??null,assertCurrent:()=>{check();assert(same(snapshot(output),out),'Returned material changed');return true;},deviceExecuted:false,cacheWarmEligible:false,fitAccepted:false});}
 // All hash inputs are private synchronous snapshots. One bounded await batch
 // checks the exact caller/owner again before any policy can be published.
 const base=owned.original.simData;
 const fieldHashes=[['positions','actualPositionsSha256'],['arrangedPositions','actualArrangedPositionsSha256'],['anchors','actualAnchorsSha256'],['sourceArrangedPositions','originalSourceArrangedPositionsSha256'],['positions2d','sourceRestCoordinatesSha256'],['triangles','clothTrianglesSha256'],['seams','seamsSha256'],['seamOrder','seamOrderSha256']];
 check();
 const [fieldDigests,originalPositionsSha256,originalAnchorsSha256,patternSha256,bodyPositionsSha256,bodyTrianglesSha256,assemblySupportTargetsSha256,assemblySupportGroupsSha256,physicalInverseMassBitsSha256,actualRestConstraintSha256]=await Promise.all([
  Promise.all(fieldHashes.map(([field])=>numericSha(d[field]))),numericSha(base.positions),numericSha(base.anchors),sourceIdentitySha(owned.pattern),numericSha(current.body.positions),numericSha(current.body.triangles),numericSha(d.assemblySupport.targets),policySha(d.assemblySupport.groups),numericSha(d.positions.filter((_,i)=>i%4===3)),policySha(d.stretchColors.map(g=>({edges:Array.from(g.edges),props:Array.from(g.props)})))
 ]);check();
 const hashes=Object.fromEntries(fieldHashes.map(([,key],i)=>[key,fieldDigests[i]]));
 const policy={...owned.proposalPolicy,actualInitialRequestedActivation:copyData(owned.initialActivation),activationOrigin:'actual-current-app-CPU-requested-initial-mask',preparationOrigin:'actual-app-finalized-source-before-SI-rigid-v1',revision:1,originalPositionsSha256,originalAnchorsSha256,actualAppPatternSha256:patternSha256,...hashes,bodyPositionsSha256,bodyTrianglesSha256,assemblySupportTargetsSha256,assemblySupportGroupsSha256,physicalInverseMassBitsSha256,actualRestConstraintSha256,sourcePhysicalMaterialPolicySha256:undefined,originalPhysicalMaterialPolicySha256:d.sourcePhysicalMembrane.policySha256,originalSourceDescriptorSha256:undefined,oldDescriptorOrContextRelabelled:false,GPUValidated:false,fullFitAccepted:false};delete policy.actualUsedActivation;delete policy.sourcePhysicalMaterialPolicySha256;delete policy.originalSourceDescriptorSha256;
 const hash=await policySha(policy);check();const preSI=snapshot(owned.captured);preSI.simData.sourceInitialArrangementPolicy=copyData(policy);preSI.simData.sourceInitialArrangementPolicySha256=hash;
 const assignments=copyData(d.sourcePhysicalMembrane.policy.pieces);const output={...preSI,simData:await prepareSourcePhysicalMembrane(preSI.simData,assignments)};check();validateSourcePhysicalMembrane(output.simData);
 for(const field of ['positions','arrangedPositions','sourceArrangedPositions','anchors','positions2d','triangles','seams','seamOrder','assemblySupport','stretchColors','bendColors'])assert(equalData(output.simData[field],d[field]),'Actual reseal changed physical/source geometry: '+field);
 const result=snapshot(output),out=snapshot(result),checkOutput=()=>{check();assert(same(snapshot(result),out),'Returned app material/profile changed');return true;};
 return Object.freeze({prepared:result,changed:true,sourceInitialArrangementPolicySha256:hash,assertCurrent:checkOutput,executionContextMustBeAuthorizedSeparately:true,deviceExecuted:false,cacheWarmEligible:false,sourceAssemblyComplete:false,fitAccepted:false});
}
