/** NEW copied device proposal, not device-validated or production-linked.
 * Physical rows/terms/anchors MUST be authored by authentic GPU finite/packing
 * stages. This shader takes physical RHS only; augmented work RHS is rejected.
 * Eight storage buffers. Exclusive disjoint components own shared particle IDs.
 * Tangential history publication and fresh complete finite/path certification are
 * outside this numerical operator and mandatory. No native factory is supplied. */
export const sourcePhysicalReactionWGSL=String.raw`
struct PhysicalRow {
 normal:vec4f, // xyz actual packed normal; w MUST physical1mm (no work reserve)
 span:vec4u, // firstTerm, termCount, body0/self1, authentic finite anchor index
 data:vec4f, // physicalNeed, J W Jt, declared muStatic, muKinetic
}
struct PhysicalTerm { gradient:vec3f, particle:u32, scalar:vec4f } // scalar.x signed material beta
struct Config {
 counts:vec4u, // particles,rows,terms,components
 arrangement:vec4u, // first component descriptor,membershipWords,ownerOffset,anchorCount
 limits:vec4u, // bounded sweeps1..8192,parentToken,sourceToken,unsupported
 policy:vec4f, // actual physical1mm, ORIGINAL5mm NET, algebra tolerance, physicalDt
 epoch:vec4u, // bodyGeneration,gateRevision,full raw count,actual packproof offset
}
@group(0) @binding(0) var<storage,read> parent:array<vec4f>;
@group(0) @binding(1) var<storage,read> rows:array<PhysicalRow>;
@group(0) @binding(2) var<storage,read> terms:array<PhysicalTerm>;
@group(0) @binding(3) var<storage,read> anchors:array<vec4f>; // authentic body q + OLD material offset, w finite-proof1
@group(0) @binding(4) var<storage,read> membership:array<u32>;
@group(0) @binding(5) var<storage,read_write> reaction:array<vec4f>; // normalλ,tangentXYZ kg*m
@group(0) @binding(6) var<storage,read_write> ideal:array<vec4f>; // direct pre-world-add metres
@group(0) @binding(7) var<storage,read_write> status:array<u32>;
@group(0) @binding(8) var<uniform> cfg:Config;
fn finite1(x:f32)->bool{return abs(x)<=3.402823466e38;}
fn finite3(x:vec3f)->bool{return all(abs(x)<=vec3f(3.402823466e38));}
fn error(c:u32,reason:u32){status[8u+c*8u]=reason;status[11u+c*8u]=cfg.limits.y;}
fn effect(q:PhysicalRow)->f32{var value=0.;for(var k=0u;k<q.span.y;k++){let t=terms[q.span.x+k];value+=dot(t.gradient,ideal[t.particle].xyz);}return value;}
@compute @workgroup_size(1)
fn seal_header(){
 if(arrayLength(&status)<8u || cfg.epoch.w>arrayLength(&status) || arrayLength(&status)-cfg.epoch.w<8u){return;}
 let o=cfg.epoch.w;
 // Actual physical pack flags/count/rawcount/terms/parent/source/body/gate copied
 // verbatim into the owned tail BEFORE this dispatch; not a host success flag.
 let good=status[o]==0u && status[o+1u]==cfg.counts.y && status[o+2u]==cfg.epoch.z && status[o+3u]==cfg.counts.z && status[o+4u]==cfg.limits.y && status[o+5u]==cfg.limits.z && status[o+6u]==cfg.epoch.x && status[o+7u]==cfg.epoch.y;
 status[0]=select(16u,0u,good);status[1]=cfg.counts.y;status[2]=7u;status[3]=cfg.counts.z;status[4]=cfg.counts.w;status[5]=cfg.limits.y;status[6]=cfg.limits.z;status[7]=1u;
}
@compute @workgroup_size(1)
fn solve(@builtin(global_invocation_id) gid:vec3u){
 let c=gid.x;if(c>=cfg.counts.w){return;}
 if(arrayLength(&status)<8u+cfg.counts.w*8u){return;}
 // Complete actual pack header, source epoch, physical-RHS discriminator1.
 if(status[0]!=0u || status[1]!=cfg.counts.y || status[2]!=7u || status[3]!=cfg.counts.z || status[4]!=cfg.counts.w || status[5]!=cfg.limits.y || status[6]!=cfg.limits.z || status[7]!=1u){error(c,16u);return;}
 if(cfg.policy.x!=0.001 || cfg.policy.y!=0.005 || cfg.policy.z<=0. || cfg.policy.w<=0. || cfg.limits.x<1u || cfg.limits.x>8192u || cfg.limits.w!=0u || cfg.counts.x!=arrayLength(&parent) || cfg.counts.x!=arrayLength(&ideal) || cfg.counts.y!=arrayLength(&rows) || cfg.counts.y!=arrayLength(&reaction) || cfg.counts.z!=arrayLength(&terms) || cfg.arrangement.w!=arrayLength(&anchors) || cfg.arrangement.y!=arrayLength(&membership)){error(c,16u);return;}
 let descriptor=cfg.arrangement.x+4u*c;if(descriptor+3u>=cfg.arrangement.y){error(c,1u);return;}
 let firstRow=membership[descriptor];let rowCount=membership[descriptor+1u];let firstNode=membership[descriptor+2u];let nodeCount=membership[descriptor+3u];
 if(firstRow>cfg.arrangement.y || rowCount>cfg.arrangement.y-firstRow || firstNode>cfg.arrangement.y || nodeCount>cfg.arrangement.y-firstNode || cfg.arrangement.z>cfg.arrangement.y || cfg.counts.x>cfg.arrangement.y-cfg.arrangement.z){error(c,1u);return;}
 for(var i=0u;i<nodeCount;i++){let p=membership[firstNode+i];if(p>=cfg.counts.x){error(c,1u);return;}if(membership[cfg.arrangement.z+p]!=c || !finite3(parent[p].xyz) || !finite1(parent[p].w) || parent[p].w<0.){error(c,2u);return;}}
 for(var i=0u;i<rowCount;i++){
  let r=membership[firstRow+i];if(r>=cfg.counts.y){error(c,1u);return;}let q=rows[r];
  if(q.span.x>cfg.counts.z || q.span.y>cfg.counts.z-q.span.x || q.span.y>6u || q.span.z>1u || !finite3(q.normal.xyz) || abs(length(q.normal.xyz)-1.)>0.00002 || q.normal.w!=cfg.policy.x || !finite1(q.data.x) || !finite1(q.data.y) || q.data.y<0. || !finite1(q.data.z) || !finite1(q.data.w) || q.data.z<q.data.w || q.data.w<0.){error(c,2u);return;}
  if(q.span.z==0u && (q.span.w>=cfg.arrangement.w || !finite3(anchors[q.span.w].xyz) || anchors[q.span.w].w!=1.)){error(c,32u);return;}
  for(var k=0u;k<q.span.y;k++){let t=terms[q.span.x+k];if(t.particle>=cfg.counts.x){error(c,1u);return;}if((parent[t.particle].w>0. && membership[cfg.arrangement.z+t.particle]!=c) || !finite3(t.gradient) || !finite1(t.scalar.x) || (q.span.z==0u && t.scalar.x<0.)){error(c,2u);return;}}
 }
 for(var i=0u;i<nodeCount;i++){ideal[membership[firstNode+i]]=vec4f(0.);}
 for(var i=0u;i<rowCount;i++){reaction[membership[firstRow+i]]=vec4f(0.);}
 var converged=false;var maximumDeficit=0.;var maximumComplementarity=0.;var maximumFriction=0.;var sweeps=0u;
 for(var sweep=0u;sweep<cfg.limits.x;sweep++){
  sweeps=sweep+1u;
  for(var i=0u;i<rowCount;i++){
   let r=membership[firstRow+i];let q=rows[r];let old=reaction[r];if(q.data.y==0.){if(q.data.x>0.){error(c,32u);return;}continue;}let lambda=max(0.,old.x+(q.data.x-effect(q))/q.data.y);let change=lambda-old.x;
   if(!finite1(lambda)){error(c,2u);return;}
   for(var k=0u;k<q.span.y;k++){let t=terms[q.span.x+k];if(parent[t.particle].w>0.){ideal[t.particle]=vec4f(ideal[t.particle].xyz+parent[t.particle].w*t.gradient*change,0.);}}
   var tangent=vec3f(0.);
   if(q.span.z==0u && lambda>0.){
    var point=vec3f(0.);var metric=0.;for(var k=0u;k<q.span.y;k++){let t=terms[q.span.x+k];point+=t.scalar.x*(parent[t.particle].xyz+ideal[t.particle].xyz);metric+=parent[t.particle].w*t.scalar.x*t.scalar.x;}
    if(metric<=0.){error(c,2u);return;}let n=normalize(q.normal.xyz);let relative=point-anchors[q.span.w].xyz;let slip=relative-n*dot(relative,n);let required=old.yzw-slip/metric;let size=length(required);
    if(size<=q.data.z*lambda*length(q.normal.xyz)){tangent=required;}else if(size>0.){tangent=required*(min(q.data.w*lambda*length(q.normal.xyz),size)/size);}
   }
   let changeT=tangent-old.yzw;
   for(var k=0u;k<q.span.y;k++){let t=terms[q.span.x+k];if(parent[t.particle].w>0.){ideal[t.particle]=vec4f(ideal[t.particle].xyz+parent[t.particle].w*t.scalar.x*changeT,0.);}}
   reaction[r]=vec4f(lambda,tangent);
  }
  maximumDeficit=0.;maximumComplementarity=0.;maximumFriction=0.;
  for(var i=0u;i<rowCount;i++){
   let r=membership[firstRow+i];let q=rows[r];let gap=effect(q)-q.data.x;maximumDeficit=max(maximumDeficit,-gap);if(reaction[r].x>0.){maximumComplementarity=max(maximumComplementarity,abs(gap));}
   if(q.span.z==0u && reaction[r].x>0.){
    var point=vec3f(0.);var metric=0.;for(var k=0u;k<q.span.y;k++){let t=terms[q.span.x+k];point+=t.scalar.x*(parent[t.particle].xyz+ideal[t.particle].xyz);metric+=parent[t.particle].w*t.scalar.x*t.scalar.x;}
    let n=normalize(q.normal.xyz);let relative=point-anchors[q.span.w].xyz;let slip=relative-n*dot(relative,n);let required=reaction[r].yzw-slip/metric;let size=length(required);var expected=required;
    if(size>q.data.z*reaction[r].x*length(q.normal.xyz) && size>0.){expected=required*(min(q.data.w*reaction[r].x*length(q.normal.xyz),size)/size);}
    maximumFriction=max(maximumFriction,metric*length(expected-reaction[r].yzw));
   }
  }
  if(!finite1(maximumDeficit)||!finite1(maximumComplementarity)||!finite1(maximumFriction)){error(c,2u);return;}
  if(max(maximumDeficit,max(maximumComplementarity,maximumFriction))<=cfg.policy.z){converged=true;break;}
 }
 if(!converged){error(c,64u);return;}
 var maximumNet=0.;
 for(var i=0u;i<nodeCount;i++){
  let p=membership[firstNode+i];let d=ideal[p].xyz;if(!finite3(d)){error(c,2u);return;}
  if(parent[p].w==0. && any(d!=vec3f(0.))){error(c,2u);return;}
  var stored=parent[p].xyz;for(var k=0u;k<3u;k++){if(d[k]!=0.){stored[k]+=d[k];}}
  if(!finite3(stored)){error(c,2u);return;}maximumNet=max(maximumNet,length(stored-parent[p].xyz));
 }
 if(maximumNet>cfg.policy.y){error(c,4u);return;}
 status[8u+c*8u]=0u;status[9u+c*8u]=bitcast<u32>(maximumNet);status[10u+c*8u]=sweeps;status[11u+c*8u]=cfg.limits.y;status[12u+c*8u]=bitcast<u32>(maximumDeficit);status[13u+c*8u]=bitcast<u32>(maximumComplementarity);status[14u+c*8u]=bitcast<u32>(maximumFriction);status[15u+c*8u]=bitcast<u32>(cfg.policy.z);
}
// Separate dispatch barrier. One bad component disables the ENTIRE correction;
// upstream rollback owns persistent history. No partial physical ledger commit.
@compute @workgroup_size(64)
fn validate_output(@builtin(global_invocation_id) gid:vec3u){
 let p=gid.x;if(p>=cfg.counts.x){return;}var valid=status[0]==0u;
 for(var c=0u;c<cfg.counts.w;c++){if(status[8u+c*8u]!=0u || status[11u+c*8u]!=cfg.limits.y){valid=false;}}
 if(!valid){ideal[p]=vec4f(0.);}
}
`;
