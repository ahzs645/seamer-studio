/** CPU request sealing only; never component, frame, registry or fit authority. */
import {copyData} from '../snapshots.mjs';
import {snapshotAppPreparedData,ownPreparationRecord} from '../appSIPreparation.ts';
import {physicalBytesSha256} from '../portablePhysicalHashes.mjs';
export function snapshotPreparationPacket(value){
 const record=ownPreparationRecord(value),prepared=record.prepared;const rest=Object.fromEntries(Object.entries(record).filter(([key])=>key!=='prepared'));return {...copyData(rest),prepared:snapshotAppPreparedData(prepared)};
}
export async function preparationPacketSha256(value){
 // Callers give privately copied data. Map entries are bound intrinsically;
 // unlike a generic own-key equality this cannot omit cuff/edge metadata.
 const jobs=[];
 function shape(v){
  if(v instanceof Map){if(Object.getPrototypeOf(v)!==Map.prototype||Reflect.ownKeys(v).length)throw Error('Plain CPU edge map required');return ['map',Array.from(Map.prototype.entries.call(v),([k,x])=>[shape(k),shape(x)])];}
  if(ArrayBuffer.isView(v)||v instanceof ArrayBuffer){const owned=copyData(v),n=jobs.length;const bytes=owned instanceof ArrayBuffer?new Uint8Array(owned):new Uint8Array(owned.buffer,owned.byteOffset,owned.byteLength);jobs.push(physicalBytesSha256(bytes));return ['bytes',owned instanceof ArrayBuffer?'ArrayBuffer':owned.constructor.name,bytes.length,n];}
  if(typeof v==='number'){const b=new ArrayBuffer(8);new DataView(b).setFloat64(0,v,false);return ['number',Array.from(new Uint8Array(b),x=>x.toString(16).padStart(2,'0')).join('')];}
  if(v===undefined)return ['undefined'];if(v===null||typeof v==='string'||typeof v==='boolean')return v;
  if(Array.isArray(v))return ['array',v.map(shape)];
  if(v&&typeof v==='object'){const d=Object.getOwnPropertyDescriptors(v);if(![Object.prototype,null].includes(Object.getPrototypeOf(v))||Reflect.ownKeys(d).some(k=>typeof k!=='string'||!d[k].enumerable||!Object.hasOwn(d[k],'value')))throw Error('Plain CPU request data required');return ['record',Object.entries(d).map(([k,x])=>[k,shape(x.value)])];}
  throw Error('CPU request contains an unsupported authority/value');
 }
 const tree=shape(value),hashes=await Promise.all(jobs);return physicalBytesSha256(new TextEncoder().encode(JSON.stringify([tree,hashes])));
}
export function equalPreparationPacket(a,b){
 if(a instanceof Map||b instanceof Map){if(!(a instanceof Map&&b instanceof Map)||Object.getPrototypeOf(a)!==Map.prototype||Object.getPrototypeOf(b)!==Map.prototype||Reflect.ownKeys(a).length||Reflect.ownKeys(b).length||a.size!==b.size)return false;const x=Array.from(Map.prototype.entries.call(a)),y=Array.from(Map.prototype.entries.call(b));return x.every(([k,v],i)=>equalPreparationPacket(k,y[i][0])&&equalPreparationPacket(v,y[i][1]));}
 if(ArrayBuffer.isView(a)||ArrayBuffer.isView(b)){if(!ArrayBuffer.isView(a)||!ArrayBuffer.isView(b)||a.constructor!==b.constructor||a.byteLength!==b.byteLength)return false;const x=new Uint8Array(a.buffer,a.byteOffset,a.byteLength),y=new Uint8Array(b.buffer,b.byteOffset,b.byteLength);return x.every((v,i)=>v===y[i]);}
 if(a instanceof ArrayBuffer||b instanceof ArrayBuffer)return a instanceof ArrayBuffer&&b instanceof ArrayBuffer&&equalPreparationPacket(new Uint8Array(a),new Uint8Array(b));
 if(Object.is(a,b))return true;if(!a||!b||typeof a!=='object'||typeof b!=='object')return false;
 const x=Object.getOwnPropertyDescriptors(a),y=Object.getOwnPropertyDescriptors(b),keys=Reflect.ownKeys(x),other=Reflect.ownKeys(y);return keys.length===other.length&&keys.every((k,i)=>k===other[i]&&Object.hasOwn(x[k],'value')&&Object.hasOwn(y[k],'value')&&equalPreparationPacket(x[k].value,y[k].value));
}
