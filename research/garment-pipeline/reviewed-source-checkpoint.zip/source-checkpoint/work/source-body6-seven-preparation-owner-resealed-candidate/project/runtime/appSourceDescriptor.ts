/** NEW genuine-app byte descriptor. This mints a new source domain, never borrows
 * a recorded seven-style descriptor SHA or grants finite/device/frame authority. */
import {hashSourceCalibrationValue,SOURCE_BODY_FIT_REVISION,SOURCE_BODY_CALIBRATION_POLICY} from '../packages/avatar/src/sourceCalibrationIdentity';
import {copyData,equalData} from './snapshots.mjs';
import {physicalBytesSha256} from './portablePhysicalHashes.mjs';
import {validateSourcePhysicalMembrane,type CandidateSim} from './source/sourcePhysicalMembrane.ts';
export interface ActualAppDescriptorInput {
 pattern:unknown;prepared:unknown;sourceToken:number;bodyGeneration:number;
 sourceBodyCalibration?:unknown;simulationConfig:unknown;isCurrent:()=>boolean;sourcePins?:unknown;
}
function validatePreparedMaterial(prepared:unknown){const p=prepared as {simData:CandidateSim&{edgeRuns?:unknown}};const sim={...p.simData};const edge=sim.edgeRuns as {encoding?:string;entries?:[string,unknown][]}|undefined;if(edge?.encoding==='literal-prepared-edge-map-entries-v1')sim.edgeRuns=new Map(edge.entries);const executed=validateSourcePhysicalMembrane(sim);if(!executed)throw Error('Actual validated SI material payload required');return executed;}
const u32=(v:number)=>Number.isSafeInteger(v)&&v>=0&&v<=0xffffffff;
const sha=(v:unknown):v is string=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
const exact=(v:ArrayBufferView)=>new Uint8Array(v.buffer,v.byteOffset,v.byteLength);
/** The production preparation has one genuine edgeRuns Map. Convert its intrinsic
 * entries to data before the plain descriptor copier; never call a user iterator. */
function preparedData(value:unknown){
 if(!value||typeof value!=='object'||![Object.prototype,null].includes(Object.getPrototypeOf(value))||Reflect.ownKeys(value).some(k=>typeof k!=='string'))throw Error('Actual plain app prepared data required');
 const p=Object.getOwnPropertyDescriptors(value),sim=p.simData;
 if(!sim||!('value' in sim)||!sim.value||typeof sim.value!=='object'||![Object.prototype,null].includes(Object.getPrototypeOf(sim.value))||Reflect.ownKeys(sim.value).some(k=>typeof k!=='string'))throw Error('Actual own plain prepared SimData required');
 const d=Object.getOwnPropertyDescriptors(sim.value),edge=d.edgeRuns;
 const plain=(descriptors:PropertyDescriptorMap,omit:string)=>Object.fromEntries(Object.entries(descriptors).filter(([key])=>key!==omit).map(([key,x])=>{if(!('value' in x)||!x.enumerable)throw Error('Actual plain prepared fields required');return[key,x.value];}));
 const data=plain(d,'edgeRuns');
 if(edge){if(!('value' in edge)||!edge.enumerable)throw Error('Actual own prepared edge map required');const map=edge.value;
  if(map instanceof Map){if(Object.getPrototypeOf(map)!==Map.prototype||Reflect.ownKeys(map).length)throw Error('Actual intrinsic prepared edge map required');data.edgeRuns={encoding:'literal-prepared-edge-map-entries-v1',entries:Array.from(Map.prototype.entries.call(map),([key,v]:[unknown,unknown])=>[copyData(key),copyData(v)])};}
  else data.edgeRuns=map;
 }
 return {...plain(p,'simData'),simData:data};
}

function base64(v:ArrayBufferView){const b=exact(v);let text='';for(let i=0;i<b.length;i+=8192)text+=String.fromCharCode(...b.subarray(i,i+8192));return btoa(text);}
/** Intrinsic copied plain metadata only. Explicit -0 token preserves JSON numeric
 * signed zero; typed fields carry exact represented bytes rather than number lists. */
function text(v:unknown):string {
 if(v===undefined)return '{"$sourceUndefined":true}';
 if(v===null)return 'null';if(typeof v==='string'||typeof v==='boolean')return JSON.stringify(v);
 if(typeof v==='number'){if(!Number.isFinite(v))throw Error('Nonfinite app source metadata');return Object.is(v,-0)?'-0':String(v);}
 if(ArrayBuffer.isView(v))return text({encoding:'exact-represented-typed-bytes-v1',type:Object.getPrototypeOf(v).constructor.name,byteLength:v.byteLength,base64:base64(v)});
 if(v instanceof ArrayBuffer)return text({encoding:'exact-arraybuffer-bytes-v1',base64:base64(new Uint8Array(v))});
 if(Array.isArray(v))return '['+v.map(text).join(',')+']';
 if(v&&typeof v==='object')return '{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+text((v as Record<string,unknown>)[k])).join(',')+'}';
 throw Error('Data-only app source metadata required');
}
export async function mintActualAppSourceDescriptor(input:ActualAppDescriptorInput,scope='fresh-source-physical-profile') {
 if(scope!=='fresh-source-physical-profile')return null;
 const callback=input.isCurrent;if(typeof callback!=='function'||callback()!==true)throw Error('Current genuine app descriptor owner required');
 const consume=()=>({pattern:input.pattern,prepared:preparedData(input.prepared),sourceToken:input.sourceToken,bodyGeneration:input.bodyGeneration,simulationConfig:input.simulationConfig,sourcePins:input.sourcePins,sourceBodyCalibration:input.sourceBodyCalibration});
 const captured=copyData(consume());validatePreparedMaterial(captured.prepared);
 const current=()=>{if(input.isCurrent!==callback||callback()!==true||!equalData(copyData(consume(),false),captured))throw Error('Actual app source/body/preparation changed across descriptor await');return true;};current();
 const p=captured.prepared as {simData:{particleCount:number;positions:Float32Array;triangles:Uint32Array;sourcePhysicalMembrane:{policySha256:string}};body:{positions:Float32Array;triangles:Uint32Array}},s=p?.simData,b=p?.body;
 if(!u32(captured.sourceToken)||!captured.sourceToken||!u32(captured.bodyGeneration)||!captured.bodyGeneration||!s||!u32(s.particleCount)||!s.particleCount||!(s.positions instanceof Float32Array)||s.positions.length!==s.particleCount*4||!(s.triangles instanceof Uint32Array)||s.triangles.length%4||!(b?.positions instanceof Float32Array)||b.positions.length%4||!(b.triangles instanceof Uint32Array)||b.triangles.length%4||!sha(s.sourcePhysicalMembrane?.policySha256))throw Error('Actual SI prepared body/topology/material descriptor required');
 if(![s.positions,b.positions].every(a=>a.every((v,i)=>Number.isFinite(v)&&(a===b.positions||i%4!==3||v>=0))))throw Error('Nonfinite actual SI/body source bytes');
 for(const [tri,n] of [[s.triangles,s.particleCount],[b.triangles,b.positions.length/4]] as const)for(let i=0;i<tri.length;i+=4)if(new Set(tri.subarray(i,i+3)).size!==3||tri.subarray(i,i+3).some(id=>id>=n))throw Error('Actual app finite triangle IDs invalid');
 const bodyPositions=Array.from(b.positions).filter((_,i)=>i%4!==3),bodyIndices=Array.from(b.triangles).filter((_,i)=>i%4!==3);
 if(Array.from(b.positions).some((v,i)=>i%4===3&&v!==0))throw Error('Actual source skin vec4 W must preserve rigid zero');
 const calibration=captured.sourceBodyCalibration as {revision:number;policy:string;posedSha256:string;fingerprint:string};if(calibration?.revision!==SOURCE_BODY_FIT_REVISION||calibration.policy!==SOURCE_BODY_CALIBRATION_POLICY||!sha(calibration.fingerprint)||!sha(calibration.posedSha256))throw Error('Actual captured body6 calibration provenance required');
 const packed=new Float32Array(bodyPositions);if(await hashSourceCalibrationValue(packed)!==calibration.posedSha256)throw Error('Body6 calibration provenance differs from actual posed body bytes');current();
 const descriptor={encoding:'genuine-app-si-source-execution-v1',origin:'actual-app-prepared-source-not-recorded-fixture',particleCount:s.particleCount,clothTriangles:Array.from(s.triangles),bodyPositions,bodyIndices,initialPhysicalPositionsFloat32LEBase64:base64(s.positions),pattern:captured.pattern,prepared:captured.prepared,simulationConfig:captured.simulationConfig,sourcePins:captured.sourcePins,sourceToken:captured.sourceToken,bodyGeneration:captured.bodyGeneration,sourceFitRevision:6,sourceAssemblyRevision:5,sourceBodyCalibration:captured.sourceBodyCalibration,sourceInitialArrangementPolicySha256:(s as unknown as {sourceInitialArrangementPolicySha256?:string}).sourceInitialArrangementPolicySha256??null,sourceAssemblySchedulePolicySha256:(s as unknown as {sourceStaging?:{attachedOpenSchedule?:{policySha256:string}}}).sourceStaging?.attachedOpenSchedule?.policySha256??null,physicalMassPolicySha256:s.sourcePhysicalMembrane.policySha256,sourcePhysicalMaterialPolicy:validatePreparedMaterial(captured.prepared),sourcePhysicalMaterialPreparationPolicy:(s.sourcePhysicalMembrane as unknown as {policy:unknown}).policy,sourcePhysicalMaterialPolicySha256:s.sourcePhysicalMembrane.policySha256,usedActivationMeaning:'execution-controller-owned-used-gate-not-accepted',accepted:false,fullFitAccepted:false};
 const raw=new TextEncoder().encode(text(descriptor));
 const sourceSha256=await physicalBytesSha256(raw);current();const bodySha256=await physicalBytesSha256(b.positions);current();const topologySha256=await physicalBytesSha256(s.triangles);current();const bodyTopologySha256=await physicalBytesSha256(b.triangles);current();const physicalPositionsSha256=await physicalBytesSha256(s.positions);current();
 const binding=Object.freeze({sourceSha256,bodySha256,topologySha256,sourceToken:captured.sourceToken,bodyGeneration:captured.bodyGeneration});
 const context=Object.freeze({...binding,bodyTopologySha256,bodyFaceCount:b.triangles.length/4,particleCount:s.particleCount,physicalMassPolicySha256:s.sourcePhysicalMembrane.policySha256,initialPhysicalPositionsSha256:physicalPositionsSha256,executionEncoding:'raw-utf8-frozen-source-execution-descriptor-v1',recordedFiniteContextMatched:false,wholeFrameAccepted:false,fitAccepted:false});
 return Object.freeze({sourceExecutionBytes:raw.slice(),sourceExecutionEncoding:'raw-utf8-frozen-source-execution-descriptor-v1',sourceBinding:binding,context,assertCurrent:current,capture(){current();return {sourceExecutionBytes:raw.slice(),sourceExecutionEncoding:'raw-utf8-frozen-source-execution-descriptor-v1',sourceBinding:{...binding},context:{...context}};}});
}

export interface CapturedAppDescriptorInput extends ActualAppDescriptorInput {
 sourceExecutionBytes:Uint8Array;sourceExecutionEncoding:string;expectedSourceSha256:string;
}
const numberData=(v:unknown):unknown=>ArrayBuffer.isView(v)?Array.from(v as unknown as ArrayLike<number>):Array.isArray(v)?v.map(numberData):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).map(([k,x])=>[k,numberData(x)])):v;
function fromBase64(value:string){if(typeof value!=='string'||!value)throw Error('Authentic represented source positions required');const raw=atob(value),out=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)out[i]=raw.charCodeAt(i);return out;}
/** Existing bytes are retained literally only when their full source/SI/support
 * context matches the actual app preparation. This grants no kernel approval. */
export async function captureActualAppSourceDescriptor(input:CapturedAppDescriptorInput,scope='fresh-source-physical-profile') {
 if(scope!=='fresh-source-physical-profile')return null;
 const callback=input.isCurrent;if(typeof callback!=='function'||callback()!==true)throw Error('Current genuine app descriptor owner required');
 const consume=()=>({pattern:input.pattern,prepared:preparedData(input.prepared),sourceToken:input.sourceToken,bodyGeneration:input.bodyGeneration,simulationConfig:input.simulationConfig,sourcePins:input.sourcePins,sourceExecutionBytes:input.sourceExecutionBytes,sourceExecutionEncoding:input.sourceExecutionEncoding,expectedSourceSha256:input.expectedSourceSha256});
 const captured=copyData(consume());validatePreparedMaterial(captured.prepared);const current=()=>{if(input.isCurrent!==callback||callback()!==true||!equalData(copyData(consume(),false),captured))throw Error('Captured authentic app source/preparation changed');return true;};current();
 if(!(captured.sourceExecutionBytes instanceof Uint8Array)||!captured.sourceExecutionBytes.length||captured.sourceExecutionEncoding!=='raw-utf8-authentic-si-initial-descriptor-v1'||!sha(captured.expectedSourceSha256)||!u32(captured.sourceToken)||!captured.sourceToken||!u32(captured.bodyGeneration)||!captured.bodyGeneration)throw Error('Exact authentic SI source byte domain required');
 const raw=captured.sourceExecutionBytes.slice(),sourceSha256=await physicalBytesSha256(raw);current();if(sourceSha256!==captured.expectedSourceSha256)throw Error('Authentic source descriptor SHA differs');
 let d;try{d=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(raw));}catch{throw Error('Authentic UTF8 source descriptor JSON required');}
 const p=captured.prepared,s=p?.simData,b=p?.body;
 const requireEqual=(actual:unknown,expected:unknown,label:string)=>{if(!equalData(numberData(actual),expected))throw Error('Authentic descriptor differs from actual app '+label);};
 requireEqual(captured.pattern,d.pattern,'original pattern/cuts/source document');requireEqual(captured.simulationConfig,d.simulationConfig,'simulation policy');
 if(!s||!b||s.particleCount!==d.particleCount||!(s.positions instanceof Float32Array)||s.positions.length!==d.particleCount*4||!(s.triangles instanceof Uint32Array)||!(b.positions instanceof Float32Array)||!(b.triangles instanceof Uint32Array))throw Error('Authentic actual SI/body typed geometry required');
 requireEqual(s.triangles,d.clothTriangles,'cloth topology');requireEqual(Array.from(b.positions).filter((_,i)=>i%4!==3),d.bodyPositions,'full body positions');requireEqual(Array.from(b.triangles).filter((_,i)=>i%4!==3),d.bodyIndices,'full body topology');
 const initial=fromBase64(d.initialPhysicalPositionsFloat32LEBase64),rest=fromBase64(d.sourceRestMaterialCoordinatesFloat32LEBase64);if(!equalData(exact(s.positions),initial)||!equalData(exact(s.positions2d),rest))throw Error('Authentic SI XYZ/W/rest material bits differ');
 if(s.sourcePhysicalMembrane?.policySha256!==d.sourcePhysicalMaterialPolicySha256)throw Error('Actual SI material policy differs from literal source descriptor');requireEqual(s.sourcePhysicalMembrane.policy,d.sourcePhysicalMaterialPreparationPolicy,'full material preparation policy');
 for(const field of ['seams','seamOrder','sourceStaging','sourceStretchPolicy','sourceGatherRefinement','sourceGatherCollisionGeometry'])if(Object.hasOwn(d,field)||s[field]!==undefined)requireEqual(s[field],d[field],field);
 // Recorded corpus names its literal constructor seed in addition to targets.
 // Both vectors must equal the actual preparation; the two provenance labels
 // are not additional runtime support or a permission to substitute a vector.
 const recordedSupport=copyData(d.assemblySupport);
 if(recordedSupport&&Object.hasOwn(recordedSupport,'initialTargets')){requireEqual(s.assemblySupport?.targets,recordedSupport.initialTargets,'initial support target seed');if(recordedSupport.targetsAreInitialSeed!==true)throw Error('Authentic support seed semantics differ');delete recordedSupport.initialTargets;delete recordedSupport.targetsAreInitialSeed;}
 requireEqual(s.assemblySupport,recordedSupport,'assemblySupport');
 if(d.initialAnchorsFloat32LEBase64!==undefined&&!equalData(exact(s.anchors),fromBase64(d.initialAnchorsFloat32LEBase64)))throw Error('Authentic anchor/hold bits differ');
 if(captured.sourcePins!==undefined)requireEqual(captured.sourcePins,d.sourceFingerprints,'literal source program pins');
 const bodySha256=await physicalBytesSha256(b.positions);current();const topologySha256=await physicalBytesSha256(s.triangles);current();const bodyTopologySha256=await physicalBytesSha256(b.triangles);current();
 const binding=Object.freeze({sourceSha256,bodySha256,topologySha256,sourceToken:captured.sourceToken,bodyGeneration:captured.bodyGeneration}),context=Object.freeze({...binding,particleCount:s.particleCount,bodyFaceCount:b.triangles.length/4,bodyTopologySha256,physicalMassPolicySha256:s.sourcePhysicalMembrane.policySha256,executionEncoding:captured.sourceExecutionEncoding,sourceBytesPreservedLiterally:true,actualFullSourceAndSIPreparationMatched:true,wholeFrameAccepted:false,fitAccepted:false});
 return Object.freeze({sourceExecutionBytes:raw.slice(),sourceExecutionEncoding:captured.sourceExecutionEncoding,sourceBinding:binding,context,assertCurrent:current,capture(){current();return {sourceExecutionBytes:raw.slice(),sourceExecutionEncoding:captured.sourceExecutionEncoding,sourceBinding:{...binding},context:{...context}};}});
}
