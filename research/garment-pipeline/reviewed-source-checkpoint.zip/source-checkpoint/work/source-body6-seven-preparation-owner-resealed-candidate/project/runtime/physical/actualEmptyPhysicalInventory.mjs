import{physicalBytesSha256,canonicalPhysicalCertificateText}from'./portablePhysicalHashes.mjs';
import{copyData,equalData}from'./snapshots.mjs';
import{requirePhysicalIncomingRawProof}from'./wholePhysicalAliasWGSL.mjs';

const sha=/^[a-f0-9]{64}$/;
/** Zero force/no anchor allocation is permitted ONLY for a complete actual
 * original-parent inventory. A different corrected geometry cannot prove that
 * the physical parent had no contacts. Infinity is an authentic empty bound,
 * never converted to null or a fabricated finite clearance. */
async function verifyEmpty(certificate,actualRawProof,binding){
 requirePhysicalIncomingRawProof(actualRawProof,0);
 if(!certificate||certificate.rawOccurrences!==0||certificate.allRawOccurrences!==0||certificate.validatedOccurrences!==0||certificate.complete!==true||
  certificate.actualGpuFiniteProducer!==true||certificate.unsupported!==0||certificate.unsupportedFlags!==0||certificate.clearanceDeficits!==0||certificate.strictClearanceDeficits!==0||
  certificate.allCurrentRawOccurrencesChecked!==true||certificate.minimumLowerBoundM!==Infinity||certificate.minimumClearanceLowerBoundM!==Infinity||
  !binding||!['originalParentSha256','currentSha256','historySha256','sourceSha256','bodySha256','usedGateSha256','emptyInventoryCertificateSha256'].every(k=>sha.test(binding[k]))||
  binding.currentSha256!==binding.originalParentSha256||certificate.candidateSha256!==binding.originalParentSha256||certificate.historySha256!==binding.historySha256||
  certificate.sourceSha256!==binding.sourceSha256||certificate.bodySha256!==binding.bodySha256||certificate.usedGateSha256!==binding.usedGateSha256)
  throw Error('Actual empty physical proof must bind the original parent and source/body/gate');
 const text=canonicalPhysicalCertificateText(certificate),digest=await physicalBytesSha256(new TextEncoder().encode(text));
 if(digest!==binding.emptyInventoryCertificateSha256)throw Error('Empty physical certificate digest mismatch');
 return{actualEmptyProducerReceiptSha256:digest,physicalNormalLambdaKgM:0,minimumClearanceLowerBoundM:Infinity,
  emptyBoundsEncoding:'canonical-sorted-json-v2-empty-contact-bounds',normalReactionAuthoritative:false,
  retainDormantMaterialHistory:true,newHistorySlotsAllocated:0};
}

export async function requireActualEmptyPhysicalInventory(certificate,actualRawProof,binding,{isCurrent}={}){if(typeof isCurrent!=="function"||isCurrent()!==true)throw Error("Actual current empty inventory owner required");const original={certificate,actualRawProof,binding},snapshot=copyData(original);const result=await verifyEmpty(snapshot.certificate,snapshot.actualRawProof,snapshot.binding);if(isCurrent()!==true||!equalData(original,snapshot))throw Error("Empty inventory owner/input changed across hash");return result;}
