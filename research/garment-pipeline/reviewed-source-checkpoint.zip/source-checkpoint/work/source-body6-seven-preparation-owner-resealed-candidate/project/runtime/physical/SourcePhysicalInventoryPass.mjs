import{physicalInventoryReceiptSha256}from'./physicalInventoryHash.mjs';
export{physicalInventoryReceiptSha256}from'./physicalInventoryHash.mjs';
import{wholePhysicalSelectionWGSL,decodeWholePhysicalSelection}from'./wholePhysicalSelectionWGSL.mjs';
import{wholePhysicalFixedCertificateWGSL,decodePhysicalFixedCertificate}from'./wholePhysicalFixedCertificateWGSL.mjs';
const u32=n=>Number.isSafeInteger(n)&&n>=0&&n<=0xffffffff,SHA=/^[a-f0-9]{64}$/;

export function createSourcePhysicalInventoryPass(device,scope,options){return scope==='fresh-source-physical-profile'?new SourcePhysicalInventoryPass(device,options):null;}
/** NEW actual GPU selection and ALL-fixed certification lifecycle. Geometry,
 * RHS, gradients and lambda are always borrowed genuine GPU resources. Only
 * bound policy/count words are uploaded. No CPU evaluated row can enter here. */
export class SourcePhysicalInventoryPass{
 #device;#o;#owned=[];#mask;#state;#proof;#params;#readback;#layouts;#pipes;
 #busy=false;#closing=false;#generation=0;#pending=null;#closePromise=null;
 constructor(device,options,assertCurrent=()=>true){assertCurrent();
  this.#device=device;this.#o=Object.freeze(structuredClone(options));
  if(!u32(options.particles)||!u32(options.rowCapacity)||options.particles<1||options.rowCapacity<1||device.limits.maxStorageBuffersPerShaderStage<8)throw Error('Invalid physical inventory capacity');
  const make=(label,size,usage)=>{if(!Number.isSafeInteger(size)||size<4||size>device.limits.maxStorageBufferBindingSize)throw Error('Physical inventory buffer bound');const b=device.createBuffer({label,size,usage});this.#owned.push(b);return b;};
  try{
   const writable=GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST;
   this.#mask=make('physical selected/all-fixed additions',options.rowCapacity*4,writable);this.#state=make('physical complete inventory proof',64,writable);
   this.#proof=make('copied actual physical pack proof',32,writable);this.#params=make('physical inventory private policy',64,GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST);
   this.#readback=make('actual inventory receipt readback',64+options.rowCapacity*4,GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ);
   this.#layouts={};this.#pipes={};
   this.ready=(async()=>{
    for(const[kind,code,n]of[['selection',wholePhysicalSelectionWGSL,6],['fixed',wholePhysicalFixedCertificateWGSL,8]]){
     const layout=device.createBindGroupLayout({entries:Array.from({length:n+1},(_,binding)=>({binding,visibility:GPUShaderStage.COMPUTE,
      buffer:{type:binding===n?'uniform':binding<n-2?'read-only-storage':'storage'}}))});
     const pipelineLayout=device.createPipelineLayout({bindGroupLayouts:[layout]}),module=device.createShaderModule({code});
     const errors=(await module.getCompilationInfo()).messages.filter(m=>m.type==='error');assertCurrent();if(errors.length)throw Error(errors.map(m=>`${m.lineNum}:${m.linePos} ${m.message}`).join('\n'));
     if(this.#closing)throw Error('Physical inventory closed during compile');
     this.#layouts[kind]=layout;const entrypoints=kind==='selection'?['selection_reset','selection_rows','selection_complete']:['fixed_reset','fixed_particles','fixed_rows','fixed_complete'];
     this.#pipes[kind]=Object.fromEntries(entrypoints.map(entryPoint=>[entryPoint,device.createComputePipeline({layout:pipelineLayout,compute:{module,entryPoint}})]));
    }
   })();this.ready.catch(()=>{});
  }catch(e){this.#owned.forEach(b=>b.destroy());this.#owned=[];throw e;}
 }
 selectActualRows(input){return this.#inspect('selection',input);}
 certifyAllFixedRows(input){return this.#inspect('fixed',input);}
 #inspect(kind,input){
  if(this.#busy||this.#closing)return Promise.reject(Error('Physical inventory busy/closed'));
  const expected=structuredClone(input.expected),binding=structuredClone(input.binding),packProof=input.observedPackProof?.slice();
  const handles={rows:input.rows,terms:input.terms,ideal:input.ideal,packedProof:input.packProof,parent:input.originalParent,reaction:input.reaction};
  const offset=input.packProofOffset??0,generation=this.#generation,isCurrent=input.isCurrent;this.#busy=true;
  const current=()=>!this.#closing&&generation===this.#generation&&isCurrent?.()===true;
  const work=(async()=>{let mapped=false;try{
   await this.ready;if(!current())throw Error('Physical inventory lease changed');
   if(!expected||!['rows','rawOccurrences','parentToken','sourceToken','bodyGeneration','physicalSubstep','gateRevision'].every(k=>u32(expected[k]))||
    expected.rows<1||expected.rows>this.#o.rowCapacity||expected.parentToken<1||expected.sourceToken<1||expected.bodyGeneration<1||expected.physicalSubstep<1||expected.physicalSubstep>40||
    !u32(offset)||offset%4||!(packProof instanceof Uint32Array)||packProof.length!==8||
    !binding||binding.authenticAllRawReadLease!==true||binding.actualGpuPhysicalPackProducer!==true||
    !['originalParentSha256','packedPhysicalRowsSha256','packedPhysicalTermsSha256','currentIdealSha256','fullRawRow128Sha256','usedGateSha256','bodySha256','sourceSha256'].every(k=>SHA.test(binding[k])))throw Error('Unbound physical inventory');
   const wanted=[0,expected.rows,expected.rawOccurrences,expected.rows*6,expected.parentToken,expected.sourceToken,expected.bodyGeneration,expected.gateRevision];
   if(packProof.some((v,i)=>v!==wanted[i]))throw Error('Invalid physical packing proof');
   const selectedHandles=[handles.rows,handles.terms,handles.ideal,handles.packedProof,...(kind==='fixed'?[handles.parent,handles.reaction]:[])];
   if(new Set(selectedHandles).size!==selectedHandles.length||selectedHandles.some(h=>!h||this.#owned.includes(h)))throw Error('Aliased physical inventory resources');
   const P=this.#o.particles,R=expected.rows;
   if(handles.rows.size<R*48||handles.terms.size<R*192||handles.ideal.size!==P*16||handles.packedProof.size<offset+32||
    (kind==='fixed'&&(handles.parent.size!==P*16||handles.reaction.size<R*16||binding.actualGpuPhysicalReactionReadback!==true||
     !SHA.test(binding.actualReactionReceiptSha256)||!SHA.test(binding.executedTolerancePolicySha256)||
     !['algebraicNormalDeficitM','algebraicComplementarityResidualM'].every(k=>Number.isFinite(expected[k])&&expected[k]>0&&expected[k]<=2e-8))))throw Error('Incomplete physical inventory range/policy');
   const cfg=new Uint32Array(16);cfg.set([P,R,R*6,expected.parentToken,expected.sourceToken,expected.bodyGeneration,expected.physicalSubstep,expected.gateRevision]);
   if(kind==='fixed'){new Float32Array(cfg.buffer).set([expected.algebraicNormalDeficitM,expected.algebraicComplementarityResidualM,.005,.001],8);cfg.set([0,expected.rawOccurrences,0,0],12);}
   this.#device.queue.writeBuffer(this.#params,0,cfg);
   const e=this.#device.createCommandEncoder();e.copyBufferToBuffer(handles.packedProof,offset,this.#proof,0,32);
   const resources=kind==='selection'?[{buffer:handles.rows,size:R*48},{buffer:handles.terms,size:R*192},{buffer:handles.ideal},{buffer:this.#proof},{buffer:this.#mask,size:R*4},{buffer:this.#state,size:32},{buffer:this.#params,size:32}]:
    [{buffer:handles.parent},{buffer:handles.rows,size:R*48},{buffer:handles.terms,size:R*192},{buffer:handles.ideal},{buffer:handles.reaction,size:R*16},{buffer:this.#proof},{buffer:this.#mask,size:R*4},{buffer:this.#state},{buffer:this.#params}];
   const group=this.#device.createBindGroup({layout:this.#layouts[kind],entries:resources.map((resource,binding)=>({binding,resource}))});
   const stages=kind==='selection'?[['selection_reset',1],['selection_rows',Math.ceil(R/64)],['selection_complete',1]]:
    [['fixed_reset',1],['fixed_particles',Math.ceil(P/64)],['fixed_rows',Math.ceil(R/64)],['fixed_complete',1]];
   for(const[name,count]of stages){const p=e.beginComputePass();p.setPipeline(this.#pipes[kind][name]);p.setBindGroup(0,group);p.dispatchWorkgroups(count);p.end();}
   e.copyBufferToBuffer(this.#state,0,this.#readback,0,kind==='selection'?32:64);e.copyBufferToBuffer(this.#mask,0,this.#readback,64,R*4);
   this.#device.queue.submit([e.finish()]);await this.#readback.mapAsync(GPUMapMode.READ);mapped=true;const bytes=this.#readback.getMappedRange().slice(0);
   if(!current())throw Error('Physical inventory changed during mapping');
   const proof=new Uint32Array(bytes,0,kind==='selection'?8:16).slice(),mask=new Uint32Array(bytes,64,R).slice();
   const result=kind==='selection'?decodeWholePhysicalSelection(mask,proof,expected):decodePhysicalFixedCertificate(mask,proof,expected);
   const digest=(await physicalInventoryReceiptSha256(proof,mask,binding));
   if(!current())throw Error("Physical inventory owner changed during hash");
   return{...result,proof,mask,binding,expected,actualGpuSelectionReadback:kind==='selection',actualGpuFixedCertificateReadback:kind==='fixed',actualInventoryReceiptSha256:digest};
  }finally{if(mapped)this.#readback.unmap();this.#busy=false;}})();
  this.#pending=work;work.then(()=>{if(this.#pending===work)this.#pending=null;},()=>{if(this.#pending===work)this.#pending=null;});return work;
 }
 invalidate(){this.#generation++;}
 destroy(){if(this.#closePromise)return this.#closePromise;this.#closing=true;this.invalidate();this.#closePromise=(async()=>{const errors=[];
  await this.ready.catch(e=>errors.push(e));if(this.#pending)await this.#pending.catch(e=>errors.push(e));
  try{await this.#device.queue.onSubmittedWorkDone();}catch(e){errors.push(e);}finally{for(const b of this.#owned)try{b.destroy();}catch(e){errors.push(e);}this.#owned=[];}
  if(errors.length)throw new AggregateError(errors,'Physical inventory cleanup failed');})();return this.#closePromise;}
}
