/** NEW work-only browser boundary. Original authored graph algorithms are
 * preserved. This prepares a fresh private seed, never an accepted frame/cache.
 * The app supplies its current finalized geometry and actual sourceFit6 model. */
import {assert} from './assertions.mjs';
import {copyData,equalData} from './snapshots.mjs';
import {buildCapBeforeTubeProposal} from './capBeforeTube.mjs';
import {proposeInitialArmPlacement} from './initialArmPlacement.mjs';
import {physicalSeamStitchIndices} from './shared/seamGate.ts';
import {SourceStagingController} from './shared/sourceStaging.ts';
import {validateSourcePhysicalMembrane,prepareSourcePhysicalMembrane} from './material/sourcePhysicalMembrane.ts';
const preparedSeeds=new WeakMap();
export const SOURCE_FIT6_MODEL_SHA256='e59f6970198ec907fb536f7bff94858e14dc91e1119324130f04b487f20f166a';
export const canonical=value=>Array.isArray(value)?value.map(canonical):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().map(k=>[k,canonical(value[k])])):value;
const sha=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
export const policySha=policy=>sha(new TextEncoder().encode(JSON.stringify(canonical(policy))));
export const numericSha=view=>sha(new Uint8Array(view.buffer,view.byteOffset,view.byteLength));
const packedBodyEquals=(f,prepared)=>{
 const b=prepared.body;
 assert(b.positions.length===f.bodyPositions.length/3*4&&b.triangles.length===f.bodyIndices.length/3*4,'Actual body shape differs');
 for(let n=0;n<f.bodyPositions.length/3;n++){for(let k=0;k<3;k++)assert(Object.is(b.positions[n*4+k],f.bodyPositions[n*3+k]),'Actual posed body differs');assert(Object.is(b.positions[n*4+3],0),'Body padding differs');}
 for(let n=0;n<f.bodyIndices.length/3;n++){for(let k=0;k<3;k++)assert(b.triangles[n*4+k]===f.bodyIndices[n*3+k],'Actual body topology differs');assert(b.triangles[n*4+3]===0,'Body triangle padding differs');}
};
function snapshotPrepared(prepared){const {edgeRuns,...data}=prepared.simData,result=copyData({...prepared,simData:data});
 if(edgeRuns instanceof Map){assert(Object.getPrototypeOf(edgeRuns)===Map.prototype&&Reflect.ownKeys(edgeRuns).length===0,'Actual plain edge map required');result.simData.edgeRuns=new Map(Array.from(Map.prototype.entries.call(edgeRuns),([k,v])=>[k,copyData(v)]));}else result.simData.edgeRuns=copyData(edgeRuns);return result;}
function samePrepared(a,b){const {edgeRuns:x,...ad}=a.simData,{edgeRuns:y,...bd}=b.simData;return equalData({...a,simData:ad},{...b,simData:bd})&&equalData(x instanceof Map?Array.from(x):x,y instanceof Map?Array.from(y):y);}
function bindSource(f,d){
 for(const [field,key,C] of [['positions','clothPositions',Float32Array],['sourceArrangedPositions','sourceArrangedPositions',Float32Array],['triangles','clothTriangles',Uint32Array]])assert(equalData(d[field],C.from(f[key])),'Source descriptor geometry differs: '+field);
 assert(d.particleCount===f.particleCount&&d.stitchCount===f.stitchCount,'Source particle/stitch count differs');
 assert(equalData(d.sourceStaging,f.sourceStaging),'Source staged topology differs');
 assert(equalData(actualDictionary(d),f.collisionSeamDictionary),'Actual source dictionary differs');
}
function actualDictionary(d){const indices=physicalSeamStitchIndices(d.seams,d.seamOrder,d.seamPairsBySeam,d.seamStitchRanges);
 return {stitchCount:d.stitchCount,seamPairsBySeam:d.seamPairsBySeam.map((group,index)=>({seamId:group.seamId,index,pairs:Array.from(group.pairs),stitchIndices:Array.from(indices[index]),stitchIndexKinds:Array.from(indices[index],(_,pair)=>group.pairs[pair*2]===group.pairs[pair*2+1]?'identity-logical':'reciprocal-first-stamp')}))};}
/** Build the input from actual app preparation. This is explicitly an initial
 * CPU-requested gate, never the Worker-used or accepted activation. */
export function captureActualAppInitialPreparation({pattern,prepared,avatarVertices,avatarIndices,sourceFitRevision,sourceAssemblyRevision}){
 const d=prepared.simData;assert(prepared.collisionSafety===true&&sourceFitRevision===6&&sourceAssemblyRevision===5,'Actual body6/source assembly5 required');
 const controller=d.sourceStaging?new SourceStagingController(d.sourceStaging):null;
 const source={pattern:copyData(pattern),sourceFitRevision,sourceAssemblyRevision,particleCount:d.particleCount,stitchCount:d.stitchCount,
  clothPositions:Array.from(d.positions),clothTriangles:Array.from(d.triangles),sourceArrangedPositions:Array.from(d.sourceArrangedPositions),sourceStaging:copyData(d.sourceStaging),
  bodyPositions:Array.from(avatarVertices),bodyIndices:Array.from(avatarIndices),collisionSeamDictionary:actualDictionary(d),
  collisionSeamActivation:{revision:controller?.maskRevision??0,activeSeams:Array.from(controller?controller.nextActiveSeamMask:new Uint32Array(d.seamPairsBySeam.length).fill(1)),sewnUpTo:d.stitchCount}};
 packedBodyEquals(source,prepared);bindSource(source,d);
 return {source,anatomy:{pieces:d.pieces.map(({pieceId,start,count})=>({pieceId,start,count}))},activationOrigin:'actual-current-app-CPU-requested-initial-mask',deviceUsed:false};
}
/** readCurrentOwner returns {prepared,source,anatomy,stillCurrent,moveOpenArms,
 * modelBytes,expectedModelSha256}. source is an owned actual app descriptor,
 * not frozen q used as a substitute seed; exact equality above is mandatory.
 * moveOpenArms is explicit preparation intent, not body/device approval. */
export function prepareAttachedOpenAppSeed(readCurrentOwner,scope){
 if(scope!=='fresh-source-physical-profile')return null;
 const first=readCurrentOwner(),prepared=first.prepared,source=first.source,anatomy=first.anatomy,callback=first.stillCurrent,move=first.moveOpenArms===true;
 assert(prepared.collisionSafety===true&&!prepared.simData.sourcePhysicalMembrane,'Fresh finalized source must be prepared BEFORE SI');
 assert(!source.pattern.assembly&&!source.pattern.settings3d.fixTop&&!source.pattern.pieces.some(p=>p.settings3d.frozen||p.settings3d.savedPositions.length||p.settings3d.savedDrapeState==='held'),'Fresh free source required');
 const p=snapshotPrepared(prepared),f=copyData(source),a=copyData(anatomy),modelBytes=move?copyData(first.modelBytes):null,modelSha=first.expectedModelSha256;
 const assertCurrent=()=>{const before=readCurrentOwner();assert(before.stillCurrent===callback&&callback()===true,'Source generation changed');const now=readCurrentOwner();
  assert(now.prepared===prepared&&now.source===source&&now.anatomy===anatomy&&now.stillCurrent===callback&&(now.moveOpenArms===true)===move&&samePrepared(snapshotPrepared(prepared),p)&&equalData(copyData(source),f)&&equalData(copyData(anatomy),a),'Source preparation inputs changed');
  if(move)assert(now.modelBytes===first.modelBytes&&now.expectedModelSha256===modelSha&&equalData(copyData(now.modelBytes),modelBytes),'Source model identity changed');return true;};
 assertCurrent();bindSource(f,p.simData);packedBodyEquals(f,p);
 return(async()=>{
  let landmarks=null;
  if(move){assert(modelBytes instanceof Uint8Array&&modelSha===SOURCE_FIT6_MODEL_SHA256,'Actual sourceFit6 model bytes required');assert(await sha(modelBytes)===modelSha,'Actual source model digest differs');assertCurrent();
   const model=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(modelBytes)),anchor=model.measurements.find(m=>m.name==='neckSideToShoulder')?.coordinates?.[1];
   assert(anchor&&[anchor.u,anchor.v,anchor.w].filter(v=>v===1).length===1&&[anchor.u,anchor.v,anchor.w].every(v=>v===0||v===1),'Exact native skin shoulder vertex required');
   const right=f.bodyIndices[anchor.faceIndex*3+(anchor.u===1?0:anchor.v===1?1:2)],pair=model.symmetry.pairs.find(ids=>ids.includes(right));assert(Number.isSafeInteger(right)&&pair?.length===2,'Actual model shoulder symmetry missing');
   landmarks={Right:right,Left:pair[0]===right?pair[1]:pair[0]};
  }
  const proposal=buildCapBeforeTubeProposal(f),placement=move?proposeInitialArmPlacement(f,a,{verifiedBodyLandmarks:landmarks}):null;
  let plan=copyData(f.sourceStaging);
  if(proposal){const transitions=[...proposal.units,...proposal.hoods].flatMap(u=>u.transitions).map(t=>copyData(t)),owned=new Set(transitions.flatMap(t=>t.enable)),remaining=proposal.initialActiveSeams.map((v,i)=>!v&&!owned.has(i)?i:null).filter(i=>i!==null);
   if(remaining.length)transitions.push({requireClosed:proposal.initialActiveSeams.map((_,i)=>i).filter(i=>!remaining.includes(i)),enable:remaining});
   const content={policy:proposal.policy,initialActiveSeams:proposal.initialActiveSeams,transitions},attachedOpenSchedule={...content,policySha256:await policySha(content)};assertCurrent();
   plan={...plan,attachedOpenSchedule};plan.topology=JSON.stringify(canonical({originalTopology:f.sourceStaging.topology,attachedOpenSchedule}));
  }
  const d=p.simData,q=placement?.changed?placement.positions:d.positions.slice(),arranged=d.arrangedPositions.slice(),anchors=d.anchors.slice();
  if(placement?.changed)for(const m of placement.moves)for(let n=m.start;n<m.start+m.count;n++)for(let k=0;k<3;k++){arranged[n*4+k]=q[n*4+k];anchors[n*4+k]=q[n*4+k];}
  for(let n=3;n<q.length;n+=4)assert(Object.is(q[n],d.positions[n]),'Initial placement changed signed W');
  const result={...p,simData:{...d,positions:q,arrangedPositions:arranged,anchors,...(proposal?{sourceStaging:plan,arrangementSourceStaging:copyData(plan)}:{})}};
  assertCurrent();const initialSnapshot=snapshotPrepared(result),ownedPlacement=copyData(placement),checkSeed=()=>{assertCurrent();assert(samePrepared(snapshotPrepared(result),initialSnapshot)&&equalData(copyData(placement),ownedPlacement),'Returned preparation seed changed');return true;};
  const seed=Object.freeze({prepared:result,placement,schedulePolicySha256:plan?.attachedOpenSchedule?.policySha256??null,actualModelLandmarks:landmarks?Object.freeze({...landmarks}):null,assertCurrent:checkSeed,preparationOnly:true,fullPreflightRequired:true,sourceAssemblyComplete:false,all40Executed:false,fitAccepted:false});
  preparedSeeds.set(seed,{initial:initialSnapshot,source:copyData(f),placement:ownedPlacement,assertCurrent:checkSeed,modelSha:move?modelSha:null});return seed;
 })();
}
/** Seal ONLY the genuine material routine's privately produced SI data. This
 * NEW app identity deliberately does not borrow a historical descriptor SHA.
 * No warm cache, device-origin, guard-positive or completion marker is minted. */
export async function sealAttachedOpenAppMaterial(seed,prepared){
 const owned=preparedSeeds.get(seed);assert(owned,'Actual app preparation token required');owned.assertCurrent();
 assert(samePrepared(snapshotPrepared(seed.prepared),owned.initial),'Returned initial seed changed');
 const materialSnapshot=snapshotPrepared(prepared),input=snapshotPrepared(prepared),d=input.simData,initial=owned.initial.simData;validateSourcePhysicalMembrane(d);
 for(const k of ['body','collisionSafety'])assert(equalData(input[k],owned.initial[k]),'Material body/source scope changed');
 for(const k of ['positions2d','triangles','seams','seamOrder','anchors','assemblySupport','sourceStaging','arrangementSourceStaging','sourceGatherRefinement','sourceGatherCollisionGeometry'])assert(equalData(d[k],initial[k]),'Material changed actual source placement: '+k);
 for(const key of ['positions','arrangedPositions','sourceArrangedPositions']){assert(d[key]?.length===initial[key]?.length,'Actual seed size differs');for(let i=0;i<d[key].length;i++)if(i%4!==3||initial[key][i]===0)assert(Object.is(d[key][i],initial[key][i]),'Material changed original XYZ/fixed W');else assert(Object.is(d[key][i],d.positions[i]),'Physical W differs across actual restart seeds');}
 const reseal=()=>{owned.assertCurrent();assert(samePrepared(snapshotPrepared(seed.prepared),owned.initial)&&samePrepared(snapshotPrepared(prepared),materialSnapshot),'App material/preparation changed while sealing');return true;};
 let policy=d.sourceInitialArrangementPolicy??null;
 if(owned.placement?.changed){
  const hashes={};for(const [field,key] of [['positions','actualPositionsSha256'],['arrangedPositions','actualArrangedPositionsSha256'],['anchors','actualAnchorsSha256'],['sourceArrangedPositions','originalSourceArrangedPositionsSha256'],['positions2d','sourceRestCoordinatesSha256'],['triangles','clothTrianglesSha256'],['seams','seamsSha256'],['seamOrder','seamOrderSha256']]){hashes[key]=await numericSha(d[field]);reseal();}
  const extras={};for(const [key,value,numeric] of [['originalAppPreparationSha256',owned.source,false],['bodyPositionsSha256',input.body.positions,true],['bodyTrianglesSha256',input.body.triangles,true],['physicalInverseMassBitsSha256',d.positions.filter((_,i)=>i%4===3),true],['assemblySupportTargetsSha256',d.assemblySupport.targets,true],['assemblySupportGroupsSha256',d.assemblySupport.groups,false]]){extras[key]=await (numeric?numericSha(value):policySha(value));reseal();}
  policy={policy:owned.placement.policy,revision:1,preparationOrigin:'actual-app-finalized-source-before-SI-v1',...extras,bodyBaseModelSha256:owned.modelSha,sourceFitRevision:owned.source.sourceFitRevision,sourceAssemblyRevision:owned.source.sourceAssemblyRevision,body6RecomputedGeometry:true,oldBody5GeometryAuthorityBorrowed:false,
   originalSourceProfileSha256:initial.sourceInitialArrangementPolicySha256??null,originalAppMaterialPolicySha256:d.sourcePhysicalMembrane.policySha256,...hashes,
   assemblySchedulePolicySha256:seed.schedulePolicySha256,
   moves:owned.placement.moves,storedFloat32IsometryIsExact:false,maxPackedEdgeLengthDifferenceM:owned.placement.maxPackedEdgeLengthDifferenceM,authoredCuffAssemblyGapPreserved:true};reseal();
 }
 const hash=policy?await policySha(policy):null;reseal();
 let output=input;
 if(owned.placement?.changed){
  // The material context authenticates ALL SimData fields. Install this NEW
  // app policy on the actual pre-SI seed and execute the real routine again;
  // appending metadata to an already sealed material would invalidate it.
  const beforeSI=snapshotPrepared(owned.initial);beforeSI.simData.sourceInitialArrangementPolicy=policy;beforeSI.simData.sourceInitialArrangementPolicySha256=hash;
  const assignments=copyData(d.sourcePhysicalMembrane.policy.pieces);
  output={...beforeSI,simData:await prepareSourcePhysicalMembrane(beforeSI.simData,assignments)};reseal();validateSourcePhysicalMembrane(output.simData);
  for(const k of ['positions','arrangedPositions','sourceArrangedPositions','anchors','positions2d','triangles','seams','seamOrder','assemblySupport'])assert(equalData(output.simData[k],d[k]),'Actual resealed material changed physical geometry: '+k);
 }
 const outputSnapshot=snapshotPrepared(output),checkOutput=()=>{reseal();assert(samePrepared(snapshotPrepared(output),outputSnapshot),'Returned app material changed');return true;};
 return Object.freeze({prepared:output,sourceInitialArrangementPolicySha256:hash,sourceAssemblySchedulePolicySha256:seed.schedulePolicySha256,assertCurrent:checkOutput,
  executionContextMustBeAuthorizedSeparately:true,cacheWarmEligible:false,deviceExecuted:false,sourceAssemblyComplete:false,fitAccepted:false});
}
