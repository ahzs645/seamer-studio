export const physicalMechanicalCandidateWGSL=String.raw`
@group(0) @binding(0) var<storage,read> parent:array<vec4f>;
@group(0) @binding(1) var<storage,read> ideal:array<vec4f>;
@group(0) @binding(2) var<storage,read_write> candidate:array<vec4f>;
@compute @workgroup_size(64) fn mechanical_candidate(@builtin(global_invocation_id) gid:vec3u){
 let p=gid.x;if(p>=arrayLength(&parent)){return;}var q=parent[p];
 // Preserve literal fixed/signed-zero bits; direct ideal is retained separately.
 if(q.w>0.0){for(var k=0u;k<3u;k++){if(ideal[p][k]!=0.0){q[k]+=ideal[p][k];}}}candidate[p]=q;
}`;
