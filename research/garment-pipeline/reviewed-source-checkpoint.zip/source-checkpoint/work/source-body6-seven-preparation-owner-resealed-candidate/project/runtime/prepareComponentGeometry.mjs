/** Packet preparation only; the genuine app graph owns refined preparation.
 * This function neither mints an approval nor authorizes a device allocation. */
import {packJointGeometry} from './refined/vendor/sourceJointGeometry.mjs';
import {physicalSeamStitchIndices,buildSeamGateLayout} from './refined/vendor/seamGate.mjs';
import {surfaceTopologyExclusions,surfaceSeamLinks} from './refined/vendor/surfaceTopology.mjs';
import {physicalBytesSha256} from './portablePhysicalHashes.mjs';
export async function prepareActualComponentGeometry(input,mode='source') {
 if(mode==='native'||mode==='off')return null;
 const {prepared,sourceBinding,isCurrent,refinedAdapter}=input;
 if(typeof isCurrent!=='function'||isCurrent()!==true)throw Error('Actual app packet owner required');
 const p=structuredClone(prepared),b=structuredClone(sourceBinding),d=p.simData;
 const body=await physicalBytesSha256(p.body.positions);if(isCurrent()!==true)throw Error('Actual packet owner changed');
 const topology=await physicalBytesSha256(d.triangles);if(isCurrent()!==true)throw Error('Actual packet owner changed');
 if(body!==b.bodySha256||topology!==b.topologySha256)throw Error('Actual immutable body/topology preparation differs');
 if(d.sourceGatherCollisionGeometry){
  if(!refinedAdapter)throw Error('Genuine same-app refined adapter required');
  const refinedPreparation=await refinedAdapter.prepareVerifiedRefinedBackend(b);if(isCurrent()!==true)throw Error('Actual packet owner changed');
  if(!refinedPreparation)throw Error('Actual finalized source refinement required');
  const capture=refinedPreparation.capture();return {packed:capture.packed,layout:capture.layout,binding:b,refinedPreparation};
 }
 const groups=d.seamPairsBySeam.map((g,index)=>({...g,index,stitchIndices:physicalSeamStitchIndices(d.seams,d.seamOrder,[g],d.seamStitchRanges)[0]}));
 const layout=buildSeamGateLayout(d.stitchCount,groups.length),packed=packJointGeometry({scope:'fresh-source',particleCount:d.particleCount,clothTriangles:d.triangles,bodyPositions:p.body.positions,bodyTriangles:p.body.triangles,sourceTopology:surfaceTopologyExclusions(d.triangles,d.seams,d.seamOrder,groups,true,groups.map(g=>g.stitchIndices)),sourceSeamLinks:surfaceSeamLinks(groups),...b,refinedBoundary:false});
 if(isCurrent()!==true)throw Error('Actual packet owner changed');return {packed,layout,binding:b};
}
