import { wholePhysicalRowPackWGSL, wholePhysicalPackStateWords } from './wholePhysicalRowPackWGSL.mjs';
import { requirePhysicalIncomingRawProof } from './wholePhysicalAliasWGSL.mjs';
const u32 = n => Number.isSafeInteger(n) && n >= 0 && n <= 0xffffffff;
const sha = /^[a-f0-9]{64}$/;
export function createSourcePhysicalRowPackPass(device, scope, options) {
 return scope === 'fresh-source-physical-profile' ? new SourcePhysicalRowPackPass(device, options) : null;
}
/** Concrete authentic GPU pack host. Only representative raw ORDINALS are
 * uploaded by the host. No CPU RHS/normal/anchor/gradient or mass is injected.
 * Returned output lease survives readback until explicit release; it cannot be
 * silently overwritten while a coupled reaction uses its rows and terms.
 * NEW shader/adapter, not yet device validated. */
export class SourcePhysicalRowPackPass {
 #device; #options; #owned = []; #rows; #terms; #selected; #state; #params; #readback;
 #layout; #pipes; #busy = false; #output = null; #pending = null; #generation = 0;
 #closed = false; #closing = false; #closePromise = null; #token = 0;
 constructor(device, options, assertCurrent=()=>true) {assertCurrent();
  this.#device = device; this.#options = Object.freeze(structuredClone(options));
  const { particles, rawCapacity, rowCapacity } = this.#options;
  if (![particles, rawCapacity, rowCapacity].every(u32) || particles < 1 || rawCapacity < 1 ||
      rowCapacity < 1 || rowCapacity > rawCapacity || device.limits.maxStorageBuffersPerShaderStage < 8)
   throw Error('Invalid complete physical pack capacities');
  const make = (label, size, usage) => {
   if (!Number.isSafeInteger(size) || size < 4 || size > device.limits.maxStorageBufferBindingSize)
    throw Error('Complete physical pack exceeds binding capacity');
   const b = device.createBuffer({ label, size, usage }); this.#owned.push(b); return b;
  };
  try {
   const writable = GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST;
   this.#rows = make('actual physical1mm rows', rowCapacity * 48, writable);
   this.#terms = make('actual physical J terms', rowCapacity * 6 * 32, writable);
   this.#selected = make('physical exact alias representative ordinals', rowCapacity * 4, writable);
   this.#state = make('incoming/raw physical proof and bitset', wholePhysicalPackStateWords(rawCapacity) * 4, writable);
   this.#params = make('physical immutable packing epoch', 64, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST);
   this.#readback = make('physical actual pack readback', 32 + this.#rows.size + this.#terms.size,
    GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ);
   this.#layout = device.createBindGroupLayout({ entries: Array.from({ length: 9 }, (_, binding) => ({
    binding, visibility: GPUShaderStage.COMPUTE, buffer: { type: binding === 8 ? 'uniform' : binding < 5 ? 'read-only-storage' : 'storage' }
   })) });
   const layout = device.createPipelineLayout({ bindGroupLayouts: [this.#layout] });
   const module = device.createShaderModule({ code: wholePhysicalRowPackWGSL });
   this.ready = (async () => {
    const info = await module.getCompilationInfo(), errors = info.messages.filter(m => m.type === 'error');assertCurrent();
    if (errors.length) throw Error(errors.map(m => `${m.lineNum}:${m.linePos} ${m.message}`).join('\n'));
    if (this.#closing) throw Error('Physical pack closed during compilation');
    this.#pipes = Object.fromEntries(['reset', 'validate_particles', 'pack', 'complete'].map(entryPoint => [entryPoint,
     device.createComputePipeline({ layout, compute: { module, entryPoint } })]));
   })(); this.ready.catch(() => {});
  } catch (e) { for (const b of this.#owned) b.destroy(); this.#owned = []; throw e; }
 }
 packActualRows(input) {
  if (this.#closing || this.#closed || this.#busy || this.#output) return Promise.reject(Error('Physical pack concurrent/leased/closed'));
  const handles = { parent: input.originalParent, current: input.current, history: input.history,
   raw: input.raw, rawProof: input.rawProof };
  const binding = structuredClone(input.binding), expected = structuredClone(input.expected),
   ordinals = input.selectedOriginalIds?.slice(), proof = input.observedRawProof?.slice(), profile = structuredClone(input.frictionProfile);
  const generation = this.#generation, isCurrent = input.isCurrent; this.#busy = true;
  const current = () => !this.#closing && generation === this.#generation && isCurrent?.() === true;
  const work = (async () => {
   let mapped = false;
   try {
    await this.ready;
    if (!current()) throw Error('Physical pack source lease changed');
    if (!expected || !['rawOccurrences', 'parentToken', 'sourceToken', 'bodyGeneration', 'physicalSubstep', 'gateRevision'].every(k => u32(expected[k])) ||
        expected.rawOccurrences < 1 || expected.rawOccurrences > this.#options.rawCapacity || !expected.parentToken || !expected.sourceToken || !expected.bodyGeneration ||
        expected.physicalSubstep < 1 || expected.physicalSubstep > 40 ||
        !binding || binding.authenticAllRawReadLease !== true || binding.actualGpuAliasKeyReceipt !== true ||
        !['originalParentSha256', 'currentSha256', 'historySha256', 'usedGateSha256', 'sourceSha256', 'bodySha256',
          'physicalMassPolicySha256', 'fullRawRow128Sha256', 'actualAliasKeyReceiptSha256', 'declaredFrictionProfileSha256'].every(k => sha.test(binding[k])))
     throw Error('Physical pack missing authentic inventory/key binding');
    requirePhysicalIncomingRawProof(proof, expected.rawOccurrences);
    if (!(ordinals instanceof Uint32Array) || ordinals.length < 1 || ordinals.length > this.#options.rowCapacity ||
        new Set(ordinals).size !== ordinals.length || ordinals.some(id => id >= expected.rawOccurrences)) throw Error('Malformed physical alias representative partition');
    if (!profile || !Number.isFinite(profile.muStatic) || !Number.isFinite(profile.muKinetic) ||
        profile.muKinetic < 0 || profile.muStatic < profile.muKinetic) throw Error('Undeclared physical friction coefficients');
    const p = this.#options.particles, r = ordinals.length;
    if (Object.values(handles).some(h => !h || this.#owned.includes(h)) ||
        [handles.parent, handles.current, handles.history].some(h => h.size !== p * 16) ||
        handles.rawProof.size !== 32 || handles.raw.size !== this.#options.rawCapacity * 128)
     throw Error('Unbound physical pack resource ranges');
    this.#device.queue.writeBuffer(this.#selected, 0, ordinals);
    const cfg = Uint32Array.of(p, this.#options.rawCapacity, r, r * 6,
     expected.parentToken, expected.sourceToken, expected.bodyGeneration, expected.gateRevision,
     expected.physicalSubstep, 0, 8, this.#state.size / 4, 0, 0, 0, 0);
    new Float32Array(cfg.buffer).set([profile.muStatic, profile.muKinetic, .001, 0], 12);
    this.#device.queue.writeBuffer(this.#params, 0, cfg);
    const e = this.#device.createCommandEncoder(); e.copyBufferToBuffer(handles.rawProof, 0, this.#state, 0, 32);
    const resources = [{ buffer: handles.parent }, { buffer: handles.current }, { buffer: handles.history },
     { buffer: handles.raw }, { buffer: this.#selected, size: r * 4 }, { buffer: this.#rows, size: r * 48 },
     { buffer: this.#terms, size: r * 192 }, { buffer: this.#state }, { buffer: this.#params }];
    const group = this.#device.createBindGroup({ layout: this.#layout, entries: resources.map((resource, binding) => ({ binding, resource })) });
    for (const [name, count] of [['reset', 1], ['validate_particles', Math.ceil(p / 64)], ['pack', Math.ceil(r / 64)], ['complete', 1]]) {
     const pass = e.beginComputePass(); pass.setPipeline(this.#pipes[name]); pass.setBindGroup(0, group); pass.dispatchWorkgroups(count); pass.end();
    }
    e.copyBufferToBuffer(this.#state, 32, this.#readback, 0, 32);
    e.copyBufferToBuffer(this.#rows, 0, this.#readback, 32, r * 48);
    e.copyBufferToBuffer(this.#terms, 0, this.#readback, 32 + this.#rows.size, r * 192);
    this.#device.queue.submit([e.finish()]); await this.#readback.mapAsync(GPUMapMode.READ); mapped = true;
    const bytes = this.#readback.getMappedRange().slice(0);
    if (!current()) throw Error('Physical pack changed during readback');
    const outputProof = new Uint32Array(bytes, 0, 8).slice();
    const expectedProof = [0, r, expected.rawOccurrences, r * 6, expected.parentToken, expected.sourceToken, expected.bodyGeneration, expected.gateRevision];
    if (outputProof.some((v, i) => v !== expectedProof[i])) throw Error('Actual physical pack failed complete receipt');
    const receipt = { token: ++this.#token, binding, expected, selectedOriginalIds: ordinals,
     actualPhysicalRows: new Uint8Array(bytes, 32, r * 48).slice(),
     actualPhysicalTerms: new Uint8Array(bytes, 32 + this.#rows.size, r * 192).slice(), proof: outputProof,
     rows: this.#rows, terms: this.#terms, packProof: this.#state, packProofOffset: 32,
     executedRows: r, actualGpuPhysicalPackProducer: true, physicalPressureAuthoritative: false };
    this.#output = receipt; return receipt;
   } finally { if (mapped) this.#readback.unmap(); this.#busy = false; }
  })();
  this.#pending = work; work.then(() => { if (this.#pending === work) this.#pending = null; }, () => { if (this.#pending === work) this.#pending = null; });
  return work;
 }
 releasePacket(token) { if (!this.#output || this.#output.token !== token) throw Error('Stale physical pack output release'); this.#output = null; }
 invalidate() { this.#generation++; }
 destroy() {
  if (this.#closePromise) return this.#closePromise; this.#closing = true; this.invalidate();
  this.#closePromise = (async () => { const errors = []; await this.ready.catch(e => errors.push(e));
   if (this.#pending) await this.#pending.catch(e => errors.push(e));
   try { await this.#device.queue.onSubmittedWorkDone(); } catch (e) { errors.push(e); }
   finally { for (const b of this.#owned) try { b.destroy(); } catch (e) { errors.push(e); }
    this.#owned = []; this.#closed = true; this.#output = null; }
   if (errors.length) throw new AggregateError(errors, 'Physical pack cleanup failed');
  })(); return this.#closePromise;
 }
}
