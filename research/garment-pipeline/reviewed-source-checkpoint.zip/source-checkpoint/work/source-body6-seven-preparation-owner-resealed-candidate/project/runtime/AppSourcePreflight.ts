/** CPU-only initial guard through the SAME SOURCE graph used by the real Worker.
 * A clear static seed is not an accepted frame, pressure or fit certificate. */
import {SourceActiveOriginalSeamSelfGuard} from './engine-source/activeOriginalSeamSelf.mjs';
import {SourceBodyFacetClearanceGuard} from './engine-source/bodyFacetClearance.mjs';
import type {PreparedCloth} from './engine-source/simulator.ts';
import {ClothCollisionGuard,type CollisionSeamActivation,type CollisionGuardInput} from './engine-source/collisionGuard.ts';
import {SourceStagingController} from './engine-source/sourceStaging.ts';
import {physicalSeamStitchIndices} from './engine-source/webgpu/seamGate.ts';
export function createActualInitialSpacingGuards(prepared:PreparedCloth) {
 if(prepared.collisionSafety!==true)throw Error('Active source preflight requires actual finalized source');
 const d=prepared.simData,indices=physicalSeamStitchIndices(d.seams,d.seamOrder,d.seamPairsBySeam,d.seamStitchRanges);
 const dictionary={stitchCount:d.stitchCount,seamPairsBySeam:d.seamPairsBySeam.map((g,index)=>({seamId:g.seamId,index,pairs:Array.from(g.pairs),stitchIndices:Array.from(indices[index]),stitchIndexKinds:Array.from(indices[index],(_,pair)=>g.pairs[pair*2]===g.pairs[pair*2+1]?'identity-logical' as const:'reciprocal-first-stamp' as const)}))};
 const controller=d.sourceStaging?new SourceStagingController(d.sourceStaging):null;
 const activation:CollisionSeamActivation={revision:controller?.maskRevision??0,activeSeams:controller?.nextActiveSeamMask??new Uint32Array(dictionary.seamPairsBySeam.length).fill(1),sewnUpTo:d.stitchCount};
 const guard=new ClothCollisionGuard({bodyPositions:prepared.body.positions,bodyIndices:prepared.body.triangles,bodyPositionStride:4,bodyTriangleStride:4,clothTriangles:d.triangles,particleCount:d.particleCount,seams:d.seams,...dictionary,
  ...(d.sourceGatherRefinement||d.sourceGatherCollisionGeometry?{sourceGatherRefinementRevision:d.sourceGatherRefinement?.revision,sourceGatherCollisionGeometry:d.sourceGatherCollisionGeometry as CollisionGuardInput['sourceGatherCollisionGeometry']}: {})});
 return Object.freeze({finiteGuard:guard,activation,dictionary});
}
export function inspectActualAppInitialSource(prepared:PreparedCloth) {
 const {finiteGuard:guard,activation}=createActualInitialSpacingGuards(prepared);
 const report=guard.inspect(prepared.simData.positions,undefined,activation);
 if(!report.safe||!report.finite||!report.bodyClosed)throw Error('This initial garment placement could not be verified. Reset to its arrangement before starting.');
 return Object.freeze({report:structuredClone(report),requestedInitialActivation:structuredClone(activation),activationOrigin:'actual-current-app-CPU-requested-initial-mask',staticOnly:true,all40Executed:false,fitAccepted:false});
}

/** NEW body6 preparation gate: execute the unchanged strict source169 finite
 * BODY 1mm and zero-thickness SELF predicates on the actual final seed.
 * The gate is a CPU-requested initial mask, never an executed USED/frame proof. */
export function inspectStrictActualAppInitialSource(prepared:PreparedCloth) {
 const initial=inspectActualAppInitialSource(prepared),{dictionary,activation}=createActualInitialSpacingGuards(prepared);
 const d=prepared.simData,input={particleCount:d.particleCount,clothTriangles:d.triangles,clothTriangleStride:4};
 const body=new SourceBodyFacetClearanceGuard({...input,bodyPositions:prepared.body.positions,bodyIndices:prepared.body.triangles,bodyPositionStride:4,bodyTriangleStride:4}).inspect(d.positions,d.positions);
 const self=new SourceActiveOriginalSeamSelfGuard({...input,...dictionary}).inspect(d.positions,d.positions,activation);
 const report={...initial,strictBody:body,strictSelf:self,bodyClearanceM:.001,positiveSelfThicknessCertified:false,bodyFitRevision:6,CPUOnly:true,all40Executed:false,fitAccepted:false};
 if(!body.accepted||!self.clear)throw Object.assign(Error('Actual body6 initial strict BODY/SELF preparation is unresolved'),{initialStrictReport:report});
 return Object.freeze(report);
}
