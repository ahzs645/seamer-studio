import {executeComputationalPreparation,type ComputationalPreparationPacket} from './handler.ts';
const jobs=new Map<number,{active:boolean}>();
self.addEventListener('message',(event:MessageEvent)=>{
 const {operation,id,packet,requestSha256}=event.data??{};
 if(!Number.isSafeInteger(id)||id<1)return;
 if(operation==='cancel'){const old=jobs.get(id);if(old)old.active=false;return;}
 if(operation!=='prepare'||jobs.has(id))return;
 const state={active:true};jobs.set(id,state);
 void executeComputationalPreparation(packet as ComputationalPreparationPacket,requestSha256,()=>state.active)
  .then(reply=>{if(state.active)self.postMessage({id,...reply});})
  .catch(error=>{if(state.active)self.postMessage({id,error:error instanceof Error?error.message:String(error)});})
  .finally(()=>jobs.delete(id));
});
