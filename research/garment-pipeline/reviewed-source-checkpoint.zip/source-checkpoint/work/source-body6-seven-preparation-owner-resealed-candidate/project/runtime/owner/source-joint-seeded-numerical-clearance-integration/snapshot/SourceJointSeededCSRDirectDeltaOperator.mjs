/** NEW ABI4 seeded host variant: preserves MAIN ideal delta by ordered copy BEFORE APPLY overwrites its storage. Frozen CSR143 host remains unchanged. No engine publication. */
/** NEW scalable virtual CSR operator ABI4. NEVER imported by shipping engine.
 * Production rows/terms/components/membership must be actual GPU producer buffers.
 * The isolated algebra fixture explicitly uploads sealed CPU-reference CSR; that
 * producer proof certifies its fixed packing only, never finite-world discovery.
 * This host never uploads authored CPU contact rows and never commits live XYZ/W.
 * The receipt is finite algebra/NET evidence only. Full actual fresh finite ALLraw,
 * history/trajectory/velocity/friction and rollback integration remain mandatory.
 */
import { sourceJointSeededCSRContactWGSL, SOURCE_JOINT_CSR_OPERATOR_ABI } from './sourceJointSeededCSRContact.mjs';
const sha = (s) => /^[0-9a-f]{64}$/.test(s), u32 = (v) => Number.isSafeInteger(v) && v >= 0 && v <= 0xffffffff;
function bound(b) {
    if (b?.exclusiveBuffersLease !== true || b.actualGpuBytesObserved !== true || ![b.mechanicalCandidateSha256,b.mechanicalIdealSha256,b.originalParentSha256, b.historySha256, b.sourceSha256, b.bodySha256, b.gateSha256].every(sha) || ![b.parentToken, b.sourceToken, b.bodyGeneration, b.gateRevision].every(u32) || b.parentToken === 0)
        throw Error('Unbound CSR original parent');
    return JSON.stringify(b);
}
export class SourceJointSeededCSRDirectDeltaOperator {
    device;
    caller;
    rowCapacity;
    componentCapacity;
    abi = SOURCE_JOINT_CSR_OPERATOR_ABI;
    enabled;
    productionIntegrationReady = false;
    owned = [];
    immutable;
    ideal;
    output;
    dual;
    status;
    uniform;
    readback;
    layout;
    stages = new Map();
    disposed = false;
    started = false;
    mappedBusy = null;
    releaseBusy;
    closePromise = null;
    sealed = null;
    initialHandle;
    initialCount;
    selectedComponentCount = 0;
    closing = false;
    constructor(device, caller, scope, rowCapacity, componentCapacity) {
        this.device = device;
        this.caller = caller;
        this.rowCapacity = rowCapacity;
        this.componentCapacity = componentCapacity;
        this.enabled = scope === 'fresh-source';
        this.initialHandle = caller.positions;
        this.initialCount = caller.particleCount;this.initialMechanicalHandle=caller.mechanicalCandidate;this.initialMechanicalIdeal=caller.mechanicalIdeal;
        if (!this.enabled)
            return;
        if (!u32(caller.particleCount) || caller.particleCount === 0 || !u32(rowCapacity) || !rowCapacity || !u32(componentCapacity) || !componentCapacity || device.limits.maxStorageBuffersPerShaderStage < 8 || caller.positions.size < caller.particleCount * 16 || !caller.mechanicalCandidate || !caller.mechanicalIdeal || new Set([caller.positions,caller.mechanicalCandidate,caller.mechanicalIdeal]).size!==3 || caller.mechanicalCandidate.size<caller.particleCount*16 || caller.mechanicalIdeal.size<caller.particleCount*16)
            throw Error('Invalid CSR capacity/device');
        const make = (name, size, usage) => { if (size > device.limits.maxStorageBufferBindingSize)
            throw Error('CSR storage capacity'); const b = device.createBuffer({ label: 'isolated-CSR4:' + name, size: Math.max(4, size), usage }); this.owned.push(b); return b; };
        try {
            const storage = GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST;
            this.immutable = make('original-parent-mechanical-seed-and-direct-ideal', caller.particleCount * 48, storage);
            this.ideal = make('preserved-pre-world-round-ideal-delta', caller.particleCount * 16, storage);
            this.output = make('virtual-output', caller.particleCount * 16, storage);
            this.dual = make('multipliers', rowCapacity * 4, storage);
            this.status = make('producer-and-component-status', (8 + componentCapacity * 4) * 4, storage);
            this.uniform = make('config', 48, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST);
            this.readback = make('status-readback', (8 + componentCapacity * 4) * 4, GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST);
            this.layout = device.createBindGroupLayout({ entries: [...Array.from({ length: 8 }, (_, binding) => ({ binding, visibility: GPUShaderStage.COMPUTE, buffer: { type: binding < 5 ? 'read-only-storage' : 'storage' } })), { binding: 8, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'uniform' } }] });
            const module = device.createShaderModule({ label: 'isolated-CSR4-numerical-only', code: sourceJointSeededCSRContactWGSL });this.compilationPromise=module.getCompilationInfo().then(info=>{if(info.messages.some(m=>m.type==='error'))throw Error('Seeded CSR compilation failed');return{actualModuleCompilationChecked:true};});this.compilationPromise.catch(()=>{});const layout = device.createPipelineLayout({ bindGroupLayouts: [this.layout] });
            for (const entryPoint of ['main', 'apply'])
                this.stages.set(entryPoint, device.createComputePipeline({ layout, compute: { module, entryPoint } }));
        }
        catch (error) {
            for (const b of this.owned)
                b.destroy();
            this.owned = [];
            this.disposed = true;
            throw error;
        }
    }
    async verifyCompilationBeforeDispatch(){if(this.closing||this.disposed)throw Error('Seeded CSR closed');this.compilationVerified=await this.compilationPromise;if(this.closing||this.disposed)throw Error('Seeded CSR closed during compilation');}
    check() { if (this.disposed)
        throw Error('CSR operator destroyed'); if (this.caller.positions !== this.initialHandle || this.caller.particleCount !== this.initialCount || this.caller.mechanicalCandidate!==this.initialMechanicalHandle || this.caller.mechanicalIdeal!==this.initialMechanicalIdeal)
        throw Error('CSR caller handle changed'); }
    get virtualPositions() { return this.output; }
    get idealContactDelta() { return this.ideal; }
    get augmentedMultipliers() { return this.dual; }
    get diagnosticStatusBuffer() { return this.status; }
    // Original parent is an immutable caller buffer, never the previous virtual round.
    preservesDirectIdealDelta = true;
    encodeOneResponse(encoder, b, p, sweeps = 256) {
        if (!this.enabled)
            return;
        this.check();
        if(!this.compilationVerified?.actualModuleCompilationChecked)throw Error('Seeded CSR compilation barrier incomplete');
        if (this.closing || this.mappedBusy || this.started)
            throw Error('CSR one immutable response already used/busy');
        const identity = bound(b);
        if (![p.rowCount, p.termCount, p.componentCount, p.membershipWords, p.ownerOffset, sweeps].every(u32) || p.rowCount > this.rowCapacity || p.componentCount > this.componentCapacity || !p.componentCount || sweeps < 1 || sweeps > 256 || p.termCount > p.rowCount * 6 || p.ownerOffset + this.caller.particleCount > p.membershipWords)
            throw Error('CSR explicit complete capacity');
        const handles = [p.rows, p.terms, p.components, p.membership, p.proof, this.initialHandle,this.initialMechanicalHandle,this.initialMechanicalIdeal];
        if (new Set(handles).size !== handles.length)
            throw Error('CSR producer aliases immutable input');
        for (const [buffer, size] of [[p.rows, p.rowCount * 16], [p.terms, p.termCount * 16], [p.components, p.componentCount * 16], [p.membership, p.membershipWords * 4], [p.proof, 32]])
            if (buffer.size < size || buffer.size > this.device.limits.maxStorageBufferBindingSize)
                throw Error('Truncated CSR producer buffer');
        this.started = true;
        this.selectedComponentCount = p.componentCount;
        this.sealed = identity;
        const words = Uint32Array.of(this.caller.particleCount, p.rowCount, p.termCount, p.componentCount, p.membershipWords, sweeps, p.ownerOffset, 0, b.parentToken, b.sourceToken, b.bodyGeneration, b.gateRevision);
        this.device.queue.writeBuffer(this.uniform, 0, words);
        encoder.copyBufferToBuffer(this.initialHandle,0,this.immutable,0,this.caller.particleCount*16);
        encoder.copyBufferToBuffer(this.initialMechanicalHandle,0,this.immutable,this.caller.particleCount*16,this.caller.particleCount*16);
        encoder.copyBufferToBuffer(this.initialMechanicalIdeal,0,this.immutable,this.caller.particleCount*32,this.caller.particleCount*16);
        encoder.clearBuffer(this.output);
        encoder.clearBuffer(this.dual);
        encoder.clearBuffer(this.status);
        encoder.copyBufferToBuffer(p.proof, 0, this.status, 0, 32);
        const group = this.device.createBindGroup({ layout: this.layout, entries: [this.immutable, p.rows, p.terms, p.components, p.membership, this.output, this.dual, this.status, this.uniform].map((buffer, binding) => ({ binding, resource: { buffer: buffer } })) });
        for (const entry of ['main', 'apply']) {
            const pass = encoder.beginComputePass({ label: 'isolated-CSR4:' + entry });
            pass.setPipeline(this.stages.get(entry));
            pass.setBindGroup(0, group);
            pass.dispatchWorkgroups(entry === 'main' ? p.componentCount : Math.ceil(this.caller.particleCount / 64));
            pass.end();
            if (entry === 'main')
                encoder.copyBufferToBuffer(this.output, 0, this.ideal, 0, this.caller.particleCount * 16);
        }
        encoder.copyBufferToBuffer(this.status, 0, this.readback, 0, (8 + p.componentCount * 4) * 4);
    }
    async readReceipt(componentCount) {
        if (!this.enabled)
            return { nativeBypass: true, allocatedBuffers: 0, garmentAccepted: false };
        this.check();
        if (this.closing || this.mappedBusy || !this.started || !this.sealed || !u32(componentCount) || componentCount !== this.selectedComponentCount)
            throw Error('CSR receipt missing/busy');
        const binding = this.sealed, readback = this.readback;
        this.mappedBusy = new Promise(r => { this.releaseBusy = r; });
        let mapped = false;
        try {
            await readback.mapAsync(GPUMapMode.READ);
            mapped = true;
            const words = new Uint32Array(readback.getMappedRange().slice(0, (8 + componentCount * 4) * 4));
            this.check();
            if (binding !== this.sealed)
                throw Error('CSR stale receipt');
            return { abi: this.abi, binding, producerProof: Array.from(words.slice(0, 8)), components: Array.from({ length: componentCount }, (_, i) => { const at = 8 + i * 4, f = new Float32Array(words.buffer); return { status: words[at], maximumNetMm: f[at + 1] * 1000, algebraicDeficitMm: f[at + 2] * 1000, parentToken: words[at + 3] }; }), virtualOnly: true, physicalCertificate: false, garmentAccepted: false };
        }
        finally {
            if (mapped)
                readback.unmap();
            this.releaseBusy?.();
            this.releaseBusy = undefined;
            this.mappedBusy = null;
        }
    }
    destroy() { if (this.closePromise)
        return this.closePromise; this.closing = true; this.closePromise = (async () => { if (this.mappedBusy)
        await this.mappedBusy; try {
        await this.device.queue.onSubmittedWorkDone();
    }
    finally {
        this.disposed = true;
        for (const b of this.owned)
            b.destroy();
        this.owned = [];
    } })(); return this.closePromise; }
}
