import{portableDigest as digest,concatPhysicalBytes,physicalViewBytes}from'./portableByteTools.mjs';
import{requireWholePhysicalPreparation,createPreparedWholePhysicalFactory}from'./privateWholePreparation.mjs';
export{sourceDeclaredFrictionProfileSha256}from'./declaredFrictionProfile.mjs';
import{SourcePhysicalAliasPass}from'./SourcePhysicalAliasPass.mjs';
import{SourcePhysicalRowPackPass}from'./SourcePhysicalRowPackPass.mjs';
import{SourcePhysicalInventoryPass}from'./SourcePhysicalInventoryPass.mjs';
import{SourceWholePhysicalReactionPass}from'./SourceWholePhysicalReactionPass.mjs';
import{graphActualPhysicalRows}from'./actualPhysicalComponentGraph.mjs';
import{requirePhysicalIncomingRawProof}from'./wholePhysicalAliasWGSL.mjs';
import{PHYSICAL_REACTION_TOLERANCE_POLICY_SHA256}from'./tolerancePolicy.mjs';
import{SOURCE_ANCHOR_PARTITION_POLICY_SHA256}from'./anchorPartitionPolicy.mjs';
import{requireActualEmptyPhysicalInventory}from'./actualEmptyPhysicalInventory.mjs';
import{actualAllContactOperatorEvidence}from'./actualAllContactOperatorEvidence.mjs';
const sha=/^[a-f0-9]{64}$/,u32=n=>Number.isSafeInteger(n)&&n>=0&&n<=0xffffffff;

import{physicalMechanicalCandidateWGSL}from'./physicalMechanicalCandidateWGSL.mjs';
export{physicalMechanicalCandidateWGSL}from'./physicalMechanicalCandidateWGSL.mjs';

export function createSourcePhysicalMechanicalController(device,scope,options){if(scope!=='fresh-source-physical-profile')return null;return createPreparedWholePhysicalFactory(SourcePhysicalMechanicalController)(device,scope,options);}

/** Concrete ONE-parent physical-only controller. No CPU geometry is packed.
 * It solves sparse coupled reactions and certifies EVERY fixed inequality.
 * Persistent history, numerical clearance, fresh finite/CCD and forty-step
 * publication are deliberately separate owners; this is not an engine-ready
 * pressure provider until those concrete stages are composed and device tested. */
export class SourcePhysicalMechanicalController{
 #assertOwner;#frictionSha;#device;#o;#owned=[];#children=[];#alias;#pack;#inventory;#reaction;#parent;#history;#current;
 #combined;#zero;#candidate;#membership;#observe;#raw;#rawProof;#packetObserve;#candidateLayout;#candidatePipe;
 #busy=false;#output=null;#pending=null;#closing=false;#closePromise=null;#generation=0;#token=0;
 constructor(device,token){const prepared=requireWholePhysicalPreparation(token),options=prepared.options;this.#frictionSha=prepared.frictionSha256;this.#assertOwner=prepared.assertCurrent;
  this.#device=device;this.#o=Object.freeze(structuredClone(options));const o=this.#o;
  if(!['particles','rawCapacity','rowCapacity','componentCapacity','sweeps','maximumActiveSetRounds','maximumRowsPerComponent','maximumParticlesPerComponent'].every(k=>u32(o[k])&&o[k]>0)||
   o.rowCapacity>o.rawCapacity||o.componentCapacity>o.particles||o.maximumActiveSetRounds>64||!sha.test(o.sourceSha256)||!sha.test(o.bodySha256)||!sha.test(o.physicalMassPolicySha256)||
   !(o.physicalInverseMassBits instanceof Uint32Array)||o.physicalInverseMassBits.length!==o.particles||
   !u32(o.sourceToken)||!o.sourceToken||!u32(o.bodyGeneration)||!o.bodyGeneration)throw Error('Invalid bound physical controller policy');
  if(new Float32Array(o.physicalInverseMassBits.buffer,o.physicalInverseMassBits.byteOffset,o.physicalInverseMassBits.length).some(w=>!Number.isFinite(w)||w<0))throw Error('Invalid declared physical inverse masses');
  prepared.assertCurrent();
  const make=(label,size,usage)=>{prepared.assertCurrent();if(!Number.isSafeInteger(size)||size<4||size>device.limits.maxStorageBufferBindingSize)throw Error('Physical controller exceeds portable resource bound');const b=device.createBuffer({label,size,usage});this.#owned.push(b);return b;};
  try{
   const writable=GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST;
   this.#parent=make('physical original parent private bytes',o.particles*16,writable);this.#history=make('physical old material private bytes',o.particles*16,writable);
   this.#current=make('physical finite enumeration current private bytes',o.particles*16,writable);this.#combined=make('physical original parent plus material history',o.particles*32,writable);
   this.#zero=make('initial physical ideal zero',o.particles*16,writable);this.#candidate=make('owned mechanical world candidate',o.particles*16,writable);
   this.#membership=make('integer physical disjoint ownership',(o.rowCapacity+6*o.particles)*4,writable);
   this.#observe=make('owned physical parent current history receipt',o.particles*48,GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST);
   this.#raw=make('owned authentic physical ALLraw snapshot',o.rawCapacity*128,writable);this.#rawProof=make('owned authentic incoming physical proof',32,writable);
   this.#packetObserve=make('raw/proof sealed read receipt',32+o.rawCapacity*128,GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST);
   this.#alias=new SourcePhysicalAliasPass(device,o,prepared.assertCurrent);this.#children.push(this.#alias);
   this.#pack=new SourcePhysicalRowPackPass(device,o,prepared.assertCurrent);this.#children.push(this.#pack);
   this.#inventory=new SourcePhysicalInventoryPass(device,o,prepared.assertCurrent);this.#children.push(this.#inventory);
   this.#reaction=new SourceWholePhysicalReactionPass(device,{...o,algebraTolerance:2e-8,coordinateRepresentation:'relative-material-history'},prepared.assertCurrent);this.#children.push(this.#reaction);
   this.#candidateLayout=device.createBindGroupLayout({entries:[0,1,2].map(binding=>({binding,visibility:GPUShaderStage.COMPUTE,buffer:{type:binding<2?'read-only-storage':'storage'}}))});
   const module=device.createShaderModule({code:physicalMechanicalCandidateWGSL}),layout=device.createPipelineLayout({bindGroupLayouts:[this.#candidateLayout]});
   this.ready=(async()=>{await Promise.all(this.#children.map(c=>c.ready));const errors=(await module.getCompilationInfo()).messages.filter(m=>m.type==='error');
    prepared.assertCurrent();if(errors.length)throw Error(errors.map(m=>`${m.lineNum}:${m.linePos} ${m.message}`).join('\n'));if(this.#closing)throw Error('Physical controller closed during ready');
    this.#candidatePipe=device.createComputePipeline({layout,compute:{module,entryPoint:'mechanical_candidate'}});
   })();this.ready.catch(()=>{});
  }catch(e){this.#owned.forEach(b=>b.destroy());this.#owned=[];for(const c of this.#children)void c.destroy().catch(()=>{});throw e;}
 }
 solveActualPhysicalParent(input){
  if(input.expected?.rawOccurrences===0)return this.solveActualEmptyParent(input);
  if(this.#busy||this.#output||this.#closing)return Promise.reject(Error('Physical controller busy/leased/closed'));
  const handles={originalParent:input.originalParent,current:input.current,history:input.history,raw:input.actualRow128,rawProof:input.actualRawProof};
  const b=structuredClone(input.binding),x=structuredClone(input.expected),incoming=input.observedRawProof?.slice(),prepareRelativeTargets=input.prepareRelativeTargets;
  const isCurrent=input.isCurrent,generation=this.#generation;this.#busy=true;
  const valid=()=>{this.#assertOwner();return !this.#closing&&generation===this.#generation&&isCurrent?.()===true;};
  const work=(async()=>{let mapped=false,packet=null;try{
   await this.ready;if(!valid())throw Error('Physical parent changed during readiness');const o=this.#o,P=o.particles;
   if(!x||!['rawOccurrences','parentToken','sourceToken','bodyGeneration','physicalSubstep','gateRevision'].every(k=>u32(x[k]))||x.rawOccurrences<1||x.rawOccurrences>o.rawCapacity||
    !b?.key||!['generation','frameSequence','parentToken','physicalSubstep','gateRevision'].every(k=>u32(b.key[k]))||
    x.parentToken!==b.key.parentToken||x.physicalSubstep!==b.key.physicalSubstep||x.gateRevision!==b.key.gateRevision||x.sourceToken!==b.sourceToken||x.bodyGeneration!==b.bodyGeneration||
    x.sourceToken!==o.sourceToken||x.bodyGeneration!==o.bodyGeneration||
    b.sourceSha256!==o.sourceSha256||b.bodySha256!==o.bodySha256||b.physicalMassPolicySha256!==o.physicalMassPolicySha256||
    b.declaredFrictionProfileSha256!==this.#frictionSha||
    !['originalParentSha256','currentSha256','historySha256','usedGateSha256','fullRawRow128Sha256'].every(k=>sha.test(b[k]))||b.authenticAllRawReadLease!==true||
    typeof prepareRelativeTargets!=='function'||new Set(Object.values(handles)).size!==5||Object.values(handles).some(h=>!h||this.#owned.includes(h))||
    [handles.originalParent,handles.current,handles.history].some(h=>h.size!==P*16)||handles.raw.size!==o.rawCapacity*128||handles.rawProof.size!==32)throw Error('Unbound physical parent/raw/mass/profile');
   requirePhysicalIncomingRawProof(incoming,x.rawOccurrences);
   const rawHash=await this.#captureRawProof(handles,x,b,incoming,true,valid);
   const e=this.#device.createCommandEncoder();
   for(const[name,target,offset]of[['originalParent',this.#parent,0],['history',this.#history,P*16],['current',this.#current,P*32]]){
    e.copyBufferToBuffer(handles[name],0,target,0,P*16);e.copyBufferToBuffer(target,0,this.#observe,offset,P*16);
   }
   e.copyBufferToBuffer(this.#parent,0,this.#combined,0,P*16);e.copyBufferToBuffer(this.#history,0,this.#combined,P*16,P*16);e.clearBuffer(this.#zero);
   this.#device.queue.submit([e.finish()]);await this.#observe.mapAsync(GPUMapMode.READ);mapped=true;const observed=this.#observe.getMappedRange().slice(0);this.#observe.unmap();mapped=false;
   const parentBytes=new Uint8Array(observed,0,P*16).slice(),historyBytes=new Uint8Array(observed,P*16,P*16).slice(),currentBytes=new Uint8Array(observed,P*32,P*16).slice();
   if(!valid()||(await digest(parentBytes,valid))!==b.originalParentSha256||(await digest(historyBytes,valid))!==b.historySha256||(await digest(currentBytes,valid))!==b.currentSha256)throw Error('Authentic physical XYZ/W snapshot digest mismatch');
   for(const bytes of[parentBytes,historyBytes,currentBytes]){const words=new Uint32Array(bytes.buffer);for(let p=0;p<P;p++)if(words[p*4+3]!==o.physicalInverseMassBits[p])throw Error('Actual parent/history/current physical mass bits changed');}
   const aliases=await this.#alias.inspectAllRaw({raw:this.#raw,rawProof:this.#rawProof,observedRawProof:incoming,expected:x,binding:b,isCurrent:valid});
   if(!valid())throw Error('Physical alias lease changed');const aliasHash=(await digest(concatPhysicalBytes([physicalViewBytes(aliases.records.buffer),physicalViewBytes(aliases.proof.buffer)]),valid));
   packet=await this.#pack.packActualRows({originalParent:this.#parent,current:this.#current,history:this.#history,raw:this.#raw,rawProof:this.#rawProof,
    observedRawProof:incoming,selectedOriginalIds:aliases.selectedOriginalIds,expected:x,binding:{...b,actualGpuAliasKeyReceipt:true,actualAliasKeyReceiptSha256:aliasHash},frictionProfile:o.frictionProfile,isCurrent:valid});
   if(!valid())throw Error('Physical packed parent changed');const R=packet.executedRows,rowsHash=(await digest(packet.actualPhysicalRows,valid)),termsHash=(await digest(packet.actualPhysicalTerms,valid));
   const common={...b,rawOccurrences:x.rawOccurrences,originalRawOccurrences:x.rawOccurrences,originalRawRow128Sha256:b.fullRawRow128Sha256,
    originalRawProofSha256:(await digest(new Uint8Array(incoming.buffer,incoming.byteOffset,incoming.byteLength),valid)),
    actualGpuPhysicalPackProducer:true,packedPhysicalRowsSha256:rowsHash,packedPhysicalTermsSha256:termsHash};
   const expected={...x,rows:R};const inventory={rows:packet.rows,terms:packet.terms,ideal:this.#zero,packProof:packet.packProof,packProofOffset:packet.packProofOffset,
    observedPackProof:packet.proof,expected,binding:{...common,currentIdealSha256:(await digest(new Uint8Array(P*16),valid))},isCurrent:valid};
   const initial=await this.#inventory.selectActualRows(inventory);let selected=initial.selectedPhysicalOrdinals,retained=[],last,graph,fixed;
   const anchors=await prepareRelativeTargets({aliases:structuredClone(aliases),actualExactKeyRecords:this.#alias.keyRecordsBuffer,rows:packet.rows,terms:packet.terms,
    originalParent:this.#parent,history:this.#history,current:this.#current,actualRow128:this.#raw,actualRawProof:this.#rawProof,
    selectedPhysicalOrdinals:initial.selectedPhysicalOrdinals.slice(),selectedOriginalIds:packet.selectedOriginalIds.slice(),expected:structuredClone(x),binding:structuredClone(b),isCurrent:valid});
   if(!valid()||!anchors?.buffer||anchors.buffer===this.#combined||anchors.anchorRange?.rawOccurrences!==x.rawOccurrences||!sha.test(anchors.anchorRange?.authenticProbeReceiptSha256))throw Error('Missing authentic persistent relative anchor resource');
   const combinedBytes=concatPhysicalBytes([physicalViewBytes(parentBytes),physicalViewBytes(historyBytes)]),reactionBinding={...common,
    exclusiveBuffersLease:true,actualGpuBodyBVHAnchorProducer:true,finiteAnchorProbeSha256:anchors.anchorRange.authenticProbeReceiptSha256,
    packedPhysicalJacobianSha256:(await digest(concatPhysicalBytes([physicalViewBytes(packet.actualPhysicalRows),physicalViewBytes(packet.actualPhysicalTerms)]),valid)),
    physicalRhsSha256:rowsHash,packedPhysicalParentHistorySha256:(await digest(combinedBytes,valid)),executedTolerancePolicySha256:PHYSICAL_REACTION_TOLERANCE_POLICY_SHA256,
    executedAnchorPartitionPolicySha256:SOURCE_ANCHOR_PARTITION_POLICY_SHA256};
   const selectionEvidence=[initial];
   for(let round=0;round<o.maximumActiveSetRounds;round++){
    if(!valid())throw Error('Physical controller lost source parent');
    graph=(await graphActualPhysicalRows({rowBytes:packet.actualPhysicalRows,termBytes:packet.actualPhysicalTerms,originalParentBytes:parentBytes,
     selectedPhysicalOrdinals:selected,retainedComponents:retained,expected:{...expected,particles:P},observedPackProof:packet.proof,
     binding:{...common,actualGpuSelectionReadback:true,physicalSelectionReceiptSha256:(await digest(selectionEvidence.map(r=>r.actualInventoryReceiptSha256).join('\n'),valid))},selectionEvidence,
     limits:{maximumRowsPerComponent:o.maximumRowsPerComponent,maximumParticlesPerComponent:o.maximumParticlesPerComponent,maximumComponents:o.componentCapacity}},valid));
    retained=graph.retainedComponents;this.#device.queue.writeBuffer(this.#membership,0,graph.membership);
    const command=this.#device.createCommandEncoder();await this.#reaction.encode(command,{parent:this.#combined,rows:packet.rows,terms:packet.terms,anchors:anchors.buffer,
     anchorRange:anchors.anchorRange,membership:this.#membership,packProof:packet.packProof,packProofOffset:packet.packProofOffset,
     executed:{rows:R,components:graph.components,membershipWords:graph.membership.length,descriptorOffset:graph.descriptorOffset,ownerOffset:graph.ownerOffset,anchorCount:x.rawOccurrences}},reactionBinding,valid);
    this.#device.queue.submit([command.finish()]);last=await this.#reaction.readReceipt();
    if(!valid()||!last.physicalOperatorAccepted)throw Error('Coupled physical normal/tangent response unresolved');
    const reactionHash=(await digest(concatPhysicalBytes([physicalViewBytes(last.status.buffer),physicalViewBytes(last.reaction.buffer),physicalViewBytes(last.idealCombinedContactDelta.buffer)]),valid));
    fixed=await this.#inventory.certifyAllFixedRows({...inventory,originalParent:this.#parent,ideal:this.#reaction.idealCombinedContactDelta,reaction:this.#reaction.reactionBuffer,
     expected:{...expected,algebraicNormalDeficitM:2e-8,algebraicComplementarityResidualM:2e-8},binding:{...common,currentIdealSha256:(await digest(last.idealCombinedContactDelta,valid)),
      actualGpuPhysicalReactionReadback:true,actualReactionReceiptSha256:reactionHash,executedTolerancePolicySha256:PHYSICAL_REACTION_TOLERANCE_POLICY_SHA256}});
    if(!valid())throw Error('ALL-fixed physical certificate stale');
    if(fixed.accepted)break;
    if(!fixed.additionalPhysicalOrdinals.length)throw Error('ALL-fixed physical complementarity unresolved');
    selected=Uint32Array.from(Array.from(new Set([...selected,...fixed.additionalPhysicalOrdinals])).sort((a,b)=>a-b));selectionEvidence.push(fixed);
   }
   if(!fixed?.accepted)throw Error('Explicit physical active-set round limit reached');
   const candidateCommand=this.#device.createCommandEncoder(),group=this.#device.createBindGroup({layout:this.#candidateLayout,entries:
    [this.#parent,this.#reaction.idealCombinedContactDelta,this.#candidate].map((buffer,binding)=>({binding,resource:{buffer}}))});
   const cp=candidateCommand.beginComputePass();cp.setPipeline(this.#candidatePipe);cp.setBindGroup(0,group);cp.dispatchWorkgroups(Math.ceil(P/64));cp.end();
   this.#device.queue.submit([candidateCommand.finish()]);await this.#device.queue.onSubmittedWorkDone();if(!valid())throw Error('Mechanical candidate generation changed');
   // Reobserve borrowed parent/history/current and COMPLETE raw/proof after all
   // asynchronous alias, pack, anchor and response operations. Owned snapshots
   // drive arithmetic; upstream writes still cannot silently authorize commit.
   await this.#captureRawProof(handles,x,b,incoming,false,valid);
   const sealCommand=this.#device.createCommandEncoder();for(const[name,offset]of[['originalParent',0],['history',P*16],['current',P*32]])sealCommand.copyBufferToBuffer(handles[name],0,this.#observe,offset,P*16);
   this.#device.queue.submit([sealCommand.finish()]);await this.#observe.mapAsync(GPUMapMode.READ);mapped=true;
   const sealed=this.#observe.getMappedRange().slice(0);this.#observe.unmap();mapped=false;
   if(!valid()||(await digest(new Uint8Array(sealed,0,P*16),valid))!==b.originalParentSha256||(await digest(new Uint8Array(sealed,P*16,P*16),valid))!==b.historySha256||(await digest(new Uint8Array(sealed,P*32,P*16),valid))!==b.currentSha256)
    throw Error('Actual source parent/history/current changed during physical solve');
   const token=++this.#token;this.#output={token,packToken:packet.token};const physicalPacket=packet;packet=null;
   return{token,candidate:this.#candidate,idealPhysicalContactDelta:this.#reaction.idealCombinedContactDelta,actualReaction:last,actualFixedCertificate:fixed,
    actualAllContactOperatorEvidence:(await actualAllContactOperatorEvidence(physicalPacket,last,reactionBinding,P,{isCurrent:valid})),
    actualAliases:aliases,actualExactKeyRecords:this.#alias.keyRecordsBuffer,actualRaw:this.#raw,actualRawProof:this.#rawProof,
    actualReactionBuffer:this.#reaction.reactionBuffer,actualStatusBuffer:this.#reaction.statusBuffer,rowModeOffsetBytes:this.#reaction.rowModeOffsetBytes,
    physicalRows:physicalPacket,retainedComponents:structuredClone(retained),
    originalParent:this.#parent,history:this.#history,binding:reactionBinding,actualGpuPhysicalResponse:true,
    ownedActualReadLeaseSha256:(await digest(JSON.stringify({originalParentSha256:b.originalParentSha256,historySha256:b.historySha256,currentSha256:b.currentSha256,rawHash,
     usedGateSha256:b.usedGateSha256,sourceSha256:b.sourceSha256,bodySha256:b.bodySha256,key:b.key}),valid)),
    freshAllRawPhysicalCertificateRequired:true,numericalClearanceReconciliationRequired:true,pressureHistoryCommitRequired:true,
    normalReactionAuthoritative:false,productionReady:false};
  }finally{if(mapped)this.#observe.unmap();if(packet)this.#pack.releasePacket(packet.token);this.#busy=false;}})();
  this.#pending=work;work.then(()=>{if(this.#pending===work)this.#pending=null;},()=>{if(this.#pending===work)this.#pending=null;});return work;
 }
 releaseOutput(token){if(!this.#output||this.#output.token!==token)throw Error('Stale mechanical output release');if(this.#output.packToken!==null)this.#pack.releasePacket(this.#output.packToken);this.#output=null;}
 solveActualEmptyParent(input){
  if(this.#busy||this.#output||this.#closing)return Promise.reject(Error('Physical controller busy/leased/closed'));
  const handles={originalParent:input.originalParent,history:input.history,current:input.current,raw:input.actualRow128,rawProof:input.actualRawProof},
   b=structuredClone(input.binding),x=structuredClone(input.expected),incoming=input.observedRawProof?.slice(),certificate=structuredClone(input.actualEmptyCertificate),isCurrent=input.isCurrent,
   generation=this.#generation;this.#busy=true;const valid=()=>{this.#assertOwner();return !this.#closing&&generation===this.#generation&&isCurrent?.()===true;};
  const work=(async()=>{let mapped=false;try{
   await this.ready;const o=this.#o,P=o.particles;
   if(!valid()||!x||x.rawOccurrences!==0||!['parentToken','sourceToken','bodyGeneration','physicalSubstep','gateRevision'].every(k=>u32(x[k]))||
    x.parentToken<1||x.physicalSubstep<1||x.physicalSubstep>40||x.sourceToken!==o.sourceToken||x.bodyGeneration!==o.bodyGeneration||!b?.key||
    !['generation','frameSequence','parentToken','physicalSubstep','gateRevision'].every(k=>u32(b.key[k]))||x.parentToken!==b.key.parentToken||x.physicalSubstep!==b.key.physicalSubstep||x.gateRevision!==b.key.gateRevision||
    b.sourceToken!==o.sourceToken||b.bodyGeneration!==o.bodyGeneration||b.sourceSha256!==o.sourceSha256||b.bodySha256!==o.bodySha256||b.physicalMassPolicySha256!==o.physicalMassPolicySha256||
    b.declaredFrictionProfileSha256!==this.#frictionSha||b.authenticAllRawReadLease!==true||
    [handles.originalParent,handles.current,handles.history].some(h=>!h||h.size!==P*16||this.#owned.includes(h))||!handles.raw||handles.raw.size!==o.rawCapacity*128||!handles.rawProof||handles.rawProof.size!==32||
    new Set(Object.values(handles)).size!==5)throw Error('Unbound authentic empty physical parent');
   const emptyReceipt=(await requireActualEmptyPhysicalInventory(certificate,incoming,b,{isCurrent:valid}));
   await this.#captureRawProof(handles,x,b,incoming,true,valid);
   const observe=async()=>{const e=this.#device.createCommandEncoder();for(const[name,offset]of[['originalParent',0],['history',P*16],['current',P*32]])e.copyBufferToBuffer(handles[name],0,this.#observe,offset,P*16);
    this.#device.queue.submit([e.finish()]);await this.#observe.mapAsync(GPUMapMode.READ);mapped=true;const bytes=this.#observe.getMappedRange().slice(0);this.#observe.unmap();mapped=false;
    for(const[offset,key]of[[0,'originalParentSha256'],[P*16,'historySha256'],[P*32,'currentSha256']]){
     const view=new Uint8Array(bytes,offset,P*16),words=new Uint32Array(view.buffer,view.byteOffset,P*4),floats=new Float32Array(view.buffer,view.byteOffset,P*4);
     if((await digest(view,valid))!==b[key]||floats.some(n=>!Number.isFinite(n)))throw Error('Empty physical parent/history snapshot changed');
     for(let p=0;p<P;p++)if(words[p*4+3]!==o.physicalInverseMassBits[p])throw Error('Empty physical mass bits changed');
    }
    if(!valid())throw Error('Empty physical generation changed');};
   await observe();const copy=this.#device.createCommandEncoder();copy.copyBufferToBuffer(handles.originalParent,0,this.#candidate,0,P*16);copy.copyBufferToBuffer(handles.originalParent,0,this.#parent,0,P*16);
   copy.copyBufferToBuffer(handles.history,0,this.#history,0,P*16);copy.clearBuffer(this.#zero);this.#device.queue.submit([copy.finish()]);
   await this.#device.queue.onSubmittedWorkDone();await this.#captureRawProof(handles,x,b,incoming,false,valid);await observe();
   const token=++this.#token;this.#output={token,packToken:null};return{token,candidate:this.#candidate,idealPhysicalContactDelta:this.#zero,
    actualEmptyPhysicalReceipt:emptyReceipt,actualEmptyCertificate:certificate,originalParent:this.#parent,history:this.#history,binding:b,
    actualGpuPhysicalResponse:false,emptyNormalForceCertified:true,pressureHistoryCommitRequired:true,normalReactionAuthoritative:false,productionReady:false};
  }finally{if(mapped)this.#observe.unmap();this.#busy=false;}})();
  this.#pending=work;work.then(()=>{if(this.#pending===work)this.#pending=null;},()=>{if(this.#pending===work)this.#pending=null;});return work;
 }
 async #captureRawProof(handles,x,b,incoming,copyPrivate,valid){
  let mapped=false;try{
   const e=this.#device.createCommandEncoder();
   e.copyBufferToBuffer(handles.rawProof,0,this.#packetObserve,0,32);if(x.rawOccurrences)e.copyBufferToBuffer(handles.raw,0,this.#packetObserve,32,x.rawOccurrences*128);
   if(copyPrivate){e.copyBufferToBuffer(handles.rawProof,0,this.#rawProof,0,32);if(x.rawOccurrences)e.copyBufferToBuffer(handles.raw,0,this.#raw,0,x.rawOccurrences*128);}
   this.#device.queue.submit([e.finish()]);await this.#packetObserve.mapAsync(GPUMapMode.READ);mapped=true;
   const bytes=this.#packetObserve.getMappedRange(0,32+x.rawOccurrences*128).slice(0),actualProof=new Uint32Array(bytes,0,8),rawHash=(await digest(new Uint8Array(bytes,32),valid));
   if(!valid()||actualProof.some((v,i)=>v!==incoming[i])||rawHash!==b.fullRawRow128Sha256)throw Error('Actual ALLraw/proof mutated or does not match authentic source receipt');
   requirePhysicalIncomingRawProof(actualProof,x.rawOccurrences);return rawHash;
  }finally{if(mapped)this.#packetObserve.unmap();}
 }
 invalidate(){this.#generation++;this.#children.forEach(c=>c.invalidate());}
 destroy(){if(this.#closePromise)return this.#closePromise;this.#closing=true;this.invalidate();this.#closePromise=(async()=>{const errors=[];
  await this.ready.catch(e=>errors.push(e));if(this.#pending)await this.#pending.catch(e=>errors.push(e));
  for(const c of this.#children)await c.destroy().catch(e=>errors.push(e));try{await this.#device.queue.onSubmittedWorkDone();}catch(e){errors.push(e);}
  finally{for(const b of this.#owned)try{b.destroy();}catch(e){errors.push(e);}this.#owned=[];this.#output=null;}
  if(errors.length)throw new AggregateError(errors,'Physical mechanical controller cleanup failed');})();return this.#closePromise;}
}
