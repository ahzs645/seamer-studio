/** Per-physical-parent ownership, separate from reusable backend storage. Every
 * ordered map/consumer finishes before close; queue failure still frees ALL owned
 * resources. No unbounded closed-resource history. */
export class JointParentResourceLease{
 constructor(device){this.device=device;this.buffers=new Set();this.resources=new Set();this.closePromise=null;this.closing=false;}
 addBuffer(buffer){if(this.closing)throw Error('Closed parent lease');this.buffers.add(buffer);return buffer;}
 addResource(resource){if(this.closing)throw Error('Closed parent lease');this.resources.add(resource);return resource;}
 async release(resource){if(!this.resources.has(resource))throw Error('Unknown parent resource');if(resource.dispose)await resource.dispose();else await resource.destroy();this.resources.delete(resource);}
 releaseBuffer(buffer){if(!this.buffers.has(buffer))throw Error('Unknown parent buffer');buffer.destroy();this.buffers.delete(buffer);}
 close(){if(this.closePromise)return this.closePromise;this.closing=true;this.closePromise=(async()=>{const errors=[];try{await this.device.queue.onSubmittedWorkDone();}catch(e){errors.push(e);}for(const resource of this.resources){try{if(resource.dispose)await resource.dispose();else await resource.destroy();}catch(e){errors.push(e);}}this.resources.clear();for(const buffer of this.buffers){try{buffer.destroy();}catch(e){errors.push(e);}}this.buffers.clear();if(errors.length)throw new AggregateError(errors,'Physical parent drained with cleanup failures');})();return this.closePromise;}
}
