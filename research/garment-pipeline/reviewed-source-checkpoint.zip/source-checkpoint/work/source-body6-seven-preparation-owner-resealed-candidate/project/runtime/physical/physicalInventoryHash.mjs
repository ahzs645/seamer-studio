import {physicalBytesSha256} from './portablePhysicalHashes.mjs';
import {copyData,equalData} from './snapshots.mjs';
/** Same raw proof bytes + mask bytes + insertion-order JSON binding as held Node.
 * Explicitly not canonical sorted JSON and not a full-frame hash domain. */
export async function physicalInventoryReceiptSha256(proof,mask,binding){if(!(proof instanceof Uint32Array)||!(mask instanceof Uint32Array)||!binding)throw Error('Missing actual inventory receipt bytes');const original={proof,mask,binding},snapshot=copyData(original),p=new Uint8Array(snapshot.proof.buffer),m=new Uint8Array(snapshot.mask.buffer),b=new TextEncoder().encode(JSON.stringify(snapshot.binding)),all=new Uint8Array(p.length+m.length+b.length);all.set(p);all.set(m,p.length);all.set(b,p.length+m.length);const sha=await physicalBytesSha256(all);if(!equalData(original,snapshot))throw Error('Actual inventory inputs mutated across hash');return sha;}
