/** Concrete copied engine delivery using the SAME SOURCE app/private registry
 * graph. This is an eventual startup hook, not a live/default solver promotion. */
import {createActualSourceJointEngineFactory} from './SourceJointWholeEngineBackend.mjs';
import {createAppSourceDelivery} from './appDelivery.ts';
import {createAppRefinedScope} from './refined/appEntry.ts';
import {prepareActualComponentGeometry} from './prepareComponentGeometry.mjs';
import {loadApprovedComponentArtifacts} from './approvedArtifacts.mjs';
import {equalData} from './refined/bytes.mjs';
import type {AppNumericalOwner} from './appFactory.ts';
interface Creation {
 device:GPUDevice;simulation:{particleCount:number};isCurrent:()=>boolean;
 captureRefinedRuntimeState:(key:unknown)=>unknown;
}
export interface EngineSceneOwner extends AppNumericalOwner {
 providerOptions:Record<string,unknown>;
 simulationConfig:Record<string,unknown>;
 /** Real operator implementation identity and owned body-anchor/input adapter,
  * not a test flag, fabricated geometry provider or caller approval record. */
 implementationSha256:string;
 preparePhysicalReactionInput:(input:unknown)=>Promise<unknown>;
}
export async function prepareAppSourceEngineDelivery(device:GPUDevice,scope:string,readCurrentOwner:(creation?:Creation)=>EngineSceneOwner) {
 if(scope!=='fresh-source-physical-profile')return null;
 const first=readCurrentOwner(),prepared=first.prepared,pattern=first.pattern,implementation=first.implementationSha256,physicalInput=first.preparePhysicalReactionInput;
 if(!/^[a-f0-9]{64}$/.test(implementation)||typeof physicalInput!=='function')throw Error('Actual engine implementation/body-anchor adapter required');
 const current=()=>{const now=readCurrentOwner();return now.pattern===pattern&&now.prepared===prepared&&now.stillCurrent()===true&&now.implementationSha256===implementation&&now.preparePhysicalReactionInput===physicalInput;};
 const assertCurrent=()=>{if(!current())throw Error('App engine startup generation changed');return true;};
 assertCurrent();const delivery=createAppSourceDelivery(()=>readCurrentOwner());
 const reaction=await delivery.createPhysical(device,scope);
 try {
  assertCurrent();if(!reaction)throw Error('Owned physical provider unavailable');
  const factory=createActualSourceJointEngineFactory({
   implementationSha256:implementation,physicalReactionProvider:reaction,
   preparePhysicalReactionInput:physicalInput,
   async prepareActualGeometry(creation:Creation) {
    assertCurrent();if(!creation.isCurrent())throw Error('Engine geometry creation changed');
    const owner=readCurrentOwner(creation),binding=owner.sourceBinding;
    if(owner.prepared!==prepared||owner.pattern!==pattern)throw Error('Engine creation does not own this app preparation');
    const adapter=createAppRefinedScope(()=>({...readCurrentOwner(creation),scope:'fresh-source'}));
    const geometry=await prepareActualComponentGeometry({prepared,sourceBinding:binding,isCurrent:()=>assertCurrent()&&creation.isCurrent(),refinedAdapter:adapter});
    assertCurrent();if(!geometry||!creation.isCurrent())throw Error('Engine geometry creation changed');
    const artifacts=await loadApprovedComponentArtifacts(()=>assertCurrent()&&creation.isCurrent());
    assertCurrent();return {actualRefinedChildContextVerified:!!geometry.refinedPreparation,
     backendOptions:{...owner.backendOptions,...geometry,styleId:owner.styleId,sourceExecutionBytes:owner.sourceExecutionBytes,sourceExecutionEncoding:owner.sourceExecutionEncoding,
      finiteComponentEvidenceArtifact:artifacts.finite.bytes,approvedFiniteComponentEvidenceSha256:artifacts.finite.sha256,
      seededNumericalDeviceValidationArtifact:artifacts.numerical.bytes,approvedSeededNumericalDeviceValidationSha256:artifacts.numerical.sha256}};
   },
   async createSourceNumericalOwner(creation:Creation,requested:Record<string,unknown>) {
    assertCurrent();if(!creation.isCurrent())throw Error('Actual numerical engine creation changed');
    const owner=readCurrentOwner(creation),binding=owner.sourceBinding;
    if(!equalData(requested.binding,binding))throw Error('Engine/app actual source binding differs');
    const options={...owner.backendOptions,
     // ONLY actual internal engine observation callbacks are handed through;
     // generated packets/approval artifacts are recreated privately in-app.
     consumeActualEnumeration:requested.consumeActualEnumeration};
    const capture=(...args:unknown[])=>{if(!creation.isCurrent())throw Error('Actual controller creation changed');return creation.captureRefinedRuntimeState(args[0]);};
    const callback=()=>assertCurrent()&&creation.isCurrent();
    const scoped=createAppSourceDelivery(()=>({...readCurrentOwner(creation),backendOptions:options,captureRefinedRuntimeState:capture,stillCurrent:callback}));
    const result=await scoped.createNumerical(creation.device,'fresh-source-equal-layer');
    if(!result)throw Error('Owned numerical provider unavailable');
    try{assertCurrent();if(!creation.isCurrent())throw Error('Actual numerical engine creation changed');return result;}
    catch(error){try{await result.destroy();}catch(cleanup){throw new AggregateError([error,cleanup],'Stale numerical engine handoff cleanup failed',{cause:error});}throw error;}
   },
  });
  // These inputs come from the actual SOURCE engine invocation, before receipt
  // generation. They must never be reconstructed from an accepted receipt.
  let backend:ReturnType<typeof factory>|null=null,frameOwner:Record<string,unknown>|null=null;
  const ownedFactory:typeof factory=creation=>{
   assertCurrent();if(backend)throw Error('App source backend factory already consumed');
   const actual=factory(creation);backend=actual;
   const begin=actual.beginFrame.bind(actual);
   actual.beginFrame=(input:Record<string,unknown>)=>{
    const captured=structuredClone(input);frameOwner=null;
    return begin(input).then(()=>{assertCurrent();if(!creation.isCurrent())throw Error('App frame owner changed');frameOwner=captured;});
   };
   const invalidate=actual.invalidate.bind(actual),reset=actual.resetHistory.bind(actual),destroy=actual.destroy.bind(actual);
   actual.invalidate=()=>{frameOwner=null;invalidate();};
   actual.resetHistory=()=>{frameOwner=null;reset();};
   actual.destroy=()=>{frameOwner=null;return destroy();};
   return actual;
  };
  assertCurrent();let disposed=false;
  return Object.freeze({sourceJointBackendFactory:ownedFactory,
   captureExecutedFrameOwner(){assertCurrent();if(!backend||!frameOwner||backend.closed||backend.invalidated||!backend.creation.isCurrent())throw Error('Actual app frame owner unavailable');return Object.freeze({frame:structuredClone(frameOwner),providerImplementationSha256:reaction.implementationSha256,validation:structuredClone(reaction.deviceValidation),backendImplementationSha256:implementation});},
   /** Scene startup transfers this provider to simulation only after its own
    * generation check. On failed/superseded startup this hook must be awaited. */
   async disposeFailedStartup(){if(disposed)return;disposed=true;await reaction.destroy();},
   scope:'approved-components-only',fullFitAccepted:false,
  });
 } catch(error) {
  try{await reaction?.destroy();}catch(cleanup){throw new AggregateError([error,cleanup],'App source engine startup cleanup failed',{cause:error});}
  throw error;
 }
}
