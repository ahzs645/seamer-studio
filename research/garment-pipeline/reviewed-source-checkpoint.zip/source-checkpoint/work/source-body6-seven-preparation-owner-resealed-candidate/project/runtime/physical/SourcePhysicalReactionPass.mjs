/** NEW copied device proposal. Complete finite GPU producer + physical-only
 * pack + authentic finite anchor queries are required. No shipping integration,
 * no device-tested readiness, no native allocations. Explicit manual layout
 * preserves eight bindings even when an entrypoint does not read one of them. */
import {sourcePhysicalReactionWGSL}from'./physicalReactionWGSL.mjs';
import{requirePhysicalTolerancePolicy}from'./tolerancePolicy.mjs';
const SHA=/^[a-f0-9]{64}$/;
const u32=x=>Number.isSafeInteger(x)&&x>=0&&x<=0xffffffff;
const hashes=['originalParentSha256','historySha256','usedGateSha256','sourceSha256','bodySha256','fullRawRow128Sha256','packedPhysicalJacobianSha256','physicalMassPolicySha256','declaredFrictionProfileSha256','physicalRhsSha256','finiteAnchorProbeSha256','executedTolerancePolicySha256'];
const clone=x=>structuredClone(x);
export function decodePhysicalReactionReceipt(status,reaction,ideal,options,binding){
 if(!(status instanceof Uint32Array)||status.length!==16+options.components*8||!(reaction instanceof Float32Array)||reaction.length!==options.rows*4||!(ideal instanceof Float32Array)||ideal.length!==options.particles*4||reaction.some(x=>!Number.isFinite(x))||ideal.some(x=>!Number.isFinite(x)))throw Error('Incomplete/nonfinite actual physical receipt');
 if(status[0]===0&&[options.rows,7,options.terms,options.components,binding.key.parentToken,binding.sourceToken,1].some((v,k)=>status[k+1]!==v))throw Error('Actual physical packproof header mismatch');
 const tolerances=requirePhysicalTolerancePolicy(options,binding);const components=[];for(let c=0;c<options.components;c++){const offset=8+c*8,net=new Float32Array(status.slice(offset+1,offset+2).buffer)[0];if(status[offset]===0&&(!Number.isFinite(net)||net<0||net>.005||status[offset+2]<1||status[offset+2]>options.sweeps||status[offset+3]!==binding.key.parentToken))throw Error('Actual physical component receipt mismatch');const residuals=new Float32Array(status.slice(offset+4,offset+8).buffer);const residualNames=Object.keys(tolerances);if(status[offset]===0&&(residuals.some(x=>!Number.isFinite(x)||x<0)||residuals[3]!==Math.fround(options.algebraTolerance)||residualNames.some((name,i)=>residuals[i]>tolerances[name])))throw Error('Actual physical residual exceeded executed tolerance policy');components.push({flags:status[offset],maximumNetM:net,sweeps:status[offset+2],parentToken:status[offset+3],...Object.fromEntries(residualNames.map((name,i)=>[name,residuals[i]]))});}
 for(let r=0;r<options.rows;r++)if(reaction[r*4]<0||Array.from(reaction.subarray(r*4,r*4+4)).some(x=>!Number.isFinite(x/(options.dt*options.dt))))throw Error('Invalid actual physical force/multiplier');
 for(let p=0;p<options.particles;p++)if(ideal[p*4+3]!==0)throw Error('Physical ideal W lane changed');
 return{physicalOperatorAccepted:status[0]===0&&components.every(c=>c.flags===0),components,normalMultiplierUnit:'kg-m'};
}
export function createSourcePhysicalReactionPass(device,scope,...args){return scope==='fresh-source-physical-profile'?new SourcePhysicalReactionPass(device,...args):null;}
export class SourcePhysicalReactionPass{
 constructor(device,options){
  this.device=device;this.options=Object.freeze(clone(options));this.closed=false;this.closing=false;this.running=false;this.encoding=false;this.awaitingReceipt=false;this.pendingEncode=null;this.pendingMap=null;this.closePromise=null;this.generation=0;this.token=0;this.bound=null;this.owned=[];
  const {particles,rows,terms,components,membershipWords,anchorCount,sweeps,algebraTolerance,dt}=this.options;
  if(![particles,rows,terms,components,membershipWords,anchorCount,sweeps].every(u32)||particles<1||rows<1||rows>32768||terms!==rows*6||components<1||sweeps<1||sweeps>8192||!Number.isFinite(algebraTolerance)||algebraTolerance<=0||!Number.isFinite(dt)||dt<=0||dt*dt===0||!Number.isFinite(dt*dt)||device.limits.maxStorageBuffersPerShaderStage<8)throw Error('Invalid bounded source pressure policy');
  const usage=GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST;
  const alloc=(label,size,use=usage)=>{if(size>device.limits.maxStorageBufferBindingSize)throw Error('Complete physical reaction exceeds binding limit');const b=device.createBuffer({label:'source-physical-reaction:'+label,size,usage:use});this.owned.push(b);return b;};
  try{
   this.packProofOffset=8+8*components;this.reaction=alloc('physical-normal-and-tangent-kg-m',rows*16);this.ideal=alloc('direct-combined-ideal-metres',particles*16);this.status=alloc('physical-KKT-and-actual-pack-proof',(this.packProofOffset+8)*4);this.params=alloc('private-bound-physical-policy',96,GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST);
   this.readback=alloc('owned-reaction-receipt',this.status.size+this.reaction.size+this.ideal.size,GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ);
   const entries=Array.from({length:9},(_,binding)=>({binding,visibility:GPUShaderStage.COMPUTE,buffer:{type:binding===8?'uniform':binding<5?'read-only-storage':'storage'}}));this.layout=device.createBindGroupLayout({entries});this.pipelineLayout=device.createPipelineLayout({bindGroupLayouts:[this.layout]});
   const module=device.createShaderModule({code:sourcePhysicalReactionWGSL});this.ready=(async()=>{const info=await module.getCompilationInfo();const errors=info.messages.filter(m=>m.type==='error');if(errors.length)throw Error(errors.map(m=>`${m.lineNum}:${m.linePos} ${m.message}`).join('\n'));if(this.closing)throw Error('Physical reaction closed during compile');this.pipes={};for(const entryPoint of['seal_header','solve','validate_output'])this.pipes[entryPoint]=device.createComputePipeline({layout:this.pipelineLayout,compute:{module,entryPoint}});})();this.ready.catch(()=>{});
  }catch(error){for(const b of this.owned)b.destroy();this.owned=[];throw error;}
 }
 get snapshotBytes(){return this.reaction.size+this.ideal.size+this.status.size;}
 encodeSnapshot(encoder,target,offset=0){if(this.closed||this.closing||this.running||this.encoding||this.awaitingReceipt)throw Error('Pressure snapshot while closed/readback busy');let at=offset;for(const b of[this.reaction,this.ideal,this.status]){encoder.copyBufferToBuffer(b,0,target,at,b.size);at+=b.size;}}
 encodeRestore(encoder,source,offset=0){if(this.closed||this.closing||this.running||this.encoding||this.awaitingReceipt)throw Error('Pressure restore while closed/readback busy');this.invalidate();let at=offset;for(const b of[this.reaction,this.ideal,this.status]){encoder.copyBufferToBuffer(source,at,b,0,b.size);at+=b.size;}}
 invalidate(){this.generation++;this.bound=null;if(!this.encoding&&!this.running)this.awaitingReceipt=false;}
 encode(encoder,input,binding,isCurrent){
  if(this.closed||this.closing||this.running||this.encoding||this.awaitingReceipt)return Promise.reject(Error('Concurrent/closed physical reaction encode lease'));
  const b=clone(binding),handles={...input},generation=this.generation;
  this.encoding=true;this.awaitingReceipt=true;
  const work=(async()=>{try{await this.ready;
  if(this.closed||this.closing||this.running||generation!==this.generation||isCurrent()!==true||hashes.some(k=>!SHA.test(b[k]))||!b.key||!Object.values(b.key).every(u32)||b.key.physicalSubstep<1||b.key.physicalSubstep>40||!b.key.parentToken||b.exclusiveBuffersLease!==true||b.actualGpuPhysicalPackProducer!==true||b.actualGpuFiniteAnchorProducer!==true)throw Error('Missing immutable actual source physical reaction lease');
  const expected={parent:this.options.particles*16,rows:this.options.rows*48,terms:this.options.terms*32,anchors:this.options.anchorCount*16,membership:this.options.membershipWords*4,packProof:32};
  for(const [key,size]of Object.entries(expected))if(!handles[key]||handles[key].size<size||this.owned.includes(handles[key]))throw Error('Incomplete/aliased authentic physical inputs');
  // Borrowed writable input aliases are disallowed even at a nonzero offset.
  if(new Set(Object.values(handles)).size!==Object.keys(handles).length)throw Error('Aliased physical input handles');
  const words=new Uint32Array(24);words.set([this.options.particles,this.options.rows,this.options.terms,this.options.components,this.options.descriptorOffset,this.options.membershipWords,this.options.ownerOffset,this.options.anchorCount,this.options.sweeps,b.key.parentToken,b.sourceToken,0]);
  new Float32Array(words.buffer).set([.001,.005,this.options.algebraTolerance,this.options.dt],12);words.set([b.bodyGeneration,b.key.gateRevision,b.rawOccurrences,this.packProofOffset],16);
  if(![this.options.descriptorOffset,this.options.ownerOffset,b.sourceToken,b.bodyGeneration,b.rawOccurrences].every(u32))throw Error('Unbound physical operator schema');
  requirePhysicalTolerancePolicy(this.options,b);this.device.queue.writeBuffer(this.params,0,words);encoder.clearBuffer(this.ideal);encoder.clearBuffer(this.reaction);encoder.clearBuffer(this.status);encoder.copyBufferToBuffer(handles.packProof,handles.packProofOffset??0,this.status,this.packProofOffset*4,32);
  const buffers=[handles.parent,handles.rows,handles.terms,handles.anchors,handles.membership,this.reaction,this.ideal,this.status,this.params];const group=this.device.createBindGroup({layout:this.layout,entries:buffers.map((buffer,binding)=>({binding,resource:{buffer}}))});
  for(const [entryPoint,groups]of[['seal_header',1],['solve',this.options.components],['validate_output',Math.ceil(this.options.particles/64)]]){const p=encoder.beginComputePass();p.setPipeline(this.pipes[entryPoint]);p.setBindGroup(0,group);p.dispatchWorkgroups(groups);p.end();}
  this.bound={binding:b,token:++this.token,generation,isCurrent};
  }catch(error){this.awaitingReceipt=false;this.bound=null;throw error;}finally{this.encoding=false;}})();
  this.pendingEncode=work;work.then(()=>{if(this.pendingEncode===work)this.pendingEncode=null;},()=>{if(this.pendingEncode===work)this.pendingEncode=null;});return work;
 }
 async readReceipt(){
  if(this.closed||this.closing||this.running||this.encoding||!this.awaitingReceipt||!this.bound)throw Error('Missing/concurrent physical reaction receipt');this.running=true;const bound=this.bound;
  const work=(async()=>{let mapped=false;try{const e=this.device.createCommandEncoder();let offset=0;for(const b of[this.status,this.reaction,this.ideal]){e.copyBufferToBuffer(b,0,this.readback,offset,b.size);offset+=b.size;}this.device.queue.submit([e.finish()]);await this.readback.mapAsync(GPUMapMode.READ);mapped=true;const bytes=this.readback.getMappedRange().slice(0);if(this.closed||this.closing||bound!==this.bound||bound.generation!==this.generation||bound.isCurrent()!==true)throw Error('Physical source lease changed during readback');const status=new Uint32Array(bytes,0,this.status.size/4),reaction=new Float32Array(bytes,this.status.size,this.reaction.size/4),ideal=new Float32Array(bytes,this.status.size+this.reaction.size,this.ideal.size/4),decoded=decodePhysicalReactionReceipt(status,reaction,ideal,this.options,bound.binding);return{...decoded,binding:clone(bound.binding),status:status.slice(),reaction:reaction.slice(),idealContactDelta:ideal.slice(),actualGpuReactionReadback:true,normalReactionAuthoritative:false,frictionReconciled:false,freshAllRawCertificateRequired:true,published:false};}finally{if(mapped)this.readback.unmap();this.running=false;this.awaitingReceipt=false;}})();this.pendingMap=work;try{return await work;}finally{if(this.pendingMap===work)this.pendingMap=null;}
 }
 destroy(){if(this.closePromise)return this.closePromise;this.closing=true;this.invalidate();this.closePromise=(async()=>{const errors=[];await this.ready.catch(e=>errors.push(e));if(this.pendingEncode)await this.pendingEncode.catch(e=>errors.push(e));if(this.pendingMap)await this.pendingMap.catch(e=>errors.push(e));try{await this.device.queue.onSubmittedWorkDone();}catch(e){errors.push(e);}finally{for(const b of this.owned)try{b.destroy();}catch(e){errors.push(e);}this.owned=[];this.closed=true;}if(errors.length)throw new AggregateError(errors,'Physical reaction cleanup failed');})();return this.closePromise;}
}
