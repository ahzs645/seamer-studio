import{physicalBytesSha256}from'./portablePhysicalHashes.mjs';
import{copyData,equalData}from'./snapshots.mjs';
async function profileHash(profile){
 if(!profile||!Number.isFinite(profile.muStatic)||!Number.isFinite(profile.muKinetic)||profile.muStatic<profile.muKinetic||profile.muKinetic<0||profile.declaredApproximate!==true)
  throw Error('Missing declared approximate physical friction profile');
 return physicalBytesSha256(new TextEncoder().encode(JSON.stringify({encoding:'declared-approximate-coulomb-profile-v1',muStatic:profile.muStatic,muKinetic:profile.muKinetic})));
}

export async function sourceDeclaredFrictionProfileSha256(profile){const snapshot=copyData(profile),hash=await profileHash(snapshot);if(!equalData(profile,snapshot))throw Error("Declared friction profile changed across hash");return hash;}
