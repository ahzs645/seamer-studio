/** Portable binding validator. No filesystem, device creation, or fit authority.
 * The caller supplies independently trusted execution context and the actual
 * accepted getter value. This cannot establish GPU origin from invented data.
 */
import{stringifyPhysicalReceipt,physicalReceiptListSha256,physicalFrameReceiptSha256,PHYSICAL_RECEIPT_ENCODING}from'./vendor/frameReceiptCodec.mjs';
import{verifyPhysicalCertificateQueryChain}from'./physicalCertificateQueryChain.mjs';
import{requireSourceBodyFacetTrajectoryProof}from'./frame-proof/bodyFacetProof.mjs';
import{requireSourceSelfIntervalTrajectoryProof}from'./frame-proof/selfIntervalProof.mjs';
export const PHYSICAL_CERTIFICATE_HASH_ENCODING='canonical-sorted-json-v2-empty-contact-bounds';
export function canonicalPhysicalCertificateText(value){
 const empty=value?.rawOccurrences===0&&value?.allRawOccurrences===0&&value?.validatedOccurrences===0&&value?.complete===true&&value?.unsupported===0&&value?.unsupportedFlags===0&&value?.clearanceDeficits===0&&value?.strictClearanceDeficits===0&&value?.allCurrentRawOccurrencesChecked===true&&value?.actualGpuFiniteProducer===true;
 const boundFields=new Set(['minimumLowerBoundM','minimumClearanceLowerBoundM']);
 const visit=(x,path=[])=>{
  if(path.length===1&&boundFields.has(path[0])){
   if(x===Infinity&&empty)return{'$physicalClearanceBound':'positive-infinity-no-contact-rows'};
   if(typeof x!=='number'||!Number.isFinite(x))throw Error('Invalid nonempty physical certificate clearance bound');
  }
  if(x===null||typeof x==='boolean'||typeof x==='string')return x;
  if(typeof x==='number'){if(!Number.isFinite(x))throw Error('Nonfinite physical certificate value');return x;}
  if(ArrayBuffer.isView(x)&&!(x instanceof DataView))return Array.from(x,(v,i)=>visit(v,[...path,i]));
  if(Array.isArray(x))return x.map((v,i)=>visit(v,[...path,i]));
  if(x&&typeof x==='object'&&(Object.getPrototypeOf(x)===Object.prototype||Object.getPrototypeOf(x)===null))return Object.fromEntries(Object.keys(x).sort().map(k=>[k,visit(x[k],[...path,k])]));
  throw Error('Unsupported/undefined physical certificate value');
 };return JSON.stringify(visit(value));
}
const requireValue=(ok,message)=>{if(!ok)throw Error(message);};
const sha=v=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
const integer=v=>Number.isSafeInteger(v)&&v>=0&&v<=0xffffffff;
export async function byteSha256(bytes){
 requireValue(bytes instanceof Uint8Array,'Exact byte view required');
 return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
}
export const physicalCertificateSha256=value=>byteSha256(new TextEncoder().encode(canonicalPhysicalCertificateText(value)));
const same=(a,b)=>stringifyPhysicalReceipt(a)===stringifyPhysicalReceipt(b);
function copiedSamples(samples,count){
 requireValue(Array.isArray(samples)&&samples.length===41,'Exactly 41 actual samples required');
 return samples.map(v=>{requireValue(v instanceof Float32Array&&v.length===count*4,'Actual Float32 vec4 sample required');requireValue(v.every(Number.isFinite),'Nonfinite actual sample');return v.slice();});
}
function floatBytes(sample){const bytes=new Uint8Array(sample.length*4),view=new DataView(bytes.buffer);sample.forEach((v,i)=>view.setFloat32(i*4,v,true));return bytes;}
function activationBytes(a){
 requireValue(a&&integer(a.revision)&&integer(a.sewnUpTo),'Actual used activation required');
 requireValue((Array.isArray(a.activeSeams)||a.activeSeams instanceof Uint32Array)&&a.activeSeams.length>0&&Array.from(a.activeSeams).every(v=>v===0||v===1),'Actual seam mask required');
 const bytes=new Uint8Array((4+a.activeSeams.length)*8),view=new DataView(bytes.buffer);
 [1,a.revision,a.sewnUpTo,a.activeSeams.length,...a.activeSeams].forEach((v,i)=>view.setFloat64(i*8,v,true));return bytes;
}
async function traceBinding(samples){
 const bytes=samples.map(floatBytes),whole=new Uint8Array(bytes.reduce((n,b)=>n+b.length,0));let at=0;
 for(const b of bytes){whole.set(b,at);at+=b.length;}
 return{sampleSha256s:await Promise.all(bytes.map(byteSha256)),binarySha256:await byteSha256(whole)};
}

export async function validateActualSourceFrameCommit(input){
 // Seal every input before the first asynchronous digest.
 requireValue(input&&typeof input==='object','Actual frame inputs required');
 const context=structuredClone(input.context),receipt=structuredClone(input.receipt),accepted=structuredClone(input.acceptedReceipt),proof=structuredClone(input.proof);
 requireValue(context&&integer(context.particleCount)&&context.particleCount>0&&integer(context.bodyFaceCount)&&context.bodyFaceCount>0&&integer(context.generation)&&integer(context.frameSequence)&&context.frameSequence>0,'Independent physical execution context required');
 const positions=copiedSamples(input.positionSamples,context.particleCount),deltas=copiedSamples(input.physicalDeltaSamples,context.particleCount);
 const hashes=['sourceSha256','bodySha256','topologySha256','workerContextSha256','usedGateSha256','physicalMassPolicySha256','sourceDeltaPolicySha256','backendImplementationSha256','pressureProviderImplementationSha256','pressureDeviceReceiptSha256','physicalPackShaderSha256','reactionShaderSha256','tolerancePolicySha256','anchorPartitionPolicySha256'];
 for(const key of hashes)requireValue(sha(context[key]),'Missing independent execution digest: '+key);
 requireValue((Array.isArray(context.physicalInverseMassBitsFloat32)||context.physicalInverseMassBitsFloat32 instanceof Uint32Array)&&context.physicalInverseMassBitsFloat32.length===context.particleCount&&Array.from(context.physicalInverseMassBitsFloat32).every(integer),'Authentic physical inverse-mass bits required');
 const baseBits=new Uint32Array(positions[0].buffer);
 for(let s=0;s<41;s++){
  const bits=new Uint32Array(positions[s].buffer);
  for(let p=0;p<context.particleCount;p++){
   requireValue(bits[p*4+3]===context.physicalInverseMassBitsFloat32[p]&&positions[s][p*4+3]>=0,'Physical inverse-mass bits changed');
   if(positions[0][p*4+3]===0)for(let a=0;a<3;a++)requireValue(bits[p*4+a]===baseBits[p*4+a],'Fixed XYZ bits changed');
   requireValue(Object.is(deltas[s][p*4+3],0),'Physical delta W must be positive zero');
  }
 }
 requireValue(receipt?.kind==='actual-source-joint-frame-commit-v1'&&receipt.accepted===true&&receipt.fullFitAccepted===false,'Actual accepted commit receipt required');
 requireValue(accepted?.kind===receipt.kind&&same(receipt,accepted),'Actual accepted getter differs from exported receipt');
 requireValue(receipt.generation===context.generation&&receipt.frameSequence===context.frameSequence&&receipt.physicalSubsteps===40&&receipt.geometrySamples===41,'Commit physical generation/frame mismatch');
 for(const key of ['sourceDeltaPolicySha256','backendImplementationSha256','pressureProviderImplementationSha256'])requireValue(receipt[key]===context[key],'Commit execution identity mismatch: '+key);
 requireValue(same(receipt.usedActivation,context.usedActivation)&&same(proof?.seamActivation,context.usedActivation),'Foreign proof-used sewing mask');
 const commitSha=receipt.frameCommitSha256;requireValue(sha(commitSha),'Missing actual commit SHA');
 requireValue(receipt.frameReceiptEncoding===PHYSICAL_RECEIPT_ENCODING,'Missing executed frame receipt v3 encoding');
 requireValue(await physicalFrameReceiptSha256(receipt)===commitSha,'Retained commit SHA changed content');
 const q=await traceBinding(positions),d=await traceBinding(deltas),worker=receipt.verifiedWorkerRequest;
 requireValue(proof?.safe===true&&proof.finite===true&&proof.bodyClosed===true&&proof.trajectory?.valid===true&&proof.trajectory.expectedSubSteps===40&&proof.trajectory.inspectedSubsteps===40,'Missing actual clear all41 geometry proof');
  for(const key of ['insideParticleCount','bodyCrossingTriangleCount','selfCrossingPairCount','sweptBodyCrossingParticleCount','rayDisagreementCount'])requireValue(proof[key]===0,'Geometry guard failure: '+key);
  const sourceBodyFacetTrajectory=requireSourceBodyFacetTrajectoryProof(proof);
  const sourceSelfIntervalTrajectory=requireSourceSelfIntervalTrajectoryProof(proof);
 requireValue(worker?.encoding==='source-guard-actual-byte-receipt-v1'&&worker.expectedSubSteps===40&&integer(worker.requestId)&&worker.requestId>0&&worker.workerContextSha256===context.workerContextSha256,'Foreign actual Worker context');
 requireValue(same(worker,proof.verifiedWorkerRequest)&&same(worker.sampleSha256s,q.sampleSha256s)&&worker.startPositionsSha256===q.sampleSha256s[0]&&worker.finalPositionsSha256===q.sampleSha256s[40],'Actual q41 bytes differ from verified Worker request');
 requireValue(worker.activationSha256===await byteSha256(activationBytes(context.usedActivation)),'Worker activation digest mismatch');
 const delta=receipt.verifiedPhysicalDeltaTrace;
 requireValue(delta?.encoding==='float32-le-vec4-physical-delta41-v1'&&delta.particleCount===context.particleCount&&delta.sampleCount===41&&delta.physicalSubsteps===40&&delta.sample0Meaning==='frame-entry-ledger-not-assumed-zero','Missing executed delta41 binding');
 requireValue(same(delta.sampleSha256s,d.sampleSha256s)&&delta.binarySha256===d.binarySha256&&delta.startSha256===d.sampleSha256s[0]&&delta.endSha256===d.sampleSha256s[40],'Actual delta41 bytes differ from commit');
 requireValue(delta.materialPolicySha256===context.physicalMassPolicySha256&&delta.sourceDeltaPolicySha256===context.sourceDeltaPolicySha256,'Delta trace physical policy changed');
 if(proof.verifiedPhysicalDeltaTrace!==undefined)requireValue(same(proof.verifiedPhysicalDeltaTrace,delta),'Guard has foreign delta binding');
 requireValue(receipt.all41GuardProofSha256===await physicalCertificateSha256({...proof,verifiedPhysicalDeltaTrace:delta}),'Guard proof content changed');
 requireValue(Array.isArray(receipt.physicalReceipts)&&receipt.physicalReceipts.length===40,'Exactly 40 physical pressure receipts required');
 requireValue(receipt.physicalReceiptsSha256===await physicalReceiptListSha256(receipt.physicalReceipts),'Physical receipt collection hash changed');
 const reactionHashes=[];
 for(let i=0;i<40;i++){
  const c=receipt.physicalReceipts[i],key=c?.key;
  requireValue(key?.generation===context.generation&&key.frameSequence===context.frameSequence&&key.physicalSubstep===i+1&&key.gateRevision===context.usedActivation.revision&&integer(key.parentToken)&&key.parentToken>0,'Foreign physical parent key');
  for(const name of ['sourceSha256','bodySha256','topologySha256','usedGateSha256'])requireValue(c[name]===context[name],'Physical source/body/topology/gate mismatch: '+name);
  requireValue(c.bodyFaceCount===context.bodyFaceCount,'Executed finite body face count changed');
  requireValue(c.historySha256===q.sampleSha256s[i]&&c.candidateSha256===q.sampleSha256s[i+1],'Physical history/candidate not bound to actual q41');
  requireValue(c.actualGpuFiniteProducer===true&&c.allCurrentRawOccurrencesChecked===true&&c.complete===true&&c.rawOccurrences===c.allRawOccurrences&&c.rawOccurrences===c.validatedOccurrences&&c.unsupported===0&&c.unsupportedFlags===0&&c.clearanceDeficits===0&&c.strictClearanceDeficits===0&&c.normalReactionAuthoritative===true&&c.normalMultiplierUnit==='kg-m'&&c.frictionReconciled===true&&c.numericalMarginIsPhysicalPressure===false&&c.published===false,'Incomplete physical finite/pressure authority');
  const empty=c.rawOccurrences===0&&c.allRawOccurrences===0&&c.validatedOccurrences===0&&c.complete===true&&c.unsupported===0&&c.unsupportedFlags===0&&c.clearanceDeficits===0&&c.strictClearanceDeficits===0&&c.allCurrentRawOccurrencesChecked===true&&c.actualGpuFiniteProducer===true;
  requireValue(integer(c.rawOccurrences)&&((Number.isFinite(c.minimumClearanceLowerBoundM)&&c.minimumClearanceLowerBoundM>=.001)||(empty&&c.minimumClearanceLowerBoundM===Infinity)),'Missing finite physical clearance bound');
  requireValue(Number.isFinite(c.maximumOriginalParentNetM)&&c.maximumOriginalParentNetM>=0&&c.maximumOriginalParentNetM<=.005,'Unbounded physical response');
  const r=c.physicalReactionReceipt,b=r?.binding;
  requireValue(r&&same(b?.key,key),'Missing actual pressure receipt key');
  await verifyPhysicalCertificateQueryChain(c.physicalCertificateQueryChain,{reactionReceipt:r,outerCertificate:c,requireFloor:true,certificateSha256:physicalCertificateSha256,byteSha256,canonicalText:canonicalPhysicalCertificateText});
  requireValue(integer(b.originalRawOccurrences)&&sha(b.originalRawRow128Sha256)&&sha(b.originalRawProofSha256),'Missing authentic original pressure inventory binding');
  for(const name of ['sourceSha256','bodySha256','historySha256','usedGateSha256','originalParentSha256'])requireValue(sha(b[name])&&b[name]===c[name],'Pressure uses foreign physical body/history: '+name);
  requireValue(b.physicalMassPolicySha256===context.physicalMassPolicySha256&&b.executedTolerancePolicySha256===context.tolerancePolicySha256&&b.executedAnchorPartitionPolicySha256===context.anchorPartitionPolicySha256,'Pressure execution policy changed');
  requireValue(r.finalCandidateSha256===c.candidateSha256&&r.normalPhysicalRhs==='exact-physical-1mm'&&r.normalMultiplierUnit==='kg-m'&&r.numericalMarginIsPhysicalPressure===false&&r.normalReactionAuthoritative===true&&r.storedForceFinite===true&&r.fixedMassAndSignedZeroBitsPreserved===true&&r.all41GuardProofSha256===null,'Incomplete physical-only pressure receipt');
  requireValue(r.deviceReactionReceiptSha256===context.pressureDeviceReceiptSha256&&r.executedPhysicalPackShaderSha256===context.physicalPackShaderSha256&&r.executedReactionShaderSha256===context.reactionShaderSha256,'Pressure device implementation changed');
  requireValue(Number.isFinite(r.originalParentNetM)&&r.originalParentNetM>=0&&r.originalParentNetM<=.005&&r.originalParentNetM===c.maximumOriginalParentNetM,'Pressure original-parent net response mismatch');
  for(const name of ['algebraicNormalDeficitM','algebraicComplementarityResidualM','frictionResidualM'])requireValue(Number.isFinite(r[name])&&r[name]>=0&&Number.isFinite(context.validatedTolerances?.[name])&&context.validatedTolerances[name]>=0&&r[name]<=context.validatedTolerances[name],'Pressure residual exceeds independently declared tolerance');
  requireValue(Array.isArray(r.reactions),'Missing physical reaction rows');
  requireValue(r.reactionRecordScope==='body-pressure-friction-only-v1'&&sha(r.actualAllContactOperatorReceiptSha256),'Missing authenticated ALL-contact operator/body-pressure scope');
  const counts=[r.allContactPhysicalRowCount,r.bodyContactPhysicalRowCount,r.selfContactPhysicalRowCount];
  requireValue(counts.every(integer)&&r.bodyContactPhysicalRowCount+r.selfContactPhysicalRowCount===r.allContactPhysicalRowCount&&r.allContactPhysicalRowCount<=b.originalRawOccurrences&&(b.originalRawOccurrences===0?r.allContactPhysicalRowCount===0:r.allContactPhysicalRowCount>0)&&r.reactions.length<=r.bodyContactPhysicalRowCount,'Invalid complete canonical physical contact counts');
  const functions=new Set(),ownedRawOrdinals=new Set(),vec=v=>(Array.isArray(v)||ArrayBuffer.isView(v))&&v.length===3&&Array.from(v).every(Number.isFinite);
  for(const reaction of r.reactions){
   requireValue(sha(reaction.materialFunctionalSha256)&&!functions.has(reaction.materialFunctionalSha256)&&Number.isFinite(reaction.physicalNormalLambdaKgM)&&reaction.physicalNormalLambdaKgM>=0&&vec(reaction.normalForceN)&&vec(reaction.tangentialLambdaKgM)&&['separated','stick','slide'].includes(reaction.mode),'Invalid or duplicate canonical reaction');
   functions.add(reaction.materialFunctionalSha256);
   requireValue(Array.isArray(reaction.originalRawAliases)&&reaction.originalRawAliases.length>0&&new Set(reaction.originalRawAliases).size===reaction.originalRawAliases.length&&reaction.originalRawAliases.every(v=>integer(v)&&v<b.originalRawOccurrences),'Invalid reaction raw aliases');
   // The executed canonical partition assigns each raw ordinal to one functional.
   // Zero-pressure groups can be absent; repeated pressure ownership cannot.
   for(const ordinal of reaction.originalRawAliases){requireValue(!ownedRawOrdinals.has(ordinal),'Raw pressure alias has multiple functional owners');ownedRawOrdinals.add(ordinal);}
   requireValue((reaction.mode!=='separated'||reaction.physicalNormalLambdaKgM===0)&&(reaction.physicalNormalLambdaKgM!==0||[...reaction.normalForceN,...reaction.tangentialLambdaKgM].every(v=>v===0)),'No-pressure reaction invents force');
   const anchor=reaction.currentBodyMaterialAnchor;
   {
    requireValue(anchor&&integer(anchor.bodyFace)&&anchor.bodyFace<context.bodyFaceCount&&vec(anchor.bodyBarycentric)&&vec(anchor.materialOffset)&&sha(anchor.authenticFiniteProbeSha256)&&anchor.producerPhysicalSubstep===i+1,'Missing actual finite body-material anchor');
    for(const name of ['bodySha256','sourceSha256','historySha256','usedGateSha256'])requireValue(anchor[name]===b[name],'Body anchor uses foreign execution provenance');
    for(const weights of [anchor.bodyBarycentric,anchor.sourceMaterialWeights])requireValue((Array.isArray(weights)||ArrayBuffer.isView(weights))&&weights.length>0&&Array.from(weights).every(v=>Number.isFinite(v)&&v>=0&&v<=1)&&Math.abs(Array.from(weights).reduce((a,v)=>a+v,0)-1)<=2e-6,'Invalid finite material partition');
    requireValue(Array.isArray(anchor.sourceMaterialIds)&&anchor.sourceMaterialIds.length===anchor.sourceMaterialWeights.length&&new Set(anchor.sourceMaterialIds).size===anchor.sourceMaterialIds.length&&anchor.sourceMaterialIds.every(v=>integer(v)&&v<context.particleCount),'Invalid material particle identity');
   }
  }
  reactionHashes.push(await physicalCertificateSha256(r));
 }
 const pressure=receipt.pressureAcceptance;
 requireValue(pressure?.generation===context.generation&&pressure.frameSequence===context.frameSequence&&pressure.physicalSubstepsCommitted===40&&pressure.all41GuardProofSha256===receipt.all41GuardProofSha256&&pressure.usedGateSha256===context.usedGateSha256&&sha(pressure.pressureHistorySha256)&&pressure.pressureHistorySha256===receipt.pressureHistorySha256&&same(pressure.actualReactionReceiptSha256s,reactionHashes),'Missing accepted pressure history or 40 reaction digests');
 return Object.freeze({bindingValidated:true,physicalBackendFrameCommitted:true,physicalCertificateQueryChainBound:true,frameCommitSha256:commitSha,actualPosition41BinarySha256:q.binarySha256,actualPhysicalDelta41BinarySha256:d.binarySha256,physicalSubsteps:40,geometrySamples:41,sourceSha256:context.sourceSha256,bodySha256:context.bodySha256,sourceBodyFacetTrajectoryBound:true,sourceBodyFacetClearancePolicy:sourceBodyFacetTrajectory.policy,sourceSelfIntervalTrajectoryBound:true,sourceSelfIntervalPolicy:sourceSelfIntervalTrajectory.policy,activeOriginalPointSeamPolicy:sourceSelfIntervalTrajectory.activeOriginalPointSeamPolicy,activeOriginalEdgeSeamPolicy:sourceSelfIntervalTrajectory.activeOriginalEdgeSeamPolicy,activeOriginalMovingSeamPlaneTrajectoryBound:true,activeOriginalMovingSeamPlanePolicy:sourceSelfIntervalTrajectory.activeOriginalMovingSeamPlanePolicy,activeOriginalMovingSeamSATTrajectoryBound:true,activeOriginalMovingSeamSATPolicy:sourceSelfIntervalTrajectory.activeOriginalMovingSeamSATPolicy,sharedIndexedPointMovingPlaneTrajectoryBound:true,sharedIndexedPointMovingPlanePolicy:sourceSelfIntervalTrajectory.sharedIndexedPointMovingPlanePolicy,zeroThicknessSelfContinuousCertified:true,positiveSelfThicknessCertified:false,scope:'content binding only; trusted getter/context/device origin are supplied externally; positive body-facet and zero-thickness self policies on supplied linear intervals required; original USED point/adjacent-edge/moving-plane/moving-SAT origin and original indexed-point path bound; no positive self thickness, unrecorded path or fit certification',fullFitAccepted:false});
}
