import{portableDigest as sha,concatPhysicalBytes,physicalViewBytes}from'./portableByteTools.mjs';
import{actualAllContactOperatorEvidence}from'./actualAllContactOperatorEvidence.mjs';
const bytes=x=>new Uint8Array(x.buffer,x.byteOffset,x.byteLength);
const same=(a,b)=>a.byteLength===b.byteLength&&a.every((v,i)=>v===b[i]);
/** Read the private executed operator while the owner's final output lease is
 * held. Caller labels cannot substitute for the actual packed J/RHS bytes. */
export async function readActualPhysicalOperatorEvidence({mechanical,particles,readBytes,isCurrent}){
 if(typeof readBytes!=='function'||typeof isCurrent!=='function'||!isCurrent()||mechanical?.actualGpuPhysicalResponse!==true)
  throw Error('Private actual physical operator lease required');
 const packet=mechanical.physicalRows,reaction=mechanical.actualReaction,binding=structuredClone(mechanical.binding);
 const specs=[
  ['rows',packet.rows,0,packet.actualPhysicalRows],['terms',packet.terms,0,packet.actualPhysicalTerms],
  ['proof',packet.packProof,packet.packProofOffset,bytes(packet.proof)],
  ['status',mechanical.actualStatusBuffer,0,bytes(reaction.statusCapacity)],
  ['reaction',mechanical.actualReactionBuffer,0,bytes(reaction.reaction)],
  ['ideal',mechanical.idealPhysicalContactDelta,0,bytes(reaction.idealCombinedContactDelta)]];
 // Snapshot all CPU observations before the first asynchronous read as well.
 const expected=specs.map(([name,buffer,offset,value])=>({name,buffer,offset,value:value.slice()}));
 const observed={};
 for(const s of expected){
  const b=await readBytes(s.buffer,s.value.byteLength,s.offset);
  if(!isCurrent()||!(b instanceof Uint8Array)||!same(b,s.value))throw Error('Executed physical operator bytes changed: '+s.name);
  observed[s.name]=b.slice();
 }
 const p={...packet,actualPhysicalRows:observed.rows,actualPhysicalTerms:observed.terms,proof:new Uint32Array(observed.proof.buffer)};
 const r={...reaction,statusCapacity:new Uint32Array(observed.status.buffer),reaction:new Float32Array(observed.reaction.buffer),
  idealCombinedContactDelta:new Float32Array(observed.ideal.buffer)};
 const evidence=(await actualAllContactOperatorEvidence(p,r,binding,particles,{isCurrent}));
 if(evidence.actualAllContactOperatorReceiptSha256!==mechanical.actualAllContactOperatorEvidence.actualAllContactOperatorReceiptSha256||
  (await sha(concatPhysicalBytes([physicalViewBytes(observed.rows),physicalViewBytes(observed.terms)]),isCurrent))!==binding.packedPhysicalJacobianSha256||
  (await sha(observed.rows,isCurrent))!==binding.physicalRhsSha256||!isCurrent())throw Error('Executed physical operator digest/J/RHS differs from private receipt');
 return Object.freeze({...evidence,binding,actualGpuOperatorReadbackVerified:true,
  packedPhysicalJacobianSha256:binding.packedPhysicalJacobianSha256,physicalRhsSha256:binding.physicalRhsSha256,
  actualPhysicalRows:observed.rows,actualPhysicalTerms:observed.terms,actualPackProof:new Uint32Array(observed.proof.buffer),
  actualStatus:new Uint32Array(observed.status.buffer),actualReaction:new Float32Array(observed.reaction.buffer),
  actualIdealPhysicalContactDelta:new Float32Array(observed.ideal.buffer)});
}
