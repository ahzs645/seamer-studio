/** NEW owned-copy boundary around the device-passed anchor V2 producer.
 * No CPU finite geometry rows or classifications are uploaded. A complete
 * authentic ALLraw read lease and actual executed geometry receipt are required.
 * Exclusive buffers stay owned until this method releases its input lease. */
import{releaseExactFiniteKernelAuthority}from'../FiniteKernelCache.mjs';
import{physicalBytesSha256}from'../portablePhysicalHashes.mjs';
import{executedJointCertificateFields}from'../owner/source-joint-executed-topology-anchor-integration/snapshot/ExecutedJointGeometryDescriptor.mjs';
import{SourceJointBodyMaterialAnchorProbe,decodeJointBodyAnchorReceipt}from'./SourceJointBodyMaterialAnchorProbeV2.mjs';
const byteHash=a=>physicalBytesSha256(typeof a==='string'?new TextEncoder().encode(a):a);
const exact=x=>{if(x instanceof ArrayBuffer)return new Uint8Array(x.slice(0));if(ArrayBuffer.isView(x))return new Uint8Array(x.buffer,x.byteOffset,x.byteLength).slice();throw Error('Actual exact anchor byte readback required');};
const bytesOf=a=>new Uint8Array(a.buffer,a.byteOffset,a.byteLength);
const canonical=x=>JSON.stringify(x,(_,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.entries(v).sort(([a],[b])=>a.localeCompare(b))):v);
const u32=x=>Number.isSafeInteger(x)&&x>=0&&x<=0xffffffff;
export function createSourceExecutedBodyAnchorV2(device,scope){if(scope!=='fresh-source-equal-layer')return null;return new SourceExecutedBodyAnchorV2(device);}
export class SourceExecutedBodyAnchorV2{
 constructor(device){this.device=device;this.busy=false;this.closing=false;this.closed=false;this.closePromise=null;this.outputs=new Map();this.nextToken=0;this.pending=null;}
 async produceActual(input){
  if(this.busy||this.closing||this.closed)throw Error('Concurrent/closed executed anchor owner');
  const {observed,gate,gateLayout,raw,rawProof,executedGeometryOwner,executedGeometryReadbackReceipt,readGpuBytes,isCurrent}=input;
  const prepared={...input.prepared,packed:{...input.prepared.packed,words:input.prepared.packed.words.slice()},receipt:structuredClone(input.prepared.receipt)};
  const originalParent=input.originalParent,originalParentSha256=input.originalParentSha256;
  const count=input.count,epoch=Object.freeze({...input.epoch}),layout=Object.freeze({...gateLayout}),key=Object.freeze({...input.key});
  if(!['generation','frameSequence','physicalSubstep','parentToken','gateRevision'].every(f=>u32(key[f]))||key.frameSequence<1||key.parentToken<1||key.physicalSubstep!==epoch.correctedSubstep||key.gateRevision!==epoch.gateRevision)throw Error('Unbound physical frame/parent anchor key');
  const fields=executedJointCertificateFields(executedGeometryOwner,executedGeometryReadbackReceipt),descriptor=fields.executedGeometryDescriptor;
  if(!u32(count)||count<1||count>262144||!Object.values(epoch).every(u32)||epoch.correctedSubstep<1||epoch.correctedSubstep>40||epoch.sourceToken!==descriptor.sourceToken||epoch.bodyGeneration!==descriptor.bodyGeneration||typeof readGpuBytes!=='function'||typeof isCurrent!=='function'||input.exclusiveReadLease!==true||isCurrent()!==true)throw Error('Unbound executed anchor input lease');
  if(!(observed.current instanceof Float32Array)||!(observed.previous instanceof Float32Array)||!(observed.gateWords instanceof Uint32Array)||observed.current.length!==descriptor.particleCount*4||observed.previous.length!==descriptor.particleCount*4||observed.gateWords.byteLength!==layout.byteLength||![observed.current,observed.previous].every(a=>a.every((x,i)=>Number.isFinite(x)&&(i%4!==3||x>=0))))throw Error('Exact finite typed observed source arrays/counts required');
  const observation={...observed,binding:structuredClone(observed.binding),current:observed.current.slice(),previous:observed.previous.slice(),gateWords:observed.gateWords.slice()};
  this.busy=true;let finish;this.pending=new Promise(resolve=>finish=resolve);let probe,packet,summary,owned=[],succeeded=false;
  try{
  const hash=async a=>{const digest=await byteHash(a);if(this.closing||isCurrent()!==true)throw Error('Executed anchor source changed across byte digest');return digest;};
  for(const[name,field]of [['current','currentSha256'],['previous','historySha256'],['gateWords','gateSha256']])if((await hash(bytesOf(observation[name])))!==observation.binding[field])throw Error('CPU observation bytes differ from authenticated GPU binding: '+name);
  for(const key of ['sourceSha256','bodySha256','topologySha256'])if(observation.binding[key]!==descriptor[key])throw Error('Anchor executed source/topology differs: '+key);
  if(observation.binding.sourceToken!==epoch.sourceToken||observation.binding.bodyGeneration!==epoch.bodyGeneration||observation.binding.gateRevision!==epoch.gateRevision||gate!==observation.gateBuffer||raw.size<count*128||rawProof.size!==32||new Set([raw,rawProof,gate,observation.currentBuffer,observation.previousBuffer]).size!==5)throw Error('Anchor handles/masses/epoch unbound');
  const packedBytes=bytesOf(prepared.packed.words);if((await hash(packedBytes))!==descriptor.packedGeometrySha256)throw Error('Anchor packed geometry differs from actually executed bytes');
  if(!originalParent||originalParent.size<descriptor.particleCount*16||!/^[a-f0-9]{64}$/.test(originalParentSha256))throw Error('Missing authentic original physical parent');
  const inputs=[['originalParent',originalParent,descriptor.particleCount*16],['current',observation.currentBuffer,descriptor.particleCount*16],['history',observation.previousBuffer,descriptor.particleCount*16],['gate',gate,layout.byteLength],['raw',raw,count*128],['rawProof',rawProof,32]];
  const read=async(b,n)=>{const a=exact(await readGpuBytes(b,n));if(a.byteLength!==n)throw Error('Truncated authentic anchor input/output');if(isCurrent()!==true||this.closing)throw Error('Executed anchor generation changed');return a;};
   const seals={};for(const[name,b,n]of inputs)seals[name]=(await hash(await read(b,n)));
   for(const[name,key]of [['current','currentSha256'],['history','historySha256'],['gate','gateSha256']])if(seals[name]!==observation.binding[key])throw Error('Actual anchor observed GPU bytes differ: '+name);
   if(seals.originalParent!==originalParentSha256)throw Error('Actual original physical parent bytes differ');
   const parentWords=new Uint32Array((await read(originalParent,descriptor.particleCount*16)).buffer),oldWords=new Uint32Array(observation.previous.buffer,observation.previous.byteOffset,observation.previous.length),currentWords=new Uint32Array(observation.current.buffer,observation.current.byteOffset,observation.current.length);for(let id=0;id<descriptor.particleCount;id++)if(parentWords[id*4+3]!==oldWords[id*4+3]||parentWords[id*4+3]!==currentWords[id*4+3])throw Error('Anchor original-parent/history/current W differs');
   const incoming=new Uint32Array((await read(rawProof,32)).buffer);if(incoming[0]!==0||incoming[1]!==count||incoming[2]!==7||incoming[3]!==0||incoming[5]!==count)throw Error('Anchor incoming complete ALLraw proof not certified');
   probe=new SourceJointBodyMaterialAnchorProbe(this.device,prepared,observation,gate,layout,raw,rawProof,count,epoch,this);
   await probe.verifyCompilationBeforeDispatch();if(isCurrent()!==true||this.closing)throw Error('Anchor stale after actual compilation');
   const encoder=this.device.createCommandEncoder();probe.encode(encoder,observation);this.device.queue.submit([encoder.finish()]);
   const packetBytes=await read(probe.packet,probe.outputLayout.byteLength),summaryBytes=await read(probe.proof,96),rawBytes=await read(raw,count*128);
   const decoded=decodeJointBodyAnchorReceipt(new Uint32Array(summaryBytes.buffer),new Uint32Array(packetBytes.buffer),new Uint32Array(rawBytes.buffer),probe.outputLayout,epoch,descriptor.bodyFaceCount);
   if(!decoded.allBodyAnchorsReady)throw Error('Authentic anchor unsupported: '+decoded.unsupportedFlags);
   for(const[name,b,n]of inputs)if((await hash(await read(b,n)))!==seals[name])throw Error('Anchor input changed during complete finite query: '+name);
   const make=(label,n)=>{const b=this.device.createBuffer({label:'executed-anchor-owned:'+label,size:n,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST});owned.push(b);return b;};
   packet=make('actual-V2-packet',probe.outputLayout.byteLength);summary=make('actual-GPU-summary',96);
   const copy=this.device.createCommandEncoder();copy.copyBufferToBuffer(probe.packet,0,packet,0,probe.outputLayout.byteLength);copy.copyBufferToBuffer(probe.proof,0,summary,0,96);this.device.queue.submit([copy.finish()]);
   const copiedPacket=await read(packet,probe.outputLayout.byteLength),copiedSummary=await read(summary,96);
   if((await hash(copiedPacket))!==(await hash(packetBytes))||(await hash(copiedSummary))!==(await hash(summaryBytes)))throw Error('Actual GPU anchor owned copy differs');
   for(const[name,b,n]of inputs)if((await hash(await read(b,n)))!==seals[name])throw Error('Anchor input changed before owned-copy receipt: '+name);
   const token=++this.nextToken,outputLayout=Object.freeze({...probe.outputLayout});
   const receiptData={...decoded,...fields,key,anchorProducerWGSLSourceSha256:(await hash(probe.compilationSource)),actualModuleCompilationChecked:probe.compilationVerified.actualModuleCompilationChecked,executedGeometryDescriptor:structuredClone(descriptor),outputLayout,packetSha256:(await hash(packetBytes)),summarySha256:(await hash(summaryBytes)),originalParentSha256:seals.originalParent,rawSha256:seals.raw,rawProofSha256:seals.rawProof,currentSha256:seals.current,historySha256:seals.history,usedGateSha256:seals.gate,copyProvenance:'actual-GPU-buffer-to-buffer-V2-packet-and-summary-with-exact-readback-v1',exclusiveInputReadLease:true,pressureAuthoritative:false,wholeFrameAccepted:false,garmentAccepted:false};const receipt=Object.freeze({...receiptData,receiptSha256:(await hash(canonical(receiptData)))});
   this.outputs.set(token,{owned,packet,summary,receipt});succeeded=true;
   const binding=Object.freeze({sourceSha256:receipt.sourceSha256,bodySha256:receipt.bodySha256,topologySha256:receipt.topologySha256,bodyFaceCount:receipt.bodyFaceCount,historySha256:receipt.historySha256,currentSha256:receipt.currentSha256,usedGateSha256:receipt.usedGateSha256,fullRawRow128Sha256:receipt.rawSha256,fullRawProofSha256:receipt.rawProofSha256,originalParentSha256:receipt.originalParentSha256,finiteAnchorProbePacketSha256:receipt.packetSha256,finiteAnchorProbeSummarySha256:receipt.summarySha256,finiteAnchorProbeSha256:receipt.receiptSha256,sourceToken:epoch.sourceToken,bodyGeneration:epoch.bodyGeneration,key,actualGpuBodyBVHAnchorProducer:true,actualExecutedGeometryDescriptorSha256:descriptor.executedGeometryDescriptorSha256});
   return Object.freeze({token,packetBuffer:packet,summaryBuffer:summary,probe:Object.freeze({packet,summary,layout:outputLayout,binding}),anchors:Object.freeze({buffer:packet,offset:outputLayout.anchorsOffset,size:outputLayout.anchorsByteLength}),receipt});
  }finally{
   const failures=[];if(probe)try{await probe.destroy();}catch(e){failures.push(e);}if(!succeeded){try{await this.device.queue.onSubmittedWorkDone();}catch(e){failures.push(e);}for(const b of owned)try{b.destroy();}catch(e){failures.push(e);}}
   if(failures.length&&succeeded){for(const[token,o]of this.outputs)if(o.packet===packet){for(const b of o.owned)try{b.destroy();}catch(e){failures.push(e);}this.outputs.delete(token);}}
   this.busy=false;this.pending=null;finish();if(failures.length)throw new AggregateError(failures,'Executed anchor query/copy cleanup failure');
  }
 }
 async releaseOutput(token){if(this.busy||this.closing||this.closed)throw Error('Concurrent/closed anchor output release');const output=this.outputs.get(token);if(!output)throw Error('Unknown/released executed anchor output');this.busy=true;let finish;this.pending=new Promise(resolve=>finish=resolve);try{await this.device.queue.onSubmittedWorkDone();}finally{for(const b of output.owned)b.destroy();this.outputs.delete(token);this.busy=false;this.pending=null;finish();}}
 destroy(){if(this.closePromise)return this.closePromise;this.closing=true;this.closePromise=(async()=>{const errors=[];if(this.pending)await this.pending;try{await this.device.queue.onSubmittedWorkDone();}catch(e){errors.push(e);}finally{for(const o of this.outputs.values())for(const b of o.owned)try{b.destroy();}catch(e){errors.push(e);}this.outputs.clear();releaseExactFiniteKernelAuthority(this.device,this);this.closed=true;}if(errors.length)throw new AggregateError(errors,'Executed anchor owner cleanup failed');})();return this.closePromise;}
}
