/** Dynamic observation identity comes from the captured real engine parent key.
 * History bytes and USED gate bytes remain independently observed and SHA-bound.
 * Tokens never substitute for those bytes or authorize an old snapshot. */
export function snapshotJointPhysicalKey(key){const fields=['generation','frameSequence','physicalSubstep','parentToken','gateRevision'],snapshot=Object.fromEntries(fields.map(field=>[field,key?.[field]]));if(!Object.values(snapshot).every(x=>Number.isSafeInteger(x)&&x>=0&&x<=0xffffffff)||snapshot.frameSequence<1||snapshot.parentToken<1||snapshot.physicalSubstep<1||snapshot.physicalSubstep>40)throw Error('Unbound physical parent key');return Object.freeze(snapshot);}
export function projectJointPhysicalObservationBinding(binding,key,refinedScope){
 const captured=snapshotJointPhysicalKey(key);
 return {...binding,correctedSubstep:captured.physicalSubstep,gateRevision:captured.gateRevision,historyToken:captured.parentToken,gateToken:captured.gateRevision,...(refinedScope?{refinedBoundary:true,verifiedRefinedScope:refinedScope}:{})};
}
