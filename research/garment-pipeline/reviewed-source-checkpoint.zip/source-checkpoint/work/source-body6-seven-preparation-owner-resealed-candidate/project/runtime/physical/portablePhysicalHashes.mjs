/** Explicit NEW portable boundary. Byte/structure hashes are not execution proof.
 * Source callers keep an exclusive GPU lease and recheck current generation. */
import {encodePhysicalReceiptValue,decodePhysicalReceiptValue,physicalReceiptSha256,physicalReceiptListSha256,physicalFrameReceiptSha256,PHYSICAL_RECEIPT_ENCODING} from './vendor/frameReceiptCodec.mjs';
export const PHYSICAL_CERTIFICATE_HASH_ENCODING='canonical-sorted-json-v2-empty-contact-bounds';
export const PHYSICAL_FRAME_RECEIPT_ENCODING=PHYSICAL_RECEIPT_ENCODING;
const bytes=value=>value instanceof ArrayBuffer?new Uint8Array(value):ArrayBuffer.isView(value)?new Uint8Array(value.buffer,value.byteOffset,value.byteLength):null;
function equal(a,b){return a?.length===b?.length&&a.every((v,i)=>v===b[i]);}
export async function physicalBytesSha256(value){const original=bytes(value);if(!original)throw Error('Actual typed/ArrayBuffer bytes required');const snapshot=original.slice(),hash=await globalThis.crypto.subtle.digest('SHA-256',snapshot);if(!equal(original,snapshot))throw Error('Physical byte input mutated across digest');return Array.from(new Uint8Array(hash),v=>v.toString(16).padStart(2,'0')).join('');}
export function canonicalPhysicalCertificateText(value){const encoded=encodePhysicalReceiptValue(value);function check(v,depth=0){if(!v||typeof v!=='object')return;if(Object.hasOwn(v,'$physicalClearanceBound')&&depth!==1)throw Error('Nested contact bounds require explicit v3 receipt domain');Object.values(v).forEach(child=>check(child,depth+1));}check(encoded);return JSON.stringify(encoded);}
export async function physicalCertificateSha256(value){const text=canonicalPhysicalCertificateText(value);return physicalBytesSha256(new TextEncoder().encode(text));}
export {physicalReceiptSha256,physicalReceiptListSha256,physicalFrameReceiptSha256};
/** Snapshot structural input synchronously at the caller boundary before using
 * async hashes to port a former sync graph/history callback. This issues no seal
 * for GPU memory; callers still use their authentic before/after read lease. */
export function snapshotPhysicalReceipt(value){return decodePhysicalReceiptValue(encodePhysicalReceiptValue(value));}
