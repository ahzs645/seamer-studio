import{sourcePhysicalRow128PackWGSL}from'./physicalRow128PackWGSL.mjs';
/** Exact packed physical-functional dedup, independent of face/proof aliases.
 * Original raw proofs are ALL retained and checked. Equal planes require exact
 * dyadic q·n equality, never rounded f32/f64 RHS equality or a proximity epsilon.
 * This is a bounded primitive/reference selector, NOT a scalable producer. */
const coefficients=sourcePhysicalRow128PackWGSL.slice(sourcePhysicalRow128PackWGSL.indexOf('struct Big {'),sourcePhysicalRow128PackWGSL.indexOf('fn point('));
export const physicalAliasWGSL=String.raw`
struct FiniteRow {a:vec4u,b:vec4u,wa:vec4f,wb:vec4f,n:vec4f,q:vec4f,feature:vec4u,proof:vec4u}
struct Config {counts:vec4u,epoch:vec4u} // raw count,source,body,step; gate,parent,0,0
@group(0) @binding(0) var<storage,read> raw:array<FiniteRow>;
@group(0) @binding(1) var<storage,read_write> representatives:array<u32>;
@group(0) @binding(2) var<storage,read_write> state:array<u32>;
@group(0) @binding(3) var<uniform> cfg:Config;
const NONE=0xffffffffu;
fn finite1(x:f32)->bool{return (bitcast<u32>(x)&0x7f800000u)!=0x7f800000u;}
`+coefficients+String.raw`
struct Wide {words:array<u32,18>}
struct Plane {magnitude:Wide,negative:bool}
fn addWide(p:ptr<function,Wide>,index:u32,value:u32){var i=index;var v=value;while(v!=0u&&i<18u){let old=(*p).words[i];let sum=old+v;(*p).words[i]=sum;v=select(0u,1u,sum<old);i++;}}
fn addShifted(p:ptr<function,Wide>,lo:u32,hi:u32,shift:u32){let i=shift/32u;let offset=shift%32u;addWide(p,i,lo<<offset);if(offset==0u){addWide(p,i+1u,hi);}else{addWide(p,i+1u,(lo>>(32u-offset))|(hi<<offset));addWide(p,i+2u,hi>>(32u-offset));}}
fn exactPlane(r:FiniteRow)->Plane{
 var positive:Wide;var negative:Wide;var out:Wide;
 for(var i=0u;i<18u;i++){positive.words[i]=0u;negative.words[i]=0u;out.words[i]=0u;}
 for(var k=0u;k<3u;k++){
  let a=bitcast<u32>(r.q[k]);let b=bitcast<u32>(r.n[k]);let ea=(a>>23u)&255u;let eb=(b>>23u)&255u;
  let sa=(a&0x7fffffu)|select(0u,0x800000u,ea!=0u);let sb=(b&0x7fffffu)|select(0u,0x800000u,eb!=0u);
  let middle=(sa>>16u)*(sb&65535u)+(sa&65535u)*(sb>>16u);
  let low=(sa&65535u)*(sb&65535u);let shifted=middle<<16u;let lo=low+shifted;
  let hi=(sa>>16u)*(sb>>16u)+(middle>>16u)+select(0u,1u,lo<low);
  let shift=select(0u,ea-1u,ea!=0u)+select(0u,eb-1u,eb!=0u);
  if(((a^b)&0x80000000u)!=0u){addShifted(&negative,lo,hi,shift);}else{addShifted(&positive,lo,hi,shift);}
 }
 var order=0;for(var i=18u;i>0u;i--){let j=i-1u;if(positive.words[j]>negative.words[j]){order=1;break;}if(positive.words[j]<negative.words[j]){order=-1;break;}}
 var borrow=0u;for(var i=0u;i<18u;i++){let a=select(positive.words[i],negative.words[i],order<0);let b=select(negative.words[i],positive.words[i],order<0);let first=a-b;out.words[i]=first-borrow;borrow=select(0u,1u,a<b||first<borrow);}
 return Plane(out,order<0);
}
fn samePlane(a:Plane,b:Plane)->bool{if(a.negative!=b.negative){return false;}for(var i=0u;i<18u;i++){if(a.magnitude.words[i]!=b.magnitude.words[i]){return false;}}return true;}
fn sameFunctional(a:FiniteRow,b:FiniteRow)->bool{
 let rigidA=a.q.w==1.;let rigidB=b.q.w==1.;if(rigidA!=rigidB||any(bitcast<vec3u>(a.n.xyz)!=bitcast<vec3u>(b.n.xyz))||bitcast<u32>(a.n.w)!=bitcast<u32>(b.n.w)){return false;}
 if(!samePlane(exactPlane(a),exactPlane(b))){return false;}
 // Both ID sets, including repeated/shared lanes, must have identical exact
 // merged represented-F32 coefficients. Only exact zero terms may disappear.
 for(var side=0u;side<2u;side++){var r=a;if(side==1u){r=b;}for(var k=0u;k<6u;k++){
  var id=NONE;if(k<3u){id=r.a[k];}else{id=r.b[k-3u];}if(id==NONE){continue;}
  let ca=mergedCoefficient(a,id);let cb=mergedCoefficient(b,id);
  if(ca.valid==0u||cb.valid==0u||ca.nonzero!=cb.nonzero||bitcast<u32>(ca.value)!=bitcast<u32>(cb.value)){return false;}
 }}return true;
}
fn valid(r:FiniteRow)->bool{
 if(r.proof.x!=cfg.counts.z||r.proof.y!=cfg.counts.w||r.proof.z!=cfg.counts.y||r.feature.z!=cfg.epoch.x||r.n.w!=.001){return false;}
 for(var k=0u;k<4u;k++){if(!finite1(r.n[k])||!finite1(r.q[k])||!finite1(r.wa[k])||!finite1(r.wb[k])){return false;}}
 return r.a.w==6u&&r.b.w==127u&&r.proof.w==127u&&r.q.w==1.; // initial body-only primitive scope
}
@compute @workgroup_size(1) fn main(){
 if(arrayLength(&state)<4u){return;}for(var i=0u;i<4u;i++){state[i]=0u;}
 if(cfg.counts.x!=arrayLength(&raw)||cfg.counts.x!=arrayLength(&representatives)||cfg.counts.x>1024u){state[0]=1u;return;}
 for(var i=0u;i<cfg.counts.x;i++){if(!valid(raw[i])){state[0]=16u;return;}var first=i;for(var j=0u;j<i;j++){if(sameFunctional(raw[i],raw[j])){first=representatives[j];break;}}representatives[i]=first;if(first==i){state[1]++;}state[2]++;}state[3]=cfg.epoch.y;
}
`;
