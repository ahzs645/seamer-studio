/** Work-only renderer request adapter. It prepares an actual finalized app SI
 * owner; the live renderer and document remain unchanged until a reviewed scene
 * startup transaction adopts it. No device, constructor or trust ledger here. */
import type {SourceSheetAssignment} from './source/sourcePhysicalMembrane.ts';
import {prepareActualAppSIMaterial,type AppMaterialOwner} from './appSIPreparation.ts';
import {copyData,equalData} from './snapshots.mjs';
import {captureActualAppSourceDescriptor,mintActualAppSourceDescriptor} from './appSourceDescriptor.ts';
import {captureActualAppInitialPreparation,prepareAttachedOpenAppSeed,sealAttachedOpenAppMaterial} from './initial-preparation/attachedOpenPreparation.mjs';
import {inspectActualAppInitialSource,inspectStrictActualAppInitialSource,createActualInitialSpacingGuards} from './AppSourcePreflight.ts';
import {prepareBrowserInitialSpacing,sealBrowserInitialSpacingMaterial} from './initial-spacing/browserInitialSpacing.mjs';
import {prepareSourcePhysicalMembrane,validateSourcePhysicalMembrane} from './source/sourcePhysicalMembrane.ts';
import {SOURCE_BODY_FIT_REVISION,GARMENT_CODE_ASSEMBLY_REVISION} from '$lib/scene/sourceBodyCheckpoint';
export interface SceneSourceInputOwner extends AppMaterialOwner {
 sourceToken:number;bodyGeneration:number;styleId:string;sourceBodyCalibration:Record<string,unknown>;
 simulationConfig:Record<string,unknown>;
 sourcePins?:Record<string,string>;
 /** Explicit preparation intent; model bytes are bound to actual sourceFit6. */
 initialPreparation?:{moveOpenArms:boolean;modelBytes?:Uint8Array;expectedModelSha256?:string};
}
export interface SceneSourceInputRequest {
 sourceExecutionBytes?:Uint8Array;
 sourceExecutionEncoding?:string;
 expectedSourceSha256?:string;
}
/** Descriptor implementation is imported only after its separate owner freeze;
 * callers cannot replace it with a mint/readiness callback. */
export function prepareActualSceneSourceInputs(readCurrentOwner:()=>SceneSourceInputOwner,assignments:readonly SourceSheetAssignment[],request:SceneSourceInputRequest,scope:string){
 if(scope!=='fresh-source-physical-profile')return null;
 return (async()=>{
 const owner=readCurrentOwner(),callback=owner.stillCurrent,pattern=owner.pattern,prepared=owner.prepared;
 const metadata=copyData({sourceToken:owner.sourceToken,bodyGeneration:owner.bodyGeneration,styleId:owner.styleId,sourceBodyCalibration:owner.sourceBodyCalibration,simulationConfig:owner.simulationConfig,sourcePins:owner.sourcePins,initialPreparation:owner.initialPreparation}),input=copyData(request);
 for(const key of ['sourceToken','bodyGeneration'] as const)if(!Number.isSafeInteger(metadata[key])||metadata[key]<1||metadata[key]>0xffffffff)throw Error('Actual app physical owner token required');
 if(typeof metadata.styleId!=='string'||!metadata.styleId)throw Error('Actual app style identity required');
 const assertCurrent=()=>{
  const before=readCurrentOwner();if(before.stillCurrent!==callback||callback()!==true)throw Error('Actual source scene request superseded');
  const now=readCurrentOwner();if(now.pattern!==pattern||now.prepared!==prepared||now.stillCurrent!==callback||!equalData(copyData({sourceToken:now.sourceToken,bodyGeneration:now.bodyGeneration,styleId:now.styleId,sourceBodyCalibration:now.sourceBodyCalibration,simulationConfig:now.simulationConfig,sourcePins:now.sourcePins,initialPreparation:now.initialPreparation}),metadata)||!equalData(copyData(request),input))throw Error('Actual source scene body/profile/request changed');
  return true;
 };
 assertCurrent();
 const spacing=await prepareBrowserInitialSpacing(()=>({prepared,pattern,avatarVertices:owner.avatarVertices,avatarIndices:owner.avatarIndices,stillCurrent:assertCurrent,manual:owner.manualRecording,explicitConfiguration:owner.explicitSettings}),scope,{createActualGuards:createActualInitialSpacingGuards});assertCurrent();
 if(!spacing)throw Error('Actual initial spacing owner unavailable');
 const spacingCurrent=()=>spacing.assertCurrent()&&assertCurrent();
 const initial=spacing.prepared;
 const captured=captureActualAppInitialPreparation({pattern,prepared:initial,avatarVertices:owner.avatarVertices,avatarIndices:owner.avatarIndices,sourceFitRevision:SOURCE_BODY_FIT_REVISION,sourceAssemblyRevision:GARMENT_CODE_ASSEMBLY_REVISION});
 const seed=await prepareAttachedOpenAppSeed(()=>({prepared:initial,...captured,stillCurrent:spacingCurrent,moveOpenArms:metadata.initialPreparation?.moveOpenArms===true,modelBytes:owner.initialPreparation?.modelBytes,expectedModelSha256:owner.initialPreparation?.expectedModelSha256}),scope);assertCurrent();
 if(!seed)throw Error('Actual initial source preparation unavailable');
 if(spacing.changed&&seed.placement?.changed===true)throw Error('Combined initial spacing and arm placement requires a reviewed preparation profile');
 const seedCurrent=()=>seed.assertCurrent()&&assertCurrent();
 const material=await prepareActualAppSIMaterial(()=>({...readCurrentOwner(),prepared:seed.prepared,stillCurrent:seedCurrent}),assignments,scope);seedCurrent();
 if(!material)throw Error('Actual app source material preparation unavailable');
 const sealed=await sealAttachedOpenAppMaterial(seed,material.prepared);material.assertCurrent();sealed.assertCurrent();
 const preflightOfMaterial=inspectActualAppInitialSource(sealed.prepared);sealed.assertCurrent();
 const rigid=spacing.changed?await sealBrowserInitialSpacingMaterial(spacing,sealed.prepared,{prepareSourcePhysicalMembrane,validateSourcePhysicalMembrane}):null;spacingCurrent();sealed.assertCurrent();
 const finalized=rigid?.prepared??sealed.prepared;
 const finalCurrent=()=>{rigid?.assertCurrent();return spacingCurrent()&&sealed.assertCurrent()&&material.assertCurrent()&&assertCurrent();};

 const preflight=inspectStrictActualAppInitialSource(finalized);finalCurrent();
 const fields={pattern,prepared:finalized,sourceToken:metadata.sourceToken,bodyGeneration:metadata.bodyGeneration,simulationConfig:metadata.simulationConfig,sourcePins:metadata.sourcePins,sourceBodyCalibration:metadata.sourceBodyCalibration,isCurrent:finalCurrent};
 const descriptor=input.sourceExecutionBytes
  ?await captureActualAppSourceDescriptor({...fields,sourceExecutionBytes:input.sourceExecutionBytes,sourceExecutionEncoding:input.sourceExecutionEncoding,expectedSourceSha256:input.expectedSourceSha256},scope)
  :await mintActualAppSourceDescriptor(fields,scope);
 assertCurrent();material.assertCurrent();sealed.assertCurrent();if(!descriptor)throw Error('Actual app execution descriptor unavailable');
 return Object.freeze({prepared:finalized,pattern,styleId:metadata.styleId,simulationConfig:metadata.simulationConfig,descriptor,preflight,
  assertCurrent(){descriptor.assertCurrent();return finalCurrent();},
  parameterScope:material.parameterScope,measuredGarmentParameters:false,wholeFrameExecuted:false,fitAccepted:false});
 })();
}
