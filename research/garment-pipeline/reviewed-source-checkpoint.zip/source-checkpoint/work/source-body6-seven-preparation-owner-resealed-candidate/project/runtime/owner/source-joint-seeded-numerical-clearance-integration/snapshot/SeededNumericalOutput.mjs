/** Arithmetic contract only, never a finite certificate or physical reaction. */
export function validateSeededNumericalOutput(parent,mechanicalCandidate,mechanicalIdeal,candidate,numericalIdeal,members){
 if(![parent,mechanicalCandidate,mechanicalIdeal,candidate,numericalIdeal].every(a=>a instanceof Float32Array&&a.length===parent.length&&a.length%4===0))throw Error('Incomplete seeded numerical XYZ/ideal');
 const words=a=>new Uint32Array(a.buffer,a.byteOffset,a.length),p=words(parent),m=words(mechanicalCandidate),q=words(candidate),owned=new Set(members),bit=x=>new Uint32Array(Float32Array.of(x).buffer)[0];let maximum=0;
 for(let id=0;id<parent.length/4;id++){
  for(const a of[parent,mechanicalCandidate,mechanicalIdeal,candidate,numericalIdeal])if(a.subarray(id*4,id*4+4).some(v=>!Number.isFinite(v)))throw Error('Nonfinite seeded numerical state');
  if(parent[id*4+3]<0||p[id*4+3]!==m[id*4+3]||p[id*4+3]!==q[id*4+3]||mechanicalIdeal[id*4+3]!==0||numericalIdeal[id*4+3]!==0)throw Error('Seeded numerical mass/W changed');
  for(let k=0;k<3;k++){
   const at=id*4+k,mi=mechanicalIdeal[at],ni=numericalIdeal[at],expectedMechanical=mi===0?parent[at]:Math.fround(parent[at]+mi);
   if(m[at]!==bit(expectedMechanical))throw Error('Mechanical ideal does not reconstruct authentic seed');
   if(parent[id*4+3]===0&&(m[at]!==p[at]||q[at]!==p[at]||mi!==0||ni!==0))throw Error('Fixed signed-zero/XYZ changed');
   if(!owned.has(id)&&(ni!==0||q[at]!==m[at]))throw Error('Unbound numerical particle changed');
   const total=Math.fround(mi+ni),expected=ni===0?mechanicalCandidate[at]:total===0?parent[at]:Math.fround(parent[at]+total);
   if(q[at]!==bit(expected))throw Error('Numerical-only ideal composition does not reproduce candidate');
  }
  maximum=Math.max(maximum,Math.hypot(...[0,1,2].map(k=>candidate[id*4+k]-parent[id*4+k])));
 }
 if(maximum>.005)throw Error('Total ORIGINAL physical parent NET exceeds5mm');return maximum;
}
