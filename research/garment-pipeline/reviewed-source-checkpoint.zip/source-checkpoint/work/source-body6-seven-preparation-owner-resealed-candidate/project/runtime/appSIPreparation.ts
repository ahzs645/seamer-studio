/** Work-only application preparation: consume the renderer's actual finalized
 * SimData/BodyMesh, original app document and posed avatar buffers. No fixture
 * geometry, approval ledger, implicit fabric law or GPU allocation is supplied. */
import {activeGarmentCodeBody} from '@seamer/avatar';
import {sourceGatherIdentity,type PreparedCloth} from '@seamer/cloth-sim';
import {sourceGatherRegistry} from '$lib/utils/sourceGatherPreparation';
import type {Pattern} from '@seamer/pattern-model';
import {prepareSourcePhysicalMembrane,validateSourcePhysicalMembrane,type SourceSheetAssignment} from './source/sourcePhysicalMembrane.ts';
import {copyData} from './snapshots.mjs';
import {equalData} from './refined/bytes.mjs';
export interface AppMaterialOwner {
 pattern:Pattern;prepared:PreparedCloth;
 /** Actual current avatar's posed arrays, not a copied body's self-assertion. */
 avatarVertices:Float32Array;avatarIndices:Uint32Array;
 stillCurrent:()=>boolean;manualRecording:boolean;explicitSettings:boolean;
}
export const ownPreparationRecord=(value:unknown):Record<string,unknown>=>{
 if(!value||typeof value!=='object'||![Object.prototype,null].includes(Object.getPrototypeOf(value)))throw Error('Actual plain own preparation record required');
 const d=Object.getOwnPropertyDescriptors(value);
 if(Reflect.ownKeys(d).some(k=>typeof k!=='string'||!d[k].enumerable||!Object.hasOwn(d[k],'value')))throw Error('Preparation accessors/metadata unsupported');
 return Object.fromEntries(Object.entries(d).map(([key,descriptor])=>[key,descriptor.value]));
};
export const snapshotAppPreparedData=(p:PreparedCloth)=>{
 const record=ownPreparationRecord(p),sim=ownPreparationRecord(record.simData);
 const edgePresent=Object.hasOwn(sim,'edgeRuns'),edgeRuns=sim.edgeRuns;
 const data=Object.fromEntries(Object.entries(sim).filter(([key])=>key!=='edgeRuns'));
 const rest=Object.fromEntries(Object.entries(record).filter(([key])=>key!=='simData'));
 if(edgeRuns instanceof Map&&(Object.getPrototypeOf(edgeRuns)!==Map.prototype||Reflect.ownKeys(edgeRuns).length))throw Error('Actual plain prepared edge map required');
 const result=copyData({...rest,simData:data}) as PreparedCloth;
 if(edgePresent)result.simData.edgeRuns=edgeRuns instanceof Map?new Map(Array.from(Map.prototype.entries.call(edgeRuns),([key,value]:[unknown,unknown])=>{if(typeof key!=='string')throw Error('Prepared edge map keys must be strings');return [key,copyData(value)];})):copyData(edgeRuns);
 return result;
};

function verifyVisibleBody(prepared:PreparedCloth,vertices:Float32Array,indices:Uint32Array){
 const body=prepared.body;if(vertices.length%3||indices.length%3||body.positions.length!==vertices.length/3*4||body.triangles.length!==indices.length/3*4)throw Error('Actual visible body packing differs from prepared body');
 for(let i=0;i<vertices.length/3;i++){for(let k=0;k<3;k++)if(!Object.is(body.positions[i*4+k],vertices[i*3+k]))throw Error('Prepared body differs from actual posed avatar XYZ');if(!Object.is(body.positions[i*4+3],0))throw Error('Actual body padding must be positive zero');}
 for(let i=0;i<indices.length/3;i++){for(let k=0;k<3;k++)if(body.triangles[i*4+k]!==indices[i*3+k])throw Error('Prepared body topology differs from actual avatar');if(body.triangles[i*4+3]!==0)throw Error('Actual body face padding differs');}
}
export function prepareActualAppSIMaterial(readCurrentOwner:()=>AppMaterialOwner,assignments:readonly SourceSheetAssignment[],scope:string){
 if(scope!=='fresh-source-physical-profile')return null; // Native: no reads/copies.
 const first=readCurrentOwner(),{pattern,prepared,avatarVertices,avatarIndices}=first,callback=first.stillCurrent,manualRecording=first.manualRecording,explicitSettings=first.explicitSettings;
 if(prepared.collisionSafety!==true||!activeGarmentCodeBody(pattern.body))throw Error('Actual finalized active source body required');
 if(first.manualRecording||first.explicitSettings||pattern.assembly||pattern.settings3d.fixTop||pattern.pieces.some(p=>p.settings3d.frozen||p.settings3d.savedDrapeState==='held'||p.settings3d.savedPositions.length>0))throw Error('Fresh free app source preparation required');
 const original=snapshotAppPreparedData(prepared),document=copyData(pattern) as Pattern,vertices=copyData(avatarVertices),indices=copyData(avatarIndices),sheet=copyData(assignments),identity=sourceGatherIdentity(pattern),registry=sourceGatherRegistry.lookup(pattern);
 if(prepared.simData.sourceGatherRefinement){const approval=registry?.approvedEvidence,numerical=approval&&Object.fromEntries(Object.entries(approval).filter(([key])=>key!=='sourceIdentity'));
  if(!registry?.enabled||!registry.sourceBodyActive||!numerical||!equalData(numerical,prepared.simData.sourceGatherRefinement.approvedEvidence))throw Error('Same-app genuine finalized gather approval required');
  if(!prepared.simData.sourceGatherCollisionGeometry)throw Error('Actual source refinement finalization incomplete');
 }
 const assertCurrent=()=>{
  const before=readCurrentOwner();if(before.pattern!==pattern||before.prepared!==prepared||before.stillCurrent!==callback||callback()!==true)throw Error('App SI preparation generation changed');
  const now=readCurrentOwner();
  if(now.pattern!==pattern||now.prepared!==prepared||now.stillCurrent!==callback||now.avatarVertices!==avatarVertices||now.avatarIndices!==avatarIndices||now.manualRecording!==manualRecording||now.explicitSettings!==explicitSettings||!equalData(copyData(pattern),document)||!equalData(snapshotAppPreparedData(prepared),original)||!equalData(now.avatarVertices,vertices)||!equalData(now.avatarIndices,indices)||!equalData(copyData(assignments),sheet)||sourceGatherIdentity(pattern)!==identity||!equalData(sourceGatherRegistry.lookup(pattern),registry))throw Error('App SI body/source/geometry/material inputs changed');
  return true;
 };
 assertCurrent();verifyVisibleBody(original,vertices,indices);
 if(!sheet.length)throw Error('Explicit actual per-source-instance SI assignments required');
 const ids=original.simData.sourceStretchPolicy?.sourcePieceIds??[];
 for(const a of sheet){const p=document.pieces.find(p=>p.id===a.pieceId.replace(/#M$/,''));if(!ids.includes(a.pieceId)||!p||!Object.is(a.grainDirection[0],p.grainVector.x)||!Object.is(a.grainDirection[1],p.grainVector.y))throw Error('Material assignment differs from actual original source grain');}
 return (async()=>{
  const simData=await prepareSourcePhysicalMembrane(original.simData,sheet);assertCurrent();
  const material=validateSourcePhysicalMembrane(simData);if(!material)throw Error('Actual executed SI material validation missing');
  // Only physical inverse masses and source material constraint rows may change.
  for(let i=0;i<simData.positions.length;i++)if(i%4!==3||original.simData.positions[i]===0)if(!Object.is(simData.positions[i],original.simData.positions[i]))throw Error('SI preparation changed actual XYZ/fixed bits');
  for(const key of ['triangles','positions2d','seams','seamOrder','anchors','assemblySupport','sourceGatherRefinement','sourceGatherCollisionGeometry'] as const)if(!equalData(simData[key],original.simData[key]))throw Error('SI preparation changed original topology/source/support geometry');
  const result={...original,simData};verifyVisibleBody(result,vertices,indices);assertCurrent();
  return Object.freeze({prepared:result,sourcePhysicalMaterialPolicy:material,assertCurrent,
   parameterScope:'explicit-illustrative-membrane-only',measuredGarmentParameters:false,wholeFrameExecuted:false,fitAccepted:false});
 })();
}
