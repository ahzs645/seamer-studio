import{packagedPhysicalPolicy}from'./packagedPhysicalPolicy.mjs';
/** Declared operator residual limits. Actual device validation is still required;
 * this profile cannot authorize weakened physical clearance or a larger NET. */
export const PHYSICAL_REACTION_TOLERANCES=Object.freeze({algebraicNormalDeficitM:2e-8,algebraicComplementarityResidualM:2e-8,frictionResidualM:2e-8});
export const PHYSICAL_REACTION_TOLERANCE_ENCODING='physical-reaction-residual-policy-v1';
export const PHYSICAL_REACTION_TOLERANCE_POLICY_TEXT=JSON.stringify({encoding:PHYSICAL_REACTION_TOLERANCE_ENCODING,limits:PHYSICAL_REACTION_TOLERANCES});
export const PHYSICAL_REACTION_TOLERANCE_POLICY_SHA256=packagedPhysicalPolicy.toleranceSha256;
export function requirePhysicalTolerancePolicy(options,binding){
 if(options.algebraTolerance!==2e-8||binding.executedTolerancePolicySha256!==PHYSICAL_REACTION_TOLERANCE_POLICY_SHA256)throw Error('Missing/mismatched executed physical residual tolerance policy');
 return PHYSICAL_REACTION_TOLERANCES;
}
