/** Actual same-main app registry plus CPU Worker boundary; no device origin. */
export{prepareCloth,finalizeSourceGatherCollisionGeometry}from'@seamer/cloth-sim';
export{decodeOriginalGatherDocument}from'$lib/utils/sourceGatherEvidence';
export{sourceGatherRegistry}from'$lib/utils/sourceGatherPreparation';
export{PINNED_GATHER_PROGRAMS}from'$lib/utils/pinnedGatherPrograms';
export{prepareActualSceneSourceInputsInWorker}from'./preparation-worker/client.ts';

export {AvatarController, setAvatarAssetsBase, currentSourceBodyCalibrationIdentity} from '@seamer/avatar';
export * as THREE from 'three';
export {SOURCE_BODY_FIT_REVISION, compatibleSourceBodyCheckpoint} from '$lib/scene/sourceBodyCheckpoint';
export {inspectStrictActualAppInitialSource} from './AppSourcePreflight.ts';
