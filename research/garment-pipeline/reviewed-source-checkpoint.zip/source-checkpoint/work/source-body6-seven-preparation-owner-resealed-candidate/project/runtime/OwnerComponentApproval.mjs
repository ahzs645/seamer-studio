/** NEW browser-only private allocation boundary. Artifact approvals authorize
 * component kernels, never a physical frame, publication, or garment fit. */
import { validateFiniteComponentArtifact, authorizeFiniteFactoryComponent } from './finiteComponentValidator.mjs';
import { requireSeededNumericalDeviceValidation } from './numericalDeviceValidation.mjs';
import { physicalBytesSha256 } from './portablePhysicalHashes.mjs';
import { copyData, equalData } from './snapshots.mjs';
import { createExecutedJointGeometryDescriptor } from './owner/source-joint-executed-topology-anchor-integration/snapshot/ExecutedJointGeometryDescriptor.mjs';
import { createVerifiedRefinedScope, refinedFiniteFactory, refinedOriginalFiniteFactory, requireVerifiedRefinedScope } from './refined/RefinedBackendScope.mjs';
import { prepareJointClosedBodyProbe } from './refined/vendor/sourceJointClosedBodyProbe.mjs';
import { sourceJointClosedRawInventoryFactory } from './refined/vendor/sourceJointOrdinaryRawInventory.mjs';
import { bodyFaceFeatureLanesWGSL } from './refined/bodyFaceFeatureLanes.mjs';

const approved = new WeakMap(), consumed = new WeakMap();
const callbacks = new Set(['creationIsCurrent','captureRefinedRuntimeState','consumeActualEnumeration','consumeActualDiagnosticStage','consumeActualResponse','diagnosticTrace']);
const encode = value => new TextEncoder().encode(value);

/** Read only own data properties. Callback/preparation identities are sealed
 * separately; all consumable metadata and typed bytes are privately copied. */
function captureOptions(input,copyBytes=true) {
 if (!input || Object.getPrototypeOf(input) !== Object.prototype) throw Error('Plain source options required');
 const values = {}, identities = {};
 for (const key of Reflect.ownKeys(input)) {
  const descriptor = Object.getOwnPropertyDescriptor(input,key);
  if (typeof key !== 'string' || !descriptor?.enumerable || !Object.hasOwn(descriptor,'value')) throw Error('Source option getters/hidden metadata unsupported');
  const value = descriptor.value;
  if (callbacks.has(key)) {
   if (value !== undefined && typeof value !== 'function') throw Error('Actual source callback required: '+key);
   identities[key] = value;
  } else if (key === 'refinedPreparation') identities[key] = value;
  else values[key] = copyData(value,copyBytes);
 }
 return {values,identities};
}
export function consumeFiniteNumericalOwnerApproval(options) {
 const record = approved.get(options);
 if (!record) throw Error('Privately validated finite+numerical source options required before allocation');
 record.assertCurrent(); approved.delete(options); consumed.set(options,record); return record;
}
export function requireConsumedFiniteNumericalOwnerApproval(options) {
 const record=consumed.get(options);
 if (!record) throw Error('Approved numerical owner construction required before base allocation');
 record.assertCurrent();
 consumed.delete(options);
}

export async function approveFiniteNumericalOwnerOptions(device,input) {
 const initial = captureOptions(input), options = {...initial.values,...initial.identities};
 if (typeof options.creationIsCurrent !== 'function') throw Error('Exclusive current source factory lease required');
 let refinedToken = null, ownedSeal = null;
 const assertSeals = () => {
  const now = captureOptions(input,false);
  if (!equalData(now.values,initial.values) || Object.keys(now.identities).length !== Object.keys(initial.identities).length || Object.keys(initial.identities).some(key=>now.identities[key] !== initial.identities[key])) throw Error('Source factory bytes/metadata/current owner changed across await');
  if (ownedSeal) {
   const owned = captureOptions(options,false);
   if (!equalData(owned.values,ownedSeal.values) || Object.keys(owned.identities).length !== Object.keys(ownedSeal.identities).length || Object.keys(ownedSeal.identities).some(key=>owned.identities[key] !== ownedSeal.identities[key])) throw Error('Privately approved owner options changed before consumption');
  }
  if (refinedToken) requireVerifiedRefinedScope(refinedToken,options.packed,options.layout);
 };
 const assertCurrent = () => {
  assertSeals();
  if(options.creationIsCurrent()!==true)throw Error('Source factory current owner changed across await');
  assertSeals();
 };
 const hash = async bytes => { assertCurrent(); const result = await physicalBytesSha256(bytes); assertCurrent(); return result; };
 const wait = async promise => { const result = await promise; assertCurrent(); return result; };
 assertCurrent();options.diagnosticTrace?.('component-validation-start',{});
 if (!(options.finiteComponentEvidenceArtifact instanceof Uint8Array) || !(options.seededNumericalDeviceValidationArtifact instanceof Uint8Array)) throw Error('Actual component artifact Uint8Array required');
 const finite = await wait(validateFiniteComponentArtifact({artifactBytes:options.finiteComponentEvidenceArtifact,expectedArtifactSha256:options.approvedFiniteComponentEvidenceSha256,sha256:hash}));
 options.diagnosticTrace?.('finite-artifact-validated',{});
 const numeric = await wait(requireSeededNumericalDeviceValidation(options.seededNumericalDeviceValidationArtifact,options.approvedSeededNumericalDeviceValidationSha256,{isCurrent:()=>{assertCurrent();return true;},packerWGSL:options.packerWGSL}));
 options.diagnosticTrace?.('numerical-artifact-validated',{});
 // Authenticated actual UTF8 source, packed body and outside-aware topology;
 // preparation-code SHA and another garment's descriptor are not substitutes.
 await wait(createExecutedJointGeometryDescriptor({packed:options.packed,sourceExecutionBytes:options.sourceExecutionBytes,sourceExecutionEncoding:options.sourceExecutionEncoding,expectedBinding:options.binding,isCurrent:()=>{assertCurrent();return true;}}));
 options.diagnosticTrace?.('actual-source-descriptor-validated',{});
 const declared = JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(options.sourceExecutionBytes));
 const physicalPolicy = declared.sourcePhysicalMaterialPolicySha256;
 if (!/^[a-f0-9]{64}$/.test(physicalPolicy??'') || declared.sourcePhysicalMaterialPolicy?.policySha256 !== physicalPolicy) throw Error('Actual source physical policy bytes required');
 let scope = 'fresh-source-equal-layer', original, derived;
 if (options.packed.refinedBoundary === true) {
  refinedToken = createVerifiedRefinedScope(options.refinedPreparation,options.packed,options.layout,options.binding);
  const capture = options.refinedPreparation.capture();
  if (capture.receipt.physicalMassPolicySha256 !== physicalPolicy) throw Error('Prepared physical policy differs from actual source descriptor');
  scope = 'verified-source-gather-child';
  original = refinedOriginalFiniteFactory(refinedToken,options.packed,options.layout);
  derived = refinedFiniteFactory(refinedToken,options.packed,options.layout);
 } else {
  if (options.refinedPreparation) throw Error('Ordinary source cannot inherit refined preparation');
  const prepared = await wait(prepareJointClosedBodyProbe(options.packed,'fresh-source'));
  original = sourceJointClosedRawInventoryFactory(prepared,options.layout);
  derived = bodyFaceFeatureLanesWGSL(original);
 }
 assertCurrent();
 options.diagnosticTrace?.('actual-finite-factory-emitted',{});
 const p = options.packed;
 const context = {particleCount:p.particleCount,clothFaceCount:p.clothFaces,bodyFaceCount:p.bodyFaces,geometrySha256:await hash(p.words),materialCoordinatesSha256:p.materialCoordinatesSha256??null,childGeometrySha256:p.childGeometrySha256??null,seamDictionarySha256:p.seamDictionarySha256??null,refinementPolicySha256:p.refinementPolicySha256??null,physicalMassPolicySha256:physicalPolicy,layout:options.layout,bodySha256:p.bodySha256,topologySha256:p.topologySha256,sourceSha256:p.sourceSha256,sourceToken:p.sourceToken,bodyGeneration:p.bodyGeneration};
 const originalHash = await hash(encode(original)), derivedHash = await hash(encode(derived));
 // The first device property read occurs only after exact artifact, three
 // numerical kernels, raw source, body/topology and current-owner validation.
 assertCurrent();
 options.diagnosticTrace?.('component-device-limit-read',{});
 const limit = device.limits.maxComputeWorkgroupsPerDimension;
 const approval = await wait(authorizeFiniteFactoryComponent(finite,{styleId:options.styleId,scope,originalWGSL:original,derivedWGSL:derived,context,factoryDerivation:{policy:'complete-body-finite-fifteen-feature-lanes-v1',featureLanes:15,originalRuntimeFullFactorySourceSha256:originalHash,derivedRuntimeFullFactorySourceSha256:derivedHash,bodyFaceDispatch:'ceil(actualClothFaces*15/64)'},privateScopeProtocol:'one-private-source-registry-v1',dispatch:{clothFaces:p.clothFaces,groups:Math.ceil(p.clothFaces*15/64),maxComputeWorkgroupsPerDimension:limit}},hash));
 options.finiteComponentApproval = approval;
 options.seededNumericalComponentApproval = numeric;
 ownedSeal = captureOptions(options);
 // The actual constructor consumes this unique object. A copied approval,
 // plain boolean or independently bundled private graph cannot authorize it.
 approved.set(options,{approval,numeric,assertCurrent,originalWGSL:original,derivedWGSL:derived});
 return options;
}
