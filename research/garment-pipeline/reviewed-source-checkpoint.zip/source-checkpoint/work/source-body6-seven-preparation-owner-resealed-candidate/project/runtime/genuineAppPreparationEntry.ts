/** Actual copied application preparation + SAME private source registry graph.
 * CPU corpus code supplies authentic body5/input documents, never saved cloth q. */
export {prepareCloth,finalizeSourceGatherCollisionGeometry} from '@seamer/cloth-sim';
export {decodeOriginalGatherDocument} from '$lib/utils/sourceGatherEvidence';
export {sourceGatherRegistry} from '$lib/utils/sourceGatherPreparation';
export {prepareActualSceneSourceInputs} from './sceneSourceInputs.ts';
