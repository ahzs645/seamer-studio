/** NEW physical-only work selection. Every packed inequality remains in the
 * inventory; only response storage is sparse. ORIGINAL-parent violations are
 * selected again even if the current virtual correction has cleared them.
 * A separate ALL-fixed-row pass adds protective inequalities affected later.
 * Never feed the augmented numerical RHS or augmented lambda into this stage. */
export const wholePhysicalSelectionWGSL = String.raw`
struct PhysicalRow { normal:vec4f, span:vec4u, data:vec4f }
struct PhysicalTerm { gradient:vec3f, particle:u32, scalar:vec4f }
struct Config { counts:vec4u, epoch:vec4u } // particles,rows,terms,parent; source,body,step,gate
@group(0) @binding(0) var<storage,read> rows:array<PhysicalRow>;
@group(0) @binding(1) var<storage,read> terms:array<PhysicalTerm>;
@group(0) @binding(2) var<storage,read> currentIdeal:array<vec4f>;
@group(0) @binding(3) var<storage,read> physicalPackProof:array<u32>;
@group(0) @binding(4) var<storage,read_write> selected:array<u32>;
@group(0) @binding(5) var<storage,read_write> state:array<atomic<u32>>;
@group(0) @binding(6) var<uniform> cfg:Config;
fn finiteP(x:f32)->bool{return (bitcast<u32>(x)&0x7f800000u)!=0x7f800000u;}
@compute @workgroup_size(1) fn selection_reset(){
 for(var k=0u;k<8u;k++){atomicStore(&state[k],0u);}
 atomicStore(&state[3],cfg.counts.w);atomicStore(&state[4],cfg.epoch.x);
 atomicStore(&state[5],cfg.epoch.y);atomicStore(&state[6],cfg.epoch.z);atomicStore(&state[7],cfg.epoch.w);
 if(arrayLength(&rows)!=cfg.counts.y||arrayLength(&terms)!=cfg.counts.z||arrayLength(&currentIdeal)!=cfg.counts.x||arrayLength(&selected)!=cfg.counts.y||arrayLength(&physicalPackProof)!=8u||cfg.epoch.z<1u||cfg.epoch.z>40u||cfg.counts.w==0u||cfg.epoch.x==0u||cfg.epoch.y==0u){atomicOr(&state[0],16u);return;}
 if(physicalPackProof[0]!=0u||physicalPackProof[1]!=cfg.counts.y||physicalPackProof[3]!=cfg.counts.z||physicalPackProof[4]!=cfg.counts.w||physicalPackProof[5]!=cfg.epoch.x||physicalPackProof[6]!=cfg.epoch.y||physicalPackProof[7]!=cfg.epoch.w){atomicOr(&state[0],8u);}
}
@compute @workgroup_size(64) fn selection_rows(@builtin(global_invocation_id) gid:vec3u){
 let ordinal=gid.x;if(ordinal>=cfg.counts.y){return;}selected[ordinal]=0u;
 if(atomicLoad(&state[0])!=0u){return;}let row=rows[ordinal];
 if(row.normal.w!=.001||!finiteP(row.data.x)||!finiteP(row.data.y)||row.data.y<0.0||row.span.y>6u||row.span.x>cfg.counts.z||row.span.y>cfg.counts.z-row.span.x){atomicOr(&state[0],2u);return;}
 var effect=0.0;
 for(var k=0u;k<row.span.y;k++){
  let term=terms[row.span.x+k];if(term.particle>=cfg.counts.x||!all(abs(term.gradient)<=vec3f(3.402823466e38))){atomicOr(&state[0],2u);return;}
  let delta=currentIdeal[term.particle];if(!all(abs(delta)<=vec4f(3.402823466e38))||delta.w!=0.0){atomicOr(&state[0],2u);return;}
  effect+=dot(term.gradient,delta.xyz);
 }
 if(!finiteP(effect)){atomicOr(&state[0],2u);return;}
 // EXACT represented positive test, no tolerance or tiny-weight pruning.
 let needed=row.data.x>0.0||row.data.x-effect>0.0;
 if(row.data.y==0.0&&needed){atomicOr(&state[0],32u);return;}
 selected[ordinal]=select(0u,1u,needed);atomicAdd(&state[1],1u);
 if(needed){atomicAdd(&state[2],1u);}
}
@compute @workgroup_size(1) fn selection_complete(){if(atomicLoad(&state[1])!=cfg.counts.y){atomicOr(&state[0],8u);}}
`;

/** Host handles only actual GPU ordinal decisions: no CPU contact distances,
 * RHS, geometry, lambda or floating coefficients are synthesized here. */
export function decodeWholePhysicalSelection(mask, proof, expected) {
 if (!(mask instanceof Uint32Array) || !(proof instanceof Uint32Array) || proof.length !== 8 ||
     !expected || !['rows', 'parentToken', 'sourceToken', 'bodyGeneration', 'physicalSubstep', 'gateRevision']
      .every(k => Number.isSafeInteger(expected[k]) && expected[k] >= 0 && expected[k] <= 0xffffffff) ||
     expected.parentToken < 1 || expected.sourceToken < 1 || expected.bodyGeneration < 1 ||
     expected.physicalSubstep < 1 || expected.physicalSubstep > 40 || mask.length !== expected.rows ||
     mask.some(x => x !== 0 && x !== 1) || proof[0] !== 0 || proof[1] !== expected.rows ||
     proof[2] !== mask.reduce((a, b) => a + b, 0) || proof[3] !== expected.parentToken ||
     proof[4] !== expected.sourceToken || proof[5] !== expected.bodyGeneration ||
     proof[6] !== expected.physicalSubstep || proof[7] !== expected.gateRevision)
  throw Error('Incomplete/stale physical response selection');
 return { selectedPhysicalOrdinals: Uint32Array.from(Array.from(mask, (v, i) => v ? i : -1).filter(i => i >= 0)),
  allFixedPhysicalInequalitiesStillRequired: true, physicalPressureAuthoritative: false,
 };
}
