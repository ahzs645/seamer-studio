/** COPIED actual constructor handoff. Import SOURCE with the app's existing
 * renderer registry. This does not install the new solver into the live scene. */
import {ClothSimulation,type PreparedCloth} from './engine-source/simulator.ts';
import type {SourceJointBackendFactory} from './engine-source/webgpu/sourceJointEngineBridge.ts';
import {prepareAppSourceEngineDelivery,type EngineSceneOwner} from './appEngineDelivery.ts';
import {snapshotAppPreparedData} from './appSIPreparation.ts';
import {equalData} from './refined/bytes.mjs';
import {copyData} from './snapshots.mjs';
import {verifyActualAppFrame} from './AppFramePublication.ts';
export async function drainAppSourceSimulation(simulation:Pick<ClothSimulation,'dispose'|'waitForSourceJointDisposal'>,delivery:{disposeFailedStartup:()=>Promise<void>}){
 const errors:unknown[]=[];
 try{simulation.dispose();}catch(e){errors.push(e);}
 try{await simulation.waitForSourceJointDisposal();}catch(e){errors.push(e);}
 // Delivery owns the physical provider before the engine's lazy first step.
 // Its idempotent destroy also covers a constructor that never initialized backend.
 try{await delivery.disposeFailedStartup();}catch(e){errors.push(e);}
 if(errors.length)throw new AggregateError(errors,'App source simulation/provider drain failed');
}
export function createActualAppSourceSimulation(device:GPUDevice,scope:string,readCurrentOwner:()=>EngineSceneOwner){
 if(scope!=='fresh-source-physical-profile')return null;
 const initial=readCurrentOwner(),pattern=initial.pattern,prepared=initial.prepared,callback=initial.stillCurrent,snapshot=snapshotAppPreparedData(prepared as unknown as PreparedCloth),config=copyData(initial.simulationConfig);
 const current=()=>{const before=readCurrentOwner();if(before.stillCurrent!==callback||callback()!==true)return false;const now=readCurrentOwner();return now.pattern===pattern&&now.prepared===prepared&&now.stillCurrent===callback&&equalData(snapshotAppPreparedData(prepared as unknown as PreparedCloth),snapshot);};
 return (async()=>{
  const delivery=await prepareAppSourceEngineDelivery(device,scope,readCurrentOwner);
  let simulation:ClothSimulation|null=null;
  try{
   if(!delivery||!current())throw Error('App physical scene startup superseded');
   // The actual copied constructor performs its own material/initial geometry
   // validation and starts the genuine source Worker; no mock constructor here.
   simulation=new ClothSimulation(device,prepared as unknown as PreparedCloth,{sourceJointBackendFactory:delivery.sourceJointBackendFactory as unknown as SourceJointBackendFactory});
   simulation.setAnchorScale(0); // Same fresh free SOURCE intent as renderer/host.
   if(!equalData(simulation.simulationConfig,config))throw Error('Actual source constructor configuration differs from authenticated app execution');
   if(!current())throw Error('App physical scene changed during construction');
   const created=simulation;let disposal:Promise<void>|null=null;
   return Object.freeze({simulation:created,prepared,pattern,
    verifyAcceptedFrame(){return verifyActualAppFrame({simulation:created,prepared:prepared as unknown as PreparedCloth,sourceBinding:{...initial.sourceBinding},captureExecutedFrameOwner:delivery.captureExecutedFrameOwner,isCurrent:current});},
    assertCurrent(){if(!current())throw Error('App source simulation publication generation changed');return true;},
    /** Renderer reset/rebuild/dispose must await this, including an active step. */
    dispose(){return disposal??=drainAppSourceSimulation(created,delivery);},
    scope:'approved-components-only',wholeFrameExecuted:false,fitAccepted:false});
  }catch(error){
   const errors:unknown[]=[error];
   if(simulation&&delivery){try{await drainAppSourceSimulation(simulation,delivery);}catch(cleanup){errors.push(cleanup);}}
   else if(delivery){try{await delivery.disposeFailedStartup();}catch(cleanup){errors.push(cleanup);}}
   if(errors.length>1)throw new AggregateError(errors,'App source constructor/startup cleanup failed',{cause:error});throw error;
  }
 })();
}
