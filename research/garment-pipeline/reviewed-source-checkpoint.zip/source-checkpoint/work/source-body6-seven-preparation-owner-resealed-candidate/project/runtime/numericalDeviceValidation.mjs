/** Exact kernel-scoped device approval boundary. Full finite producer approval
 * and actual current/source leases are separate mandatory runtime contracts. */
import{physicalBytesSha256}from'./portablePhysicalHashes.mjs';
import{copyData,equalData}from'./snapshots.mjs';
import{sourceJointSeededOrdinalSelectionWGSL}from'./owner/source-joint-seeded-numerical-clearance-integration/snapshot/sourceJointSeededOrdinalSelection.mjs';
import{sourceJointSeededCSRContactWGSL}from'./owner/source-joint-seeded-numerical-clearance-integration/snapshot/sourceJointSeededCSRContact.mjs';
const SHA=/^[a-f0-9]{64}$/,digest=x=>physicalBytesSha256(typeof x==='string'?new TextEncoder().encode(x):x);
export const NUMERICAL_PACKER_SHADER_SHA256='82488774a7aa0abaaa66c36ebff727611e8662f71177476b24940542e5c5d13c';
export const NUMERICAL_OPERATOR_SHADER_SHA256S=Object.freeze({selectorShaderSha256:await digest(sourceJointSeededOrdinalSelectionWGSL),csrShaderSha256:await digest(sourceJointSeededCSRContactWGSL)});
export const NUMERICAL_OPERATOR_REQUIRED_CASES=Object.freeze(['CURRENT-only','ORIGINAL-only','MECHANICAL-only','all-clear','changed-mobility','genuine-SI-zero-seed-pack','genuine-SI-recorded-normal-seed','genuine-SI-recorded-tangent-seed','genuine-SI-recorded-fixed-minus-zero-seed','genuine-SI-rounded-away-direct-ideal','genuine-SI-original-total-five-mm-reject','historical-legacy-W-zero-seed-BYTE-parity']);
export async function requireSeededNumericalDeviceValidation(bytes,approvedSha256,context){
 if(!context||typeof context.isCurrent!=='function'||context.isCurrent()!==true)throw Error('Current numerical kernel validation owner required');
 const original=copyData(bytes),approved=approvedSha256,callback=context.isCurrent,packer=context.packerWGSL;const captured=copyData({packer});
 const current=()=>{if(callback()!==true||context.isCurrent!==callback||!equalData({packer:context.packerWGSL},captured)||!equalData(bytes,original)||approvedSha256!==approved)throw Error('Numerical artifact bytes/current owner changed across digest');};current();
 if(!(bytes instanceof Uint8Array)||typeof approvedSha256!=='string'||!SHA.test(approvedSha256)||(await digest(original))!==approvedSha256)throw Error('Missing exact approved seeded numerical kernel artifact');
 current();const a=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(original));
 if(a.scope!=='seeded-numerical-operator-kernels-v1'||a.actualDeviceControlsPassed!==true||a.resourcesClosed!==true||a.selectorABI!==3||a.csrABI!==4||a.selectorStorage!==6||a.csrStorage!==8||a.uniformBytes!==48||a.originalNetLimitM!==.005||a.maximumSweeps!==256||a.completeFiniteProducerValidated!==false||a.physicalPressureValidated!==false||a.fullFrameValidated!==false||
  !SHA.test(a.driverSha256??'')||a.packerShaderSha256!==NUMERICAL_PACKER_SHADER_SHA256||!SHA.test(a.actualEvidenceSha256??'')||a.source70ManifestSha256!=='7cdb379a3c681e9f74b9442ec2dde57619f3474e7276d852f524944f013ccd61'||
  Object.entries(NUMERICAL_OPERATOR_SHADER_SHA256S).some(([k,v])=>a[k]!==v)||!Array.isArray(a.coveredCases)||NUMERICAL_OPERATOR_REQUIRED_CASES.some(c=>!a.coveredCases.includes(c))||a.historicalZeroSeedOracleScope!=='legacy-W-algebra-only-NOT-SI'||a.genuineSIOriginalMassPolicySha256!=='e67d1de06cc7baf9cad3325041fd6ddd57419e4c6707ca0530cd1cc94fe08bff'||a.savedZeroSeedByteParity!==true||a.nonzeroDirectIdealByteParity!==true||a.originalTotalMotionNegativeRejected!==true)
  throw Error('Device artifact does not validate executed seeded selector/CSR ABI or declared cases');

 if(typeof packer!=='string'||a.packerShaderSha256!==await digest(packer))throw Error('Numerical kernel artifact does not bind actual executed packer');
 current();return Object.freeze({...structuredClone(a),receiptSha256:approvedSha256});
}
