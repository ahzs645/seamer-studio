import {assert} from './assertions.mjs';import{classifyCoplanarXY,translatePanelX}from'./spacing.mjs';
const bytes=a=>new Uint8Array(a.buffer,a.byteOffset,a.byteLength),sha=async a=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes(a))),b=>b.toString(16).padStart(2,'0')).join('');const equalBytes=(a,b)=>{const x=bytes(a),y=bytes(b);return x.length===y.length&&x.every((v,i)=>v===y[i]);};
// NEW source-only fresh implicit arrangement proposal. No production callsite imports this file.
export async function proposeSourceInitialDepenetration(prepared,pattern,{selfGuard,bodyFacetGuard,finiteGuard,activation,manual=false,explicitConfiguration=false,maximumPanelTranslationM=.003,separationIncrementM=.0005}={}){
 const d=prepared.simData;const fallback=reason=>({prepared,changed:false,reason});
 if(d.sourceStretchPolicy?.policy!=='source-authored-seam-stretch-v1'||!pattern.garmentCodeSource)return fallback('native-or-unknown-source');
 if(manual||explicitConfiguration||pattern.assembly)return fallback('manual-explicit-assembly-or-configuration');
 const pieces=pattern.pieces.filter(p=>p.settings3d?.enable3d!==false),ranges=d.pieces;
 if(ranges.length!==d.sourceStretchPolicy.sourcePieceIds.length||ranges.some(r=>!d.sourceStretchPolicy.sourcePieceIds.includes(r.pieceId)))return fallback('mixed-source');
 if(pieces.some(p=>p.settings3d?.frozen||p.settings3d?.fixTop||p.settings3d?.savedPositions?.length||p.settings3d?.savedDrapeState==='held')||Array.from(d.anchors).some((x,i)=>i%4===3&&x>0))return fallback('cached-held-fixed-or-anchored');
 if(Array.from(d.positions).some((x,i)=>i%4===3&&x===0))return fallback('fixed-particle');
 if(!equalBytes(d.positions,d.arrangedPositions))return fallback('not-fresh-arrangement');
 assert(selfGuard&&bodyFacetGuard&&finiteGuard&&activation,'Actual preflight guards and immutable USED activation required');
 assert(Number.isFinite(maximumPanelTranslationM)&&maximumPanelTranslationM>0&&Number.isFinite(separationIncrementM)&&separationIncrementM>0);
 const original=d.positions,offsets=ranges.map(()=>0),owner=id=>ranges.findIndex(r=>id>=r.start&&id<r.start+r.count),center=j=>{let sum=0;for(let i=ranges[j].start;i<ranges[j].start+ranges[j].count;i++)sum+=original[i*4];return sum/ranges[j].count;};let q=original,report=selfGuard.inspect(q,q),steps=[];
 for(let k=0;k<16&&!report.clear;k++){
  const pair=report.firstUnresolvedPair,ids=[pair.clothFace,pair.otherClothFace].map(face=>Array.from(d.triangles.slice(face*4,face*4+3))),points=ids.map(t=>t.map(i=>Array.from(q.subarray(i*4,i*4+3)))),classification=classifyCoplanarXY(...points);
  // Exact active endpoint contacts belong to the separate source-aware guard proof; never space them here.
  if(classification.classification!=='confirmed-coplanar-interior-overlap')return fallback('unresolved-without-exact-interior-overlap');
  const a=owner(ids[0][0]),b=owner(ids[1][0]);if(a<0||b<0||a===b||ids[0].some(i=>owner(i)!==a)||ids[1].some(i=>owner(i)!==b))return fallback('non-distinct-panel-overlap');
  const sign=center(a)>=center(b)?1:-1;offsets[a]+=separationIncrementM*sign;offsets[b]-=separationIncrementM*sign;
  if(Math.max(...offsets.map(Math.abs))>maximumPanelTranslationM)return fallback('bounded-translation-exhausted');
  q=translatePanelX(original,ranges,offsets);steps.push({pair,classification,panels:[ranges[a].pieceId,ranges[b].pieceId]});report=selfGuard.inspect(q,q);
 }
 if(!report.clear)return fallback('all-pair-self-proof-unresolved');if(!steps.length)return fallback('already-clear');
 if(d.assemblySupport?.groups.some(g=>g.kind==='shoulder'))return fallback('shoulder-support-repreparation-required');
 const bodyReport=bodyFacetGuard.inspect(q,q),finiteReport=finiteGuard.inspect(q,undefined,activation);
 if(!bodyReport.accepted||!finiteReport.safe)return fallback('body-or-finite-preflight-rejected');
 const next={...d,positions:q,arrangedPositions:translatePanelX(d.arrangedPositions,ranges,offsets),anchors:translatePanelX(d.anchors,ranges,offsets)};
 const policy={policy:'source-rigid-initial-depenetration-v1',experimental:true,originalPositionsSha256:await sha(original),actualPositionsSha256:await sha(q),sourceRestCoordinatesSha256:await sha(d.positions2d),bodyPositionsSha256:await sha(prepared.body.positions),bodyTrianglesSha256:await sha(prepared.body.triangles),clothTrianglesSha256:await sha(d.triangles),seamsSha256:await sha(d.seams),seamOrderSha256:await sha(d.seamOrder),actualUsedActivation:{revision:activation.revision,sewnUpTo:activation.sewnUpTo,activeSeams:Array.from(activation.activeSeams)},originalAnchorsSha256:await sha(d.anchors),actualAnchorsSha256:await sha(next.anchors),assemblySupportTargetsSha256:await sha(d.assemblySupport.targets),sourcePhysicalMaterialPolicySha256:d.sourcePhysicalMembrane?.policySha256??null,
  translations:ranges.map((r,i)=>({pieceId:r.pieceId,translationMeters:[offsets[i],0,0]})),modifiedArrays:['positions.X','arrangedPositions.X','anchors.X'],originalSourceArrangedPositionsPreserved:true,actualBodyMinimumClearanceMeters:.001,steps,selfReport:report,bodyReport,finiteReport,GPUValidated:false,fullFitAccepted:false};
 next.sourceInitialArrangementPolicy=policy;return{prepared:{...prepared,simData:next},changed:true,policy};
}
