import { sourcePhysicalRow128PackWGSL } from './physicalRow128PackWGSL.mjs';
const oldDuplicate = 'for(var i=0u;i<index;i++){if(selectedOriginalIds[i]==original){fail(8u);return;}}';
const oldProof = 'if(atomicLoad(&state[cfg.route.y])!=0u||atomicLoad(&state[cfg.route.y+2u])!=7u||atomicLoad(&state[cfg.route.y+1u])>cfg.counts.y){fail(2u);return;}';
if (sourcePhysicalRow128PackWGSL.split(oldDuplicate).length !== 2 || sourcePhysicalRow128PackWGSL.split(oldProof).length !== 2)
 throw Error('Pinned physical pack structure changed; review required');

/** NEW full-inventory packing bookkeeping. Same physical coefficient/gradient/
 * RHS/metric formulas as the device-tested primitive; no numerical work margin.
 * state: authentic incoming proof8, physical output proof8, atomic raw-ID seen
 * bitset ceil(rawStorageCapacity/32). Complete duplicates fail in O(selected)
 * rather than the small primitive's O(selected^2). Eight storage, no live link.
 * This changed shader requires its own actual device proof before authority. */
export const wholePhysicalRowPackWGSL = sourcePhysicalRow128PackWGSL
 .replace('for(var i=0u;i<8u;i++){atomicStore(&state[cfg.route.z+i],0u);}',
  'for(var i=0u;i<8u;i++){atomicStore(&state[cfg.route.z+i],0u);}\n if(cfg.route.y!=0u||cfg.route.z!=8u||cfg.counts.y>0xffffffffu-31u||arrayLength(&state)!=16u+(cfg.counts.y+31u)/32u){fail(1u);return;}\n for(var i=16u;i<arrayLength(&state);i++){atomicStore(&state[i],0u);}')
 .replace(oldProof,
  'if(atomicLoad(&state[0])!=0u||atomicLoad(&state[2])!=7u||atomicLoad(&state[3])!=0u||atomicLoad(&state[1])>cfg.counts.y||atomicLoad(&state[5])!=atomicLoad(&state[1])){fail(2u);return;}')
 .replace(oldDuplicate,
  'let bit=1u<<(original%32u);let seenWord=16u+original/32u;\n if(seenWord>=arrayLength(&state)||(atomicOr(&state[seenWord],bit)&bit)!=0u){fail(8u);return;}');

export function wholePhysicalPackStateWords(rawStorageCapacity) {
 if (!Number.isSafeInteger(rawStorageCapacity) || rawStorageCapacity < 1 || rawStorageCapacity > 0xffffffff - 31)
  throw Error('Invalid complete physical raw capacity');
 return 16 + Math.ceil(rawStorageCapacity / 32);
}
