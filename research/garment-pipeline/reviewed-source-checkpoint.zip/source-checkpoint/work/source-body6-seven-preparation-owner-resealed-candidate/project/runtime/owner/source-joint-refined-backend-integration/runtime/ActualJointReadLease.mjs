/** Explicit exclusive lease remains required: before/after equality detects
 * mutation but cannot prevent change-and-revert during actual GPU enumeration. */
export async function withActualJointReadLease(buffers,read,digest,consumer){
 const sealed=await Promise.all(buffers.map(async entry=>({...entry,sha:await digest(await read(entry.buffer,entry.bytes))})));
 const result=await consumer();
 for(const entry of sealed)if(await digest(await read(entry.buffer,entry.bytes))!==entry.sha)throw Error('Read-only consumer changed actual GPU '+entry.name);
 return result;
}
