/** Work-only proposed app composition entry; renderer retains this closure privately.
 * Uses the genuine app registry. Does not approve, write a ledger, or accept a
 * persisted approval flag. Numerical preparation is captured from the renderer. */
import { sourceGatherRegistry } from '$lib/utils/sourceGatherPreparation';
import { sourceGatherIdentity } from '@seamer/cloth-sim';
import { createBrowserRefinedPreparer } from './preparation.mjs';
import { createBrowserRefinedScopeAdapter } from './RefinedBackendScope.mjs';
import { equalData } from './bytes.mjs';
import { copyData } from '../snapshots.mjs';
import type { Pattern } from '@seamer/pattern-model';
export interface AppPreparedOwner {
 pattern:Pattern; prepared:unknown;
 sourceBinding:{sourceSha256:string;bodySha256:string;topologySha256:string;sourceToken:number;bodyGeneration:number};
 scope:'fresh-source'; manualRecording:boolean; held:boolean; cached:boolean; explicitSettings:boolean;
 stillCurrent:()=>boolean;
}
/** Called only by the genuine renderer, after finalizeSourceGatherCollisionGeometry
 * and explicit SI material preparation. Native/off returns before owner access. */
export function createAppRefinedScope(readCurrentOwner:()=>AppPreparedOwner) {
 const preparer=createBrowserRefinedPreparer(()=>{
  const owner=readCurrentOwner(),identity=sourceGatherIdentity(owner.pattern),body=copyData(owner.pattern.body),scope=sourceGatherRegistry.lookup(owner.pattern);
  const data=(owner.prepared as {simData?:{sourceGatherRefinement?:{approvedEvidence:unknown}}})?.simData;
  const evidence=scope?.approvedEvidence;
  const numericalEvidence=evidence?Object.fromEntries(Object.entries(evidence).filter(([key])=>key!=='sourceIdentity')):undefined;
  const approved=scope?.enabled&&scope.sourceBodyActive&&scope.approvedEvidence
    &&equalData(numericalEvidence,data?.sourceGatherRefinement?.approvedEvidence);
  return {...owner,
   manualRecording:owner.manualRecording||!!owner.pattern.assembly,
   held:owner.held||owner.pattern.settings3d.fixTop||owner.pattern.pieces.some(piece=>piece.settings3d.savedDrapeState==='held'||piece.settings3d.frozen),
   cached:owner.cached||owner.pattern.pieces.some(piece=>piece.settings3d.savedPositions.length>0),
   registryApproved:!!approved,
   stillCurrent:()=>owner.stillCurrent()&&equalData(owner.pattern.body,body)&&sourceGatherIdentity(owner.pattern)===identity
    &&equalData(sourceGatherRegistry.lookup(owner.pattern)?.approvedEvidence,scope?.approvedEvidence)};
 });
 return createBrowserRefinedScopeAdapter(preparer);
}
