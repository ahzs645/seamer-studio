import {sha,digest,equalData} from './bytes.mjs';
/** NEW authority separate from geometric packet. Only trusted current production
 * preparation can supply these actual arrays; this helper never grants approval. */
export async function bindPreparedRefinedMobility({prepared,scope='fresh-source',manualRecording=false,held=false,cached=false,explicitSettings=false}){
 if(scope!=='fresh-source'||manualRecording||held||cached||explicitSettings)throw Error('Only genuine fresh free implicit source mode is eligible');
 const p=structuredClone(prepared),d=p.simData,g=d?.sourceGatherCollisionGeometry;
 if(!p.collisionSafety||!d.sourceGatherRefinement?.approvedEvidence||!g||!(d.positions instanceof Float32Array)||!(d.anchors instanceof Float32Array)||d.positions.length!==d.particleCount*4||d.anchors.length!==d.positions.length||d.pieces.some(piece=>piece.fromSaved))throw Error('Missing actual fresh refined W/anchor preparation');
 const support=d.assemblySupport;if(!support||!(support.targets instanceof Float32Array)||support.targets.length!==d.positions.length||!Array.isArray(support.groups)||!support.targets.every(Number.isFinite)||!d.positions.every(Number.isFinite)||!d.anchors.every(Number.isFinite))throw Error('Complete actual support/anchor arrays required');
 if(d.anchors.some((v,i)=>i%4===3&&v!==0))throw Error('Source preparation contains an effective XYZ hold');
 const mids=g.intervals.flatMap(rec=>rec.sides.filter(side=>side.particles.length===3).map(side=>side.particles[1]));
 if(!mids.length||new Set(mids).size!==mids.length)throw Error('Unknown/repeated free midpoint');
 for(const id of mids){if(!Number.isSafeInteger(id)||id<0||id>=d.particleCount||!(d.positions[id*4+3]>0)||d.anchors[id*4+3]!==0||support.targets[id*4+1]!==0||support.groups.some(group=>group.particles.includes(id)))throw Error('Refined midpoint is fixed/anchored/supported');for(let at=0;at<d.seams.length;at++)if(d.seams[at]===id||(Math.floor(at/4)===id&&d.seams[at]!==-1))throw Error('Refined midpoint has a physical stitch');}
 const state={positions:d.positions,anchors:d.anchors,supportTargets:support.targets,supportGroups:support.groups,midpointIds:mids,scope:'fresh-free-implicit-source',sourcePolicySha256:g.refinementPolicySha256};
 const binding={preparedPositionsSha256:await sha(state.positions),anchorsSha256:await sha(state.anchors),supportTargetsSha256:await sha(state.supportTargets),supportGroupsSha256:await digest(state.supportGroups),midpointIdsSha256:await digest(mids),sourcePolicySha256:state.sourcePolicySha256};
 const captured=structuredClone({...state,binding});
 return Object.freeze({capture:()=>structuredClone(captured),assertBindings(value){if(!equalData(value,captured))throw Error('Actual midpoint physical binding changed');return true;}});
}
