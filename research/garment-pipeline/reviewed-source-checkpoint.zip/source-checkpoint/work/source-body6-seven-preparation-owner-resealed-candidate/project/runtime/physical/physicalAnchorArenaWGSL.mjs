/** NEW arena only. No geometry discovery, mechanical solve or device authority.
 * Eight storage buffers; all geometry is copied from authentic producer handles.
 * Record64 words: header32, three source reference vec4, q/bary/offset/lambda.
 */
export const physicalAnchorArenaWGSL=String.raw`
struct Config{counts:vec4u,epoch:vec4u,offsets:vec4u,routing:vec4u,reactionHeader:vec4u,frame:vec4u,limits:vec4f}
@group(0) @binding(0) var<storage,read_write> pending:array<u32>;
@group(0) @binding(1) var<storage,read> vertices:array<vec4f>;
@group(0) @binding(2) var<storage,read> probe:array<u32>;
@group(0) @binding(3) var<storage,read> keysRaw:array<u32>;
@group(0) @binding(4) var<storage,read> routing:array<u32>;
@group(0) @binding(5) var<storage,read> reaction:array<vec4f>;
@group(0) @binding(6) var<storage,read> rows:array<u32>;
@group(0) @binding(7) var<storage,read_write> work:array<atomic<u32>>;
@group(0) @binding(8) var<uniform> cfg:Config;
const NONE=0xffffffffu;const HEADER=64u;const STRIDE=64u;
fn finite1(x:f32)->bool{return (bitcast<u32>(x)&0x7f800000u)!=0x7f800000u;}
fn finite3(x:vec3f)->bool{return finite1(x.x)&&finite1(x.y)&&finite1(x.z);}
fn fail(bit:u32){atomicOr(&work[0],bit);}
fn slotBase(slot:u32)->u32{return HEADER+slot*STRIDE;}
fn bodyKey(ordinal:u32)->bool{
 let k=ordinal*40u;let r=cfg.offsets.x+ordinal*32u;
 if(keysRaw[k]!=1u||keysRaw[k+1u]!=ordinal||keysRaw[k+2u]!=0u||keysRaw[k+3u]<1u||keysRaw[k+3u]>3u||keysRaw[k+39u]!=0u||bitcast<f32>(keysRaw[r+23u])!=1.){return false;}
 var sum=0.;for(var j=0u;j<keysRaw[k+3u];j++){
  let id=keysRaw[k+8u+j*2u];let beta=bitcast<f32>(keysRaw[k+9u+j*2u]);
  if(id>=cfg.counts.x||!finite1(beta)||beta<=0.||beta>1.||(j>0u&&id<=keysRaw[k+6u+j*2u])){return false;}
  // Body raw uses the same nonnegative source partition. Match EXACT beta bits
  // by ID, without approximate material-key coalescing or world reconstruction.
  var found=false;for(var lane=0u;lane<3u;lane++){if(keysRaw[r+lane]==id&&keysRaw[r+8u+lane]==keysRaw[k+9u+j*2u]){found=true;}}
  if(!found){return false;}sum+=beta;
 }
 return finite1(sum)&&abs(sum-1.)<=2e-6;
}
fn slotMatches(slot:u32,ordinal:u32)->bool{
 let b=slotBase(slot);let k=ordinal*40u;if(pending[b]!=1u||pending[b+1u]!=keysRaw[k+3u]){return false;}
 for(var j=0u;j<pending[b+1u];j++){if(pending[b+4u+j]!=keysRaw[k+8u+j*2u]||pending[b+8u+j]!=keysRaw[k+9u+j*2u]){return false;}}
 return true;
}
fn probeBody(ordinal:u32)->bool{
 let r=ordinal*40u;let p=cfg.offsets.y+ordinal*64u;
 if(probe[p]!=ordinal||probe[p+1u]!=cfg.epoch.x||probe[p+2u]!=cfg.epoch.y||probe[p+3u]!=cfg.epoch.z||probe[p+4u]!=cfg.epoch.w||probe[p+5u]!=0u||probe[r+35u]!=1u||bitcast<f32>(probe[r+39u])!=1.){return false;}
 var sum=0.;for(var j=0u;j<3u;j++){let beta=bitcast<f32>(probe[r+16u+j]);if(!finite1(beta)||beta<0.||beta>1.){return false;}sum+=beta;if(!finite1(bitcast<f32>(probe[r+12u+j]))||!finite1(bitcast<f32>(probe[r+28u+j]))){return false;}}
 // Ready ABI2 producer owns the complete ray/nearest proof. The arena does not
 // manufacture or upgrade it. Its source/ordinal and policy tags are retained.
 return abs(sum-1.)<=2e-6&&probe[p+60u]==2u&&probe[p+61u]==1u&&probe[p+62u]==64u&&probe[p+63u]==40u;
}
@compute @workgroup_size(1) fn arena_begin(){
 for(var i=0u;i<16u;i++){atomicStore(&work[i],0u);}
 atomicStore(&work[3],cfg.frame.x);atomicStore(&work[4],cfg.frame.y);atomicStore(&work[5],cfg.epoch.z);atomicStore(&work[6],cfg.reactionHeader.z);
 if(arrayLength(&pending)!=HEADER+cfg.counts.z*STRIDE||arrayLength(&vertices)!=cfg.counts.x||cfg.counts.y>arrayLength(&keysRaw)/72u||cfg.offsets.x!=cfg.counts.y*40u||arrayLength(&probe)!=cfg.offsets.z||cfg.epoch.z<1u||cfg.epoch.z>40u||cfg.epoch.x==0u||cfg.epoch.y==0u){fail(16u);return;}
 let s=cfg.offsets.w;
 if(atomicLoad(&work[s])!=0u||atomicLoad(&work[s+1u])!=cfg.counts.y||atomicLoad(&work[s+2u])!=7u||atomicLoad(&work[s+3u])!=0u||atomicLoad(&work[s+5u])!=cfg.counts.y||atomicLoad(&work[s+8u])!=0u||atomicLoad(&work[s+9u])+atomicLoad(&work[s+10u])!=cfg.counts.y||atomicLoad(&work[s+11u])!=atomicLoad(&work[s+9u])||atomicLoad(&work[s+12u])!=0u||atomicLoad(&work[s+13u])!=cfg.counts.y||atomicLoad(&work[s+14u])!=cfg.epoch.x||atomicLoad(&work[s+15u])!=cfg.epoch.z||atomicLoad(&work[s+16u])!=2u||atomicLoad(&work[s+17u])!=40u||atomicLoad(&work[s+19u])!=cfg.offsets.y||atomicLoad(&work[s+20u])!=cfg.offsets.z||atomicLoad(&work[s+21u])!=cfg.epoch.x||atomicLoad(&work[s+22u])!=cfg.epoch.y||atomicLoad(&work[s+23u])!=cfg.epoch.w){fail(4u);return;}
 if(cfg.reactionHeader.w==1u){
  let a=cfg.routing.w;
  if(atomicLoad(&work[a])!=0u||atomicLoad(&work[a+1u])!=cfg.counts.w||atomicLoad(&work[a+2u])!=7u||atomicLoad(&work[a+3u])!=cfg.counts.w*6u||atomicLoad(&work[a+4u])!=cfg.reactionHeader.x||atomicLoad(&work[a+5u])!=cfg.reactionHeader.z||atomicLoad(&work[a+6u])!=cfg.epoch.x||atomicLoad(&work[a+7u])!=1u){fail(8u);return;}
  for(var c=0u;c<cfg.reactionHeader.x;c++){let d=a+8u+c*8u;if(atomicLoad(&work[d])!=0u||atomicLoad(&work[d+3u])!=cfg.reactionHeader.z){fail(8u);return;}for(var j=0u;j<3u;j++){let residual=bitcast<f32>(atomicLoad(&work[d+4u+j]));if(!finite1(residual)||residual<0.||residual>cfg.limits[j]){fail(8u);return;}}}
 }
}
// Relative drift is a direct sum of NODE differences from authentic retained
// source references. No world weighted sum/subtraction or CPU XYZ target upload.
@compute @workgroup_size(64) fn arena_relative(@builtin(global_invocation_id) gid:vec3u){
 let ordinal=gid.x;if(ordinal>=cfg.counts.y||atomicLoad(&work[0])!=0u){return;}
 let k=ordinal*40u;let out=cfg.routing.z+ordinal*4u;for(var j=0u;j<4u;j++){atomicStore(&work[out+j],0u);}
 if(keysRaw[k+2u]==1u){atomicAdd(&work[1],1u);return;}
 if(!bodyKey(ordinal)||!probeBody(ordinal)){fail(4u);return;}
 let slot=routing[cfg.routing.x+ordinal];var drift=vec3f(0.);
 if(slot!=NONE){if(slot>=cfg.counts.z||!slotMatches(slot,ordinal)){fail(32u);return;}let b=slotBase(slot);
  for(var j=0u;j<pending[b+1u];j++){let id=pending[b+4u+j];let beta=bitcast<f32>(pending[b+8u+j]);let referencePoint=vec3f(bitcast<f32>(pending[b+32u+j*4u]),bitcast<f32>(pending[b+33u+j*4u]),bitcast<f32>(pending[b+34u+j*4u]));if(!finite3(vertices[id].xyz)||!finite3(referencePoint)){fail(2u);return;}drift+=beta*(vertices[id].xyz-referencePoint);}
 }
 if(!finite3(drift)){fail(2u);return;}for(var j=0u;j<3u;j++){atomicStore(&work[out+j],bitcast<u32>(drift[j]));}atomicStore(&work[out+3u],bitcast<u32>(1.));atomicAdd(&work[1],1u);
}
fn rowValid(row:u32,slot:u32)->bool{
 let r=row*12u;if(row>=cfg.counts.w||rows[r+6u]>1u||rows[r+7u]>=cfg.counts.y){return false;}let ordinal=rows[r+7u];let lambda=reaction[row].x;let mode=atomicLoad(&work[cfg.reactionHeader.y+row]);
 return rows[r+6u]==0u&&routing[ordinal]==slot&&bodyKey(ordinal)&&probeBody(ordinal)&&finite1(lambda)&&lambda>=0.&&finite3(reaction[row].yzw)&&mode<=2u&&((lambda>0.&&mode>0u)||(lambda==0.&&mode==0u&&all(reaction[row].yzw==vec3f(0.))));
}
@compute @workgroup_size(64) fn arena_validate_rows(@builtin(global_invocation_id) gid:vec3u){
 let row=gid.x;if(row>=cfg.counts.w||atomicLoad(&work[0])!=0u){return;}let r=row*12u;let ordinal=rows[r+7u];
 if(ordinal>=cfg.counts.y||rows[r+6u]>1u||!finite1(reaction[row].x)||reaction[row].x<0.||!finite3(reaction[row].yzw)){fail(4u);return;}
 let mode=atomicLoad(&work[cfg.reactionHeader.y+row]);if(mode>2u){fail(4u);return;}
 if(rows[r+6u]==1u){if(mode!=0u){fail(4u);}return;}
 let slot=routing[ordinal];if(slot==NONE){if(reaction[row].x>0.||mode!=0u){fail(32u);}return;}
 if(slot>=cfg.counts.z||!rowValid(row,slot)){fail(4u);}
}
@compute @workgroup_size(64) fn arena_validate_slots(@builtin(global_invocation_id) gid:vec3u){
 let slot=gid.x;if(slot>=cfg.counts.z||atomicLoad(&work[0])!=0u){return;}let begin=routing[cfg.routing.y+slot];let end=routing[cfg.routing.y+slot+1u];if(end<begin||end>cfg.counts.w){fail(16u);return;}
 for(var i=begin;i<end;i++){let row=routing[cfg.routing.z+i];if(!rowValid(row,slot)){fail(4u);return;}let ordinal=rows[row*12u+7u];let record=ordinal*40u;for(var axis=0u;axis<3u;axis++){let material=bitcast<f32>(probe[record+select(24u,28u,cfg.frame.z==3u)+axis]);let skin=bitcast<f32>(probe[record+select(0u,12u,cfg.frame.z==3u)+axis]);if(!finite1(material-skin)){fail(2u);return;}}let b=slotBase(slot);if(pending[b]!=0u&&!slotMatches(slot,ordinal)){fail(32u);return;}for(var j=0u;j<keysRaw[ordinal*40u+3u];j++){if(!finite3(vertices[keysRaw[ordinal*40u+8u+j*2u]].xyz)){fail(2u);return;}}}
 atomicAdd(&work[1],1u);
}
@compute @workgroup_size(1) fn arena_seal_relative(){if(atomicLoad(&work[1])!=cfg.counts.y){fail(8u);}}
@compute @workgroup_size(1) fn arena_seal_slots(){if(atomicLoad(&work[1])!=cfg.counts.z){fail(8u);}}
// A separate pass is the device-wide barrier: a bad slot disables ALL writes.
// Slot lambda is ONLY the minimum-original-alias diagnostic lane. A zero owner
// can coexist with pressure/SLIDE in another alias; it is never total pressure,
// a reusable multiplier, or evidence of separation. Full row reactions belong
// to the separately bound final physical receipt/controller ledger.
@compute @workgroup_size(64) fn arena_stage(@builtin(global_invocation_id) gid:vec3u){
 let slot=gid.x;if(slot>=cfg.counts.z||atomicLoad(&work[0])!=0u){return;}let begin=routing[cfg.routing.y+slot];let end=routing[cfg.routing.y+slot+1u];if(begin==end){return;}
 let b=slotBase(slot);var owner=NONE;var positive=false;var mode=0u;
 for(var i=begin;i<end;i++){let row=routing[cfg.routing.z+i];let ordinal=rows[row*12u+7u];if(owner==NONE||ordinal<rows[owner*12u+7u]){owner=row;}if(reaction[row].x>0.){positive=true;mode=max(mode,atomicLoad(&work[cfg.reactionHeader.y+row]));}}
 if(!positive){return;}let ordinal=rows[owner*12u+7u];let k=ordinal*40u;let first=pending[b]==0u;
 if(first){for(var j=0u;j<STRIDE;j++){pending[b+j]=0u;}pending[b]=1u;pending[b+1u]=keysRaw[k+3u];for(var j=0u;j<keysRaw[k+3u];j++){pending[b+4u+j]=keysRaw[k+8u+j*2u];pending[b+8u+j]=keysRaw[k+9u+j*2u];}}
 pending[b+2u]=mode;pending[b+3u]=ordinal;pending[b+12u]=cfg.frame.x;pending[b+13u]=cfg.frame.y;pending[b+14u]=cfg.epoch.z;pending[b+15u]=cfg.epoch.w;
 // New slot and SLIDE anchor transport require a dedicated invocation using
 // authentic HISTORY or FINAL candidate, respectively. Host phase2 initializes
 // new refs from history, then phase3 overwrites only sliding refs with FINAL.
 if((cfg.frame.z==2u&&first)||(cfg.frame.z==3u&&mode==2u)){for(var j=0u;j<pending[b+1u];j++){let v=vertices[pending[b+4u+j]];pending[b+32u+j*4u]=bitcast<u32>(v.x);pending[b+33u+j*4u]=bitcast<u32>(v.y);pending[b+34u+j*4u]=bitcast<u32>(v.z);pending[b+35u+j*4u]=bitcast<u32>(v.w);}}
 if((first&&cfg.frame.z==2u)||(mode==2u&&cfg.frame.z==3u)){let r=ordinal*40u;let at=select(0u,12u,cfg.frame.z==3u);for(var j=0u;j<3u;j++){pending[b+44u+j]=probe[r+at+j];pending[b+48u+j]=probe[r+at+4u+j];pending[b+52u+j]=bitcast<u32>(bitcast<f32>(probe[r+select(24u,28u,cfg.frame.z==3u)+j])-bitcast<f32>(probe[r+at+j]));}pending[b+47u]=probe[r+at+3u];}
 for(var j=0u;j<4u;j++){pending[b+56u+j]=bitcast<u32>(reaction[owner][j]);}
}
`;
