/** Shared real constructor-return boundary. Always drain on a stale return,
 * including the microtask after compilation completes. Native exits upstream. */
export async function finishOwnedStartup(owner,isCurrent) {
 try {
  await owner.numericalReady;
  if (isCurrent() !== true) throw Error('Source factory owner changed during startup');
  return owner;
 } catch (error) {
  try { await owner.destroy(); }
  catch (cleanup) { throw new AggregateError([error,cleanup],'Source numerical startup and cleanup failed',{cause:error}); }
  throw error;
 }
}
