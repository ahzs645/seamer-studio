import{physicalAliasWGSL}from'./physicalAliasWGSL.mjs';
/** NEW whole-inventory key emitter, device UNVALIDATED. O(raw) independent
 * records; integer host grouping consumes GPU keys, never drops original proofs.
 * Every raw row remains available for mechanical protection/complete requery. */
const arithmetic=physicalAliasWGSL.slice(physicalAliasWGSL.indexOf('struct Big {'),physicalAliasWGSL.indexOf('fn valid('));
export const wholePhysicalAliasWGSL=String.raw`
struct FiniteRow{a:vec4u,b:vec4u,wa:vec4f,wb:vec4f,n:vec4f,q:vec4f,feature:vec4u,proof:vec4u}
struct Config{counts:vec4u,epoch:vec4u} // rawN,particles,capacity,parent; source,body,step,gate
@group(0) @binding(0) var<storage,read> raw:array<FiniteRow>;
@group(0) @binding(1) var<storage,read> rawProof:array<u32>;
@group(0) @binding(2) var<storage,read_write> records:array<u32>; // exact40 words/raw
@group(0) @binding(3) var<storage,read_write> state:array<atomic<u32>>;
@group(0) @binding(4) var<uniform> cfg:Config;
const NONE=0xffffffffu;
fn finite1(x:f32)->bool{return (bitcast<u32>(x)&0x7f800000u)!=0x7f800000u;}
`+arithmetic+String.raw`
fn validRaw(r:FiniteRow)->bool{
 let protection=r.a.w==2u||r.a.w==6u;let required=select(63u,127u,protection);
 if(r.a.w<1u||r.a.w>6u||r.a.w==5u||r.b.w!=required||r.proof.w!=required||r.feature.z!=cfg.epoch.w||r.proof.x!=cfg.epoch.y||r.proof.y!=cfg.epoch.z||r.proof.z!=cfg.epoch.x){return false;}
 if(!finite1(r.wa.w)||!finite1(r.wb.w)||r.wb.w<0.||r.wa.w<=r.wb.w||r.n.w!=.001||abs(dot(r.n.xyz,r.n.xyz)-1.)>4e-5){return false;}
 var sumA=0.;var sumB=0.;for(var k=0u;k<3u;k++){
  if(!finite1(r.wa[k])||!finite1(r.wb[k])||r.wa[k]<0.||r.wb[k]<0.){return false;}
  if(r.a[k]!=NONE){if(r.a[k]>=cfg.counts.y){return false;}sumA+=r.wa[k];}else if(r.wa[k]!=0.){return false;}
  if(r.b[k]!=NONE){if(r.b[k]>=cfg.counts.y||r.a.w>=3u){return false;}sumB+=r.wb[k];}else if(r.wb[k]!=0.){return false;}
  if(!finite1(r.n[k])||!finite1(r.q[k])){return false;}
 }
 if(abs(sumA-1.)>2e-6 || (r.a.w<3u && (abs(sumB-1.)>2e-6||r.feature.x>=r.feature.y))){return false;}
 for(var i=0u;i<3u;i++){for(var j=i+1u;j<3u;j++){if((r.a[i]!=NONE&&r.a[i]==r.a[j])||(r.b[i]!=NONE&&r.b[i]==r.b[j])){return false;}}for(var j=0u;j<3u;j++){if(r.a[i]!=NONE&&r.a[i]==r.b[j]){return false;}}}
 return r.a.x!=NONE&&r.q.w==select(0.,1.,r.a.w>=3u);
}
@compute @workgroup_size(1) fn reset(){
 if(arrayLength(&state)<8u){return;}for(var i=0u;i<8u;i++){atomicStore(&state[i],0u);}
 atomicStore(&state[3],cfg.counts.w);atomicStore(&state[4],cfg.epoch.x);atomicStore(&state[5],cfg.epoch.y);atomicStore(&state[6],cfg.epoch.z);atomicStore(&state[7],cfg.epoch.w);
 if(cfg.counts.x>0xffffffffu/40u||cfg.counts.x>cfg.counts.z||cfg.counts.z!=arrayLength(&raw)||cfg.counts.x*40u!=arrayLength(&records)||arrayLength(&rawProof)!=8u||cfg.epoch.z<1u||cfg.epoch.z>40u||cfg.counts.w==0u||cfg.epoch.x==0u||cfg.epoch.y==0u){atomicOr(&state[0],16u);return;}
 if(rawProof[0]!=0u||rawProof[1]!=cfg.counts.x||rawProof[2]!=7u||rawProof[3]!=0u||rawProof[5]!=cfg.counts.x){atomicOr(&state[0],8u);}
}
@compute @workgroup_size(64) fn emit(@builtin(global_invocation_id) gid:vec3u){
 let ordinal=gid.x;if(ordinal>=cfg.counts.x||atomicLoad(&state[0])!=0u){return;}
 let o=ordinal*40u;for(var k=0u;k<40u;k++){records[o+k]=0u;}records[o+1u]=ordinal;
 let r=raw[ordinal];if(!validRaw(r)){atomicOr(&state[0],2u);return;}
 var ids:array<u32,6>;var betas:array<u32,6>;for(var k=0u;k<6u;k++){ids[k]=NONE;betas[k]=0u;}
 var count=0u;for(var lane=0u;lane<6u;lane++){
  var id=NONE;if(lane<3u){id=r.a[lane];}else{id=r.b[lane-3u];}if(id==NONE){continue;}
  let coefficient=mergedCoefficient(r,id);if(coefficient.valid==0u){atomicOr(&state[0],32u);return;}if(coefficient.nonzero==0u){continue;}
  var at=count;while(at>0u&&ids[at-1u]>id){ids[at]=ids[at-1u];betas[at]=betas[at-1u];at--;}
  ids[at]=id;betas[at]=bitcast<u32>(coefficient.value);count++;
 }
 var planeRow=r;if(r.q.w==0.){planeRow.q=vec4f(0.);}
 let plane=exactPlane(planeRow);records[o]=1u;records[o+2u]=select(1u,0u,r.q.w==1.);records[o+3u]=count;
 for(var k=0u;k<4u;k++){records[o+4u+k]=bitcast<u32>(r.n[k]);}
 for(var k=0u;k<6u;k++){records[o+8u+k*2u]=ids[k];records[o+9u+k*2u]=betas[k];}
 for(var k=0u;k<18u;k++){records[o+20u+k]=plane.magnitude.words[k];}records[o+38u]=select(0u,1u,plane.negative);
 atomicAdd(&state[1],1u);if(r.q.w==1.){atomicAdd(&state[2],1u);}
}
@compute @workgroup_size(1) fn complete(){if(arrayLength(&state)>=8u&&atomicLoad(&state[1])!=cfg.counts.x){atomicOr(&state[0],8u);}}
`;
/** Integer-only aliases over actual GPU-produced keys. Zero tolerance, no nearest
 * rankings, ALL raw ordinals partitioned exactly once. Retain every alias proof. */
export function groupActualPhysicalAliasKeys(records,proof,expected){
 if(!expected||Object.values(expected).some(x=>!Number.isSafeInteger(x)||x<0||x>0xffffffff)||expected.sourceToken<1||expected.bodyGeneration<1||expected.parentToken<1||expected.physicalSubstep<1||expected.physicalSubstep>40||expected.rawOccurrences>0xffffffff/40)throw Error('Invalid actual physical alias epoch');
 if(!(records instanceof Uint32Array)||records.length!==expected.rawOccurrences*40||!(proof instanceof Uint32Array)||proof.length!==8||Array.from(proof).some((x,i)=>i!==2&&x!==[0,expected.rawOccurrences,0,expected.parentToken,expected.sourceToken,expected.bodyGeneration,expected.physicalSubstep,expected.gateRevision][i]))throw Error('Incomplete/unbound actual physical alias keys');
 let bodyCount=0;const groups=[],byKey=new Map(),aliases=new Uint32Array(expected.rawOccurrences);
 for(let ordinal=0;ordinal<expected.rawOccurrences;ordinal++){
  const r=records.subarray(ordinal*40,(ordinal+1)*40);if(r[0]!==1||r[1]!==ordinal||r[2]>1||r[3]>6||r[39]!==0)throw Error('Unknown actual physical key');
  if(r[2]===0)bodyCount++;
  const key=Array.from(r.subarray(2)).join(','),previous=byKey.get(key);
  if(previous!==undefined){groups[previous].originalRawAliases.push(ordinal);aliases[ordinal]=groups[previous].originalRawAliases[0];}
  else{const index=groups.length;byKey.set(key,index);groups.push({originalRawAliases:[ordinal],canonicalKeyWords:r.slice(2)});aliases[ordinal]=ordinal;}
 }
 if(proof[2]!==bodyCount)throw Error('Actual physical body count mismatch');
 return{groups,aliases,selectedOriginalIds:Uint32Array.from(groups,g=>g.originalRawAliases[0]),allOriginalProofsRetained:true,physicalPressureAuthoritative:false};
}
/** Exact already-read authentic producer status. A complete supported inventory
 * is distinct from a count-only receipt; unknown-feature count cannot vanish. */
export function requirePhysicalIncomingRawProof(proof,rawOccurrences){
 if(!(proof instanceof Uint32Array)||proof.length!==8||!Number.isSafeInteger(rawOccurrences)||rawOccurrences<0||rawOccurrences>0xffffffff||proof[0]!==0||proof[1]!==rawOccurrences||proof[2]!==7||proof[3]!==0||proof[5]!==rawOccurrences)throw Error('Incomplete or unknown physical incoming raw inventory');
 return proof.slice();
}
