import{packagedPhysicalPolicy}from'./packagedPhysicalPolicy.mjs';
import{physicalBytesSha256}from'./portablePhysicalHashes.mjs';
import{copyData,equalData}from'./snapshots.mjs';
export const SOURCE_ANCHOR_PARTITION_POLICY=Object.freeze({sourceMaterialPartitionError:2e-6,bodyBarycentricPartitionError:2e-6});
export const SOURCE_ANCHOR_PARTITION_POLICY_ENCODING='finite-body-material-anchor-partition-v1';
export function anchorPartitionPolicyText(policy){
 if(!policy||Object.keys(policy).sort().join(',')!=='bodyBarycentricPartitionError,sourceMaterialPartitionError'||Object.values(policy).some(x=>typeof x!=='number'||!Number.isFinite(x)||x<0||x>2e-6))throw Error('Invalid dimensionless anchor partition policy');
 const text=JSON.stringify({encoding:SOURCE_ANCHOR_PARTITION_POLICY_ENCODING,bodyBarycentricPartitionError:policy.bodyBarycentricPartitionError,sourceMaterialPartitionError:policy.sourceMaterialPartitionError});return text;
}
export const SOURCE_ANCHOR_PARTITION_POLICY_SHA256=packagedPhysicalPolicy.partitionSha256;
export async function anchorPartitionPolicySha256(policy){const snapshot=copyData(policy),text=anchorPartitionPolicyText(snapshot),sha=await physicalBytesSha256(new TextEncoder().encode(text));if(!equalData(policy,snapshot))throw Error("Anchor partition policy changed across hash");return sha;}
export function requireAnchorPartition(weights,kind,policy){
 anchorPartitionPolicyText(policy);const field=kind==='source'?'sourceMaterialPartitionError':kind==='body'?'bodyBarycentricPartitionError':null;
 if(!field||!Array.isArray(weights)||weights.length<1||weights.length>3||weights.some(x=>typeof x!=='number'||!Number.isFinite(x)||x<0||x>1)||Math.abs(weights.reduce((s,x)=>s+x,0)-1)>policy[field])throw Error('Finite source/body anchor partition invalid');return true;
}
export async function requireExecutedAnchorPartitionPolicy(binding,deviceValidation){
 const policy=deviceValidation?.validatedAnchorPartitionPolicy,sha=await anchorPartitionPolicySha256(policy);
 if(binding?.executedAnchorPartitionPolicySha256!==sha||deviceValidation?.validatedAnchorPartitionPolicySha256!==sha)throw Error('Executed anchor partition policy not validated/bound');return structuredClone(policy);
}
