// One intrinsic data boundary for this NEW composed graph. Preserved physical
// 58 and numerical 84 epochs retain their original independent snapshots.
export {copyData,equalData} from '../snapshots.mjs';
