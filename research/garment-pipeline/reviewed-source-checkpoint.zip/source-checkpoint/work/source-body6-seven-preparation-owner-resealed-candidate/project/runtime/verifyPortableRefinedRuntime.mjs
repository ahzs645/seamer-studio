/** Portable orchestration only. No kernel, numerical constraint, GPU allocation,
 * approval, or frame commit. The composition owner supplies its real scope API. */
const SHA=/^[a-f0-9]{64}$/;
const bytes=x=>x instanceof ArrayBuffer?new Uint8Array(x):ArrayBuffer.isView(x)?new Uint8Array(x.buffer,x.byteOffset,x.byteLength):null;
function sameBytes(a,b){const x=bytes(a),y=bytes(b);return !!x&&!!y&&x.length===y.length&&x.every((v,i)=>v===y[i]);}
async function digest(value){const snapshot=bytes(value)?.slice();if(!snapshot)throw Error('Actual readback bytes required');return Array.from(new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256',snapshot)),v=>v.toString(16).padStart(2,'0')).join('');}
export function snapshotPortablePhysicalKey(key){const fields=['generation','frameSequence','physicalSubstep','parentToken','gateRevision'],snapshot=Object.fromEntries(fields.map(field=>[field,key?.[field]]));if(!Object.values(snapshot).every(x=>Number.isSafeInteger(x)&&x>=0&&x<=0xffffffff)||snapshot.frameSequence<1||snapshot.parentToken<1||snapshot.physicalSubstep<1||snapshot.physicalSubstep>40)throw Error('Unbound physical parent key');return Object.freeze(snapshot);}
export async function verifyPortableRefinedRuntime(options,mode='source') {
 if(mode==='native')return null;
 const {scopeAdapter,token,packed,layout,observed,captureController,read,isCurrent}=options;
 if(token===null)return null;
 if(!token||typeof captureController!=='function'||typeof read!=='function'||typeof isCurrent!=='function'||typeof scopeAdapter?.assertRefinedRuntime!=='function'||typeof scopeAdapter?.requireVerifiedRefinedScope!=='function')throw Error('Actual refined scope/controller/read lease required');
 const key=snapshotPortablePhysicalKey(options.key),n=packed.particleCount*4;
 if(!(observed.current instanceof Float32Array)||!(observed.previous instanceof Float32Array)||!(observed.gateWords instanceof Uint32Array)||observed.current.length!==n||observed.previous.length!==n||observed.gateWords.byteLength!==layout.byteLength)throw Error('Exact actual observed runtime layouts required');
 const originals={current:observed.current,previous:observed.previous,gateWords:observed.gateWords,currentBuffer:observed.currentBuffer,previousBuffer:observed.previousBuffer,gateBuffer:observed.gateBuffer};
 if(new Set([originals.currentBuffer,originals.previousBuffer,originals.gateBuffer]).size!==3)throw Error('Distinct actual runtime GPU buffers required');
 const arrays={current:observed.current.slice(),previous:observed.previous.slice(),gateWords:observed.gateWords.slice()};
 const entries=[{name:'current',buffer:originals.currentBuffer,bytes:n*4,array:arrays.current},{name:'history',buffer:originals.previousBuffer,bytes:n*4,array:arrays.previous},{name:'gate',buffer:originals.gateBuffer,bytes:layout.byteLength,array:arrays.gateWords}];
 const current=()=>{
  scopeAdapter.requireVerifiedRefinedScope(token,packed,layout);
  if(isCurrent()!==true)throw Error('Actual refined generation/parent lease changed');
  if(Object.keys(originals).some(k=>observed[k]!==originals[k])||!sameBytes(observed.current,arrays.current)||!sameBytes(observed.previous,arrays.previous)||!sameBytes(observed.gateWords,arrays.gateWords))throw Error('Actual observed runtime bytes/identities changed');
 };
 current();
 // Same exclusive device lease as caller's producer. Awaited hashing and mobility
 // remain INSIDE before/after seals; no callback can advance the solver here.
 const sealed=[];
 for(const entry of entries){const actual=await read(entry.buffer,entry.bytes);if(bytes(actual)?.byteLength!==entry.bytes||!sameBytes(actual,entry.array))throw Error('Actual GPU readback differs from observed '+entry.name);sealed.push({...entry,sha256:await digest(actual)});current();}
 const state=structuredClone(await captureController(key));current();
 if(!state||state.controllerOwned!==true||Object.keys(key).some(k=>state.key?.[k]!==key[k])||state.usedActivation?.revision!==key.gateRevision)throw Error('Actual refined controller state has foreign physical key');
 const receipt=await scopeAdapter.assertRefinedRuntime(token,packed,layout,{...state,parent:arrays.current,history:arrays.previous,gate:arrays.gateWords});
 current();
 if(!receipt||!SHA.test(receipt.refinedPreparationReceiptSha256)||!SHA.test(receipt.usedGateSha256)||!SHA.test(receipt.physicalMassPolicySha256))throw Error('Awaited actual mobility receipt required');
 for(const entry of sealed){const actual=await read(entry.buffer,entry.bytes);if(bytes(actual)?.byteLength!==entry.bytes||await digest(actual)!==entry.sha256)throw Error('Read-only awaited mobility changed actual GPU '+entry.name);current();}
 return receipt;
}
