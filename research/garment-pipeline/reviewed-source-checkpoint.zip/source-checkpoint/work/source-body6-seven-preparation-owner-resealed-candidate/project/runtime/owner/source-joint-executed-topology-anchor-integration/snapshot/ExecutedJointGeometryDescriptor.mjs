/** NEW copied execution-byte descriptor. No geometry/response policy or device factory.
 * GPU origin is supplied by the provider's actual ordered readback implementation;
 * this helper binds the returned bytes, not a caller-provided readiness boolean. */
import{physicalBytesSha256}from'../../../portablePhysicalHashes.mjs';
import{copyData,equalData}from'../../../snapshots.mjs';
const sha=async(x,current)=>{const h=await physicalBytesSha256(typeof x==='string'?new TextEncoder().encode(x):x);if(typeof current!=='function'||current()!==true)throw Error('Executed byte digest owner changed');return h;},SHA=/^[a-f0-9]{64}$/;
const receipts=new WeakMap(),descriptors=new WeakSet();
const bytes=x=>{if(x instanceof ArrayBuffer)return new Uint8Array(x.slice(0));if(ArrayBuffer.isView(x))return new Uint8Array(x.buffer,x.byteOffset,x.byteLength).slice();throw Error('Exact execution bytes required');};
const wordsLE=w=>{const a=new Uint8Array(w.length*4),d=new DataView(a.buffer);w.forEach((x,i)=>d.setUint32(i*4,x,true));return a;};
const u32=x=>Number.isSafeInteger(x)&&x>=0&&x<=0xffffffff;
const canonical=x=>JSON.stringify(Object.fromEntries(Object.entries(x).sort(([a],[b])=>a.localeCompare(b))));
async function derive(words,current){
 if(!(words instanceof Uint32Array)||words.length<16||words[0]!==0x4a464731||words[1]!==1||words[6]!==16)throw Error('Executed packed geometry ABI required');
 const [particles,clothFaces,bodyVertices,bodyFaces]=Array.from(words.slice(2,6));
 if(![particles,clothFaces,bodyVertices,bodyFaces].every(x=>u32(x)&&x>0)||words[7]!==16+clothFaces*4||words[8]!==words[7]+bodyFaces*4||words[9]!==words[8]+bodyVertices*4||words[10]<words[9]||words[10]+words[11]>words.length||words[12]<words[10]+words[11]||words[12]+words[13]>words.length)throw Error('Executed finite geometry sections/counts invalid');
 const cloth=words.slice(words[6],words[7]),skin=words.slice(words[7],words[8]),xyz=words.slice(words[8],words[9]);
 for(const [triangles,n]of [[cloth,particles],[skin,bodyVertices]])for(let i=0;i<triangles.length;i+=4)if(new Set(triangles.slice(i,i+3)).size!==3||triangles.slice(i,i+3).some(x=>x>=n))throw Error('Invalid executed finite triangle IDs');
 const fv=new Float32Array(xyz.buffer);if(!fv.every(Number.isFinite))throw Error('Nonfinite executed skin bytes');
 return{particleCount:particles,clothFaceCount:clothFaces,bodyFaceCount:bodyFaces,bodyVertexCount:bodyVertices,sourceToken:words[14],bodyGeneration:words[15],topologySha256:(await sha(wordsLE(cloth),current)),bodySha256:(await sha(wordsLE(xyz),current)),bodyTopologySha256:(await sha(wordsLE(skin),current)),packedGeometrySha256:(await sha(wordsLE(words),current))};
}
export async function createExecutedJointGeometryDescriptor(input){const{packed,sourceExecutionBytes,sourceExecutionEncoding,expectedBinding,isCurrent}=input;if(typeof isCurrent!=='function'||isCurrent()!==true)throw Error('Current actual source descriptor owner required');const consume=()=>({words:packed?.words,particleCount:packed?.particleCount,clothFaces:packed?.clothFaces,bodyFaces:packed?.bodyFaces,sourceToken:packed?.sourceToken,bodyGeneration:packed?.bodyGeneration,sourceSha256:packed?.sourceSha256,bodySha256:packed?.bodySha256,topologySha256:packed?.topologySha256,sourceBytes:sourceExecutionBytes,binding:expectedBinding});const before=copyData(consume());const current=()=>{if(isCurrent()!==true||!equalData(consume(),before))throw Error('Source execution preparation mutated/stale across digest');return true;};current();
 const source=bytes(sourceExecutionBytes),words=Uint32Array.from(packed?.words??[]),metadata={particleCount:packed?.particleCount,clothFaces:packed?.clothFaces,bodyFaces:packed?.bodyFaces,sourceToken:packed?.sourceToken,bodyGeneration:packed?.bodyGeneration,sourceSha256:packed?.sourceSha256,bodySha256:packed?.bodySha256,topologySha256:packed?.topologySha256},binding=structuredClone(expectedBinding);
 if(!['raw-utf8-authentic-si-initial-descriptor-v1','raw-utf8-frozen-source-execution-descriptor-v1'].includes(sourceExecutionEncoding)||source.length===0)throw Error('Declared raw source execution descriptor domain required');
 const parsed=await derive(words,current),sourceSha256=(await sha(source,current));
 for(const key of ['sourceSha256','bodySha256','topologySha256'])if(!SHA.test(binding?.[key])||metadata[key]!==binding[key]||(key==='sourceSha256'?sourceSha256:parsed[key])!==binding[key])throw Error('Actual execution byte hash differs: '+key);
 let declared;try{declared=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(source));}catch{throw Error('Authentic raw UTF8 source descriptor JSON required');}
 if(declared.particleCount!==parsed.particleCount||!Array.isArray(declared.clothTriangles)||declared.clothTriangles.length!==parsed.clothFaceCount*4||!declared.clothTriangles.every(u32)||(await sha(wordsLE(Uint32Array.from(declared.clothTriangles)),current))!==parsed.topologySha256)throw Error('Raw source descriptor cloth topology/count differs from execution');
 if(!Array.isArray(declared.bodyPositions)||declared.bodyPositions.length!==parsed.bodyVertexCount*3||!declared.bodyPositions.every(x=>typeof x==='number'&&Number.isFinite(x))||!Array.isArray(declared.bodyIndices)||declared.bodyIndices.length!==parsed.bodyFaceCount*3||!declared.bodyIndices.every(u32))throw Error('Raw source descriptor body sections/count differ');
 const sourceBody=Float32Array.from(declared.bodyPositions.flatMap((x,i)=>i%3===2?[x,0]:[x])),sourceSkin=Uint32Array.from(declared.bodyIndices.flatMap((x,i)=>i%3===2?[x,0]:[x]));
 if((await sha(wordsLE(new Uint32Array(sourceBody.buffer)),current))!==parsed.bodySha256||(await sha(wordsLE(sourceSkin),current))!==parsed.bodyTopologySha256)throw Error('Raw source descriptor finite skin bytes differ from execution');
 for(const [key,meta]of [['particleCount','particleCount'],['clothFaceCount','clothFaces'],['bodyFaceCount','bodyFaces'],['sourceToken','sourceToken'],['bodyGeneration','bodyGeneration']])if(parsed[key]!==metadata[meta]||(['sourceToken','bodyGeneration'].includes(key)&&parsed[key]!==binding[key]))throw Error('Actual execution count/token differs: '+key);
 current();const base=Object.freeze({encoding:'executed-joint-packed-byte-descriptor-v1',sourceExecutionEncoding,sourceSha256,...parsed,sourceHashDomain:'exact-raw-UTF8-descriptor-file-bytes',bodyHashDomain:'float32-le-vec4-skin-positions-full-W',topologyHashDomain:'uint32-le-vec4-cloth-triangles-full-outside-orientation-word',bodyTopologyHashDomain:'uint32-le-vec4-skin-triangles',nativePatternHashInterchangeable:false});
 current();const descriptor=Object.freeze({capture:()=>structuredClone(base),packedBytes:()=>wordsLE(words),sourceBytes:()=>source.slice(),async sealActualUpload({buffer,readGpuBytes,observedBinding,isCurrent}){
  if(!buffer||typeof readGpuBytes!=='function'||typeof isCurrent!=='function'||buffer.size<words.byteLength||isCurrent()!==true)throw Error('Missing exclusive ordered geometry readback lease');
  const observed=structuredClone(observedBinding);
  for(const key of ['sourceSha256','bodySha256','topologySha256','sourceToken','bodyGeneration'])if(observed[key]!==base[key])throw Error('Observed executed geometry differs: '+key);
  const actual=bytes(await readGpuBytes(buffer,words.byteLength));
  if(isCurrent()!==true||actual.byteLength!==words.byteLength||(await sha(actual,current))!==base.packedGeometrySha256)throw Error('Actual GPU immutable geometry bytes changed');
  const view=new DataView(actual.buffer,actual.byteOffset,actual.byteLength),w=new Uint32Array(actual.byteLength/4);w.forEach((_,i)=>w[i]=view.getUint32(i*4,true));const derived=await derive(w,()=>current()&&isCurrent());
  for(const key of Object.keys(derived))if(derived[key]!==base[key])throw Error('Actual GPU geometry section differs: '+key);
  const data={...base,geometryReadbackBinding:'ordered-full-owned-GPU-geometry-readback-v1',observedSnapshotEpoch:observed.snapshotEpoch??null,observedCurrentSha256:observed.currentSha256??null,observedHistorySha256:observed.historySha256??null,observedGateSha256:observed.gateSha256??null};
  const receipt=Object.freeze({...data,executedGeometryDescriptorSha256:(await sha(canonical(data),current))});if(isCurrent()!==true)throw Error('Executed GPU descriptor owner changed across digest');receipts.set(receipt,descriptor);return receipt;
 }});descriptors.add(descriptor);return descriptor;
}
export function executedJointCertificateFields(descriptor,receipt){
 if(!descriptors.has(descriptor)||receipts.get(receipt)!==descriptor)throw Error('Forged executed geometry descriptor/readback receipt');
 const actual=descriptor.capture();for(const key of ['sourceSha256','bodySha256','topologySha256','packedGeometrySha256','bodyFaceCount'])if(receipt[key]!==actual[key])throw Error('Foreign executed geometry receipt');
 return Object.freeze({sourceSha256:receipt.sourceSha256,bodySha256:receipt.bodySha256,topologySha256:receipt.topologySha256,bodyFaceCount:receipt.bodyFaceCount,executedGeometryDescriptor:structuredClone(receipt)});
}
export function createSourceExecutedJointGeometryDescriptor(scope,input){if(scope!=='fresh-source-equal-layer')return null;return createExecutedJointGeometryDescriptor(input);}
