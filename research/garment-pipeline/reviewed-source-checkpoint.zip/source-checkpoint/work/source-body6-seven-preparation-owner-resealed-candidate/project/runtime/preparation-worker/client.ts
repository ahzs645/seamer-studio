import {ownPreparationRecord} from '../appSIPreparation.ts';
import {copyData,equalData} from '../snapshots.mjs';
import {sourceGatherRegistry} from '$lib/utils/sourceGatherPreparation';
import {PINNED_GATHER_PROGRAMS} from '$lib/utils/pinnedGatherPrograms';
import {approveGeneratedGather,decodeOriginalGatherDocument,type GatherTrust} from '$lib/utils/sourceGatherEvidence';
import {captureActualAppSourceDescriptor,mintActualAppSourceDescriptor} from '../appSourceDescriptor.ts';
import {validateSourcePhysicalMembrane} from '../source/sourcePhysicalMembrane.ts';
import {snapshotPreparationPacket,preparationPacketSha256,equalPreparationPacket} from './packet.mjs';
import type {ComputationalPreparationPacket} from './handler.ts';
import type {SceneSourceInputOwner,SceneSourceInputRequest} from '../sceneSourceInputs.ts';
import type {SourceSheetAssignment} from '../source/sourcePhysicalMembrane.ts';
interface Options {
 /** Deployment pins and private approval are captured internally. */
 signal?:AbortSignal;
 timeoutMilliseconds?:number;
}
export function prepareActualSceneSourceInputsInWorker(readOwner:()=>SceneSourceInputOwner,assignments:readonly SourceSheetAssignment[],request:SceneSourceInputRequest,scope:string,options:Options={}){
 if(scope!=='fresh-source-physical-profile')return null;
 return(async()=>{
  const first=ownPreparationRecord(readOwner()) as unknown as SceneSourceInputOwner,callback=first.stillCurrent,signal=options.signal;
  const {prepared,stillCurrent,...fields}=first;
  const original=snapshotPreparationPacket({prepared,owner:fields,assignments,request}) as ComputationalPreparationPacket;
  const registry=copyData(sourceGatherRegistry.lookup(first.pattern)),provenance=copyData(sourceGatherRegistry.captureApprovedProvenance(first.pattern)),deploymentPins=copyData(PINNED_GATHER_PROGRAMS);
  const current=()=>{
   const before=ownPreparationRecord(readOwner()) as unknown as SceneSourceInputOwner;if(signal?.aborted||before.stillCurrent!==callback||callback()!==true)throw Error('Garment preparation cancelled or superseded');
   const now=ownPreparationRecord(readOwner()) as unknown as SceneSourceInputOwner,{prepared:next,stillCurrent:nextCallback,...metadata}=now;
   const observed=snapshotPreparationPacket({prepared:next,owner:metadata,assignments,request});
   if(now.pattern!==first.pattern||next!==prepared||nextCallback!==callback||now.avatarVertices!==first.avatarVertices||now.avatarIndices!==first.avatarIndices
     ||!equalData(sourceGatherRegistry.lookup(first.pattern),registry)||!equalData(sourceGatherRegistry.captureApprovedProvenance(first.pattern),provenance)||!equalData(copyData(PINNED_GATHER_PROGRAMS),deploymentPins)
     ||!equalPreparationPacket(observed,original))throw Error('Original garment/body/approval changed during CPU preparation');
   return true;
  };
  current();let deploymentTrust:GatherTrust|undefined;
  if(prepared.simData.sourceGatherRefinement){
   if(!registry?.enabled||!registry.sourceBodyActive||!registry.approvedEvidence||!provenance)throw Error('Actual same-app approval and normal deployment pin capture required');
   deploymentTrust={...deploymentPins,origin:provenance.origin};current();
   const source=first.pattern.garmentCodeSource as typeof first.pattern.garmentCodeSource & {gatherSourceDocument?:unknown;gatherProvenance?:{origin:string}};
   if(!source?.gatherSourceDocument||deploymentTrust?.origin!==source.gatherProvenance?.origin)throw Error('Normal approval origin/deployment input differs');
   const verified=await approveGeneratedGather(decodeOriginalGatherDocument(source.gatherSourceDocument),first.pattern,deploymentTrust);current();
   if(!verified.provenance||!equalData(verified.scope.approvedEvidence,registry.approvedEvidence))throw Error('Actual original gathering/deployment pins do not match main approval');
  }
  const packet=snapshotPreparationPacket({...original,deploymentTrust}) as ComputationalPreparationPacket;
  const requestSha256=await preparationPacketSha256(packet);current();
  const timeout=options.timeoutMilliseconds??120000;if(!Number.isSafeInteger(timeout)||timeout<1||timeout>180000)throw Error('Bounded CPU preparation timeout required');
  const worker=new Worker(new URL('./appPreparation.worker.ts',import.meta.url),{type:'module'});
  let timer:ReturnType<typeof setTimeout>|undefined,poll:ReturnType<typeof setInterval>|undefined,abort:()=>void=()=>undefined;
  try{
   current();const reply=await new Promise<{result:Record<string,unknown>;sha256:string}>((resolve,reject)=>{
    const fail=(error:unknown)=>reject(error instanceof Error?error:new Error(String(error)));
    abort=()=>{worker.postMessage({operation:'cancel',id:1});fail(new Error('Garment preparation cancelled'));};
    signal?.addEventListener('abort',abort,{once:true});
    // Cheap generation/reference check while the CPU peer works. Full byte/Map
    // reseals remain mandatory before result adoption. Never hash large inputs
    // on each polling tick or let a superseded peer retain the preparation slot.
    poll=setInterval(()=>{try{const live=ownPreparationRecord(readOwner()) as unknown as SceneSourceInputOwner;
     if(signal?.aborted||live.stillCurrent!==callback||live.pattern!==first.pattern||live.prepared!==prepared||live.avatarVertices!==first.avatarVertices||live.avatarIndices!==first.avatarIndices||live.sourceToken!==first.sourceToken||live.bodyGeneration!==first.bodyGeneration||callback()!==true)throw Error('Garment preparation cancelled or superseded');
    }catch(error){worker.postMessage({operation:'cancel',id:1});fail(error);}},100);
    timer=setTimeout(()=>fail(new Error('Garment preparation took too long. Reset and try again.')),timeout);
    worker.addEventListener('error',event=>fail(new Error(event.message||'CPU preparation worker failed')),{once:true});
    worker.addEventListener('message',event=>{if(event.data?.id!==1)return;if(event.data.error)fail(new Error(event.data.error));else resolve(event.data);});
    worker.postMessage({operation:'prepare',id:1,packet,requestSha256});
   });current();
   const result=snapshotPreparationPacket(reply.result);
   if(await preparationPacketSha256(result)!==reply.sha256)throw Error('CPU preparation output byte binding differs');current();
   if(result.requestSha256!==requestSha256||result.CPUWorkerPreparationOnly!==true||result.wholeFrameExecuted!==false||result.fitAccepted!==false)throw Error('CPU preparation attempted an execution/fit claim');
   validateSourcePhysicalMembrane(result.prepared.simData);
   const captured=result.descriptor;
   const owned=snapshotPreparationPacket(result);
   const resultCurrent=()=>{current();if(!equalPreparationPacket(result,owned))throw Error('CPU preparation result changed after capture');return true;};
   const actualFields={pattern:first.pattern,prepared:result.prepared,sourceToken:first.sourceToken,bodyGeneration:first.bodyGeneration,simulationConfig:first.simulationConfig,sourcePins:first.sourcePins,sourceBodyCalibration:first.sourceBodyCalibration,isCurrent:resultCurrent};
   const descriptor=captured.sourceExecutionEncoding==='raw-utf8-frozen-source-execution-descriptor-v1'
    ?await mintActualAppSourceDescriptor(actualFields,scope)
    :await captureActualAppSourceDescriptor({...actualFields,sourceExecutionBytes:captured.sourceExecutionBytes,sourceExecutionEncoding:captured.sourceExecutionEncoding,expectedSourceSha256:captured.sourceBinding.sourceSha256},scope);
   resultCurrent();if(!descriptor||!equalData(descriptor.sourceExecutionBytes,captured.sourceExecutionBytes)||!equalData(descriptor.sourceBinding,captured.sourceBinding))throw Error('Actual returned source descriptor could not bind main owner exactly');
   return Object.freeze({prepared:result.prepared,pattern:first.pattern,styleId:first.styleId,sourceBodyCalibration:first.sourceBodyCalibration,simulationConfig:copyData(first.simulationConfig),descriptor,preflight:result.preflight,
    assertCurrent(){descriptor.assertCurrent();return resultCurrent();},parameterScope:'explicit-illustrative-membrane-only',measuredGarmentParameters:false,wholeFrameExecuted:false,fitAccepted:false,
    CPUWorkerPreparationOnly:true,computationMilliseconds:result.computationMilliseconds});
  }finally{if(timer)clearTimeout(timer);if(poll)clearInterval(poll);signal?.removeEventListener('abort',abort);worker.terminate();}
 })();
}
