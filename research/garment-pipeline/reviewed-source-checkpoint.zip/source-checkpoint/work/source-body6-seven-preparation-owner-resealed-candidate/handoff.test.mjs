import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {deserialize} from 'node:v8';
import {readCurrentPreparationRuntime,typedSha256} from './preparation-runtime.mjs';
import {createPreparationLifecycleScope,acquirePreparationLease} from './preparation-lifecycle.mjs';
import {preparePhysicalSourceFixture} from './prepare-source.mjs';
import {validateCreationIdentity} from './creation-identity.mjs';
import {actualFrozenAnatomicalGeometry} from './anatomy.mjs';
const manifest=readCurrentPreparationRuntime().manifest;
const row=manifest.fixtures.find(row=>row.id==='tee-short-164');
const options={id:row.id,sourceBodyFitRevision:6,sourceExecutionDescriptorSha256:row.descriptorSha256};
test('plain or disposed CPU scope cannot start a constructor',async()=>{
 await assert.rejects(preparePhysicalSourceFixture(row.id,manifest.explicitIllustrativeParameters,{}),/scope required/);
 const scope=createPreparationLifecycleScope(options);scope.dispose();
 await assert.rejects(preparePhysicalSourceFixture(row.id,manifest.explicitIllustrativeParameters,scope),/scope required/);
 assert.throws(()=>createPreparationLifecycleScope({...options,sourceBodyFitRevision:5}));
});
test('foreign lease cannot drain a currently owned construction slot',()=>{
 const scope=createPreparationLifecycleScope(options),first=acquirePreparationLease(scope,row.id),other=acquirePreparationLease(scope,row.id);
 first.begin();other.end();assert.throws(()=>acquirePreparationLease(scope,row.id),/overlaps/);
 first.observe();first.end();const last=acquirePreparationLease(scope,row.id);last.begin();last.end();scope.dispose();
});
test('changed explicit fabric parameters reject before fresh construction',async()=>{
 const scope=createPreparationLifecycleScope(options);
 await assert.rejects(preparePhysicalSourceFixture(row.id,{...manifest.explicitIllustrativeParameters,densityKgPerM2:.2},scope));
 const lease=acquirePreparationLease(scope,row.id);lease.begin();lease.end();scope.dispose();
});
test('all seven actual initial material/geometry/anatomy templates bind; changed bytes reject',()=>{
 for(const row of manifest.fixtures){
  const saved=deserialize(fs.readFileSync(row.preparedPath));
  const identity=validateCreationIdentity(saved.prepared,{sourceBodyFitRevision:6,sourceExecutionDescriptor:saved.descriptor});
  assert.equal(identity.descriptorSha256,row.descriptorSha256);
  const anatomy=actualFrozenAnatomicalGeometry(row.id,saved.prepared);
  assert.equal(anatomy.actualBodyJointsProvenance.bodyFitRevision,6);
  assert.equal(Object.keys(anatomy.joints).length,52);
 }
 const saved=deserialize(fs.readFileSync(row.preparedPath));saved.prepared.simData.positions[0]+=.001;
 assert.throws(()=>validateCreationIdentity(saved.prepared,{sourceBodyFitRevision:6,sourceExecutionDescriptor:saved.descriptor}));
});
test('typed hashes read intrinsic represented bytes instead of own buffer properties',()=>{
 const q=new Float32Array([-0,1,2]),expected=typedSha256(q);
 Object.defineProperty(q,'buffer',{get:()=>new Float32Array([0,1,2]).buffer});
 assert.equal(typedSha256(q),expected);q[0]=0;assert.notEqual(typedSha256(q),expected);
});
test('fresh actual constructor repeats genuine source fit/preparation Workers and exact descriptor',
 {timeout:240000},async()=>{
 const scope=createPreparationLifecycleScope(options);
 try{
  const actual=await preparePhysicalSourceFixture(row.id,manifest.explicitIllustrativeParameters,scope);
  assert.equal(actual.report.actualSourceFitWorker,true);assert.equal(actual.report.actualPreparationWorker,true);
  assert.equal(actual.report.currentAvatarAuthorityTransferred,false);
  assert.equal(actual.report.initialPreflight.strictBody.accepted,true);assert.equal(actual.report.initialPreflight.strictSelf.clear,true);
  validateCreationIdentity(actual.prepared,{sourceBodyFitRevision:6,sourceExecutionDescriptor:actual.descriptor});
  actualFrozenAnatomicalGeometry(row.id,actual.prepared);
 }finally{scope.dispose();}
});
