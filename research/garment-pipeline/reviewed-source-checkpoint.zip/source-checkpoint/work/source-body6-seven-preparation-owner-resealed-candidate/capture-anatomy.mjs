import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';

const hash=view=>createHash('sha256').update(Buffer.from(view.buffer,view.byteOffset,view.byteLength)).digest('hex');

/** Executed only beside the freshly constructed, unexposed actual controller.
 * This records anatomy; it cannot grant a current body/calibration capability. */
export function captureActualBody6Anatomy({api,avatar,prepared,modelBytes,calibration}){
 assert.equal(api.SOURCE_BODY_FIT_REVISION,6);
 assert.equal(avatar.sourceBodyCalibrationIdentity,calibration);
 assert(api.currentSourceBodyCalibrationIdentity(calibration));
 const xyz=avatar.vertexPositions,triangles=avatar.indices;
 const packed=prepared.body.positions,faces=prepared.body.triangles;
 assert(xyz instanceof Float32Array&&packed instanceof Float32Array);
 assert.equal(xyz.length/3,packed.length/4);
 const sourceBits=new Uint32Array(xyz.buffer,xyz.byteOffset,xyz.length);
 const packedBits=new Uint32Array(packed.buffer,packed.byteOffset,packed.length);
 for(let i=0;i<xyz.length/3;i++){
  for(let a=0;a<3;a++)assert.equal(packedBits[4*i+a],sourceBits[3*i+a],'Anatomy and prepared body XYZ differ');
  assert.equal(packedBits[4*i+3],0,'Prepared body W must be literal fixed +0');
 }
 assert.equal(triangles.length/3,faces.length/4);
 for(let i=0;i<triangles.length/3;i++){
  for(let a=0;a<3;a++)assert.equal(faces[4*i+a],triangles[3*i+a],'Anatomy and prepared body topology differ');
 }
 const model=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(modelBytes));
 const joints={};
 for(const [name] of model.bones){
  assert.equal(typeof name,'string');assert(!Object.hasOwn(joints,name),'Repeated model bone');
  const value=avatar.bonePosition(name,new api.THREE.Vector3());
  assert(value&&[value.x,value.y,value.z].every(Number.isFinite),'Actual model bone unavailable: '+name);
  joints[name]=[value.x,value.y,value.z];
 }
 assert.equal(avatar.sourceBodyCalibrationIdentity,calibration);
 assert(api.currentSourceBodyCalibrationIdentity(calibration));
 return {kind:'fresh-body6-executed-native-anatomy-v1',bodyFitRevision:6,
  actualSamePreparedBody:true,bonesOrigin:'actual-current-AvatarController.bonePosition',
  packedBodyPositionsSha256:hash(packed),packedBodyTrianglesSha256:hash(faces),
  modelSha256:hash(modelBytes),sourceBodyCalibration:structuredClone(calibration),joints,
  currentBodyAuthority:false,allocationAuthorized:false,fitAccepted:false};
}
