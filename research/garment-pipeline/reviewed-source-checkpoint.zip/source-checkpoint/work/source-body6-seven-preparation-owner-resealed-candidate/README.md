This is a NEW CPU-only preparation candidate, currently awaiting the frozen body6 identity closure before build or import. It changes no live source, saved body5 data, or existing source169 execution epoch.

The normal preparation runs in one owned app module graph: actual AvatarController with actual source-fit Worker; prepareCloth and finalized source refinement from the original pattern; the reviewed generic pants rigid-X preflight; authenticated model-shoulder arm-envelope placement and sealed cap-before-tube staging; actual SI material routine; unchanged source169 BODY 1 mm and SELF predicates on the final initial state; actual preparation Worker followed by the main-side descriptor remint. All imported code, model assets and original input bytes are frozen before the CPU replay.

Original patterns and material assignments are inputs. Saved body5/613 arrays are comparison ancestry only. The constructor never receives them. The new descriptor must contain the actual body6 calibration provenance, body/cloth bytes, policy, schedule and compiled source pins. The exact calibration hash domain is distinct from the raw descriptor and packed Float32 body SHA domains.

Panel transforms are rigid in real arithmetic; stored Float32 edge length differences are measured. Source cuts, material coordinates, topology, original reciprocal first stamps, material mass/rest/W and mandatory support release prerequisites are preserved. BODY/SELF unresolved states reject preparation rather than become a fit result. The initial controller mask is CPU-requested, not a device USED or accepted-frame proof.

A fresh component authorization, true whole-frame safety, source completion, zero supports/holds, stable 17-sample/16-path window, anatomical placement, complete finite hand outside fabric, and real rendering remain separate requirements. This package supplies no device, frame, cache, pressure, or fit authority.

This successor is awaiting independent clearance of the final owner-reseal identity graph. Held164/241 outputs remain numeric comparisons only; no origin identity or raw descriptor is reused.
