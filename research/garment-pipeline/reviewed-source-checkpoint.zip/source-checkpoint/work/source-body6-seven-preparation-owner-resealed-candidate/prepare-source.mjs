import fs from 'node:fs';
import assert from 'node:assert/strict';
import {Worker} from 'node:worker_threads';
import {PREPARATION_ROOT,bytesSha256} from './preparation-runtime.mjs';
import {acquirePreparationLease} from './preparation-lifecycle.mjs';
/** Fresh CPU construction executes actual model generation, normal preparation,
 * fit/preparation Workers and main remint. Saved outputs are comparisons only. */
export async function preparePhysicalSourceFixture(id,explicitParameters,scope){
 const captured=structuredClone(explicitParameters);
 const owner=acquirePreparationLease(scope,id);
 assert.deepEqual(captured,owner.epoch.manifest.explicitIllustrativeParameters);
 owner.begin();
 let timer,result,worker,closed,publish=false;
 try{
  worker=new Worker(new URL('./construct-fixture.worker.mjs',import.meta.url),{
   workerData:{id,executionPinsSha256:owner.epoch.manifest.executionPinsSha256,runtimePinsSha256:owner.epoch.sha256}});
  closed=new Promise(resolve=>worker.once('exit',resolve));
  result=await new Promise((resolve,reject)=>{
   timer=setTimeout(()=>reject(Error('Bounded fresh CPU preparation exceeded 240 seconds')),240000);
   owner.registerAbort(()=>reject(Error('Fresh CPU preparation cancelled by its actual scope')));
   worker.once('error',reject);
   worker.once('exit',code=>{if(!result)reject(Error('Fresh CPU constructor exited before result: '+code));});
   worker.once('message',packet=>packet.error?reject(Object.assign(Error(packet.error.message),{detail:packet.error})):resolve(packet.result));
  });
  assert.deepEqual(explicitParameters,captured,'Explicit material parameters changed during construction');
  const current=owner.observe();
  const row=current.manifest.fixtures.find(row=>row.id===id);
  assert.equal(bytesSha256(result.sourceExecutionBytes),row.descriptorSha256,'Fresh main/Worker descriptor differs from reviewed reconstruction');
  assert(Buffer.from(result.sourceExecutionBytes).equals(fs.readFileSync(row.descriptorPath)));
  assert.equal(result.report.sourceBodyCalibration.codeSha256,current.manifest.calibrationCodeSha256);
  assert.equal(result.report.initialPreflight.strictBody.accepted,true);
  assert.equal(result.report.initialPreflight.strictSelf.clear,true);
  assert.deepEqual(result.report.workerClosure,{created:{sourceFit:1,preparation:1},terminated:{sourceFit:1,preparation:1}});
  publish=true;return result;
 }finally{
  try{
   if(timer)clearTimeout(timer);if(worker)await worker.terminate();if(closed)await closed;
   if(publish){owner.observe();assert.deepEqual(explicitParameters,captured,'Material parameters changed during constructor drain');}
  }finally{owner.end();}
 }
}
