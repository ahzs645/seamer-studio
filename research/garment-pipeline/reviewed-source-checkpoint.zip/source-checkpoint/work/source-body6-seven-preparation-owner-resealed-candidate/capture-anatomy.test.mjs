import test from 'node:test';
import assert from 'node:assert/strict';
import {captureActualBody6Anatomy} from './capture-anatomy.mjs';

function control(){
 const calibration={revision:6};
 const xyz=new Float32Array([-0,1,2,3,4,5,6,7,8]);
 const positions=new Float32Array([-0,1,2,0,3,4,5,0,6,7,8,0]);
 const avatar={vertexPositions:xyz,indices:new Uint32Array([0,1,2]),sourceBodyCalibrationIdentity:calibration,
  bonePosition(name){return name==='nativeBone'?{x:1,y:2,z:3}:null;}};
 const api={SOURCE_BODY_FIT_REVISION:6,currentSourceBodyCalibrationIdentity:value=>value===calibration,
  THREE:{Vector3:class{}}};
 const prepared={body:{positions,triangles:new Uint32Array([0,1,2,0])}};
 return {api,avatar,prepared,calibration,modelBytes:new TextEncoder().encode('{"bones":[["nativeBone",{}]]}')};
}
test('CPU binding control records literal represented body and model-named bones without authority',()=>{
 const report=captureActualBody6Anatomy(control());
 assert.equal(report.actualSamePreparedBody,true);
 assert.deepEqual(report.joints,{nativeBone:[1,2,3]});
 assert.equal(report.currentBodyAuthority,false);assert.equal(report.fitAccepted,false);
});
test('signed-zero XYZ mismatch rejects the anatomy binding',()=>{
 const input=control();input.prepared.body.positions[0]=0;
 assert.throws(()=>captureActualBody6Anatomy(input),/XYZ differ/);
});
test('different body topology or rigid W bytes rejects the binding',()=>{
 const input=control();input.prepared.body.triangles[1]=2;
 assert.throws(()=>captureActualBody6Anatomy(input),/topology differ/);
 const next=control();next.prepared.body.positions[3]=-0;
 assert.throws(()=>captureActualBody6Anatomy(next),/literal fixed/);
});
test('stale private calibration or missing actual model bone rejects',()=>{
 const input=control();input.avatar.sourceBodyCalibrationIdentity={revision:6};
 assert.throws(()=>captureActualBody6Anatomy(input));
 const next=control();next.avatar.bonePosition=()=>null;
 assert.throws(()=>captureActualBody6Anatomy(next),/bone unavailable/);
});
