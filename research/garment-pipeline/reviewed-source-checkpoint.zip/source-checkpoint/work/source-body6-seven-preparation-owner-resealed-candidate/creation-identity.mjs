import fs from 'node:fs';
import assert from 'node:assert/strict';
import {deserialize} from 'node:v8';
import {readCurrentPreparationRuntime,bytesSha256,typedSha256} from './preparation-runtime.mjs';
/** Exact initial CPU origin, after the actual main and Worker material validators.
 * Saved prepared data are comparison templates, never constructor inputs. */
export function validateCreationIdentity(prepared,{sourceBodyFitRevision,sourceExecutionDescriptor}){
 assert.equal(sourceBodyFitRevision,6);
 const epoch=readCurrentPreparationRuntime();
 const row=epoch.manifest.fixtures.find(row=>row.descriptorSha256===bytesSha256(fs.readFileSync(row.descriptorPath))&&
  row.bodyPositionsSha256===typedSha256(prepared.body.positions)&&
  row.initialPhysicalPositionsSha256===typedSha256(prepared.simData.positions)&&
  JSON.parse(fs.readFileSync(row.descriptorPath)).sourcePins['compiled/genuine-app-worker-preparation.mjs']===sourceExecutionDescriptor.sourcePins?.['compiled/genuine-app-worker-preparation.mjs']&&
  JSON.parse(fs.readFileSync(row.descriptorPath)).particleCount===prepared.simData.particleCount);
 assert(row,'Authentic new body6 creation template required');
 const expected=deserialize(fs.readFileSync(row.preparedPath));
 assert.deepEqual(sourceExecutionDescriptor,expected.descriptor,'Creation raw descriptor/context differs');
 assert.deepEqual(prepared,expected.prepared,'Creation typed source/SI/rest/W/anchors/support/dictionary differs');
 assert.equal(sourceExecutionDescriptor.sourceBodyCalibration.codeSha256,epoch.manifest.calibrationCodeSha256);
 readCurrentPreparationRuntime(epoch.sha256);
 return Object.freeze({kind:'fresh-body6-actual-main-worker-initial-creation-identity-v1',sourceBodyFitRevision:6,
  descriptorSha256:row.descriptorSha256,bodyPositionsSha256:row.bodyPositionsSha256,
  bodyTopologySha256:row.bodyTopologySha256,physicalMassPolicySha256:row.physicalMassPolicySha256,
  sourceInitialArrangementPolicySha256:prepared.simData.sourceInitialArrangementPolicySha256??null,
  sourceAssemblySchedulePolicySha256:prepared.simData.sourceStaging?.attachedOpenSchedule?.policySha256??null,
  initialPackedXYZWAndFullMaterialBitsBound:true,currentAvatarAuthorityTransferred:false,
  componentAllocationAuthorized:false,wholeFrameAccepted:false,fitAccepted:false});
}
