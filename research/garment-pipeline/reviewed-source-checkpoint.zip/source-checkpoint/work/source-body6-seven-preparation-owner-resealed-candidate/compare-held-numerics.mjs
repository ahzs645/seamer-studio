/** Post-construction comparison only. Never imported by either constructor. */
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root=new URL('.',import.meta.url).pathname;
const sha=b=>createHash('sha256').update(b).digest('hex');
const previous=JSON.parse(fs.readFileSync(root+'held-predecessor.json'));
const oldBytes=fs.readFileSync(previous.path+'/actual-seven/manifest.json');
assert.equal(sha(oldBytes),previous.actualSevenManifestSha256);
const old=JSON.parse(oldBytes),next=JSON.parse(fs.readFileSync(root+'actual-seven/manifest.json'));
assert.equal(next.errors.length,0);assert.equal(next.fixtures.length,7);
const fixtures=[];
for(const current of next.fixtures){
 const prior=old.fixtures.find(row=>row.id===current.id);assert(prior);
 const compare=(a,b,label)=>{
  const oldData=fs.readFileSync(a.file),newData=fs.readFileSync(b.file);
  assert.equal(sha(oldData),a.sha256);assert.equal(sha(newData),b.sha256);
  assert(oldData.equals(newData),current.id+': numeric mismatch '+label);
 };
 for(const key of ['posed','rest','triangles'])compare(prior.bodyArtifacts[key],current.bodyArtifacts[key],'body '+key);
 assert.deepEqual(Object.keys(prior.typed).sort(),Object.keys(current.typed).sort());
 for(const key of Object.keys(prior.typed))compare(prior.typed[key],current.typed[key],key);
 assert.notEqual(current.sourceBodyCalibration.fingerprint,prior.sourceBodyCalibration.fingerprint,
  'Corrected source identity must be freshly regenerated, not retained');
 assert.notEqual(current.descriptorSha256,prior.descriptorSha256,'Corrected raw source context must be newly minted');
 assert.equal(current.initialPreflight.strictBody.accepted,true);
 assert.equal(current.initialPreflight.strictSelf.clear,true);
 fixtures.push({id:current.id,allBodyAndPreparedTypedBytesExact:true,
  previousHeldDescriptorSha256:prior.descriptorSha256,currentDescriptorSha256:current.descriptorSha256,
  calibrationFingerprintFresh:true,strictInitialBodyAndSelfClear:true});
}
const report={kind:'fresh-body6-owned-source-numeric-comparison-v1',
 previousHeldManifestSha256:sha(oldBytes),comparisonOnly:true,
 oldArraysUsedForConstruction:false,oldIdentityOrContextReused:false,fixtures,
 allocationAuthorized:false,fitAccepted:false};
fs.writeFileSync(root+'held-numeric-comparison.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({styles:fixtures.length,allNumericBytesExact:true,newIdentities:true}));
