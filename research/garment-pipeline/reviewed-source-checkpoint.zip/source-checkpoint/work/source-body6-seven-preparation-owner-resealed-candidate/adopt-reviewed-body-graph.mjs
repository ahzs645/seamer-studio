/** Run only after root's explicit clearance of the supplied immutable graph. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root=new URL('.',import.meta.url).pathname;
const [manifestPath,expectedSHA]=process.argv.slice(2);
assert(manifestPath&&/^[a-f0-9]{64}$/.test(expectedSHA??''),'Explicit reviewed manifest and exact digest required');
assert(!fs.existsSync(root+'build-receipt.json')&&!fs.existsSync(root+'execution-pins.json'),
 'Body graph adoption must precede build, import and execution freeze');
const sha=b=>createHash('sha256').update(b).digest('hex');
const bytes=fs.readFileSync(manifestPath);assert.equal(sha(bytes),expectedSHA);
const manifest=JSON.parse(bytes),origin=path.dirname(manifestPath),selected=[];
for(const row of manifest.files){
 assert.equal(sha(fs.readFileSync(row.path)),row.sha256,'Reviewed origin pin changed: '+row.path);
 if(!row.path.startsWith(origin+'/'))continue;
 const relative=path.relative(origin,row.path);
 if(relative.startsWith('packages/avatar/src/')||relative.startsWith('packages/pattern-model/src/')||
  relative==='src/lib/scene/sourceBodyCheckpoint.ts')selected.push({...row,relative});
}
assert(selected.some(row=>row.relative.endsWith('/sourceSkinnedMappings.ts')),'Actual private consumed-owner module required');
assert(selected.some(row=>row.relative.endsWith('/sourceTypedViews.ts')),'Actual intrinsic typed-view module required');
assert(selected.some(row=>row.relative.endsWith('/sourceCalibrationCodeIdentity.ts')),'Actual regenerated code identity required');
assert(selected.some(row=>row.relative==='src/lib/scene/sourceBodyCheckpoint.ts'));
for(const directory of ['packages/avatar/src','packages/pattern-model/src'])
 fs.rmSync(root+'project/'+directory,{recursive:true,force:true});
for(const row of selected){
 const owned=root+'project/'+row.relative;fs.mkdirSync(path.dirname(owned),{recursive:true});
 fs.copyFileSync(row.path,owned);assert.equal(sha(fs.readFileSync(owned)),row.sha256);
 row.owned=owned;
}
assert.equal(sha(fs.readFileSync(manifestPath)),expectedSHA,'Reviewed origin manifest changed during copy');
for(const row of manifest.files)assert.equal(sha(fs.readFileSync(row.path)),row.sha256);
fs.writeFileSync(root+'body6-origin-manifest.json',bytes,{flag:'wx'});
fs.writeFileSync(root+'body6-source-adoption.json',JSON.stringify({
 kind:'owned-reviewed-body6-private-mapping-source-copy-v1',manifestPath,
 manifestSha256:expectedSHA,ownedManifestPath:root+'body6-origin-manifest.json',
 files:selected,sourceCopiedBeforeBuildOrImport:true,numericalReferenceOnly161:true,
 old146Or157IdentityReused:false,GPUInitialized:false,fitAccepted:false
},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({ownedSources:selected.length,originManifestSha256:expectedSHA}));
