import fs from 'node:fs';
import assert from 'node:assert/strict';
import {readCurrentPreparationRuntime,bytesSha256,typedSha256} from './preparation-runtime.mjs';
/** Actual fresh body6 coordinates. No browser5 bone or saved-body substitution. */
export function actualFrozenAnatomicalGeometry(id,prepared){
 const epoch=readCurrentPreparationRuntime(),row=epoch.manifest.fixtures.find(row=>row.id===id);
 assert(row,'Authentic body6 anatomy style required');
 const source=fs.readFileSync(row.anatomyPath);assert.equal(bytesSha256(source),row.anatomySha256);
 const bone=JSON.parse(source),d=prepared.simData,body=prepared.body;
 assert.equal(bone.bodyFitRevision,6);assert.equal(bone.actualSamePreparedBody,true);
 assert(body.positions instanceof Float32Array&&body.triangles instanceof Uint32Array);
 assert.equal(typedSha256(body.positions),bone.packedBodyPositionsSha256);
 assert.equal(typedSha256(body.triangles),bone.packedBodyTrianglesSha256);
 assert.equal(bone.sourceBodyCalibration.codeSha256,epoch.manifest.calibrationCodeSha256);
 const pieces=d.pieces.map(p=>({pieceId:p.pieceId,start:p.start,count:p.count,triangles:structuredClone(p.triangles)})),cuffEdges={};
 assert(d.edgeRuns instanceof Map,'Actual original source edge map required');
 for(const[key,run]of Map.prototype.entries.call(d.edgeRuns)){
  const[piece,path]=key.split('::');(cuffEdges[piece]??={})[path]=Array.from(run);
 }
 for(const p of pieces)assert(Number.isSafeInteger(p.start)&&Number.isSafeInteger(p.count)&&p.start>=0&&p.start+p.count<=d.particleCount);
 readCurrentPreparationRuntime(epoch.sha256);
 return {pieces,cuffEdges,joints:structuredClone(bone.joints),actualBodyJointsProvenance:{
  file:row.anatomyPath,sha256:row.anatomySha256,bodyFitRevision:6,actualSamePreparedBody:true,
  actualSourceFitWorkerBody:true,actualBrowserWorkerBody:false,
  packedBodyPositionsSha256:bone.packedBodyPositionsSha256,packedBodyTrianglesSha256:bone.packedBodyTrianglesSha256,
  calibrationCodeSha256:epoch.manifest.calibrationCodeSha256,currentAvatarAuthorityTransferred:false},
  actualPreparedGeometrySha256:{packedBodyPositions:typedSha256(body.positions),packedBodyTriangles:typedSha256(body.triangles),
   clothTriangles:typedSha256(d.triangles),pieces:bytesSha256(Buffer.from(JSON.stringify(pieces))),edgeRuns:bytesSha256(Buffer.from(JSON.stringify(cuffEdges)))}};
}
