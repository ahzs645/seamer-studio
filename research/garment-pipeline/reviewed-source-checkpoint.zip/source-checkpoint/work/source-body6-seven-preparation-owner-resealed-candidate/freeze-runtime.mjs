import fs from 'node:fs';
import {deserialize} from 'node:v8';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root=new URL('.',import.meta.url).pathname;
const sha=b=>createHash('sha256').update(b).digest('hex');
const executionBytes=fs.readFileSync(root+'execution-pins.json'),execution=JSON.parse(executionBytes);
const actualBytes=fs.readFileSync(root+'actual-seven/manifest.json'),actual=JSON.parse(actualBytes);
assert.equal(actual.errors.length,0);assert.equal(actual.fixtures.length,7);
const corpus=JSON.parse(fs.readFileSync(root+'inputs/corpus.json'));
const first=deserialize(fs.readFileSync(corpus.fixtures[0].input)).materialAssignments[0].parameters;
const {benchmarkId,...parameters}=first;
const explicitIllustrativeParameters={...parameters,measuredGarmentParameters:false};
for(const row of corpus.fixtures)for(const assignment of deserialize(fs.readFileSync(row.input)).materialAssignments){
 const {benchmarkId,...values}=assignment.parameters;assert.deepEqual(values,parameters);
}
const files={};
for(const row of execution.files){assert.equal(sha(fs.readFileSync(row.path)),row.sha256);files[row.path]=row.sha256;}
const add=file=>{files[file]=sha(fs.readFileSync(file));};
for(const name of ['execution-pins.json','construct-fixture.worker.mjs','preparation-runtime.mjs','preparation-lifecycle.mjs','prepare-source.mjs','anatomy.mjs','creation-identity.mjs','freeze-runtime.mjs','held-predecessor.json','held-numeric-comparison.json'])add(root+name);
for(const row of actual.fixtures)for(const file of [row.descriptorFile,row.preparedFile,row.anatomyFile])add(file);
add(root+'actual-seven/manifest.json');
const manifest={kind:'owned-fresh-body6-source-preparation-runtime-v1',sourceBodyFitRevision:6,
 calibrationCodeSha256:'df72180a730a0fbac08272d85bd969405e434119fbe4e90103dd567109b5e849',
 sourceEpochSha256:'4d24e74f43557d24ba98d0c2c138b39d7e542fd091b09bd17b4deb3e4a06c99c',
 sourceAssemblyControllerSha256:'b1e508cab3e2b7e1731acd03e9930094c88f5ee9b83987c3b146e96f72154ec9',
 executionPinsSha256:sha(executionBytes),actualSevenManifestSha256:sha(actualBytes),
 entry:root+'prepare-source.mjs',lifecycleModule:root+'preparation-lifecycle.mjs',
 creationIdentityModule:root+'creation-identity.mjs',anatomyModule:root+'anatomy.mjs',
 descriptorEncoding:'genuine-app-si-source-execution-v1',sourceExecutionEncoding:'raw-utf8-frozen-source-execution-descriptor-v1',
 explicitIllustrativeParameters,CPUOnly:true,GPUInitialized:false,liveAvatarAuthorityTransferred:false,
 componentAllocationAuthorized:false,wholeFrameAccepted:false,fitAccepted:false,
 historicalManifests:{[root+'body6-origin-manifest.json']:sha(fs.readFileSync(root+'body6-origin-manifest.json'))},files,
 fixtures:actual.fixtures.map(row=>{
  assert.equal(row.sourceBodyCalibration.codeSha256,'df72180a730a0fbac08272d85bd969405e434119fbe4e90103dd567109b5e849');
  return {id:row.id,descriptorPath:row.descriptorFile,descriptorSha256:row.descriptorSha256,
   preparedPath:row.preparedFile,preparedSha256:row.preparedSha256,
   anatomyPath:row.anatomyFile,anatomySha256:row.anatomySha256,
   bodyPositionsSha256:row.typed.bodyPositions.sha256,bodyTopologySha256:row.typed.bodyTriangles.sha256,
   initialPhysicalPositionsSha256:row.typed.clothPositions.sha256,
   physicalMassPolicySha256:row.materialPolicySha256,sourceInitialArrangementPolicySha256:row.actualInitialPolicySha256,
   sourceAssemblySchedulePolicySha256:row.actualSchedule?.attachedOpenSchedule?.policySha256??null};})};
fs.writeFileSync(root+'runtime-manifest.json',JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({files:Object.keys(files).length,sha256:sha(fs.readFileSync(root+'runtime-manifest.json'))}));
