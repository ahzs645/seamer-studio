/** NEW CPU-only genuine body6 + app main/preparation Worker reconstruction.
 * Historical arrays are comparisons only, never construction inputs. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {deserialize,serialize} from 'node:v8';
import {Worker as NodeWorker,parentPort,workerData} from 'node:worker_threads';
import {captureActualBody6Anatomy} from './capture-anatomy.mjs';
import {readCurrentPreparationRuntime} from './preparation-runtime.mjs';
const root=new URL('.',import.meta.url).pathname;
const sha=b=>createHash('sha256').update(b).digest('hex');
const raw=view=>Buffer.from(view.buffer,view.byteOffset,view.byteLength);
const same=(a,b)=>raw(a).equals(raw(b));
const pinsPath=root+'execution-pins.json',manifestBytes=fs.readFileSync(pinsPath),pinsSHA=sha(manifestBytes),pins=JSON.parse(manifestBytes);
assert.equal(pinsSHA,workerData.executionPinsSha256,'Exact reviewed constructor execution epoch required');
readCurrentPreparationRuntime(workerData.runtimePinsSha256);
export function assertPins(){assert.equal(sha(fs.readFileSync(pinsPath)),pinsSHA,'Execution manifest changed');for(const row of pins.files)assert.equal(sha(fs.readFileSync(row.path)),row.sha256,row.path);}
assertPins();
const peers=[],closures=[],created={sourceFit:0,preparation:0},terminated={sourceFit:0,preparation:0};
function worker(script,kind){const w=new NodeWorker(new URL(script,import.meta.url));created[kind]++;let done;const exit=new Promise(r=>done=r);closures.push(exit);let closing=false;w.once('exit',code=>{terminated[kind]++;done(code);});const entry={w,close(){if(!closing){closing=true;return w.terminate();}},get closing(){return closing;}};peers.push(entry);return entry;}
function sourceFitFactory(){const e=worker('./node-source-fit-worker-transport.mjs','sourceFit'),facade={onmessage:null,onerror:null,postMessage(value,transfers){e.w.postMessage(value,transfers);},terminate(){return e.close();}};e.w.on('message',data=>facade.onmessage?.({data}));e.w.on('error',err=>facade.onerror?.({message:err.message}));return facade;}
class PreparationTransport{
 constructor(url){assert(String(url).endsWith('/appPreparation.worker.ts'),'Only actual owned preparation entry allowed');this.e=worker('./node-cpu-worker-transport.mjs','preparation');}
 addEventListener(name,fn){if(name==='message')this.e.w.on('message',data=>fn({data}));else if(name==='error')this.e.w.on('error',e=>fn({message:e.message}));else throw Error('Unexpected Worker event');}
 postMessage(v){this.e.w.postMessage(v);}terminate(){return this.e.close();}
}
globalThis.Worker=PreparationTransport;
globalThis.fetch=async url=>{const requested=new URL(String(url),'https://owned.invalid'),name=requested.pathname.replace(/^\/models\//,'');assert(/^[a-z_]+\.(?:json|bin)$/.test(name)&&requested.pathname==='/models/'+name,'Only owned body assets allowed');const file=root+'model-assets/'+name,entry=pins.files.find(p=>p.path===file);assert(entry,'Body asset absent from execution pins');const bytes=fs.readFileSync(file);assert.equal(sha(bytes),entry.sha256);return new Response(bytes,{status:200});};

let result,error;
try {
 const api=await import('./compiled/genuine-app-worker-preparation.mjs');assertPins();
 assert.equal(api.SOURCE_BODY_FIT_REVISION,6);
 const corpus=JSON.parse(fs.readFileSync(root+'inputs/corpus.json'));
 const row=corpus.fixtures.find(r=>r.id===workerData.id);assert(row,'Unknown actual source input');
 const saved=deserialize(fs.readFileSync(row.input)),historical=JSON.parse(fs.readFileSync(row.historicalExpected613));
 const sourcePins=Object.fromEntries(pins.files.filter(p=>p.role==='compiled'||p.role==='actual-runtime-source').map(p=>[p.logical,p.sha256]));
 const modelBytes=Uint8Array.from(fs.readFileSync(root+'model-assets/base_model.json')),modelSHA=sha(modelBytes);
 let avatar,material;
 try {
   // Original pattern/body measurement inputs, not historical saved body geometry.
   let pattern=structuredClone(saved.pattern);material=new api.THREE.MeshStandardMaterial();
   const bodyStarted=performance.now();avatar=await api.AvatarController.create(pattern.body,material,{sourceFitMode:'worker',sourceFitWorkerFactory:sourceFitFactory});assertPins();
   const calibration=avatar.sourceBodyCalibrationIdentity;assert(api.currentSourceBodyCalibrationIdentity(calibration),'Actual same-module body6 calibration receipt required');pattern=api.compatibleSourceBodyCheckpoint(pattern,calibration);
   const bodyMS=performance.now()-bodyStarted,avatarVertices=avatar.vertexPositions.slice(),avatarIndices=avatar.indices.slice(),rest=avatar.skinnedAvatar.restVertices.slice();
   const bodyArtifacts={posed:avatarVertices.slice(),rest:rest.slice(),triangles:avatarIndices.slice()};
   if(saved.sourceReference.sourceGatherRefinement){const original=api.decodeOriginalGatherDocument(pattern.garmentCodeSource.gatherSourceDocument);const approved=await api.sourceGatherRegistry.register(original,pattern,{origin:'explicit-authored-import',...api.PINNED_GATHER_PROGRAMS});assert(approved,'Original authored gathering must be approved in SAME main registry');pattern.garmentCodeSource.gatherProvenance=approved;}
   let prepared=api.prepareCloth({pattern,avatarVertices,avatarIndices,cylinders:new Map()},{fromArrangement:true,sourceGatherScope:api.sourceGatherRegistry.lookup(pattern)});assert(prepared?.collisionSafety,'Actual normal source preparation required');
   if(prepared.simData.sourceGatherRefinement)prepared={...prepared,simData:await api.finalizeSourceGatherCollisionGeometry(prepared.simData)};
   for(const key of ['positions2d','triangles','seams','seamOrder'])assert(same(prepared.simData[key],saved.sourceReference[key]),'Original source cut/topology/first stamps changed '+key);
   const assignments=structuredClone(saved.materialAssignments);for(const a of assignments)a.parameters.benchmarkId='NEW-'+row.id+'-source-body6-SI-membrane-only';
   const owner={pattern,prepared,avatarVertices,avatarIndices,stillCurrent:()=>avatar.sourceBodyCalibrationIdentity===calibration&&api.currentSourceBodyCalibrationIdentity(calibration),manualRecording:false,explicitSettings:false,sourceToken:1,bodyGeneration:1,styleId:row.id,sourceBodyCalibration:structuredClone(calibration),simulationConfig:historical.simulationConfig,sourcePins,initialPreparation:{moveOpenArms:['shirt-long-176','hoodie-cuffed-176'].includes(row.id),modelBytes,expectedModelSha256:modelSHA}};
   const actual=await api.prepareActualSceneSourceInputsInWorker(()=>owner,assignments,{},'fresh-source-physical-profile',{timeoutMilliseconds:180000});assert(actual);actual.assertCurrent();assertPins();
   const captured=actual.descriptor.capture(),descriptor=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(captured.sourceExecutionBytes)),d=actual.prepared.simData;
   for(const key of ['positions2d','triangles','seams','seamOrder'])assert(same(d[key],saved.sourceReference[key]),'Final source cut/topology/first stamps changed '+key);
   const oldQ=new Float32Array(Uint8Array.from(Buffer.from(historical.initialPhysicalPositionsFloat32LEBase64,'base64')).buffer),oldW=oldQ.filter((_,i)=>i%4===3),newW=d.positions.filter((_,i)=>i%4===3);assert(same(oldW,newW),'Original source SI mass/W bits changed');

  const anatomy=captureActualBody6Anatomy({api,avatar,prepared:actual.prepared,modelBytes,calibration});
  result={prepared:actual.prepared,pattern,descriptor,sourceExecutionBytes:captured.sourceExecutionBytes,
   sourceExecutionEncoding:captured.sourceExecutionEncoding,sourceBinding:captured.sourceBinding,
   context:captured.context,bodyArtifacts,anatomy,
   report:{CPUOnly:true,GPUInitialized:false,bodyConstructionMilliseconds:bodyMS,
    actualSourceFitWorker:true,actualPreparationWorker:true,actualMainDescriptorRemint:true,
    sourceBodyCalibration:structuredClone(calibration),initialPreflight:actual.preflight,
    currentAvatarAuthorityTransferred:false,oldBodyGeometryUsedForConstruction:false,fitAccepted:false}};
 }finally{avatar?.dispose();material?.dispose();}
}catch(e){error={message:e.message,stack:e.stack,initialStrictReport:e.initialStrictReport??null};}
finally {
 for(const e of peers)e.close();await Promise.all(closures);assertPins();
 if(result)result.report.workerClosure={created,terminated};
 parentPort.postMessage(error?{error}:{result});parentPort.close();
}
