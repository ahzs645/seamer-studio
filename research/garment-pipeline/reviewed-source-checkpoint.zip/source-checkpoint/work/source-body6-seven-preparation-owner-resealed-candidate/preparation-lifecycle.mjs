import assert from 'node:assert/strict';
import {readCurrentPreparationRuntime} from './preparation-runtime.mjs';
const scopes=new WeakMap();
/** CPU constructor ownership only. No live AvatarController or allocation grant. */
export function createPreparationLifecycleScope({id,sourceBodyFitRevision,sourceExecutionDescriptorSha256}){
 assert.equal(sourceBodyFitRevision,6);
 const epoch=readCurrentPreparationRuntime(),row=epoch.manifest.fixtures.find(row=>row.id===id);
 assert(row,'Unknown authentic original input');
 assert.equal(sourceExecutionDescriptorSha256,row.descriptorSha256);
 const state={id,descriptorSha256:row.descriptorSha256,epochSha256:epoch.sha256,closed:false,busy:false,abort:null,ownerToken:null};
 const scope=Object.freeze({dispose(){state.closed=true;state.abort?.();},current(){return !state.closed;}});
 scopes.set(scope,state);return scope;
}
export function acquirePreparationLease(scope,id){
 const state=scopes.get(scope);assert(state&&!state.closed,'Actual current CPU preparation scope required');
 assert.equal(state.id,id);assert.equal(state.busy,false,'CPU preparation ownership overlaps');
 const epoch=readCurrentPreparationRuntime(state.epochSha256);
 const token=Symbol('actual CPU constructor');
 const observe=()=>{assert(!state.closed&&state.id===id,'Current CPU preparation scope changed');return readCurrentPreparationRuntime(state.epochSha256);};
 return Object.freeze({epoch,
  begin(){observe();assert.equal(state.busy,false,'CPU preparation ownership overlaps');state.busy=true;state.ownerToken=token;},
  observe(){assert(state.busy&&state.ownerToken===token,'CPU constructor lease absent');return observe();},
  registerAbort(callback){assert(state.busy&&!state.closed&&state.ownerToken===token);assert.equal(state.abort,null);state.abort=callback;},
  end(){if(state.ownerToken===token){state.abort=null;state.busy=false;state.ownerToken=null;}}});
}
