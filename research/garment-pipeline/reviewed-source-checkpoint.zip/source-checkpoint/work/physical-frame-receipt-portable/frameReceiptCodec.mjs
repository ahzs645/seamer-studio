/** Portable structural receipt codec. Hashes never authenticate GPU execution;
 * position, mass, signed-zero and history bytes require independent byte hashes.
 * Existing root-only v2 certificate hash implementations are unchanged. */
export const PHYSICAL_RECEIPT_ENCODING = 'canonical-sorted-json-v3-recursive-empty-contact-bounds';
export const PHYSICAL_FRAME_RECEIPT_ENCODING = PHYSICAL_RECEIPT_ENCODING;
const TAG = '$physicalClearanceBound';
const EMPTY_BOUND = 'positive-infinity-no-contact-rows';
const BOUNDS = new Set(['minimumLowerBoundM', 'minimumClearanceLowerBoundM']);
const SHA = /^[a-f0-9]{64}$/;
function emptyCertificate(x) {
 const fields = ['rawOccurrences', 'allRawOccurrences', 'validatedOccurrences', 'complete', 'unsupported',
  'unsupportedFlags', 'clearanceDeficits', 'strictClearanceDeficits', 'allCurrentRawOccurrencesChecked', 'actualGpuFiniteProducer'];
 return fields.every(k => Object.hasOwn(x, k)) &&
  x.rawOccurrences === 0 && x.allRawOccurrences === 0 && x.validatedOccurrences === 0 &&
  x.complete === true && x.unsupported === 0 && x.unsupportedFlags === 0 &&
  x.clearanceDeficits === 0 && x.strictClearanceDeficits === 0 &&
  x.allCurrentRawOccurrencesChecked === true && x.actualGpuFiniteProducer === true;
}
function plain(x) {
 return x && typeof x === 'object' &&
  (Object.getPrototypeOf(x) === Object.prototype || Object.getPrototypeOf(x) === null);
}
function transform(value, decode) {
 const ancestors = new Set();
 const visit = (x, permitEmptyBound = false) => {
  if (permitEmptyBound && x === Infinity && !decode) return { [TAG]: EMPTY_BOUND };
  if (x && typeof x === 'object' && Object.hasOwn(x, TAG)) {
   const descriptor = Object.getOwnPropertyDescriptor(x, TAG);
   if (decode && permitEmptyBound && plain(x) && Reflect.ownKeys(x).length === 1 &&
       descriptor.enumerable && Object.hasOwn(descriptor, 'value') && descriptor.value === EMPTY_BOUND)
    return Infinity;
   throw Error('Invalid or caller supplied encoded clearance tag');
  }
  if (x === null || typeof x === 'boolean' || typeof x === 'string') return x;
  if (typeof x === 'number') {
   if (!Number.isFinite(x)) throw Error('Nonfinite physical receipt value');
   return x;
  }
  if (!x || typeof x !== 'object' || ancestors.has(x)) throw Error('Unsupported or cyclic physical receipt value');
  ancestors.add(x);
  try {
   if (ArrayBuffer.isView(x) && !(x instanceof DataView)) {
    if (Reflect.ownKeys(x).some(k => typeof k !== 'string' || !/^(0|[1-9][0-9]*)$/.test(k) || Number(k) >= x.length))
     throw Error('Extra physical receipt typed array field');
    return Array.from(x, v => visit(v));
   }
   if (Array.isArray(x)) {
    const descriptors = Object.getOwnPropertyDescriptors(x);
    if (Object.getOwnPropertySymbols(x).length || Object.keys(descriptors).some(k =>
      k !== 'length' && (!/^(0|[1-9][0-9]*)$/.test(k) || Number(k) >= x.length ||
      !Object.hasOwn(descriptors[k], 'value') || !descriptors[k].enumerable)))
     throw Error('Accessor or extra physical receipt array field');
    const result = [];
    for (let i = 0; i < x.length; i++) {
     if (!Object.hasOwn(x, i)) throw Error('Sparse physical receipt array');
     result.push(visit(x[i]));
    }
    return result;
   }
   if (!plain(x) || Object.getOwnPropertySymbols(x).length) throw Error('Unsupported physical receipt object');
   const descriptors = Object.getOwnPropertyDescriptors(x);
   if (Object.values(descriptors).some(d => !Object.hasOwn(d, 'value') || !d.enumerable))
    throw Error('Accessor or nonenumerable physical receipt field');
   const empty = emptyCertificate(x);
   return Object.fromEntries(Object.keys(x).sort().map(k => {
    const bound = BOUNDS.has(k);
    const v = x[k];
    if (bound && !(typeof v === 'number' && Number.isFinite(v)) &&
        !(empty && ((!decode && v === Infinity) || (decode && plain(v) && Object.hasOwn(v, TAG)))))
     throw Error('Invalid physical certificate clearance bound');
    return [k, visit(v, bound && empty)];
   }));
  } finally { ancestors.delete(x); }
 };
 return visit(value);
}
export const encodePhysicalReceiptValue = value => transform(value, false);
export const decodePhysicalReceiptValue = value => transform(value, true);
export const stringifyPhysicalReceipt = value => JSON.stringify(encodePhysicalReceiptValue(value));
export const parsePhysicalReceipt = text => decodePhysicalReceiptValue(JSON.parse(text));
export function canonicalPhysicalReceiptText(value) {
 return JSON.stringify({ encoding: PHYSICAL_RECEIPT_ENCODING, value: encodePhysicalReceiptValue(value) });
}
async function digest(text) {
 const bytes = await globalThis.crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
 return Array.from(new Uint8Array(bytes), x => x.toString(16).padStart(2, '0')).join('');
}
export const physicalReceiptSha256 = value => digest(canonicalPhysicalReceiptText(value));
export function canonicalPhysicalReceiptListText(receipts) {
 if (!Array.isArray(receipts) || receipts.length !== 40) throw Error('Expected forty owned physical certificates');
 return canonicalPhysicalReceiptText({ certificates: receipts });
}
export const physicalReceiptListSha256 = receipts => digest(canonicalPhysicalReceiptListText(receipts));
export async function canonicalPhysicalFrameReceiptText(frame) {
 // Snapshot synchronously BEFORE the list-hash await to exclude caller mutation.
 const copied = decodePhysicalReceiptValue(encodePhysicalReceiptValue(frame));
 if (!copied || copied.kind !== 'actual-source-joint-frame-commit-v1' || copied.accepted !== true ||
     copied.physicalSubsteps !== 40 || copied.geometrySamples !== 41 ||
     !SHA.test(copied.all41GuardProofSha256) || !SHA.test(copied.pressureHistorySha256))
  throw Error('Incomplete owned physical frame receipt');
 if (copied.physicalReceiptsSha256 !== await physicalReceiptListSha256(copied.physicalReceipts))
  throw Error('Physical certificate list digest mismatch');
 if (Object.hasOwn(copied, 'frameReceiptEncoding') && copied.frameReceiptEncoding !== PHYSICAL_RECEIPT_ENCODING)
  throw Error('Physical frame encoding mismatch');
 copied.frameReceiptEncoding = PHYSICAL_RECEIPT_ENCODING;
 delete copied.frameCommitSha256;
 return canonicalPhysicalReceiptText(copied);
}
export async function physicalFrameReceiptSha256(frame) {
 return digest(await canonicalPhysicalFrameReceiptText(frame));
}
