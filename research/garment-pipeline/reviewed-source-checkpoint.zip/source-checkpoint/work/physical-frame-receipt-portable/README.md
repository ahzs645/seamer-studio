Portable structural frame receipt codec
=======================================

This work-only module uses browser WebCrypto and has no Node runtime dependency.
Existing individual canonical-sorted-json-v2 certificate hashes remain unchanged.
The new v3 domain composes nested certificates and preserves positive-infinity
empty bounds in saved JSON. All ten zero-row/completion predicates must be own
fields with the exact existing values. Only their direct minimumLowerBoundM and
minimumClearanceLowerBoundM fields may contain this infinity. Other nonfinite
values, caller encoded tags, accessors, sparse arrays and unsupported fields reject.

Synchronous writer APIs: stringifyPhysicalReceipt/parsePhysicalReceipt and
encodePhysicalReceiptValue/decodePhysicalReceiptValue. Canonical text APIs include
an explicit v3 encoding envelope. Async hash APIs use SHA-256 via WebCrypto:
physicalReceiptSha256, physicalReceiptListSha256 and physicalFrameReceiptSha256.
The frame helper snapshots before awaiting, requires the 40-certificate/41-sample
structure and matching list digest, declares its encoding, and excludes its own
frameCommitSha256 field. It does not modify caller data.

These functions validate structure and serialization, not physical execution.
Independent validators must verify authentic producer, source/topology/gate,
q41/delta41, physical reactions and GPU history evidence. JSON deliberately does
not preserve signed-zero coordinate bytes; those require separate byte hashes.
Unit fixtures here are declared structural controls, not actual device receipts.

Run: node --test frameReceiptCodec.test.mjs
