import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { canonicalPhysicalCertificateText } from '../source-pressure-friction-integration-launcher/certificateHash.mjs';
import * as codec from './frameReceiptCodec.mjs';
const h = 'a'.repeat(64);
const empty = () => ({rawOccurrences:0,allRawOccurrences:0,validatedOccurrences:0,complete:true,
 unsupported:0,unsupportedFlags:0,clearanceDeficits:0,strictClearanceDeficits:0,
 allCurrentRawOccurrencesChecked:true,actualGpuFiniteProducer:true,
 minimumLowerBoundM:Infinity,minimumClearanceLowerBoundM:Infinity});
const digest = text => createHash('sha256').update(text).digest('hex');
test('nested zero-contact inventories round trip and retain existing v2 certificate text', async () => {
 const input = {frame:{physicalReceipts:Array.from({length:40}, (_,i) => ({...empty(),key:{physicalSubstep:i+1}}))}};
 const text = codec.stringifyPhysicalReceipt(input);
 assert.doesNotMatch(text, /:null/);
 assert.deepEqual(codec.parsePhysicalReceipt(text), input);
 assert.equal(JSON.stringify(codec.encodePhysicalReceiptValue(empty())), canonicalPhysicalCertificateText(empty()));
 assert.equal(await codec.physicalReceiptSha256(input), digest(codec.canonicalPhysicalReceiptText(input)));
});
test('all ten zero-row predicates independently required for infinity', () => {
 for (const key of ['rawOccurrences','allRawOccurrences','validatedOccurrences','complete','unsupported',
  'unsupportedFlags','clearanceDeficits','strictClearanceDeficits','allCurrentRawOccurrencesChecked','actualGpuFiniteProducer']) {
  const value = empty(); value[key] = typeof value[key] === 'boolean' ? false : 1;
  assert.throws(() => codec.stringifyPhysicalReceipt({nested:value}), key);
 }
});
test('numeric and tag counterexamples reject in encoder AND saved decoder', () => {
 const tag = {$physicalClearanceBound:'positive-infinity-no-contact-rows'};
 for (const value of [NaN,-Infinity,Infinity,undefined,new DataView(new ArrayBuffer(4)),new Date(),[,1]])
  assert.throws(() => codec.stringifyPhysicalReceipt({arbitrary:value}));
 for (const value of [NaN,-Infinity,null,tag])
  assert.throws(() => codec.stringifyPhysicalReceipt({...empty(),minimumLowerBoundM:value}));
 assert.throws(() => codec.stringifyPhysicalReceipt({arbitrary:tag}));
 for (const value of [tag,{...tag,extra:true},{$physicalClearanceBound:'wrong'}]) {
  assert.throws(() => codec.decodePhysicalReceiptValue({arbitrary:value}));
  if (value !== tag) assert.throws(() => codec.decodePhysicalReceiptValue({...empty(),minimumLowerBoundM:value}));
 }
 const encoded = codec.encodePhysicalReceiptValue(empty());
 encoded.rawOccurrences = 1;
 assert.throws(() => codec.decodePhysicalReceiptValue(encoded));
});
test('prototype pollution keys preserve inert own data and getters/cycles reject', () => {
 const input = JSON.parse('{"__proto__":{"safe":true},"constructor":4}');
 const output = codec.parsePhysicalReceipt(codec.stringifyPhysicalReceipt(input));
 assert.equal(Object.getPrototypeOf(output), Object.prototype);
 assert.equal(Object.hasOwn(output,'__proto__'),true);
 assert.equal({}.safe,undefined);
 let accessed = false;
 const getter = {get x(){accessed=true;return 1;}};
 assert.throws(() => codec.stringifyPhysicalReceipt(getter));
 assert.equal(accessed,false);
 const cyclic = {}; cyclic.self=cyclic;
 assert.throws(() => codec.stringifyPhysicalReceipt(cyclic));
 const array = [];
 Object.defineProperty(array,'0',{enumerable:true,get(){accessed=true;return 1;}});
 assert.throws(() => codec.stringifyPhysicalReceipt(array));
 assert.equal(accessed,false);
 const taggedArray = []; taggedArray.$physicalClearanceBound='positive-infinity-no-contact-rows';
 assert.throws(() => codec.stringifyPhysicalReceipt(taggedArray));
 const extraArray = []; extraArray.unrelated=Infinity;
 assert.throws(() => codec.stringifyPhysicalReceipt(extraArray));
 const extraTyped = new Float32Array(2); extraTyped.unrelated=Infinity;
 assert.throws(() => codec.stringifyPhysicalReceipt(extraTyped));
 const getterTag = {};
 Object.defineProperty(getterTag,'$physicalClearanceBound',{enumerable:true,get(){accessed=true;return 'positive-infinity-no-contact-rows';}});
 assert.throws(() => codec.decodePhysicalReceiptValue({...empty(),minimumLowerBoundM:getterTag}));
 assert.equal(accessed,false);
});
test('sorted deterministic structural hash and explicit byte boundary', async () => {
 assert.equal(await codec.physicalReceiptSha256({b:1,a:2}), await codec.physicalReceiptSha256({a:2,b:1}));
 assert.notEqual(await codec.physicalReceiptSha256({a:2}), await codec.physicalReceiptSha256({a:3}));
 assert.deepEqual(codec.parsePhysicalReceipt(codec.stringifyPhysicalReceipt({typed:new Float32Array([1,2])})),{typed:[1,2]});
 // Structural JSON deliberately does not replace independently pinned signed-zero bytes.
 assert.equal(codec.stringifyPhysicalReceipt(-0),'0');
});
test('forty-certificate frame seals snapshot, list digest, and independent evidence hashes', async () => {
 const physicalReceipts = Array.from({length:40}, empty);
 const frame = {kind:'actual-source-joint-frame-commit-v1',accepted:true,physicalSubsteps:40,geometrySamples:41,
  all41GuardProofSha256:h,pressureHistorySha256:h,physicalReceipts,
  physicalReceiptsSha256:await codec.physicalReceiptListSha256(physicalReceipts)};
 const expected = await codec.physicalFrameReceiptSha256(frame);
 assert.equal(await codec.physicalFrameReceiptSha256({...frame,frameCommitSha256:h}),expected);
 assert.equal(await codec.physicalFrameReceiptSha256(codec.parsePhysicalReceipt(codec.stringifyPhysicalReceipt(frame))),expected);
 const pending = codec.physicalFrameReceiptSha256(frame);
 frame.physicalReceipts[0].key={mutation:1};
 assert.equal(await pending,expected);
 await assert.rejects(codec.physicalFrameReceiptSha256(frame),/digest mismatch/);
 await assert.rejects(codec.physicalFrameReceiptSha256({...frame,accepted:false}));
 assert.throws(() => codec.canonicalPhysicalReceiptListText(physicalReceipts.slice(1)));
});
