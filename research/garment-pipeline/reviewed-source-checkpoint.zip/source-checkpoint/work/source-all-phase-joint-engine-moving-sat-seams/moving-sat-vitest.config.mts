import {defineConfig} from 'vitest/config';export default defineConfig({test:{environment:'node',include:['moving-sat-worker.test.ts'],testTimeout:60000}});
