Source-only positive body-facet trajectory guard
================================================

NEW copied source epoch based on the frozen frame-canonical108 source. Live files
and its historical freezes are unchanged. Actual joint engine policy enables the
body-facet option at all three Worker construction sites. Native/OFF absence keeps
the prior Worker binding bytes and report shape. collisionGuardExecutionOptions
returns a defensive actual policy snapshot for driver context recomputation.

The exact immutable body and cloth faces feed a persistent static body BVH. Every
one of the forty actual supplied intervals is screened for positive1mm finite
triangle separation. A fixed axis projects ALL endpoint vertices, bounding the
whole linear interval. Midpoints propose axes only; they never authorize safety.
Subdivision budgets are explicit and unresolved cases reject. Existing volume,
parity, endpoint and self-intersection checks all remain required.

The sourceBodyFacetTrajectory report records policy, physicalClearanceM .001,
piecewise-linear interpolation, expectedSubsteps40, inspectedSubsteps, clear,
finite integer candidateBodyPairs/intervalsChecked, and the first unresolved pair
and substep when present. It explicitly reports selfContinuousCertified:false.
No generic infinite minimum is placed in the Worker proof. The portable
requireSourceBodyFacetTrajectoryProof helper requires a complete clear40 result;
actual Worker context/q41 bindings provide execution origin separately.

Evidence: six core controls plus five independent numerical controls; actual
historical final tee static5186faces/8408pairs accepted. Its supplied old13 chord
rejects because the old state's finite edge-edge gap is0.890983mm, below1mm;
final gap is1.004532mm. This chord is not an actual observed40-substep trajectory.
The browser-target core bundle passed independent checks. Source-hook tests
including existing native/default guards:91/91 pass. TypeScript passed.

This source epoch has no actual complete physical pressure device frame, garment
fit, continuous self-facet, or unrecorded within-substep path acceptance. No live
promotion is authorized by these CPU/component results alone.
