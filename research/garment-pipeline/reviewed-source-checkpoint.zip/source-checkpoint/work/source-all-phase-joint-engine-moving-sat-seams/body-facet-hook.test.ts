import {describe,it,expect} from 'vitest';
import {ClothCollisionGuard} from './src/collisionGuard';
import {collisionGuardWorkerBinding} from './src/collisionGuardWorkerProtocol';
import {collisionGuardWorkerBinding as originalBinding} from '../source-all-phase-joint-engine-frame-canonical/src/collisionGuardWorkerProtocol';
import {BODY_FACET_POLICY} from './src/bodyFacetClearance.mjs';
import {createCollisionGuardWorkerHandler} from './src/collisionGuardWorkerRuntime';
import {requireSourceBodyFacetTrajectoryProof} from './src/bodyFacetProof.mjs';
import {CollisionGuardWorker,type CollisionGuardWorkerTransport} from './src/collisionGuardWorker';
import type {CollisionGuardWorkerResponse} from './src/collisionGuardWorkerProtocol';
const input={bodyPositions:[.005,.005,.005,-.005,-.005,.005,-.005,.005,-.005,.005,-.005,-.005],
 bodyIndices:[0,2,1,0,1,3,0,3,2,1,2,3],clothTriangles:[0,1,2,0],particleCount:3};
const positions=(z:number)=>new Float32Array([-1,-1,z,1,1,-1,z,1,0,1,z,1]);
const path=(first:Float32Array,last:Float32Array)=>[first,...Array.from({length:40},()=>last.slice())];
const options={checkSelfIntersections:false,sourceBodyFacetClearancePolicy:BODY_FACET_POLICY};
class ActualHandlerTransport {
 listeners=new Map<string,Set<EventListener>>();
 handler=createCollisionGuardWorkerHandler(response=>{
  if(response.kind==='report')this.mutate?.(response.report);
  for(const listener of this.listeners.get('message')??[])listener({data:response} as unknown as Event);
 });
 constructor(private mutate?:(report:import('./src/collisionGuard').CollisionGuardReport)=>void){}
 postMessage=(request:import('./src/collisionGuardWorkerProtocol').CollisionGuardWorkerRequest)=>{void this.handler(request);};
 addEventListener=(kind:string,listener:EventListener)=>{if(!this.listeners.has(kind))this.listeners.set(kind,new Set());this.listeners.get(kind)!.add(listener);};
 removeEventListener=(kind:string,listener:EventListener)=>{this.listeners.get(kind)?.delete(listener);};
 terminate=()=>{};
}
function actualClient(mutate?:(report:import('./src/collisionGuard').CollisionGuardReport)=>void){
 const transport=new ActualHandlerTransport(mutate);
 return new CollisionGuardWorker(input,options,()=>transport as unknown as CollisionGuardWorkerTransport);
}
describe('NEW actual source body facet trajectory hook',()=>{
 it('rejects a body through face interior even when discrete endpoints/particle sweeps pass',()=>{
  const first=positions(.05),last=positions(-.05),trajectory=path(first,last);
  const ordinary=new ClothCollisionGuard(input,{checkSelfIntersections:false}).inspectTrajectory(last,first,trajectory,40);
  expect(ordinary.safe).toBe(true);expect(ordinary.bodyCrossingTriangleCount).toBe(0);expect(ordinary.sweptBodyCrossingParticleCount).toBe(0);
  const source=new ClothCollisionGuard(input,options).inspectTrajectory(last,first,trajectory,40);
  expect(source.safe).toBe(false);expect(source.sourceBodyFacetTrajectory?.clear).toBe(false);
  expect(source.sourceBodyFacetTrajectory?.firstUnresolvedSubstep).toBe(1);
  expect(source.sourceBodyFacetTrajectory?.inspectedSubsteps).toBe(40);
 });
 it('keeps volume classification alongside surface-distance clearance',()=>{
  const enclosed=new Float32Array([0,0,0,1,.0001,0,0,1,0,.0001,0,1]);
  const result=new ClothCollisionGuard(input,options).inspectTrajectory(enclosed,enclosed,path(enclosed,enclosed),40);
  expect(result.sourceBodyFacetTrajectory?.clear).toBe(true);expect(result.insideParticleCount).toBeGreaterThan(0);expect(result.safe).toBe(false);
 });
 it('certifies all40 supplied intervals and rejects shortened source-policy traces',()=>{
  const first=positions(.05),last=positions(.06),trajectory=path(first,last);
  const guard=new ClothCollisionGuard(input,options),result=guard.inspectTrajectory(last,first,trajectory,40);
  expect(result.safe).toBe(true);expect(result.sourceBodyFacetTrajectory?.inspectedSubsteps).toBe(40);
  expect(result.sourceBodyFacetTrajectory?.physicalClearanceM).toBe(.001);
  expect(requireSourceBodyFacetTrajectoryProof(result).clear).toBe(true);
  for(const changed of [{inspectedSubsteps:39},{clear:false},{physicalClearanceM:.0005},{selfContinuousCertified:true},
    {firstUnresolvedSubstep:1},{intervalsChecked:-1}])
    expect(()=>requireSourceBodyFacetTrajectoryProof({...result,sourceBodyFacetTrajectory:{...result.sourceBodyFacetTrajectory!,...changed} as typeof result.sourceBodyFacetTrajectory})).toThrow();
  expect(()=>requireSourceBodyFacetTrajectoryProof({...result,sourceBodyFacetTrajectory:undefined})).toThrow();
  expect(guard.inspectTrajectory(last,first,[first,last],1).trajectory?.invalidReason).toBe('invalid-substeps');
 });
 it('absent policy keeps native Worker bytes and report shape unchanged',async()=>{
  expect(await collisionGuardWorkerBinding(input,{})).toBe(await originalBinding(input,{}));
  expect(await collisionGuardWorkerBinding(input,options)).not.toBe(await collisionGuardWorkerBinding(input,{checkSelfIntersections:false}));
  const q=positions(.05),ordinary=new ClothCollisionGuard(input).inspectTrajectory(q,q,[q,q],1);
  expect(Object.hasOwn(ordinary,'sourceBodyFacetTrajectory')).toBe(false);
  expect(()=>new ClothCollisionGuard(input,{sourceBodyFacetClearancePolicy:'unknown' as typeof BODY_FACET_POLICY})).toThrow();
 });
 it('actual Worker handler carries complete source-policy proof and rejects foreign policy binding',async()=>{
  const received:CollisionGuardWorkerResponse[]=[],handler=createCollisionGuardWorkerHandler(x=>received.push(x));
  const binding=await collisionGuardWorkerBinding(input,options),first=positions(.05),last=positions(-.05);
  await handler({kind:'init',token:'source',binding,requestId:0,input,options});
  expect(received[0].kind).toBe('ready');
  await handler({kind:'trajectory',token:'source',binding,requestId:1,final:last,previous:first,trajectory:path(first,last),expectedSubSteps:40});
  const report=received[1];expect(report.kind).toBe('report');
  if(report.kind==='report'){expect(report.report.safe).toBe(false);expect(report.report.sourceBodyFacetTrajectory?.inspectedSubsteps).toBe(40);}
  await handler({kind:'trajectory',token:'source',binding:await collisionGuardWorkerBinding(input,{}),requestId:2,final:last,previous:first,trajectory:path(first,last),expectedSubSteps:40});
  expect(received[2].kind).toBe('error');
 });
 it('actual client preserves genuine body-facet-only negative report and all40 proof',async()=>{
  const client=actualClient(),first=positions(.05),last=positions(-.05);
  try{const report=await client.inspectTrajectory(last,first,path(first,last),40);
   expect(report.safe).toBe(false);expect(report.bodyCrossingTriangleCount).toBe(0);
   expect(report.sourceBodyFacetTrajectory?.clear).toBe(false);expect(report.sourceBodyFacetTrajectory?.inspectedSubsteps).toBe(40);
  }finally{client.dispose();}
 });
 it('actual client accepts clear source proof and rejects deleted or forged proof fields',async()=>{
  const first=positions(.05),last=positions(.06),valid=actualClient();
  try{expect((await valid.inspectTrajectory(last,first,path(first,last),40)).safe).toBe(true);}finally{valid.dispose();}
  for(const mutate of [
   (r:import('./src/collisionGuard').CollisionGuardReport)=>{delete r.sourceBodyFacetTrajectory;},
   (r:import('./src/collisionGuard').CollisionGuardReport)=>{r.sourceBodyFacetTrajectory!.inspectedSubsteps=39;},
   (r:import('./src/collisionGuard').CollisionGuardReport)=>{r.sourceBodyFacetTrajectory!.physicalClearanceM=.0005 as .001;}
  ]){const client=actualClient(mutate);try{await expect(client.inspectTrajectory(last,first,path(first,last),40)).rejects.toThrow('invalid proof response');}finally{client.dispose();}}
 });
 it('actual client rejects malformed unresolved body IDs, intervals and clear/safe contradiction',async()=>{
  const first=positions(.05),last=positions(-.05);
  for(const mutate of [
   (r:import('./src/collisionGuard').CollisionGuardReport)=>{r.sourceBodyFacetTrajectory!.firstUnresolvedPair!.bodyFace=4;},
   (r:import('./src/collisionGuard').CollisionGuardReport)=>{r.sourceBodyFacetTrajectory!.firstUnresolvedPair!.interval=[.5,.4];},
   (r:import('./src/collisionGuard').CollisionGuardReport)=>{r.safe=true;}
  ]){const client=actualClient(mutate);try{await expect(client.inspectTrajectory(last,first,path(first,last),40)).rejects.toThrow('invalid proof response');}finally{client.dispose();}}
 });
});
