// Exact dyadic arithmetic over supplied IEEE coordinates. CPU proof only.
// No physical vertex welding, force/mobility change, or caller authorization.
export const MOVING_INDEXED_POINT_PLANE_POLICY='source-shared-indexed-point-moving-plane-bernstein-v1';
const owners=new WeakMap();
const u32=v=>Number.isSafeInteger(v)&&v>=0&&v<=0xffffffff;
const bits=new DataView(new ArrayBuffer(8));
function dyadic(x){
 if(!Number.isFinite(x))throw Error('Nonfinite exact coordinate');
 if(x===0)return{n:0n,e:0};bits.setFloat64(0,x,false);const b=bits.getBigUint64(0,false),ex=Number(b>>52n&2047n),f=b&((1n<<52n)-1n);
 return{n:(b>>63n?-1n:1n)*(ex?f+(1n<<52n):f),e:(ex?ex-1023:-1022)-52};
}
function copyArray(a,n,check){
 if(!Array.isArray(a)||a.length!==n)throw Error('Invalid proof array');
 return Array.from({length:n},(_,i)=>{const d=Object.getOwnPropertyDescriptor(a,String(i));if(!d||!('value'in d)||!check(d.value))throw Error('Invalid proof value/accessor');return d.value;});
}
function triangle(a){return copyArray(a,3,Array.isArray).map(p=>copyArray(p,3,v=>typeof v==='number'&&Number.isFinite(v)&&Math.abs(v)<=32));}
function edge(e){const c=copyArray(e,2,v=>Number.isInteger(v)&&v>=0&&v<3);if(c[0]===c[1])throw Error('Distinct edge corners required');return c;}
const add=(a,b)=>Array.from({length:Math.max(a.length,b.length)},(_,k)=>(a[k]??0n)+(b[k]??0n));
const neg=a=>a.map(x=>-x),sub=(a,b)=>add(a,neg(b));
function mul(a,b){const c=Array(a.length+b.length-1).fill(0n);for(let i=0;i<a.length;i++)for(let j=0;j<b.length;j++)c[i+j]+=a[i]*b[j];return c;}
const vsub=(a,b)=>a.map((p,k)=>sub(p,b[k]));
const cross=(a,b)=>[sub(mul(a[1],b[2]),mul(a[2],b[1])),sub(mul(a[2],b[0]),mul(a[0],b[2])),sub(mul(a[0],b[1]),mul(a[1],b[0]))];
const dot=(a,b)=>a.reduce((p,q,k)=>add(p,mul(q,b[k])),[0n]);
const same=(a,b)=>a.every((x,k)=>x===b[k]);
// Positive common denominator is omitted: only integer signs are evidence.
function bernstein(p,degree){
 const c=Array.from({length:degree+1},(_,i)=>p[i]??0n);
 if(p.slice(degree+1).some(x=>x!==0n))throw Error('Unexpected polynomial degree');
 if(degree===2)return[2n*c[0],2n*c[0]+c[1],2n*(c[0]+c[1]+c[2])];
 if(degree===3)return[3n*c[0],3n*c[0]+c[1],3n*c[0]+2n*c[1]+c[2],3n*(c[0]+c[1]+c[2]+c[3])];
 throw Error('Unsupported proof degree');
}
const describe=p=>p.map(String);
function chart(n){for(let axis=0;axis<3;axis++){const b=bernstein(n[axis],2);if(b.every(v=>v>0n)||b.every(v=>v<0n))return{axis,bernsteinIntegerNumerators:describe(b)};}return null;}
function makeLattice(tris){
 const d=tris.flat(2).map(dyadic),nonzero=d.filter(v=>v.n!==0n),exponent=nonzero.length?Math.min(...nonzero.map(v=>v.e)):0;
 let at=0;const values=tris.map(tri=>tri.map(p=>p.map(()=>{const v=d[at++];return v.n===0n?0n:v.n<<BigInt(v.e-exponent);})));return{exponent,values};
}
/** Geometric support theorem only. Genuine physical-index authorization is
 * supplied by the private actual topology wrapper, never by near coincidence. */
export function certifyMovingIndexedPointTriangles(input){
 const first=triangle(input.first),last=triangle(input.last),targetFirst=triangle(input.targetFirst),targetLast=triangle(input.targetLast),ai=input.sharedCorner,bi=input.targetSharedCorner;
 if(!Number.isInteger(ai)||ai<0||ai>2||!Number.isInteger(bi)||bi<0||bi>2)throw Error('Invalid shared corners');
 if(!same(first[ai],targetFirst[bi])||!same(last[ai],targetLast[bi]))return{clear:false,policy:MOVING_INDEXED_POINT_PLANE_POLICY,reason:'whole-common-point-path-unproved'};
 const {exponent,values:[af,al,bf,bl]}=makeLattice([first,last,targetFirst,targetLast]);
 const path=(f,l)=>f.map((p,i)=>p.map((v,k)=>[v,l[i][k]-v]));const A=path(af,al),B=path(bf,bl),normal=t=>cross(vsub(t[1],t[0]),vsub(t[2],t[0]));
 const na=normal(A),nb=normal(B),ca=chart(na),cb=chart(nb);if(!ca||!cb)return{clear:false,policy:MOVING_INDEXED_POINT_PLANE_POLICY,reason:'whole-interval-triangle-chart-unproved'};
 for(const[plane,other,common,otherCommon,n,label]of[[A,B,ai,bi,na,'A'],[B,A,bi,ai,nb,'B']]){
  const commonPoly=dot(n,vsub(other[otherCommon],plane[common]));if(commonPoly.some(v=>v!==0n))throw Error('Common indexed path algebra mismatch');
  const evidence=[0,1,2].filter(i=>i!==otherCommon).map(i=>({corner:i,bernstein:bernstein(dot(n,vsub(other[i],plane[common])),3)}));
  const orientation=evidence.every(x=>x.bernstein.every(v=>v>0n))?1n:evidence.every(x=>x.bernstein.every(v=>v<0n))?-1n:0n;if(!orientation)continue;
  return{clear:true,policy:MOVING_INDEXED_POINT_PLANE_POLICY,coordinateLatticeExponent:exponent,nondegenerateCharts:{A:ca,B:cb},planeTriangle:label,commonCorner:common,otherCommonCorner:otherCommon,wholeCommonPointPathCoincident:true,strictOtherVerticesWholeInterval:true,otherVertices:evidence.map(x=>({corner:x.corner,bernsteinIntegerNumerators:describe(x.bernstein.map(v=>orientation*v))})),completeFiniteIntersectionContainedIn:'actual-common-physical-indexed-point',sourceAuthorizationSupplied:false,positiveSelfThicknessCertified:false};
 }
 return{clear:false,policy:MOVING_INDEXED_POINT_PLANE_POLICY,reason:'moving-indexed-point-plane-support-unproved'};
}
function integerArray(a){if(!(Array.isArray(a)||a instanceof Uint32Array))throw Error('Integer source array required');const v=Array.from(a);if(v.some(x=>!u32(x)))throw Error('Invalid source integer');return v;}
/** Existing genuine guard initialization must authenticate these actual faces
 * and physical IDs through its Worker context. A private capture is not a signature. */
export function createMovingIndexedPointOwner({particleCount,clothTriangles,clothTriangleStride=4}){
 if(!u32(particleCount)||particleCount<3||![3,4].includes(clothTriangleStride))throw Error('Invalid actual indexed owner');const raw=integerArray(clothTriangles);if(raw.length%clothTriangleStride)throw Error('Invalid physical faces');const faces=[];
 for(let at=0;at<raw.length;at+=clothTriangleStride){const f=raw.slice(at,at+3);if(new Set(f).size!==3||f.some(i=>i>=particleCount))throw Error('Invalid actual physical face');faces.push(f);}
 const owner=Object.freeze({policy:MOVING_INDEXED_POINT_PLANE_POLICY});owners.set(owner,{particleCount,faces});return owner;
}
export function certifyMovingIndexedPointPair({owner,clothFace,otherClothFace,firstPositions,lastPositions}){
 const source=owners.get(owner);if(!source)return{clear:false,policy:MOVING_INDEXED_POINT_PLANE_POLICY,reason:'unbound-actual-indexed-owner'};
 if(!u32(clothFace)||!u32(otherClothFace)||clothFace===otherClothFace||clothFace>=source.faces.length||otherClothFace>=source.faces.length)throw Error('Invalid owned physical face IDs');
 if(!(firstPositions instanceof Float32Array)||!(lastPositions instanceof Float32Array)||firstPositions.length!==source.particleCount*4||lastPositions.length!==firstPositions.length)throw Error('Invalid actual indexed samples');
 const ids=source.faces[clothFace],targetIds=source.faces[otherClothFace],shared=ids.filter(id=>targetIds.includes(id));if(shared.length!==1)return{clear:false,policy:MOVING_INDEXED_POINT_PLANE_POLICY,reason:'requires-one-genuine-shared-physical-index'};
 const read=(p,id)=>{const v=[p[id*4],p[id*4+1],p[id*4+2]];if(v.some(x=>!Number.isFinite(x)||Math.abs(x)>32)||!Number.isFinite(p[id*4+3])||p[id*4+3]<0)throw Error('Invalid actual indexed coordinate/mobility');return v;};
 for(const id of new Set([...ids,...targetIds]))if(!Object.is(firstPositions[id*4+3],lastPositions[id*4+3]))throw Error('Actual particle mobility changed');
 const proof=certifyMovingIndexedPointTriangles({first:ids.map(i=>read(firstPositions,i)),last:ids.map(i=>read(lastPositions,i)),targetFirst:targetIds.map(i=>read(firstPositions,i)),targetLast:targetIds.map(i=>read(lastPositions,i)),sharedCorner:ids.indexOf(shared[0]),targetSharedCorner:targetIds.indexOf(shared[0])});
 if(!proof.clear)return proof;
 return{clear:true,policy:MOVING_INDEXED_POINT_PLANE_POLICY,clothFace,otherClothFace,originalPhysicalFaces:[ids.slice(),targetIds.slice()],sharedPhysicalIndex:shared[0],originalPhysicalSharedIndexAuthenticated:true,geometry:proof,particleIdentityChanged:false,positiveSelfThicknessCertified:false};
}
