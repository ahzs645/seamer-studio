// Exact dyadic arithmetic over supplied IEEE coordinates. CPU proof only.
// No physical vertex welding, force/mobility change, or caller authorization.
export const MOVING_SEAM_SAT_POLICY='source-original-used-seam-moving-sat-bernstein-v1';
const owners=new WeakMap();
const u32=v=>Number.isSafeInteger(v)&&v>=0&&v<=0xffffffff;
const bits=new DataView(new ArrayBuffer(8));
function dyadic(x){
 if(!Number.isFinite(x))throw Error('Nonfinite exact coordinate');
 if(x===0)return{n:0n,e:0};bits.setFloat64(0,x,false);const b=bits.getBigUint64(0,false),ex=Number(b>>52n&2047n),f=b&((1n<<52n)-1n);
 return{n:(b>>63n?-1n:1n)*(ex?f+(1n<<52n):f),e:(ex?ex-1023:-1022)-52};
}
function copyArray(a,n,check){
 if(!Array.isArray(a)||a.length!==n)throw Error('Invalid proof array');
 return Array.from({length:n},(_,i)=>{const d=Object.getOwnPropertyDescriptor(a,String(i));if(!d||!('value'in d)||!check(d.value))throw Error('Invalid proof value/accessor');return d.value;});
}
function triangle(a){return copyArray(a,3,Array.isArray).map(p=>copyArray(p,3,v=>typeof v==='number'&&Number.isFinite(v)&&Math.abs(v)<=32));}
function edge(e){const c=copyArray(e,2,v=>Number.isInteger(v)&&v>=0&&v<3);if(c[0]===c[1])throw Error('Distinct edge corners required');return c;}
const add=(a,b)=>Array.from({length:Math.max(a.length,b.length)},(_,k)=>(a[k]??0n)+(b[k]??0n));
const neg=a=>a.map(x=>-x),sub=(a,b)=>add(a,neg(b));
function mul(a,b){const c=Array(a.length+b.length-1).fill(0n);for(let i=0;i<a.length;i++)for(let j=0;j<b.length;j++)c[i+j]+=a[i]*b[j];return c;}
const vsub=(a,b)=>a.map((p,k)=>sub(p,b[k]));
const cross=(a,b)=>[sub(mul(a[1],b[2]),mul(a[2],b[1])),sub(mul(a[2],b[0]),mul(a[0],b[2])),sub(mul(a[0],b[1]),mul(a[1],b[0]))];
const dot=(a,b)=>a.reduce((p,q,k)=>add(p,mul(q,b[k])),[0n]);
const same=(a,b)=>a.every((x,k)=>x===b[k]);
// Positive common denominator is omitted: only integer signs are evidence.
function bernstein(p,degree){
 const c=Array.from({length:degree+1},(_,i)=>p[i]??0n);
 if(p.slice(degree+1).some(x=>x!==0n))throw Error('Unexpected polynomial degree');
 if(degree===2)return[2n*c[0],2n*c[0]+c[1],2n*(c[0]+c[1]+c[2])];
 if(degree===3)return[3n*c[0],3n*c[0]+c[1],3n*c[0]+2n*c[1]+c[2],3n*(c[0]+c[1]+c[2]+c[3])];
 throw Error('Unsupported proof degree');
}
const describe=p=>p.map(String);
function chart(n){for(let axis=0;axis<3;axis++){const b=bernstein(n[axis],2);if(b.every(v=>v>0n)||b.every(v=>v<0n))return{axis,bernsteinIntegerNumerators:describe(b)};}return null;}
function makeLattice(tris){
 const d=tris.flat(2).map(dyadic),nonzero=d.filter(v=>v.n!==0n),exponent=nonzero.length?Math.min(...nonzero.map(v=>v.e)):0;
 let at=0;const values=tris.map(tri=>tri.map(p=>p.map(()=>{const v=d[at++];return v.n===0n?0n:v.n<<BigInt(v.e-exponent);})));return{exponent,values};
}
/** Strict finite separation on every interior time. Endpoint contact may only
 * be the exact corresponding declared paired edges. This is geometric proof,
 * not source authorization, physical welding or positive-thickness proof. */
function trimPolynomial(p){while(p.length>1&&p.at(-1)===0n)p=p.slice(0,-1);return p;}
function divideOneMinusT(p){
 p=trimPolynomial(p);if(p.reduce((s,v)=>s+v,0n)!==0n)throw Error('Inexact endpoint-factor division');
 if(p.every(v=>v===0n))return[0n];if(p.length<2)throw Error('Invalid endpoint factor');
 const q=[];let carry=0n;for(let i=0;i<p.length-1;i++){carry+=p[i];q.push(carry);}
 if(p.at(-1)!==-q.at(-1)||!same(trimPolynomial(mul(q,[1n,-1n])),p))throw Error('Endpoint-factor identity failure');return trimPolynomial(q);
}
export function certifyMovingSeamEdgeSATTriangles(input){
 const first=triangle(input.first),last=triangle(input.last),targetFirst=triangle(input.targetFirst),targetLast=triangle(input.targetLast),seamEdge=edge(input.seamEdge),targetSeamEdge=edge(input.targetSeamEdge);
 const {exponent,values:[af,al,bf,bl]}=makeLattice([first,last,targetFirst,targetLast]);
 const path=(f,l)=>f.map((p,i)=>p.map((v,k)=>[v,l[i][k]-v]));const A=path(af,al),B=path(bf,bl),normal=t=>cross(vsub(t[1],t[0]),vsub(t[2],t[0]));
 const ca=chart(normal(A)),cb=chart(normal(B));if(!ca||!cb)return{clear:false,policy:MOVING_SEAM_SAT_POLICY,reason:'whole-interval-triangle-chart-unproved'};
 for(let ae=0;ae<3;ae++)for(let be=0;be<3;be++){
  let axis=cross(vsub(A[(ae+1)%3],A[ae]),vsub(B[(be+1)%3],B[be])).map(trimPolynomial);
  if(axis.every(p=>p.every(v=>v===0n)))continue;
  let removed=0;while(axis.every(p=>p.reduce((s,v)=>s+v,0n)===0n)){
   if(removed>=2)throw Error('Unexpected endpoint-factor multiplicity');axis=axis.map(divideOneMinusT);removed++;
  }
  const ac=chart(axis);if(!ac)continue;
  const projections=[];for(let i=0;i<3;i++)for(let j=0;j<3;j++)projections.push({firstCorner:i,otherCorner:j,power:dot(axis,vsub(B[j],A[i]))});
  const bs=projections.map(x=>bernstein(x.power,3));
  const orientation=bs.every(b=>b.every(v=>v>=0n)&&b.some(v=>v>0n))?1n:bs.every(b=>b.every(v=>v<=0n)&&b.some(v=>v<0n))?-1n:0n;
  if(!orientation)continue;const positive=bs.map(b=>b.map(v=>v*orientation));let valid=true;const endpoints=[];
  for(const[end,index,F,G]of[[0,0,first,targetFirst],[1,3,last,targetLast]]){
   const zeros=positive.map((b,i)=>b[index]===0n?projections[i]:null).filter(Boolean);
   if(!zeros.length){endpoints.push({time:end,strictlySeparated:true});continue;}
   if(zeros.some(x=>!seamEdge.includes(x.firstCorner)||!targetSeamEdge.includes(x.otherCorner))||seamEdge.some((corner,k)=>!same(F[corner],G[targetSeamEdge[k]]))){valid=false;break;}
   endpoints.push({time:end,strictlySeparated:false,correspondingPairedKnotsCoincident:true,possibleContactFirstCorners:[...new Set(zeros.map(x=>x.firstCorner))],possibleContactOtherCorners:[...new Set(zeros.map(x=>x.otherCorner))]});
  }
  if(!valid)continue;
  return{clear:true,policy:MOVING_SEAM_SAT_POLICY,coordinateLatticeExponent:exponent,nondegenerateCharts:{A:ca,B:cb,axis:ac},edgeAxis:{firstEdge:[ae,(ae+1)%3],otherEdge:[be,(be+1)%3],powerIntegerCoefficients:axis.map(describe),removedOneMinusTFactors:removed,exactPositiveInteriorFactorRemoval:true},strictInteriorSeparationCertified:true,completeFiniteIntersectionContainedIn:'corresponding-declared-paired-edge-at-time-endpoints-only',projectionDifferences:projections.map((x,i)=>({firstCorner:x.firstCorner,otherCorner:x.otherCorner,bernsteinIntegerNumerators:describe(positive[i])})),endpointEvidence:endpoints,positiveSelfThicknessCertified:false,sourceAuthorizationSupplied:false};
 }
 return{clear:false,policy:MOVING_SEAM_SAT_POLICY,reason:'strict-moving-sat-separation-unproved'};
}
function integerArray(a){if(!(Array.isArray(a)||a instanceof Uint32Array))throw Error('Integer source array required');const v=Array.from(a);if(v.some(x=>!u32(x)))throw Error('Invalid source integer');return v;}
/** Called by the existing trusted source guard using its actual init topology.
 * The opaque private capture prevents caller labels/callbacks from authorizing
 * an unresolved pair. It does not replace the Worker's source byte binding. */
export function createMovingOriginalSeamSATOwner({particleCount,clothTriangles,clothTriangleStride=4,seamPairsBySeam,stitchCount}){
 if(!u32(particleCount)||particleCount<3||![3,4].includes(clothTriangleStride)||!u32(stitchCount)||!Array.isArray(seamPairsBySeam))throw Error('Invalid original source owner');
 const raw=integerArray(clothTriangles);if(raw.length%clothTriangleStride)throw Error('Invalid original faces');const faces=[];
 for(let at=0;at<raw.length;at+=clothTriangleStride){const f=raw.slice(at,at+3);if(new Set(f).size!==3||f.some(i=>i>=particleCount))throw Error('Invalid original physical face');faces.push(f);}
 const names=new Set();const groups=seamPairsBySeam.map((g,index)=>{
  if(!g||g.index!==index||typeof g.seamId!=='string'||!g.seamId||names.has(g.seamId))throw Error('Invalid original seam group');names.add(g.seamId);
  const pairs=integerArray(g.pairs),stamps=integerArray(g.stitchIndices),kinds=Array.from(g.stitchIndexKinds??[]);
  if(pairs.length%2||stamps.length!==pairs.length/2||kinds.length!==stamps.length||pairs.some(i=>i>=particleCount)||stamps.some(v=>v>=stitchCount)||kinds.some((v,i)=>v!==(pairs[2*i]===pairs[2*i+1]?'identity-logical':'reciprocal-first-stamp')))throw Error('Invalid original seam provenance');
  return{index,seamId:g.seamId,pairs,stamps,kinds};
 });const token=Object.freeze({policy:MOVING_SEAM_SAT_POLICY});owners.set(token,{particleCount,faces,groups,stitchCount});return token;
}
function exactGapBound(first,last,targetFirst,targetLast,ae,be){
 const {exponent,values:[af,al,bf,bl]}=makeLattice([first,last,targetFirst,targetLast]);const bound=dyadic(.003);let max=0n;
 for(const[a,b]of[[af,bf],[al,bl]])for(let k=0;k<2;k++){const d=a[ae[k]].map((v,j)=>v-b[be[k]][j]),sq=d.reduce((s,v)=>s+v*v,0n);if(sq>max)max=sq;}
 const lhsExponent=2*exponent,rhsExponent=2*bound.e,min=Math.min(lhsExponent,rhsExponent);return{clear:(max<<BigInt(lhsExponent-min))<=((bound.n*bound.n)<<BigInt(rhsExponent-min)),maximumGapSquaredInteger:String(max),coordinateLatticeExponent:exponent,physicalGapBoundM:.003,physicalBothSideDistanceBoundM:.003,existingClassifierDistanceM:.005};
}
/** Actual full-particle arrays + privately owned face IDs, actual original
 * adjacent reciprocal stamps and USED mask. No particle identity is changed. */
export function certifyMovingOriginalSeamSATPair({owner,clothFace,otherClothFace,firstPositions,lastPositions,activation}){
 const source=owners.get(owner);if(!source)return{clear:false,policy:MOVING_SEAM_SAT_POLICY,reason:'unbound-source-owner'};
 if(!u32(clothFace)||!u32(otherClothFace)||clothFace===otherClothFace||clothFace>=source.faces.length||otherClothFace>=source.faces.length)throw Error('Invalid owned face IDs');
 if(!(firstPositions instanceof Float32Array)||!(lastPositions instanceof Float32Array)||firstPositions.length!==source.particleCount*4||lastPositions.length!==firstPositions.length)throw Error('Invalid authentic source samples');
 const ids=source.faces[clothFace],targetIds=source.faces[otherClothFace];
 const read=(p,id)=>{const v=[p[id*4],p[id*4+1],p[id*4+2]];if(v.some(x=>!Number.isFinite(x)||Math.abs(x)>32)||!Number.isFinite(p[id*4+3])||p[id*4+3]<0)throw Error('Invalid actual particle coordinate/mobility');return v;};
 for(const id of new Set([...ids,...targetIds]))if(!Object.is(firstPositions[id*4+3],lastPositions[id*4+3]))throw Error('Actual particle mobility changed');
 const first=ids.map(id=>read(firstPositions,id)),last=ids.map(id=>read(lastPositions,id)),targetFirst=targetIds.map(id=>read(firstPositions,id)),targetLast=targetIds.map(id=>read(lastPositions,id));
 if(!activation||!u32(activation.revision)||!u32(activation.sewnUpTo)||activation.sewnUpTo>source.stitchCount)throw Error('Invalid actual USED epoch');const active=integerArray(activation.activeSeams);if(active.length!==source.groups.length||active.some(v=>v!==0&&v!==1))throw Error('Invalid actual USED mask');
 for(const g of source.groups){if(active[g.index]!==1)continue;for(let k=0;k+1<g.stamps.length;k++){
  if(g.kinds[k]!=='reciprocal-first-stamp'||g.kinds[k+1]!=='reciprocal-first-stamp'||g.stamps[k]>=activation.sewnUpTo||g.stamps[k+1]>=activation.sewnUpTo)continue;
  for(const side of[0,1]){const ai=[g.pairs[2*k+side],g.pairs[2*(k+1)+side]],bi=[g.pairs[2*k+1-side],g.pairs[2*(k+1)+1-side]],seamEdge=ai.map(id=>ids.indexOf(id)),targetSeamEdge=bi.map(id=>targetIds.indexOf(id));if(seamEdge.some(i=>i<0)||targetSeamEdge.some(i=>i<0))continue;
   const gap=exactGapBound(first,last,targetFirst,targetLast,seamEdge,targetSeamEdge);if(!gap.clear)continue;
   const proof=certifyMovingSeamEdgeSATTriangles({first,last,targetFirst,targetLast,seamEdge,targetSeamEdge});if(proof.clear)return{clear:true,policy:MOVING_SEAM_SAT_POLICY,clothFace,otherClothFace,originalPhysicalFaces:[ids.slice(),targetIds.slice()],group:g.index,seamId:g.seamId,segment:k,physicalStitchIndices:[g.stamps[k],g.stamps[k+1]],actualUsedActivation:{revision:activation.revision,sewnUpTo:activation.sewnUpTo,activeSeams:active.slice()},originalUsedStitchOriginAuthenticated:true,originalAdjacentUsedStitchOriginAuthenticated:true,completePairedTube:gap,geometry:proof,particleIdentityChanged:false,positiveSelfThicknessCertified:false};
  }
 }}return{clear:false,policy:MOVING_SEAM_SAT_POLICY,reason:'no-supported-actual-original-used-edge'};
}
