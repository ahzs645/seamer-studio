export const MOVING_INDEXED_POINT_PLANE_POLICY:'source-shared-indexed-point-moving-plane-bernstein-v1';
export interface MovingIndexedPointResult {clear:boolean;policy:typeof MOVING_INDEXED_POINT_PLANE_POLICY;reason?:string;[key:string]:unknown}
export function certifyMovingIndexedPointTriangles(input:{first:number[][];last:number[][];targetFirst:number[][];targetLast:number[][];sharedCorner:number;targetSharedCorner:number}):MovingIndexedPointResult;
export function createMovingIndexedPointOwner(input:{particleCount:number;clothTriangles:number[]|Uint32Array;clothTriangleStride?:number}):Readonly<object>;
export function certifyMovingIndexedPointPair(input:{owner:object;clothFace:number;otherClothFace:number;firstPositions:Float32Array;lastPositions:Float32Array}):MovingIndexedPointResult;
