export const MOVING_SEAM_SAT_POLICY:'source-original-used-seam-moving-sat-bernstein-v1';
export interface MovingSeamSATResult { clear:boolean; policy:typeof MOVING_SEAM_SAT_POLICY; reason?:string; [key:string]:unknown }
export function certifyMovingSeamEdgeSATTriangles(input:{first:number[][];last:number[][];targetFirst:number[][];targetLast:number[][];seamEdge:number[];targetSeamEdge:number[]}):MovingSeamSATResult;
export function createMovingOriginalSeamSATOwner(input:{particleCount:number;clothTriangles:number[]|Uint32Array;clothTriangleStride?:number;seamPairsBySeam:unknown[];stitchCount:number}):Readonly<object>;
export function certifyMovingOriginalSeamSATPair(input:{owner:object;clothFace:number;otherClothFace:number;firstPositions:Float32Array;lastPositions:Float32Array;activation:{revision:number;sewnUpTo:number;activeSeams:number[]|Uint32Array}}):MovingSeamSATResult;
