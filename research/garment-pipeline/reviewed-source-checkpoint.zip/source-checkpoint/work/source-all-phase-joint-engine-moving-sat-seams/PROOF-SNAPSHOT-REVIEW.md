NEW copied synchronous proof snapshot hardening. Held ded2 and bb71 epochs preserved. No live edits or graphics.

Bridge and concrete backend acceptFrame now structuredClone the independent guard report at public method entry before scheduling tracked work or awaiting a provider. Both exact USED activation checks and the backend all41 proof hash consume that captured report. A caller cannot alter gate, inspected counts or nested diagnostic fields during the queued microtask/delayed acceptance window. Failed structured clone returns a rejected promise without submitting acceptance.

Two actual transpiled/real MJS asynchronous owner controls mutate the original report before the first tracked microtask and during a delayed provider accept. Both retain the entry report/hash. All 60 CPU controls and strict TypeScript pass. Synthetic pressure validation fixtures are not device receipts.

This is a review snapshot, not an execution epoch. Existing backend pin1 is known unsuccessful, later whole finite backend/global freshness is still pending, and authoritative full-body anchor/reacted friction/refined support remains unavailable. Current compatibility stays assembly5/body5; validated SI/joint/friction promotion requires a deliberate checkpoint semantic bump and genuine material/friction policy SHA/fresh reassembly. Native/off unchanged.
